-- Philosopher's Codex: settings panel for Options > AddOns.
-- Mainline Settings API with a guarded InterfaceOptions fallback.
-- Every FontString inherits a GameFont* template before SetText.

local PC = PhilosophersCodex

local GOLD = { r = 0.831, g = 0.686, b = 0.216 }
local EMERALD = { r = 0.247, g = 0.749, b = 0.498 }
local TEXT = { r = 0.95, g = 0.95, b = 0.97 }
local SUB = { r = 0.56, g = 0.56, b = 0.60 }
local SURFACE = { r = 0.09, g = 0.09, b = 0.10 }

local panel
local widgets = {}
local registered = false
local refreshing = false

local function Label(parent, text, inherit, size)
  local fs = parent:CreateFontString(nil, "ARTWORK", inherit or "GameFontHighlight")
  if fs.SetFontObject then
    pcall(fs.SetFontObject, fs, _G[inherit or "GameFontHighlight"] or GameFontHighlight)
  end
  fs:SetText(text or "")
  if fs.SetTextColor then
    fs:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
  end
  return fs
end

local function Header(parent, text)
  local fs = Label(parent, text, "GameFontNormalLarge", 16)
  if fs.SetTextColor then
    fs:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
  end
  return fs
end

-- The mock (and some templates) may leave a missing .Text as a dummy
-- function via __index. Only reuse an existing FontString region.
local function EnsureFontString(frame, key, inherit, point)
  local cur = rawget(frame, key)
  if type(cur) == "table" and cur.SetText then
    if cur.SetFontObject then
      pcall(cur.SetFontObject, cur, _G[inherit or "GameFontHighlight"] or GameFontHighlight)
    end
    return cur
  end
  local fs = frame:CreateFontString(nil, "ARTWORK", inherit or "GameFontHighlight")
  if fs.SetFontObject then
    pcall(fs.SetFontObject, fs, _G[inherit or "GameFontHighlight"] or GameFontHighlight)
  end
  if point then
    fs:SetPoint(unpack(point))
  end
  frame[key] = fs
  return fs
end

-- Checkboxes stay a fixed 22x22 box. Forever's UICheckButtonTemplate
-- anchors the checked texture with SetAllPoints, so widening the button
-- to include the label stretches the X into a line across the panel.
local CHECK_SIZE = 22

local function PinCheckTexture(tex, owner)
  if type(tex) ~= "table" then
    return
  end
  if tex.ClearAllPoints then
    tex:ClearAllPoints()
  end
  if tex.SetSize then
    tex:SetSize(CHECK_SIZE, CHECK_SIZE)
  else
    if tex.SetWidth then tex:SetWidth(CHECK_SIZE) end
    if tex.SetHeight then tex:SetHeight(CHECK_SIZE) end
  end
  if tex.SetPoint then
    tex:SetPoint("CENTER", owner, "CENTER", 0, 0)
  end
end

local function PinAllCheckTextures(cb)
  local getters = {
    "GetCheckedTexture", "GetDisabledCheckedTexture",
    "GetNormalTexture", "GetPushedTexture",
    "GetHighlightTexture", "GetDisabledTexture",
  }
  for i = 1, #getters do
    local getter = cb[getters[i]]
    if type(getter) == "function" then
      local ok, tex = pcall(getter, cb)
      if ok then
        PinCheckTexture(tex, cb)
      end
    end
  end
  local keys = {
    "checkedTexture", "CheckedTexture", "disabledCheckedTexture",
    "DisabledCheckedTexture", "normalTexture", "NormalTexture",
    "pushedTexture", "PushedTexture",
  }
  for i = 1, #keys do
    PinCheckTexture(rawget(cb, keys[i]), cb)
  end
end

local function MakeCheck(parent, name, label, onChange)
  local cb = CreateFrame("CheckButton", name, parent, "UICheckButtonTemplate")
  if not cb then
    cb = CreateFrame("CheckButton", name, parent)
  end
  if cb.SetSize then
    cb:SetSize(CHECK_SIZE, CHECK_SIZE)
  else
    if cb.SetWidth then cb:SetWidth(CHECK_SIZE) end
    if cb.SetHeight then cb:SetHeight(CHECK_SIZE) end
  end
  PinAllCheckTextures(cb)
  if (not cb.GetCheckedTexture or not cb:GetCheckedTexture()) then
    local tick = cb:CreateTexture(nil, "OVERLAY")
    if tick.SetTexture then
      tick:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
    end
    PinCheckTexture(tick, cb)
    if cb.SetCheckedTexture then
      cb:SetCheckedTexture(tick)
    end
    cb.checkedTexture = tick
  end
  -- Label is a FontString to the right of the box, not part of the button size.
  local text = EnsureFontString(cb, "Text", "GameFontHighlight", { "LEFT", cb, "RIGHT", 6, 0 })
  text:SetText(label)
  if text.SetTextColor then
    text:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
  end
  if text.SetJustifyH then
    text:SetJustifyH("LEFT")
  end
  -- Extend the hit rect over the label instead of widening the button.
  local labelW = 280
  if text.GetStringWidth then
    local sw = text:GetStringWidth()
    if type(sw) == "number" and sw > 0 then
      labelW = math.max(80, sw + 8)
    end
  end
  if cb.SetHitRectInsets then
    cb:SetHitRectInsets(0, -labelW, 0, 0)
  end
  cb._kind = "CheckButton"
  cb:SetScript("OnClick", function(self)
    if refreshing then
      return
    end
    local checked = self:GetChecked() and true or false
    if onChange then
      onChange(checked)
    end
  end)
  return cb
end

-- Each slider lives in a 70px block: title/value on top, bar below, padding
-- under the bar. Low/High (and other template min/max labels) are hidden so
-- they cannot overlap the next control. Forever is mainline-family and may
-- offer MinimalSliderWithSteppersTemplate; that template's steppers and
-- side labels overflow a 16px bar, so we do not use it.
local SLIDER_BLOCK_H = 70
local SLIDER_BAR_H = 16
local SLIDER_TITLE_H = 16

local function HideRegion(region)
  if type(region) ~= "table" then
    return
  end
  if region.SetText then
    pcall(region.SetText, region, "")
  end
  if region.Hide then
    pcall(region.Hide, region)
  end
  if region.SetAlpha then
    pcall(region.SetAlpha, region, 0)
  end
end

local function MakeSlider(parent, name, minV, maxV, step)
  local block = CreateFrame("Frame", name .. "Block", parent)
  block:SetSize(280, SLIDER_BLOCK_H)

  local s
  local ok, frame = pcall(CreateFrame, "Slider", name, block, "OptionsSliderTemplate")
  if ok and frame then
    s = frame
  end
  if not s then
    s = CreateFrame("Slider", name, block)
    if s.SetOrientation then
      s:SetOrientation("HORIZONTAL")
    end
    local bg = s:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetTexture("Interface\\Buttons\\WHITE8X8")
    bg:SetVertexColor(0.2, 0.2, 0.22, 1)
  end

  if s.SetMinMaxValues then
    s:SetMinMaxValues(minV, maxV)
  end
  if s.SetValueStep then
    s:SetValueStep(step or 0.05)
  end
  if s.SetObeyStepOnDrag then
    pcall(s.SetObeyStepOnDrag, s, true)
  end

  if s.SetParent then
    pcall(s.SetParent, s, block)
  end
  s:ClearAllPoints()
  if s.SetSize then
    s:SetSize(240, SLIDER_BAR_H)
  else
    if s.SetWidth then s:SetWidth(240) end
    if s.SetHeight then s:SetHeight(SLIDER_BAR_H) end
  end
  s:SetPoint("TOPLEFT", block, "TOPLEFT", 0, -(SLIDER_TITLE_H + 10))
  s:SetPoint("TOPRIGHT", block, "TOPRIGHT", -8, -(SLIDER_TITLE_H + 10))

  local title = EnsureFontString(s, "Text", "GameFontHighlightSmall")
  title:ClearAllPoints()
  title:SetPoint("TOPLEFT", block, "TOPLEFT", 0, -2)
  title:SetPoint("TOPRIGHT", block, "TOPRIGHT", -8, -2)
  if title.SetJustifyH then
    title:SetJustifyH("LEFT")
  end
  if title.SetHeight then
    title:SetHeight(SLIDER_TITLE_H)
  end
  if title.SetWidth then
    title:SetWidth(260)
  end
  if title.Show then
    title:Show()
  end

  local extras = { "Low", "High", "LowText", "HighText", "LeftText", "RightText", "MinText", "MaxText" }
  for i = 1, #extras do
    HideRegion(rawget(s, extras[i]))
  end

  s.block = block
  block.slider = s
  block.Text = title
  return s
end

local function MakeButton(parent, name, label, width)
  local b = CreateFrame("Button", name, parent, "UIPanelButtonTemplate")
  if not b or not b.SetText then
    b = CreateFrame("Button", name, parent)
    b:SetSize(width or 160, 24)
    local bg = b:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetTexture("Interface\\Buttons\\WHITE8X8")
    bg:SetVertexColor(0.18, 0.18, 0.20, 1)
    local lab = EnsureFontString(b, "label", "GameFontHighlight", { "CENTER" })
    lab:SetText(label)
    if not b.SetText then
      b.SetText = function(self, text) self.label:SetText(text) end
    end
  else
    b:SetSize(width or 160, 24)
    local text = rawget(b, "Text")
    if type(text) == "table" and text.SetFontObject then
      pcall(text.SetFontObject, text, GameFontHighlight)
    end
    if b.SetText then
      b:SetText(label)
    end
  end
  return b
end

local function ConfirmResetProgress()
  if not StaticPopupDialogs then
    PC:ResetAllProgress()
    return
  end
  StaticPopupDialogs["PHILOSOPHERSCODEX_RESET_PROGRESS"] = {
    text = "Reset all Philosopher's Codex progress for this character? Settings are kept. This cannot be undone.",
    button1 = YES or "Reset",
    button2 = CANCEL or "Cancel",
    OnAccept = function()
      if PC.ResetAllProgress then
        PC:ResetAllProgress()
      end
    end,
    timeout = 0,
    whileDead = 1,
    hideOnEscape = 1,
    preferredIndex = 3,
  }
  if StaticPopup_Show then
    pcall(StaticPopup_Show, "PHILOSOPHERSCODEX_RESET_PROGRESS")
  else
    PC:ResetAllProgress()
  end
end

local function SyncProfileChecks()
  local list = (PC.GetUpgradeProfiles and PC:GetUpgradeProfiles()) or {}
  local current = PC.GetUpgradeProfile and PC:GetUpgradeProfile() or nil
  local boxes = widgets.profileChecks or {}
  for i = 1, #boxes do
    local box = boxes[i]
    local def = list[i]
    if def and def.id then
      box.profileId = def.id
      box:Show()
      if box.Text then
        box.Text:SetText(def.name or def.id)
      elseif box.SetText then
        box:SetText(def.name or def.id)
      end
      box:SetChecked(current == def.id)
    else
      box.profileId = nil
      box:SetChecked(false)
      box:Hide()
    end
  end
end

local function Layout()
  if not panel or not panel.child then
    return
  end
  local child = panel.child
  local y = -8
  local function place(frame, height, x)
    if not frame then
      return
    end
    frame:ClearAllPoints()
    frame:SetPoint("TOPLEFT", child, "TOPLEFT", x or 16, y)
    -- Never widen a CheckButton: its checked texture is often SetAllPoints.
    local isCheck = (frame.GetObjectType and frame:GetObjectType() == "CheckButton")
      or frame._kind == "CheckButton"
    if (not isCheck) and frame.SetWidth and (not frame.GetWidth or (frame:GetWidth() or 0) < 40) then
      pcall(frame.SetWidth, frame, 400)
    end
    if height and frame.SetHeight and (frame._kind == "FontString" or (frame.GetObjectType and frame:GetObjectType() == "FontString")) then
      pcall(frame.SetHeight, frame, math.min(height, 22))
    end
    y = y - (height or 28)
  end

  local function placeSlider(s)
    local block = s and s.block or s
    if not block then
      return
    end
    if block.SetHeight then
      block:SetHeight(SLIDER_BLOCK_H)
    end
    if block.SetWidth then
      block:SetWidth(280)
    end
    place(block, SLIDER_BLOCK_H, 16)
  end

  local function hideLabel(fs)
    if fs and fs.Hide then
      fs:Hide()
    end
  end

  place(widgets.header, 22)
  place(widgets.sub, 18)
  y = y - 4
  if widgets.hPreview then
    place(widgets.hPreview, 22)
  end
  if widgets.demoGuild then
    -- Keep Demo near the top so it is visible without scrolling.
    place(widgets.demoGuild, 28)
  end
  if widgets.demoHelp then
    place(widgets.demoHelp, 20)
  end
  y = y - 4
  place(widgets.hGeneral, 22)
  place(widgets.minimap, 28)
  place(widgets.share, 28)
  place(widgets.bracketAlerts, 28)
  place(widgets.matchToast, 28)
  place(widgets.requestToast, 28)
  if widgets.dungeonTips then
    place(widgets.dungeonTips, 28)
  end
  hideLabel(widgets.scaleLabel)
  placeSlider(widgets.scale)
  y = y - 4
  place(widgets.hUpgrade, 22)
  place(widgets.profileLabel, 16)
  local pchecks = widgets.profileChecks or {}
  for i = 1, #pchecks do
    if pchecks[i]:IsShown() then
      place(pchecks[i], 26)
    end
  end
  place(widgets.upgradeChat, 28)
  place(widgets.upgradeToast, 28)
  place(widgets.upgradeTooltip, 28)
  y = y - 6
  place(widgets.hMini, 22)
  place(widgets.miniEnabled, 28)
  place(widgets.miniLocked, 28)
  place(widgets.miniQuests, 28)
  place(widgets.miniCombat, 28)
  place(widgets.miniInstance, 28)
  hideLabel(widgets.miniScaleLabel)
  placeSlider(widgets.miniScale)
  hideLabel(widgets.miniLinesLabel)
  placeSlider(widgets.miniLines)
  hideLabel(widgets.miniOpacityLabel)
  placeSlider(widgets.miniOpacity)
  y = y - 10
  if widgets.hFinder then
    place(widgets.hFinder, 22)
    place(widgets.available, 28)
    place(widgets.availQuest, 26)
    place(widgets.availDungeon, 26)
    place(widgets.availBoth, 26)
    hideLabel(widgets.availExpireLabel)
    placeSlider(widgets.availExpire)
    place(widgets.availLogout, 28)
    y = y - 8
  end
  if widgets.hUpdate then
    place(widgets.hUpdate, 22)
    place(widgets.updateStatus, 20)
    place(widgets.updateBtn, 32)
    y = y - 6
  end
  if widgets.hIssues then
    place(widgets.hIssues, 22)
    place(widgets.issuesSummary, 20)
    place(widgets.issuesBtn, 32)
    if widgets.welcomeBtn then
      place(widgets.welcomeBtn, 32)
    end
    place(widgets.debugMode, 28)
    y = y - 6
  end
  place(widgets.hDanger, 22)
  place(widgets.resetPos, 30)
  place(widgets.resetProgress, 30)
  y = y - 16
  local contentH = math.abs(y) + 20
  if contentH < 400 then
    contentH = 400
  end
  child:SetHeight(contentH)
  -- Settings.RegisterCanvasLayoutCategory uses the canvas frame size.
  -- If this height is omitted, later controls can be clipped and the
  -- panel may appear to have no scrollbar.
  if panel.SetHeight and not panel._settingsLocksHeight then
    -- Don't shrink the canvas itself; Settings sizes it. Only the child
    -- height drives our scroll range.
  end
  panel._contentHeight = contentH
  local scroll = panel.scroll
  if scroll then
    if scroll.UpdateScrollChildRect then
      pcall(scroll.UpdateScrollChildRect, scroll)
    end
    local range = 0
    if scroll.GetVerticalScrollRange then
      range = scroll:GetVerticalScrollRange() or 0
    else
      local vis = scroll:GetHeight() or 0
      range = math.max(0, (child:GetHeight() or 0) - vis)
    end
    if scroll.ScrollBar and scroll.ScrollBar.SetMinMaxValues then
      scroll.ScrollBar:SetMinMaxValues(0, range)
      if range <= 0 then
        scroll.ScrollBar:Hide()
      else
        scroll.ScrollBar:Show()
      end
    end
  end
end

function PC:RefreshOptionsPanel()
  if not panel or not widgets.minimap or refreshing then
    return
  end
  refreshing = true
  local db = self:GetDB()
  local mini = self:GetMiniDB() or {}
  widgets.minimap:SetChecked(not (db and db.minimap and db.minimap.hide))
  widgets.share:SetChecked(self.IsShareEnabled and self:IsShareEnabled())
  widgets.bracketAlerts:SetChecked(self:IsBracketAlertsEnabled())
  widgets.matchToast:SetChecked(self:IsMatchToastEnabled())
  widgets.requestToast:SetChecked(self:IsRequestToastEnabled())
  if widgets.dungeonTips then
    local on = true
    if PC.IsDungeonTipsAutoPop then
      on = PC:IsDungeonTipsAutoPop()
    end
    widgets.dungeonTips:SetChecked(on)
  end
  if widgets.demoGuild then
    widgets.demoGuild:SetChecked(self.IsDemoGuildOn and self:IsDemoGuildOn())
  end
  SyncProfileChecks()
  Layout()
  widgets.upgradeChat:SetChecked(self:IsUpgradeChatEnabled())
  widgets.upgradeToast:SetChecked(self:IsUpgradeToastEnabled())
  widgets.upgradeTooltip:SetChecked(self:IsUpgradeTooltipEnabled())
  local scale = db and db.window and db.window.scale or 1
  widgets.scale:SetValue(scale)
  widgets.scale.Text:SetText(string.format("Window scale: %.2f", scale))
  widgets.miniEnabled:SetChecked(mini.enabled ~= false)
  widgets.miniLocked:SetChecked(mini.locked and true or false)
  widgets.miniQuests:SetChecked(mini.showQuests ~= false)
  widgets.miniCombat:SetChecked(mini.hideInCombat and true or false)
  widgets.miniInstance:SetChecked(mini.hideInInstances and true or false)
  local mscale = mini.scale or 1
  widgets.miniScale:SetValue(mscale)
  widgets.miniScale.Text:SetText(string.format("Mini tracker scale: %.2f", mscale))
  local lines = mini.maxLines or 5
  widgets.miniLines:SetValue(lines)
  widgets.miniLines.Text:SetText("Max quest lines: " .. tostring(lines))
  local op = mini.opacity or 0.85
  widgets.miniOpacity:SetValue(op)
  widgets.miniOpacity.Text:SetText(string.format("Mini tracker opacity: %.2f", op))
  if widgets.available then
    widgets.available:SetChecked(self.IsAvailableToGroup and self:IsAvailableToGroup())
    local kind = self.GetAvailKind and self:GetAvailKind() or "both"
    widgets.availQuest:SetChecked(kind == "quest")
    widgets.availDungeon:SetChecked(kind == "dungeon")
    widgets.availBoth:SetChecked(kind == "both")
    local hours = db and db.availExpireHours or 4
    widgets.availExpire:SetValue(hours)
    if widgets.availExpire.Text then
      widgets.availExpire.Text:SetText("Expires after " .. tostring(hours) .. " hours")
    end
    widgets.availLogout:SetChecked(not db or db.availExpireOnLogout ~= false)
  end
  if widgets.updateStatus then
    local ver = self.GetAvailableUpdate and self:GetAvailableUpdate()
    if ver then
      widgets.updateStatus:SetText("Update available: v" .. ver)
      if widgets.updateStatus.SetTextColor then
        widgets.updateStatus:SetTextColor(0.831, 0.686, 0.216)
      end
    else
      widgets.updateStatus:SetText("This copy is v" .. tostring(self.VERSION or "?") .. ". You'll be told when a guildmate has a newer one.")
      if widgets.updateStatus.SetTextColor then
        widgets.updateStatus:SetTextColor(0.56, 0.56, 0.60)
      end
    end
  end
  if widgets.issuesSummary then
    local errors, missing = 0, 0
    if self.CountIssues then
      errors, missing = self:CountIssues()
    end
    widgets.issuesSummary:SetText(tostring(errors) .. " errors  ·  " .. tostring(missing) .. " missing data")
  end
  if widgets.debugMode then
    widgets.debugMode:SetChecked(self.IsDebugMode and self:IsDebugMode())
  end
  refreshing = false
end

local function BuildPanel()
  if panel and widgets.minimap and widgets.resetProgress then
    return panel
  end
  local f = CreateFrame("Frame", "PhilosophersCodexSettingsPanel", UIParent)
  f:SetSize(660, 560)
  f.name = "Philosopher's Codex"

  local scroll
  local ok, frame = pcall(CreateFrame, "ScrollFrame", "PhilosophersCodexSettingsScroll", f, "UIPanelScrollFrameTemplate")
  if ok and frame then
    scroll = frame
  else
    ok, frame = pcall(CreateFrame, "ScrollFrame", "PhilosophersCodexSettingsScroll", f, "ScrollFrameTemplate")
    if ok and frame then
      scroll = frame
    else
      scroll = CreateFrame("ScrollFrame", "PhilosophersCodexSettingsScroll", f)
    end
  end
  scroll:SetPoint("TOPLEFT", 0, -4)
  scroll:SetPoint("BOTTOMRIGHT", -24, 4)
  if scroll.EnableMouseWheel then
    scroll:EnableMouseWheel(true)
  end
  scroll:SetScript("OnMouseWheel", function(self, delta)
    local step = 40
    local current = self:GetVerticalScroll() or 0
    local maxs = 0
    if self.GetVerticalScrollRange then
      maxs = self:GetVerticalScrollRange() or 0
    end
    local newv = current - (delta * step)
    if newv < 0 then newv = 0 end
    if newv > maxs then newv = maxs end
    self:SetVerticalScroll(newv)
  end)
  if not rawget(scroll, "ScrollBar") or type(rawget(scroll, "ScrollBar")) ~= "table" then
    local bar = CreateFrame("Slider", "PhilosophersCodexSettingsScrollBar", scroll, "UIPanelScrollBarTemplate")
    if not bar or not bar.SetMinMaxValues then
      bar = CreateFrame("Slider", "PhilosophersCodexSettingsScrollBar", scroll)
      bar:SetWidth(16)
      bar:SetOrientation("VERTICAL")
      if bar.SetMinMaxValues then bar:SetMinMaxValues(0, 1) end
      if bar.SetValueStep then bar:SetValueStep(20) end
    end
    bar:ClearAllPoints()
    bar:SetPoint("TOPRIGHT", scroll, "TOPRIGHT", 0, -16)
    bar:SetPoint("BOTTOMRIGHT", scroll, "BOTTOMRIGHT", 0, 16)
    bar:SetScript("OnValueChanged", function(self, value)
      scroll:SetVerticalScroll(value or 0)
    end)
    scroll.ScrollBar = bar
  end
  local child = CreateFrame("Frame", "PhilosophersCodexSettingsChild", scroll)
  child:SetSize(620, 1400)
  scroll:SetScrollChild(child)
  f.scroll = scroll
  f.child = child
  f:SetScript("OnSizeChanged", function(self, w, h)
    if self.scroll then
      -- Anchored to the panel; re-layout so the child height and bar range stay correct
      -- whatever size Settings gives this canvas.
    end
    if Layout then
      -- Layout is local and assigned below; RefreshOptionsPanel also calls it.
    end
    if PC.RefreshOptionsPanel and panel then
      -- Avoid a loop: Layout itself does not change the panel size.
    end
  end)

  widgets.header = Header(child, "Philosopher's Codex")
  widgets.sub = Label(child, "Changes apply immediately and are saved for this character.", "GameFontHighlightSmall")
  if widgets.sub.SetTextColor then
    widgets.sub:SetTextColor(SUB.r, SUB.g, SUB.b)
  end

  widgets.hPreview = Header(child, "Preview")
  widgets.demoGuild = MakeCheck(child, "PhilosophersCodexOptDemoGuild", "Demo guildmates in the Guild tab", function(on)
    if PC.SetDemoGuild then
      PC:SetDemoGuild(on)
    end
  end)
  widgets.demoHelp = Label(child, "Shows fake, tagged Demo players so you can preview grouping. Never broadcast.", "GameFontHighlightSmall")
  if widgets.demoHelp.SetTextColor then
    widgets.demoHelp:SetTextColor(SUB.r, SUB.g, SUB.b)
  end

  widgets.hGeneral = Header(child, "General")
  widgets.minimap = MakeCheck(child, "PhilosophersCodexOptMinimap", "Show minimap button", function(on)
    local db = PC:GetDB()
    if db then
      if type(db.minimap) ~= "table" then
        db.minimap = {}
      end
      db.minimap.hide = not on
    end
    if PC.UpdateMinimapButton then
      PC:UpdateMinimapButton()
    end
  end)
  widgets.share = MakeCheck(child, "PhilosophersCodexOptShare", "Guild sharing", function(on)
    if PC.SetShareEnabled then
      PC:SetShareEnabled(on)
    end
  end)
  widgets.bracketAlerts = MakeCheck(child, "PhilosophersCodexOptBracket", "Bracket change alerts", function(on)
    PC:SetSettingFlag("bracketAlerts", on)
  end)
  widgets.matchToast = MakeCheck(child, "PhilosophersCodexOptMatchToast", "Toast when a good group match comes online", function(on)
    PC:SetSettingFlag("matchToast", on)
  end)
  widgets.requestToast = MakeCheck(child, "PhilosophersCodexOptReqToast", "Toast when someone asks to join you", function(on)
    PC:SetSettingFlag("requestToast", on)
  end)
  widgets.dungeonTips = MakeCheck(child, "PhilosophersCodexOptDungeonTips", "Show boss tips when you enter a dungeon", function(on)
    if PC.SetDungeonTipsAutoPop then
      PC:SetDungeonTipsAutoPop(on)
    end
  end)
  widgets.scaleLabel = Label(child, "Main window scale", "GameFontHighlight")
  widgets.scale = MakeSlider(child, "PhilosophersCodexOptScale", 0.8, 1.4, 0.05)
  widgets.scale:SetScript("OnValueChanged", function(self, value)
    if refreshing then
      return
    end
    value = tonumber(value) or 1
    if PC.ApplyWindowScale then
      local applied = PC:ApplyWindowScale(value)
      if applied and self.Text then
        self.Text:SetText(string.format("Window scale: %.2f", applied))
      end
    end
  end)

  widgets.hUpgrade = Header(child, "Upgrade alerts")
  widgets.profileLabel = Label(child, "Active profile", "GameFontHighlight")
  local function setProfile(which)
    if refreshing then
      return
    end
    if PC.SetUpgradeProfile then
      PC:SetUpgradeProfile(which)
    end
    if PC.RefreshOptionsPanel then
      PC:RefreshOptionsPanel()
    end
  end
  widgets.profileChecks = {}
  for i = 1, 4 do
    local idx = i
    local box = MakeCheck(child, "PhilosophersCodexOptProfile" .. i, "Profile " .. i, function()
      local id = widgets.profileChecks[idx] and widgets.profileChecks[idx].profileId
      if id then
        setProfile(id)
      end
    end)
    widgets.profileChecks[i] = box
    box:Hide()
  end
  widgets.upgradeChat = MakeCheck(child, "PhilosophersCodexOptUpChat", "Upgrade chat alerts", function(on)
    PC:SetSettingFlag("upgradeChat", on)
  end)
  widgets.upgradeToast = MakeCheck(child, "PhilosophersCodexOptUpToast", "Upgrade toast", function(on)
    PC:SetSettingFlag("upgradeToast", on)
  end)
  widgets.upgradeTooltip = MakeCheck(child, "PhilosophersCodexOptUpTip", "Tooltip upgrade line", function(on)
    PC:SetSettingFlag("upgradeTooltip", on)
  end)

  widgets.hMini = Header(child, "Mini tracker")
  widgets.miniEnabled = MakeCheck(child, "PhilosophersCodexOptMini", "Show mini tracker", function(on)
    if on then
      if PC.ShowMiniTracker then
        PC:ShowMiniTracker()
      else
        PC:SetMiniOption("enabled", true)
      end
    else
      if PC.HideMiniTracker then
        PC:HideMiniTracker()
      else
        PC:SetMiniOption("enabled", false)
      end
    end
  end)
  widgets.miniLocked = MakeCheck(child, "PhilosophersCodexOptMiniLock", "Lock mini tracker position and size", function(on)
    PC:SetMiniOption("locked", on)
  end)
  widgets.miniQuests = MakeCheck(child, "PhilosophersCodexOptMiniQuests", "Show quests for the next dungeon", function(on)
    PC:SetMiniOption("showQuests", on)
  end)
  widgets.miniCombat = MakeCheck(child, "PhilosophersCodexOptMiniCombat", "Hide mini tracker in combat", function(on)
    PC:SetMiniOption("hideInCombat", on)
  end)
  widgets.miniInstance = MakeCheck(child, "PhilosophersCodexOptMiniInst", "Hide mini tracker in instances", function(on)
    PC:SetMiniOption("hideInInstances", on)
  end)
  widgets.miniScaleLabel = Label(child, "Mini tracker scale", "GameFontHighlight")
  widgets.miniScale = MakeSlider(child, "PhilosophersCodexOptMiniScale", 0.8, 1.4, 0.05)
  widgets.miniScale:SetScript("OnValueChanged", function(self, value)
    if refreshing then
      return
    end
    value = tonumber(value) or 1
    if value < 0.8 then value = 0.8 end
    if value > 1.4 then value = 1.4 end
    PC:SetMiniOption("scale", value)
    if self.Text then
      self.Text:SetText(string.format("Mini tracker scale: %.2f", value))
    end
  end)
  widgets.miniLinesLabel = Label(child, "Maximum quest lines", "GameFontHighlight")
  widgets.miniLines = MakeSlider(child, "PhilosophersCodexOptMiniLines", 1, 10, 1)
  widgets.miniLines:SetScript("OnValueChanged", function(self, value)
    if refreshing then
      return
    end
    local n = math.floor((tonumber(value) or 5) + 0.5)
    if n < 1 then n = 1 end
    if n > 10 then n = 10 end
    PC:SetMiniOption("maxLines", n)
    if self.Text then
      self.Text:SetText("Max quest lines: " .. tostring(n))
    end
  end)
  widgets.miniOpacityLabel = Label(child, "Mini tracker opacity", "GameFontHighlight")
  widgets.miniOpacity = MakeSlider(child, "PhilosophersCodexOptMiniOpacity", 0.4, 1.0, 0.05)
  widgets.miniOpacity:SetScript("OnValueChanged", function(self, value)
    if refreshing then
      return
    end
    value = tonumber(value) or 0.85
    if value < 0.4 then value = 0.4 end
    if value > 1 then value = 1 end
    PC:SetMiniOption("opacity", value)
    if self.Text then
      self.Text:SetText(string.format("Mini tracker opacity: %.2f", value))
    end
  end)

    widgets.hFinder = Header(child, "Group finder")
  widgets.available = MakeCheck(child, "PhilosophersCodexOptAvailable", "Available to group", function(on)
    if PC.SetAvailableToGroup then
      PC:SetAvailableToGroup(on)
    end
  end)
  local function setKind(kind)
    if refreshing then
      return
    end
    if PC.SetAvailKind then
      PC:SetAvailKind(kind)
    end
    if PC.RefreshOptionsPanel then
      PC:RefreshOptionsPanel()
    end
  end
  widgets.availQuest = MakeCheck(child, "PhilosophersCodexOptAvailQuest", "Questing buddies", function(on)
    if on then setKind("quest") end
  end)
  widgets.availDungeon = MakeCheck(child, "PhilosophersCodexOptAvailDungeon", "Dungeons", function(on)
    if on then setKind("dungeon") end
  end)
  widgets.availBoth = MakeCheck(child, "PhilosophersCodexOptAvailBoth", "Both", function(on)
    if on then setKind("both") end
  end)
  widgets.availExpireLabel = Label(child, "Auto-expire availability (hours, 0 = off)", "GameFontHighlight")
  widgets.availExpire = MakeSlider(child, "PhilosophersCodexOptAvailExpire", 0, 24, 1)
  widgets.availExpire:SetScript("OnValueChanged", function(self, value)
    if refreshing then
      return
    end
    value = math.floor((tonumber(value) or 4) + 0.5)
    if PC.SetAvailExpireHours then
      PC:SetAvailExpireHours(value)
    end
    if self.Text then
      self.Text:SetText("Expires after " .. tostring(value) .. " hours")
    end
  end)
  widgets.availLogout = MakeCheck(child, "PhilosophersCodexOptAvailLogout", "Turn off availability on logout", function(on)
    if PC.SetAvailExpireOnLogout then
      PC:SetAvailExpireOnLogout(on)
    end
  end)

  widgets.hUpdate = Header(child, "Updates")
  widgets.updateStatus = Label(child, "This copy is v" .. tostring(PC.VERSION or "?") .. ".", "GameFontHighlightSmall")
  if widgets.updateStatus.SetTextColor then
    widgets.updateStatus:SetTextColor(SUB.r, SUB.g, SUB.b)
  end
  widgets.updateBtn = MakeButton(child, "PhilosophersCodexOptUpdate", "Update", 220)
  widgets.updateBtn:SetScript("OnClick", function()
    if PC.OpenUpdateDialog then
      PC:OpenUpdateDialog()
    end
  end)

  widgets.hIssues = Header(child, "Issues")
  widgets.issuesSummary = Label(child, "0 errors  ·  0 missing data", "GameFontHighlightSmall")
  if widgets.issuesSummary.SetTextColor then
    widgets.issuesSummary:SetTextColor(SUB.r, SUB.g, SUB.b)
  end
  widgets.issuesBtn = MakeButton(child, "PhilosophersCodexOptIssues", "Report a problem", 220)
  widgets.issuesBtn:SetScript("OnClick", function()
    if PC.CopyIssueReport then
      PC:CopyIssueReport()
    elseif PC.OpenIssues then
      PC:OpenIssues()
    end
  end)
  widgets.welcomeBtn = MakeButton(child, "PhilosophersCodexOptWelcome", "Show welcome again", 220)
  widgets.welcomeBtn:SetScript("OnClick", function()
    if PC.ShowWelcome then
      PC:ShowWelcome(true)
    end
  end)
  widgets.debugMode = MakeCheck(child, "PhilosophersCodexOptDebug", "Debug mode (print errors in chat)", function(on)
    if PC.SetDebugMode then
      PC:SetDebugMode(on)
    end
  end)

widgets.hDanger = Header(child, "Reset")
  widgets.resetPos = MakeButton(child, "PhilosophersCodexOptResetPos", "Reset window positions", 220)
  widgets.resetPos:SetScript("OnClick", function()
    if PC.ResetWindowPositions then
      PC:ResetWindowPositions()
    end
  end)
  widgets.resetProgress = MakeButton(child, "PhilosophersCodexOptResetAll", "Reset all progress", 220)
  widgets.resetProgress:SetScript("OnClick", ConfirmResetProgress)

  Layout()
  f:SetScript("OnSizeChanged", function(self)
    if Layout then
      Layout()
    end
  end)
  f:SetScript("OnShow", function()
    PC:RefreshOptionsPanel()
  end)
  f:Hide()
  panel = f
  if PC.ProtectFrameTree then
    pcall(function() PC:ProtectFrameTree(f) end)
  end
  return f
end

function PC:EnsureSettings()
  if registered then
    return panel
  end
  local f = BuildPanel()
  registered = true
  if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
    local ok, category = pcall(Settings.RegisterCanvasLayoutCategory, f, "Philosopher's Codex")
    if ok and category then
      pcall(Settings.RegisterAddOnCategory, category)
      self.settingsCategory = category
      if category.GetID then
        local okid, id = pcall(category.GetID, category)
        if okid then
          self.settingsCategoryID = id
        end
      end
      if not self.settingsCategoryID and category.ID then
        self.settingsCategoryID = category.ID
      end
    end
  elseif InterfaceOptions_AddCategory then
    pcall(InterfaceOptions_AddCategory, f)
  end
  self.settingsFrame = f
  return f
end

function PC:OpenSettings()
  self:EnsureSettings()
  if self.RefreshOptionsPanel then
    self:RefreshOptionsPanel()
  end
  if Settings and Settings.OpenToCategory then
    if self.settingsCategoryID then
      local ok = pcall(Settings.OpenToCategory, self.settingsCategoryID)
      if ok then
        return
      end
    end
    if self.settingsCategory then
      local ok = pcall(Settings.OpenToCategory, self.settingsCategory)
      if ok then
        return
      end
    end
    pcall(Settings.OpenToCategory, "Philosopher's Codex")
    return
  end
  if InterfaceOptionsFrame_OpenToCategory and self.settingsFrame then
    pcall(InterfaceOptionsFrame_OpenToCategory, self.settingsFrame)
    pcall(InterfaceOptionsFrame_OpenToCategory, self.settingsFrame)
    return
  end
  if self.settingsFrame then
    self.settingsFrame:ClearAllPoints()
    self.settingsFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    self.settingsFrame:Show()
  end
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:SetScript("OnEvent", function()
  if PC.GetDB and not PC:GetDB() and PC.InitDB then
    PC:InitDB()
  end
  PC:EnsureSettings()
end)
