-- Philosopher's Codex: guild tab matching, dungeon chips, roles, and demo peers.
-- Share transport still lives in PhilosophersCodexShare.lua; this file adds
-- the 1.14 group-finder layout data and a compact, backward-compatible
-- dungeon-chip field on the existing status payload.

local PC = PhilosophersCodex

local ALLOWED_ROLES = {
  WARRIOR = { "tank", "dps" },
  PALADIN = { "tank", "healer", "dps" },
  HUNTER = { "dps" },
  ROGUE = { "dps" },
  PRIEST = { "healer", "dps" },
  SHAMAN = { "healer", "dps" },
  MAGE = { "dps" },
  WARLOCK = { "dps" },
  DRUID = { "tank", "healer", "dps" },
}

-- Short codes keep the trailing payload field tiny and stable.
local DUNGEON_CODE = {
  deadmines = "DM", ["shadowfang-keep"] = "SF", ["hall-of-thanes"] = "HT",
  ["wailing-caverns"] = "WC", ["ruins-of-lordaeron"] = "RL", stockade = "ST",
  ["excavation-site"] = "ES", ["blackfathom-deeps"] = "BF", ["city-of-dalaran"] = "CD",
  ["sm-graveyard"] = "GY", ["sm-library"] = "LB", ["sm-armory"] = "AR",
  ["sm-cathedral"] = "CA", gnomeregan = "GN", ["razorfen-kraul"] = "RK",
  ["drowned-city"] = "DC", kroldok = "KR", ["razorfen-downs"] = "RD",
  uldaman = "UL", zulfarrak = "ZF", maraudon = "MA", ["alcaz-prison"] = "AP",
  ["sunken-temple"] = "SU", brd = "BD", ["blackmaw-hold"] = "BH", lbrs = "LR",
  ["shapers-terrace"] = "SH", ["dire-maul"] = "DI", scholomance = "SC",
  stratholme = "SR", ubrs = "UR",
}
local CODE_DUNGEON = {}
for id, code in pairs(DUNGEON_CODE) do
  CODE_DUNGEON[code] = id
end

local demoPeers
local demoStamp

local function RoleAllowed(list, role)
  if type(list) ~= "table" then
    return false
  end
  for i = 1, #list do
    if list[i] == role then
      return true
    end
  end
  return false
end

function PC:GetAllowedRoles(classFile)
  classFile = classFile or (self.GetClassFile and self:GetClassFile()) or nil
  local data = self.GetClassData and self:GetClassData() or nil
  if data and type(data.allowedRoles) == "table" and #data.allowedRoles > 0 then
    return data.allowedRoles
  end
  if classFile and ALLOWED_ROLES[classFile] then
    return ALLOWED_ROLES[classFile]
  end
  return { "dps" }
end

function PC:ClassCanUseRole(role, classFile)
  return RoleAllowed(self:GetAllowedRoles(classFile), role)
end

function PC:ClampSocialRole(role, classFile)
  if self:ClassCanUseRole(role, classFile) then
    return role
  end
  local allowed = self:GetAllowedRoles(classFile)
  return allowed[1] or "dps"
end

function PC:EncodeDungeonChips(ids)
  if type(ids) ~= "table" or #ids == 0 then
    return "-"
  end
  local parts, seen = {}, {}
  for i = 1, #ids do
    local id = ids[i]
    local code = DUNGEON_CODE[id] or DUNGEON_CODE[string.lower(tostring(id or ""))]
    if code and not seen[code] then
      seen[code] = true
      parts[#parts + 1] = code
    end
  end
  if #parts == 0 then
    return "-"
  end
  return table.concat(parts, ",")
end

function PC:DecodeDungeonChips(field)
  local out = {}
  if type(field) ~= "string" or field == "" or field == "-" then
    return out
  end
  for token in string.gmatch(field, "[^,;+]+") do
    local id = CODE_DUNGEON[token] or CODE_DUNGEON[string.upper(token)]
    if id then
      out[#out + 1] = id
    end
  end
  return out
end

function PC:GetLevelDungeons(level)
  level = tonumber(level) or self:PlayerLevel() or 1
  local soon = (self.GEAR_SOON_WINDOW or 3)
  local list = {}
  local seen = {}
  local function consider(d)
    if type(d) ~= "table" or not d.id or seen[d.id] or d.skipped then
      return
    end
    if d.faction and string.lower(tostring(d.faction)) == "horde" then
      return
    end
    local minL, maxL
    if self.GetDungeonLevelRange then
      minL, maxL = self:GetDungeonLevelRange(d.id)
    end
    if (not minL) and self.ParseLevelRange then
      minL, maxL = self:ParseLevelRange(d.range)
    end
    if minL and minL > level + soon then
      return
    end
    if maxL and maxL < level - 4 then
      return
    end
    seen[d.id] = true
    list[#list + 1] = {
      id = d.id,
      name = d.name or d.id,
      range = d.range,
      min = minL,
      max = maxL,
    }
  end
  -- Prefer the player's current brackets, then the full route so chips
  -- still appear if a start path listed a dungeon as "already completed".
  local brackets = self.GetCurrentBrackets and self:GetCurrentBrackets() or {}
  for i = 1, #brackets do
    local dungeons = brackets[i].dungeons or {}
    for j = 1, #dungeons do
      consider(dungeons[j])
    end
  end
  local data = self.GetClassData and self:GetClassData() or nil
  if data and type(data.brackets) == "table" then
    for i = 1, #data.brackets do
      local dungeons = data.brackets[i].dungeons or {}
      for j = 1, #dungeons do
        consider(dungeons[j])
      end
    end
  end
  table.sort(list, function(a, b)
    local am, bm = a.min or 0, b.min or 0
    if am ~= bm then
      return am < bm
    end
    return (a.name or "") < (b.name or "")
  end)
  return list
end

function PC:GetSelectedDungeons()
  local db = self.GetDB and self:GetDB() or nil
  if not db or type(db.guildDungeons) ~= "table" then
    return {}
  end
  local out, seen = {}, {}
  for i = 1, #db.guildDungeons do
    local id = db.guildDungeons[i]
    if type(id) == "string" and id ~= "" and not seen[id] then
      seen[id] = true
      out[#out + 1] = id
    end
  end
  return out
end

function PC:SetSelectedDungeons(ids)
  local db = self.GetDB and self:GetDB() or nil
  if not db then
    return
  end
  local clean, seen = {}, {}
  if type(ids) == "table" then
    for i = 1, #ids do
      local id = ids[i]
      if type(id) == "string" and id ~= "" and not seen[id] then
        seen[id] = true
        clean[#clean + 1] = id
      end
    end
  end
  db.guildDungeons = clean
  if self.BroadcastStatus then
    self:BroadcastStatus(true)
  end
  if self.Refresh then
    self:Refresh()
  end
end

function PC:ToggleSelectedDungeon(id)
  if type(id) ~= "string" or id == "" then
    return
  end
  local cur = self:GetSelectedDungeons()
  local nextIds, found = {}, false
  for i = 1, #cur do
    if cur[i] == id then
      found = true
    else
      nextIds[#nextIds + 1] = cur[i]
    end
  end
  if not found then
    nextIds[#nextIds + 1] = id
  end
  self:SetSelectedDungeons(nextIds)
end

function PC:IsDungeonSelected(id)
  local cur = self:GetSelectedDungeons()
  for i = 1, #cur do
    if cur[i] == id then
      return true
    end
  end
  return false
end

function PC:PeerDungeonList(rec)
  if not rec then
    return {}
  end
  if type(rec.dungeons) == "table" and #rec.dungeons > 0 then
    return rec.dungeons
  end
  if type(rec.guildDungeons) == "table" and #rec.guildDungeons > 0 then
    return rec.guildDungeons
  end
  if rec.lfg and rec.lfg ~= "" and rec.lfg ~= "-" then
    local d = self.FindDungeon and self:FindDungeon(rec.lfg)
    if d and d.id then
      return { d.id }
    end
    return { rec.lfg }
  end
  if rec.nextDungeon and rec.nextDungeon ~= "" and rec.nextDungeon ~= "-" then
    local d = self.FindDungeon and self:FindDungeon(rec.nextDungeon)
    if d and d.id then
      return { d.id }
    end
  end
  return {}
end

local function SharedDungeons(self, rec)
  local mine = self:GetSelectedDungeons()
  local theirs = self:PeerDungeonList(rec)
  local set, shared = {}, {}
  for i = 1, #mine do
    set[mine[i]] = true
  end
  for i = 1, #theirs do
    if set[theirs[i]] then
      shared[#shared + 1] = theirs[i]
    end
  end
  return shared
end

local function LevelCompatible(level, peerLevel)
  level = tonumber(level) or 1
  peerLevel = tonumber(peerLevel) or level
  return math.abs(level - peerLevel) <= 6
end

local function SameOrNearbyZone(self, rec)
  if not rec or not rec.zone or rec.zone == "" or rec.zone == "-" then
    return false
  end
  if self.IsCurrentZoneName and self:IsCurrentZoneName(rec.zone) then
    return true
  end
  if self.CanonicalZoneName and self.GetCurrentZoneName then
    local here = self:CanonicalZoneName(self:GetCurrentZoneName() or "")
    local there = self:CanonicalZoneName(rec.zone)
    return here and there and here == there
  end
  return false
end

function PC:GetGuildListMode()
  -- 1.16.0 removed the Matches / All guild toggle. Lists are always
  -- filtered to the current activity.
  return "matches"
end

function PC:SetGuildListMode(mode)
  -- Kept as a no-op so older slash or test calls do not error.
  return
end

function PC:GetQuestingZoneOptions()
  local out, seen = {}, {}
  local function add(name)
    if type(name) ~= "string" or name == "" then
      return
    end
    local key = string.lower(name)
    if seen[key] then
      return
    end
    seen[key] = true
    out[#out + 1] = name
  end
  if self.GetCurrentZoneName then
    add(self:GetCurrentZoneName())
  end
  if self.GetActivityZone then
    add(self:GetActivityZone())
  end
  if self.GetRecommendedZone then
    local rec = self:GetRecommendedZone()
    if rec then
      add(rec.name)
    end
  end
  local brackets = self.GetCurrentBrackets and self:GetCurrentBrackets() or {}
  for i = 1, #brackets do
    local zones = brackets[i].zones or {}
    for j = 1, #zones do
      add(zones[j])
    end
  end
  return out
end

local function PartyRoles(self)
  local have = { tank = 0, healer = 0, dps = 0 }
  local myRole = self.GetSocialRole and self:GetSocialRole() or "dps"
  have[myRole] = (have[myRole] or 0) + 1
  local n = 0
  if GetNumGroupMembers then
    local ok, num = pcall(GetNumGroupMembers)
    if ok then
      n = tonumber(num) or 0
    end
  elseif GetNumPartyMembers then
    local ok, num = pcall(GetNumPartyMembers)
    if ok then
      n = (tonumber(num) or 0)
    end
  end
  -- Unit tokens for party are party1..4; raid1.. when in a raid.
  local prefix = (IsInRaid and IsInRaid()) and "raid" or "party"
  local cap = (prefix == "raid") and 40 or 4
  if n > cap then
    n = cap
  end
  for i = 1, n do
    local unit = prefix .. i
    if not UnitExists or UnitExists(unit) then
      local role
      if UnitGroupRolesAssigned then
        local ok, assigned = pcall(UnitGroupRolesAssigned, unit)
        if ok and type(assigned) == "string" then
          local a = string.lower(assigned)
          if a == "tank" or a == "healer" or a == "damager" or a == "dps" then
            role = (a == "damager") and "dps" or a
          end
        end
      end
      if not role then
        local classFile
        if UnitClass then
          local ok, _, file = pcall(UnitClass, unit)
          if ok then
            classFile = file
          end
        end
        local allowed = self:GetAllowedRoles(classFile)
        -- Guess a single typical role when the client has no assigned role.
        if RoleAllowed(allowed, "healer") and not RoleAllowed(allowed, "tank") and #allowed <= 2 then
          role = "healer"
        elseif RoleAllowed(allowed, "tank") and classFile == "WARRIOR" then
          role = "tank"
        else
          role = allowed[1] or "dps"
        end
      end
      have[role] = (have[role] or 0) + 1
    end
  end
  return have
end

function PC:GetPartyNeeds()
  local have = PartyRoles(self)
  local needs = {}
  if (have.tank or 0) < 1 then
    needs[#needs + 1] = "Tank"
  end
  if (have.healer or 0) < 1 then
    needs[#needs + 1] = "Healer"
  end
  if (have.dps or 0) < 3 then
    -- Only mention DPS when the group is otherwise empty of damage.
    if (have.dps or 0) == 0 then
      needs[#needs + 1] = "DPS"
    end
  end
  return needs, have
end

function PC:GetPartyNeedHint()
  local needs = self:GetPartyNeeds()
  if #needs == 0 then
    return nil
  end
  return "Your group needs: " .. table.concat(needs, ", ")
end

local function ScorePeer(self, rec, level, needs)
  local score = 0
  local shared = SharedDungeons(self, rec)
  score = score + (#shared * 100)
  local role = rec.role or rec.guildRole
  if needs then
    if role == "tank" and needs.tank then
      score = score + 40
    elseif role == "healer" and needs.healer then
      score = score + 40
    elseif role == "dps" and needs.dps then
      score = score + 10
    end
  end
  local pl = tonumber(rec.level) or level
  score = score + math.max(0, 20 - math.abs(level - pl))
  if SameOrNearbyZone(self, rec) then
    score = score + 15
  end
  if rec.status == "dungeon" then
    score = score + 8
  elseif rec.status == "help" or rec.status == "open" then
    score = score + 4
  end
  return score, shared
end

function PC:PeerHasExplicitOptIn(rec)
  if not rec then
    return false
  end
  if rec.demo then
    return true
  end
  -- 1.16 lists only people who opted in. Legacy 1.4-1.8 payloads have no
  -- availability field (availLegacy); they stay hidden. 1.9+ peers who
  -- explicitly sent available (or can-help) plus a status are eligible.
  if rec.availLegacy and not rec.availExplicit then
    return false
  end
  if rec.availExplicit or rec.canHelp or rec.status == "open" then
    return true
  end
  return false
end

-- activity is the viewer's current status: dungeon, questing, or help.
function PC:PeerMatchesActivity(rec, activity)
  if not rec or rec.online == false then
    return false
  end
  activity = activity or (self.GetSocialStatus and self:GetSocialStatus()) or "questing"
  if activity == "busy" or activity == "open" then
    return false
  end
  if not self:PeerHasExplicitOptIn(rec) then
    return false
  end
  local available = rec.available ~= false
  if self.PeerIsAvailable then
    available = self:PeerIsAvailable(rec)
  end
  local shared = SharedDungeons(self, rec)
  local level = self:PlayerLevel() or 1
  local peerLevel = tonumber(rec.level) or 0

  if activity == "dungeon" then
    if rec.status == "busy" or rec.status ~= "dungeon" then
      return false
    end
    if not available then
      return false
    end
    if not LevelCompatible(level, rec.level) then
      return false
    end
    local mine = self:GetSelectedDungeons()
    if #mine > 0 and #shared == 0 then
      return false
    end
    return true, shared
  end

  if activity == "questing" then
    if rec.status ~= "questing" or rec.status == "busy" then
      return false
    end
    if not available then
      return false
    end
    if not LevelCompatible(level, rec.level) then
      return false
    end
    return true, shared
  end

  if activity == "help" then
    -- Helpers of any level may come help. They opt in by being available
    -- (any status except Not looking) or by the Can help flag.
    local willing = rec.canHelp or rec.status == "open"
      or (available and rec.status ~= "busy")
    if not willing then
      return false
    end
    local need = (self.GetHelpRequiredLevel and self:GetHelpRequiredLevel()) or level
    if peerLevel < need then
      return false
    end
    return true, shared
  end

  return false
end

function PC:GetGuildmateCards(mode)
  -- mode is ignored; lists always follow the viewer's current status.
  local activity = self.GetSocialStatus and self:GetSocialStatus() or "questing"
  if activity == "busy" then
    return {}
  end
  local level = self:PlayerLevel() or 1
  local peers = self:GetDisplayPeers()
  local needsList = self:GetPartyNeeds()
  local needs = { tank = false, healer = false, dps = false }
  for i = 1, #needsList do
    local n = string.lower(needsList[i])
    if n == "tank" then needs.tank = true end
    if n == "healer" then needs.healer = true end
    if n == "dps" then needs.dps = true end
  end
  local myZone = self.GetActivityZone and self:GetActivityZone() or (self.GetCurrentZoneName and self:GetCurrentZoneName()) or nil
  local cards = {}
  for i = 1, #peers do
    local rec = peers[i]
    local ok, shared = self:PeerMatchesActivity(rec, activity)
    if ok then
      local available = rec.available ~= false
      if self.PeerIsAvailable then
        available = self:PeerIsAvailable(rec)
      end
      local score
      if activity == "help" then
        local pl = tonumber(rec.level) or 0
        score = pl * 10
        if SameOrNearbyZone(self, rec) then
          score = score + 1000
        elseif myZone and rec.zone and string.lower(tostring(rec.zone)) == string.lower(tostring(myZone)) then
          score = score + 1000
        end
        shared = shared or SharedDungeons(self, rec)
      else
        score, shared = ScorePeer(self, rec, level, needs)
        if activity == "questing" and SameOrNearbyZone(self, rec) then
          score = (score or 0) + 25
        end
      end
      cards[#cards + 1] = {
        rec = rec,
        name = rec.name,
        level = rec.level,
        classFile = rec.classFile,
        role = rec.role or rec.guildRole or "dps",
        status = rec.status or "questing",
        zone = rec.zone,
        available = available,
        demo = rec.demo and true or false,
        dungeons = self:PeerDungeonList(rec),
        shared = shared or {},
        score = score,
        match = true,
      }
    end
  end
  table.sort(cards, function(a, b)
    if activity == "help" then
      local al, bl = tonumber(a.level) or 0, tonumber(b.level) or 0
      local aZone = SameOrNearbyZone(self, a.rec or a) and 1 or 0
      local bZone = SameOrNearbyZone(self, b.rec or b) and 1 or 0
      -- Higher-level helpers first, then same zone, then name.
      if al ~= bl then
        return al > bl
      end
      if aZone ~= bZone then
        return aZone > bZone
      end
      return (a.name or "") < (b.name or "")
    end
    if (a.score or 0) ~= (b.score or 0) then
      return (a.score or 0) > (b.score or 0)
    end
    return (a.name or "") < (b.name or "")
  end)
  return cards
end

-- ---------------------------------------------------------------------------
-- Demo guildmates. Never broadcast, never invited, clearly tagged.
-- ---------------------------------------------------------------------------

function PC:IsDemoGuildOn()
  local db = self.GetDB and self:GetDB() or nil
  return db and db.demoGuild and true or false
end

function PC:SetDemoGuild(on)
  local db = self.GetDB and self:GetDB() or nil
  if not db then
    return
  end
  db.demoGuild = on and true or false
  if not db.demoGuild then
    demoPeers = nil
    demoStamp = nil
  else
    self:RebuildDemoGuildmates(true)
  end
  if self.Refresh then
    self:Refresh()
  end
  if self.RefreshOptionsPanel then
    self:RefreshOptionsPanel()
  end
  if self.RefreshMiniTracker then
    self:RefreshMiniTracker()
  end
end

function PC:RebuildDemoGuildmates(force)
  local level = self:PlayerLevel() or 17
  local zone = (self.GetCurrentZoneName and self:GetCurrentZoneName()) or "Westfall"
  local stamp = tostring(level) .. ":" .. tostring(zone)
  if demoPeers and demoStamp == stamp and not force then
    return demoPeers
  end
  local chips = self:GetSelectedDungeons()
  if #chips == 0 then
    local options = self:GetLevelDungeons(level)
    for i = 1, math.min(2, #options) do
      chips[#chips + 1] = options[i].id
    end
  end
  local other = "stockade"
  if chips[1] == "stockade" then
    other = "deadmines"
  end
  local function D(name, classFile, role, lvl, status, where, available, dungeons, canHelp)
    return {
      name = name,
      classFile = classFile,
      role = role,
      guildRole = role,
      level = lvl,
      status = status,
      zone = where,
      available = available,
      online = true,
      dungeons = dungeons or {},
      demo = true,
      canHelp = canHelp and true or false,
      availExplicit = true,
      availLegacy = false,
      statusExplicit = true,
      version = self.VERSION,
    }
  end
  local near = math.max(1, level - 2)
  local mid = level
  local up = math.min(60, level + 3)
  demoPeers = {
    D("DemoAric", "WARRIOR", "tank", mid, "dungeon", zone, true, chips),
    D("DemoLira", "PRIEST", "healer", near, "dungeon", zone, true, chips),
    D("DemoNal", "MAGE", "dps", up, "questing", zone, true, chips),
    D("DemoTess", "ROGUE", "dps", mid, "help", zone, true, { chips[1] or "deadmines" }),
    D("DemoBram", "PALADIN", "healer", mid, "open", zone, true, chips, true),
    D("DemoKerr", "HUNTER", "dps", mid, "dungeon", "Westfall", true, { "deadmines" }),
    D("DemoShae", "DRUID", "tank", up, "dungeon", zone, true, chips),
    D("DemoWren", "WARLOCK", "dps", near, "questing", zone, true, { other }),
    D("DemoPia", "MAGE", "dps", mid, "questing", "Stormwind City", true, {}),
    D("DemoHolt", "WARRIOR", "tank", math.min(60, level + 20), "dungeon", "Stranglethorn Vale", true, { "zulfarrak" }),
    D("DemoFaye", "PRIEST", "healer", math.max(1, level - 8), "questing", "Elwynn Forest", false, { "deadmines" }),
    D("DemoCorin", "DRUID", "healer", mid, "busy", zone, false, chips),
    D("DemoHelga", "WARRIOR", "tank", 60, "questing", "Stormwind City", true, {}),
    D("DemoOtto", "PALADIN", "healer", 60, "busy", "Ironforge", false, {}, true),
  }
  demoStamp = stamp
  return demoPeers
end

function PC:GetDemoGuildmates()
  if not self:IsDemoGuildOn() then
    return {}
  end
  return self:RebuildDemoGuildmates() or {}
end

function PC:IsDemoPeer(name)
  if type(name) ~= "string" or name == "" then
    return false
  end
  if not self:IsDemoGuildOn() then
    return false
  end
  local demo = self:GetDemoGuildmates()
  local needle = string.lower(name)
  for i = 1, #demo do
    local n = demo[i] and demo[i].name
    if n and string.lower(n) == needle then
      return true
    end
  end
  return false
end

function PC:GetDisplayPeers()
  local real = self.GetGuildPeers and self:GetGuildPeers() or {}
  if not self:IsDemoGuildOn() then
    return real
  end
  local demo = self:GetDemoGuildmates()
  local out = {}
  for i = 1, #real do
    out[#out + 1] = real[i]
  end
  for i = 1, #demo do
    out[#out + 1] = demo[i]
  end
  return out
end

function PC:ResetCraftLanding()
  if self._uiResetCraft then
    return self:_uiResetCraft()
  end
  local db = self.GetDB and self:GetDB() or nil
  if db then
    if type(db.expanded) ~= "table" then
      db.expanded = {}
    end
    db.expanded["craft-unlearned"] = false
  end
end
