-- Philosopher's Codex UI
-- Clean, native-feeling layout on a dark surface, with a restrained
-- gold / emerald Alchemists identity. Built-in fonts and textures only.

local PC = PhilosophersCodex

local GOLD = { r = 0.831, g = 0.686, b = 0.216 }
local EMERALD = { r = 0.247, g = 0.749, b = 0.498 }
local TEXT = { r = 0.95, g = 0.95, b = 0.97 }
local SUB = { r = 0.56, g = 0.56, b = 0.60 }
local MUTED = { r = 0.48, g = 0.48, b = 0.52 }
local SURFACE = { r = 0.07, g = 0.07, b = 0.08 }
local CARD = { r = 0.12, g = 0.12, b = 0.13 }
local HAIRLINE = { r = 0.22, g = 0.22, b = 0.24 }
local DANGER = { r = 0.85, g = 0.70, b = 0.40 }

local FRAME_WIDTH = PC.FRAME_WIDTH or 460
local FRAME_HEIGHT = PC.FRAME_HEIGHT or 720
local MIN_W, MIN_H = PC.MIN_W or 400, PC.MIN_H or 560
local MAX_W, MAX_H = PC.MAX_W or 720, PC.MAX_H or 980

local TAB_NEXT, TAB_PATH, TAB_CRAFT, TAB_GEAR, TAB_GOALS, TAB_GUILD = "next", "path", "craft", "gear", "goals", "guild"

local ALCHEMY_ICON = "Interface\\Icons\\Trade_Alchemy"
local BAR_TEXTURE = "Interface\\TargetingFrame\\UI-StatusBar"
local SOLID = "Interface\\Buttons\\WHITE8X8"
local HIGHLIGHT = "Interface\\QuestFrame\\UI-QuestTitleHighlight"
local FRIZ = "Fonts\\FRIZQT__.TTF"
local TITLE_FONT = "Fonts\\MORPHEUS.TTF"
local MASK_A = "Interface\\CharacterFrame\\TempPortraitAlphaMask"
local MASK_B = "Interface\\Minimap\\UI-Minimap-Background"

local ZONE_ICON = "Interface\\Icons\\INV_Misc_Map_01"
local DUNGEON_ICON = "Interface\\Icons\\INV_Misc_ShadowEgg"
local QUEST_ICON = "Interface\\GossipFrame\\AvailableQuestIcon"

local function ClassIcon(key)
  if PC.ClassIcon then
    return PC:ClassIcon(key)
  end
  if key == "zones" then
    return ZONE_ICON
  end
  if key == "dungeons" then
    return DUNGEON_ICON
  end
  if key == "quests" then
    return QUEST_ICON
  end
  return ALCHEMY_ICON
end

local function SpellIcon(spell)
  if PC.SpellIcon then
    return PC:SpellIcon(spell)
  end
  return ClassIcon("spells")
end

local function AccentColor()
  if PC.HasClassColor and PC:HasClassColor() and PC.ClassColor then
    local r, g, b = PC:ClassColor()
    return { r = r, g = g, b = b }
  end
  return EMERALD
end

local function ApplyPathIcon(tex, path, crop)
  if not tex or not path then
    return false
  end
  crop = crop or 0.08
  if tex.SetTexCoord then
    tex:SetTexCoord(crop, 1 - crop, crop, 1 - crop)
  end
  if tex.SetVertexColor then
    tex:SetVertexColor(1, 1, 1, 1)
  end
  if tex.SetTexture then
    tex:SetTexture(path)
  end
  return true
end

local ui = {
  created = false,
  tab = TAB_NEXT,
  rows = {},
}

-- ---------------------------------------------------------------------------
-- Fonts and small drawing helpers
-- ---------------------------------------------------------------------------

local function ApplyFont(fs, size, flags)
  if not fs then
    return
  end
  -- Always attach a built-in font object first. CreateFontString without an
  -- inherit font, then SetText, raises "Font not set" on Mainline-family clients.
  if fs.SetFontObject then
    local obj
    if size and size >= 16 then
      obj = GameFontNormalLarge
    elseif size and size <= 11 then
      obj = GameFontNormalSmall
    else
      obj = GameFontHighlight
    end
    if obj then
      pcall(fs.SetFontObject, fs, obj)
    end
  end
  if fs.SetFont then
    pcall(fs.SetFont, fs, FRIZ, size or 13, flags or "")
  end
end

local function MakeFontString(parent, size, inherit, layer)
  local fs = parent:CreateFontString(nil, layer or "ARTWORK", inherit or "GameFontHighlight")
  ApplyFont(fs, size or 13)
  return fs
end

local function TryTitleFont(fs, size)
  if not fs then
    return
  end
  ApplyFont(fs, size or 18)
  if fs.SetFont then
    pcall(fs.SetFont, fs, TITLE_FONT, size or 18, "")
  end
end

local function Paint(tex, color, a)
  tex:SetTexture(SOLID)
  tex:SetVertexColor(color.r, color.g, color.b, a or 1)
end

local function ApplyCircleMask(texture, owner)
  if not texture then
    return nil
  end
  if texture._circleMask then
    return texture._circleMask
  end
  local host = owner or texture:GetParent()
  if not host or not host.CreateMaskTexture then
    return nil
  end
  local ok, mask = pcall(host.CreateMaskTexture, host)
  if not ok or not mask then
    return nil
  end
  pcall(mask.SetTexture, mask, MASK_A)
  if mask.GetTexture and not mask:GetTexture() then
    pcall(mask.SetTexture, mask, MASK_B)
  end
  if mask.SetAllPoints then
    pcall(mask.SetAllPoints, mask, texture)
  end
  if texture.AddMaskTexture then
    pcall(texture.AddMaskTexture, texture, mask)
    texture._circleMask = mask
    return mask
  end
  return nil
end

PC.ApplyCircleMask = ApplyCircleMask

local function ContentWidth()
  if ui.splitListW then
    return math.max(280, ui.splitListW - 2)
  end
  if ui.scroll and ui.scroll.GetWidth then
    local w = ui.scroll:GetWidth()
    if w and w > 0 then
      return math.max(280, w - 2)
    end
  end
  if ui.frame then
    return math.max(280, ui.frame:GetWidth() - 24)
  end
  return FRAME_WIDTH - 24
end

local function CreateFillBar(parent, width, height)
  local bar = CreateFrame("StatusBar", nil, parent)
  bar:SetSize(width, height)
  bar:SetMinMaxValues(0, 1)
  bar:SetValue(0)
  bar:SetStatusBarTexture(BAR_TEXTURE)
  bar:SetStatusBarColor(EMERALD.r, EMERALD.g, EMERALD.b)
  local tex = bar:GetStatusBarTexture()
  if tex and tex.SetHorizTile then
    tex:SetHorizTile(false)
  end
  local bg = bar:CreateTexture(nil, "BACKGROUND")
  bg:SetAllPoints()
  Paint(bg, { r = 0.18, g = 0.18, b = 0.20 }, 1)
  return bar
end

local function SetBarProgress(bar, done, total)
  if not bar then
    return
  end
  local maxv = total or 0
  local cur = done or 0
  if maxv <= 0 then
    bar:SetMinMaxValues(0, 1)
    bar:SetValue(0)
  else
    bar:SetMinMaxValues(0, maxv)
    bar:SetValue(cur)
  end
  -- rawget: the headless mock plants dummy functions for missing keys.
  local label = rawget(bar, "label")
  if label and label.SetText then
    if maxv <= 0 then
      label:SetText("0%")
    else
      local pct = math.floor((cur / maxv) * 100 + 0.5)
      label:SetText(cur .. " / " .. maxv .. "  ·  " .. pct .. "%")
    end
  end
end

-- ---------------------------------------------------------------------------
-- Filter helpers
-- ---------------------------------------------------------------------------

local function Query()
  return PC:GetSearchQuery() or ""
end

local function Searching()
  return Query() ~= ""
end

local function Matches(completed, ...)
  if PC:IsHideCompleted() and completed then
    return false
  end
  return PC:TextMatches(Query(), ...)
end

local function DungeonMatches(d)
  if not d then
    return false
  end
  if Matches(PC:IsDungeonChecked(d.id), d.name, d.note, d.range) then
    return true
  end
  local quests = PC:GetQuestList(d.id)
  if quests then
    for i = 1, #quests do
      local q = quests[i]
      if Matches(PC:IsQuestChecked(d.id, q), q.name, q.giver, q.where) then
        return true
      end
    end
  end
  local loot = PC:GetLootForDungeon(d.id)
  if loot then
    for i = 1, #loot do
      local it = loot[i]
      local owned = false
      if it.itemID then
        owned = PC:PlayerHasGearItem({ itemID = it.itemID, name = it.name })
      elseif it.name then
        owned = PC:PlayerHasItemByName(it.name)
      end
      if Matches(owned, it.name, it.boss, it.slot) then
        return true
      end
    end
  end
  return false
end

-- ---------------------------------------------------------------------------
-- Row factory (iOS-style list rows)
-- ---------------------------------------------------------------------------

local function HideGuildExtras()
  if ui.guildStrip then
    ui.guildStrip:Hide()
  end
  if ui.guildMyCard then
    ui.guildMyCard:Hide()
  end
  if ui.guildBar then
    ui.guildBar:Hide()
  end
  if ui.guildHint then
    ui.guildHint:Hide()
  end
  if ui.guildChips then
    for i = 1, #ui.guildChips do
      ui.guildChips[i]:Hide()
    end
  end
  if ui.guildCards then
    for i = 1, #ui.guildCards do
      ui.guildCards[i]:Hide()
    end
  end
  if ui.dropMenu then
    ui.dropMenu:Hide()
  end
  if ui.noteEditor then
    ui.noteEditor:Hide()
  end
  if ui.guildStatusRow then
    ui.guildStatusRow:Hide()
  end
  if ui.guildContext then
    ui.guildContext:Hide()
  end
  if ui.guildHidden then
    ui.guildHidden:Hide()
  end
  if ui.guildZoneChips then
    for i = 1, #ui.guildZoneChips do
      ui.guildZoneChips[i]:Hide()
    end
  end
end

local function StripRows()
  for i = 1, table.maxn(ui.rows) do
    local stripRow = ui.rows[i]
    if stripRow then
      ui.rows[i]:Hide()
      if ui.rows[i].SetAlpha then
        ui.rows[i]:SetAlpha(1)
      end
      if ui.rows[i].icon then
        ui.rows[i].icon:Hide()
      end
    end
  end
  if ui.StripBands then
    ui.StripBands()
  end
  HideGuildExtras()
end

local function HideTooltip()
  if GameTooltip then
    GameTooltip:Hide()
  end
end

local function ShowRowTooltip(owner, lines)
  if not GameTooltip or not owner or not lines then
    return
  end
  GameTooltip:SetOwner(owner, "ANCHOR_LEFT")
  for i = 1, #lines do
    local line = lines[i]
    if type(line) == "table" then
      GameTooltip:AddLine(line[1], line[2] or TEXT.r, line[3] or TEXT.g, line[4] or TEXT.b, true)
    else
      GameTooltip:AddLine(line, SUB.r, SUB.g, SUB.b, true)
    end
  end
  GameTooltip:Show()
end

local function MakeRowAction(row, label, width)
  local b = CreateFrame("Button", nil, row)
  b:SetSize(width or 40, 22)
  b.bg = b:CreateTexture(nil, "BACKGROUND")
  b.bg:SetAllPoints()
  Paint(b.bg, { r = 0.18, g = 0.18, b = 0.20 }, 1)
  if PC._RoundifyButton then PC._RoundifyButton(b) end
  b.label = MakeFontString(b, 11, "GameFontNormalSmall")
  b.label:SetPoint("CENTER")
  b.label:SetText(label)
  b.label:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
  b:Hide()
  b:SetScript("OnLeave", HideTooltip)
  return b
end

-- A texture-like stand-in that applies calls to every piece of a rounded fill.
local CARDS = { gap = 4, r = 7 }
local PANE, DETAIL -- detail pane (defined with the pane code below)
-- 1.23.0: filter chips are outlined and square-cornered so they never
-- read as the top tab pills.
function CARDS.ChipEdges(btn)
  if rawget(btn, "edges") then
    return btn.edges
  end
  local e = {}
  for i = 1, 4 do
    e[i] = btn:CreateTexture(nil, "BORDER")
  end
  e[1]:SetPoint("TOPLEFT", btn, "TOPLEFT", 0, 0); e[1]:SetPoint("TOPRIGHT", btn, "TOPRIGHT", 0, 0); e[1]:SetHeight(1)
  e[2]:SetPoint("BOTTOMLEFT", btn, "BOTTOMLEFT", 0, 0); e[2]:SetPoint("BOTTOMRIGHT", btn, "BOTTOMRIGHT", 0, 0); e[2]:SetHeight(1)
  e[3]:SetPoint("TOPLEFT", btn, "TOPLEFT", 0, 0); e[3]:SetPoint("BOTTOMLEFT", btn, "BOTTOMLEFT", 0, 0); e[3]:SetWidth(1)
  e[4]:SetPoint("TOPRIGHT", btn, "TOPRIGHT", 0, 0); e[4]:SetPoint("BOTTOMRIGHT", btn, "BOTTOMRIGHT", 0, 0); e[4]:SetWidth(1)
  btn.edges = e
  return e
end
function CARDS.ChipStyle(btn, on, accent)
  local e = CARDS.ChipEdges(btn)
  local c = on and accent or { r = 0.38, g = 0.38, b = 0.42 }
  for i = 1, 4 do
    e[i]:SetColorTexture(c.r, c.g, c.b, on and 0.95 or 0.7)
  end
  if on then
    Paint(btn.bg, { r = accent.r * 0.16, g = accent.g * 0.16, b = accent.b * 0.16 }, 1)
    btn.label:SetTextColor(accent.r, accent.g, accent.b)
  else
    Paint(btn.bg, { r = 0.07, g = 0.07, b = 0.08 }, 0.6)
    btn.label:SetTextColor(SUB.r, SUB.g, SUB.b)
  end
end
CARDS.chipH = 20
-- 1.23.0: a drawn map pin (round head, pointed tip) instead of the map icon.
function PC._DrawPin(btn, size)
  size = size or 20
  local head = btn:CreateTexture(nil, "ARTWORK")
  local hs = math.floor(size * 0.62)
  head:SetSize(hs, hs)
  head:SetPoint("TOP", btn, "TOP", 0, -1)
  head:SetColorTexture(0.86, 0.22, 0.20, 1)
  ApplyCircleMask(head, btn)
  local tip = btn:CreateTexture(nil, "BORDER")
  local ts = math.floor(hs * 0.62)
  tip:SetSize(ts, ts)
  tip:SetPoint("CENTER", head, "BOTTOM", 0, -math.floor(ts * 0.15))
  tip:SetColorTexture(0.70, 0.16, 0.15, 1)
  if tip.SetRotation then pcall(tip.SetRotation, tip, math.pi / 4) end
  local dot = btn:CreateTexture(nil, "OVERLAY")
  local ds = math.max(3, math.floor(hs * 0.36))
  dot:SetSize(ds, ds)
  dot:SetPoint("CENTER", head, "CENTER", 0, 0)
  dot:SetColorTexture(1, 0.93, 0.85, 1)
  ApplyCircleMask(dot, btn)
  btn.pinParts = { head, tip, dot }
  return head
end
function CARDS.Proxy(fill)
  local parts = {}
  for i = 1, #fill.fill do parts[#parts + 1] = fill.fill[i] end
  for _, t in pairs(fill.fillCorners) do parts[#parts + 1] = t end
  local proxy = { _parts = parts, _shown = true }
  local function each(method)
    return function(self, ...)
      for i = 1, #parts do
        local fn = parts[i][method]
        if fn then fn(parts[i], ...) end
      end
    end
  end
  proxy.SetTexture = each("SetTexture")
  proxy.SetVertexColor = each("SetVertexColor")
  proxy.SetAlpha = each("SetAlpha")
  proxy.SetAllPoints = function() end
  proxy.Show = function(self) self._shown = true each("Show")(self) end
  proxy.Hide = function(self) self._shown = false each("Hide")(self) end
  proxy.IsShown = function(self) return self._shown end
  return proxy
end


local function AcquireRow(index)
  if ui.rows[index] then
    return ui.rows[index]
  end
  local row = CreateFrame("Frame", nil, ui.content)
  row:EnableMouse(true)

  -- 1.19.1: rows are rounded cards. row.bg forwards to the card's pieces so
  -- every existing Paint(row.bg, ...) (hover, tint, press) still works.
  if PC.BuildRoundFill then
    pcall(function()
      row.card = PC:BuildRoundFill(row, CARD, 1, "BACKGROUND", 0)
      row.rim = PC:BuildRoundFill(row, GOLD, 1, "BACKGROUND", -1)
      PC:ShowRoundFill(row.rim, false)
    end)
  end
  if row.card then
    row.bg = CARDS.Proxy(row.card)
  else
    row.bg = row:CreateTexture(nil, "BACKGROUND")
    row.bg:SetAllPoints()
  end
  Paint(row.bg, CARD, 1)

  row.sep = row:CreateTexture(nil, "ARTWORK")
  row.sep:SetHeight(1)
  row.sep:SetPoint("BOTTOMLEFT", 52, 0)
  row.sep:SetPoint("BOTTOMRIGHT", 0, 0)
  Paint(row.sep, HAIRLINE, 0.9)

  row.hl = row:CreateTexture(nil, "HIGHLIGHT")
  if row.card then
    row.hl:SetPoint("TOPLEFT", row, "TOPLEFT", CARDS.r, -1)
    row.hl:SetPoint("BOTTOMRIGHT", row, "BOTTOMRIGHT", -CARDS.r, 1)
  else
    row.hl:SetAllPoints()
  end
  row.hl:SetTexture(HIGHLIGHT)
  if row.hl.SetBlendMode then
    row.hl:SetBlendMode("ADD")
  end
  row.hl:SetAlpha(0)

  row.icon = row:CreateTexture(nil, "ARTWORK")
  row.icon:SetSize(28, 28)
  row.icon:SetPoint("LEFT", 12, 0)
  row.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
  ApplyCircleMask(row.icon, row)
  row.icon:Hide()

  row.title = MakeFontString(row, 13)
  row.title:SetJustifyH("LEFT")
  row.title:SetJustifyV("TOP")
  row.title:SetTextColor(TEXT.r, TEXT.g, TEXT.b)

  row.meta = MakeFontString(row, 11, "GameFontNormalSmall")
  row.meta:SetJustifyH("LEFT")
  row.meta:SetJustifyV("TOP")
  row.meta:SetTextColor(SUB.r, SUB.g, SUB.b)

  row.note = MakeFontString(row, 11, "GameFontHighlightSmall")
  row.note:SetJustifyH("LEFT")
  row.note:SetJustifyV("TOP")
  row.note:SetTextColor(SUB.r, SUB.g, SUB.b)

  row.accent = row:CreateTexture(nil, "ARTWORK")
  row.accent:SetWidth(3)
  row.accent:SetPoint("TOPLEFT", 0, 0)
  row.accent:SetPoint("BOTTOMLEFT", 0, 0)
  Paint(row.accent, EMERALD, 1)
  row.accent:Hide()

  row.bar = CreateFillBar(row, 120, 6)
  row.bar:Hide()

  row.tag = MakeFontString(row, 10, "GameFontNormalSmall")
  row.tag:SetTextColor(EMERALD.r, EMERALD.g, EMERALD.b)
  row.tag:SetJustifyH("RIGHT")
  row.tag:Hide()

  -- 1.23.0: a square checkbox (outline, dark box, green fill + tick when done).
  local check = CreateFrame("Button", nil, row)
  check:SetSize(24, 24)
  check.bg = check:CreateTexture(nil, "BACKGROUND")
  check.bg:SetPoint("CENTER", 0, 0)
  check.bg:SetSize(18, 18)
  Paint(check.bg, { r = 1, g = 1, b = 1 }, 1)
  check.box = check:CreateTexture(nil, "BORDER")
  check.box:SetPoint("TOPLEFT", check.bg, "TOPLEFT", 2, -2)
  check.box:SetPoint("BOTTOMRIGHT", check.bg, "BOTTOMRIGHT", -2, 2)
  Paint(check.box, { r = 0.06, g = 0.06, b = 0.07 }, 1)
  check.fill = check:CreateTexture(nil, "ARTWORK")
  check.fill:SetPoint("TOPLEFT", check.bg, "TOPLEFT", 0, 0)
  check.fill:SetPoint("BOTTOMRIGHT", check.bg, "BOTTOMRIGHT", 0, 0)
  Paint(check.fill, EMERALD, 1)
  check.tick = check:CreateTexture(nil, "OVERLAY")
  check.tick:SetSize(20, 20)
  check.tick:SetPoint("CENTER", 1, 0)
  check.tick:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
  check.tick:SetVertexColor(1, 1, 1, 1)
  check:Hide()
  check:SetScript("OnClick", function(self)
    if self.onToggle then
      self.onToggle(not self.checked)
    end
  end)
  check:SetScript("OnEnter", function(self)
    if self.tip then
      ShowRowTooltip(self, self.tip)
    end
  end)
  check:SetScript("OnLeave", HideTooltip)
  row.check = check

  row.chevron = MakeFontString(row, 16, "GameFontHighlight")
  row.chevron:SetTextColor(MUTED.r, MUTED.g, MUTED.b)
  row.chevron:SetPoint("LEFT", 10, 0)
  row.chevron:Hide()

  row.guide = row:CreateTexture(nil, "ARTWORK")
  row.guide:SetWidth(2)
  Paint(row.guide, { r = 0.28, g = 0.28, b = 0.32 }, 0.9)
  row.guide:Hide()

  row.countBadge = MakeFontString(row, 10, "GameFontNormalSmall")
  row.countBadge:SetTextColor(MUTED.r, MUTED.g, MUTED.b)
  row.countBadge:SetJustifyH("RIGHT")
  row.countBadge:Hide()

  local pin = CreateFrame("Button", nil, row)
  pin:SetSize(22, 22)
  pin:SetPoint("RIGHT", -10, 0)
  pin.icon = PC._DrawPin(pin, 22)
  pin:Hide()
  pin:SetScript("OnClick", function(self)
    if self.waypoint and PC.SetWaypoint then
      PC:SetWaypoint(self.waypoint)
    end
  end)
  pin:SetScript("OnEnter", function(self)
    if not self.waypoint then
      return
    end
    local wp = self.waypoint
    local label = wp.title or "Waypoint"
    if wp.x and wp.y then
      label = label .. string.format("  (%.1f, %.1f)", wp.x, wp.y)
    end
    ShowRowTooltip(self, {
      { "Set a map pin", GOLD.r, GOLD.g, GOLD.b },
      label,
      "Places the game waypoint if that API exists, and a TomTom waypoint if TomTom is loaded.",
    })
  end)
  pin:SetScript("OnLeave", HideTooltip)
  row.pin = pin

  row.whisper = MakeRowAction(row, "Whisper", 56)
  row.whisper:SetScript("OnClick", function(self)
    if self.peerName and PC.WhisperPeer then
      PC:WhisperPeer(self.peerName, self.whisperText)
    end
  end)
  row.whisper:SetScript("OnEnter", function(self)
    if self.peerName then
      ShowRowTooltip(self, { { "Whisper " .. self.peerName, GOLD.r, GOLD.g, GOLD.b }, "Opens a tell to this guildmate." })
    end
  end)

  row.invite = MakeRowAction(row, "Invite", 46)
  row.invite:SetScript("OnClick", function(self)
    if self.peerName and PC.InvitePeer then
      PC:InvitePeer(self.peerName)
    end
  end)
  row.invite:SetScript("OnEnter", function(self)
    if self.peerName then
      ShowRowTooltip(self, { { "Invite " .. self.peerName, GOLD.r, GOLD.g, GOLD.b }, "Sends a group invite. This only happens when you tap the button." })
    end
  end)

  row.ask = MakeRowAction(row, "Ask", 40)
  row.ask:SetScript("OnClick", function(self)
    if self.peerName and PC.SendJoinRequest then
      PC:SendJoinRequest(self.peerName, self.askWhy)
    end
  end)
  row.ask:SetScript("OnEnter", function(self)
    if self.peerName then
      ShowRowTooltip(self, { { "Ask to join " .. self.peerName, GOLD.r, GOLD.g, GOLD.b }, "Sends a Codex request. They get Accept (invites you, click-only) or Decline." })
    end
  end)

  row.accept = MakeRowAction(row, "Accept", 54)
  row.accept:SetScript("OnClick", function(self)
    if self.peerName and PC.AcceptJoinRequest then
      PC:AcceptJoinRequest(self.peerName)
    end
  end)
  row.decline = MakeRowAction(row, "Decline", 56)
  row.decline:SetScript("OnClick", function(self)
    if self.peerName and PC.DeclineJoinRequest then
      PC:DeclineJoinRequest(self.peerName)
    end
  end)

  row:SetScript("OnEnter", function(self)
    self.hl:SetAlpha(self.useHighlight and 0.35 or 0)
    if self.itemID then
      PC:ShowItemTooltip(self, self.itemID)
    elseif self.tip then
      ShowRowTooltip(self, self.tip)
    end
  end)
  row:SetScript("OnLeave", function(self)
    self.hl:SetAlpha(0)
    HideTooltip()
  end)

  ui.rows[index] = row
  return row
end

local function PlaceRow(row, y, height)
  -- 1.23.0: whole pixels so the 2px gold rim never snaps away on one edge.
  y = math.floor((y or 0) + 0.5)
  height = math.floor((height or 0) + 0.5)
  row:ClearAllPoints()
  row:SetPoint("TOPLEFT", ui.content, "TOPLEFT", 0, -y)
  row:SetWidth(math.floor(ContentWidth()))
  row:SetHeight(height)
  row:Show()
  if row.card and PC.LayoutRoundFill then
    pcall(PC.LayoutRoundFill, PC, row.card, row, CARDS.r, 2)
    pcall(PC.LayoutRoundFill, PC, row.rim, row, CARDS.r + 1, 0)
    if not row.bg._shown then
      row.bg:Hide()
    end
    if not row._selected then
      PC:ShowRoundFill(row.rim, false)
    end
    return y + height + CARDS.gap
  end
  return y + height
end

local function SetCheckVisual(check, checked)
  check.checked = checked and true or false
  if check.checked then
    check.fill:Show()
    check.tick:Show()
    check.bg:SetVertexColor(EMERALD.r, EMERALD.g, EMERALD.b, 1)
  else
    check.fill:Hide()
    check.tick:Hide()
    check.bg:SetVertexColor(0.55, 0.55, 0.60, 1)
  end
end

local function ResetRow(row)
  row.itemID = nil
  row.useHighlight = false
  row.tip = nil
  row.hl:SetAlpha(0)
  row.bg:Show()
  Paint(row.bg, CARD, 1)
  if row.card then
    row.sep:Hide()
    row._selected = false
    PC:ShowRoundFill(row.rim, false)
  else
    row.sep:Show()
  end
  row.icon:Hide()
  row.meta:SetText("")
  row.note:SetText("")
  row.title:SetText("")
  row.title:ClearAllPoints()
  row.meta:ClearAllPoints()
  row.note:ClearAllPoints()
  ApplyFont(row.title, 13)
  ApplyFont(row.meta, 11)
  row.title:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
  row.meta:SetTextColor(SUB.r, SUB.g, SUB.b)
  row.check:Hide()
  row.check.onToggle = nil
  row.check.tip = nil
  row.chevron:Hide()
  row._trailLeft = nil
  row._trailReserve = nil
  row._trailOpts = nil
  row._titleText = nil
  row._metaText = nil
  row._noteText = nil
  if row.title and row.title.SetWidth then
    row.title:SetWidth(40)
  end
  if row.meta and row.meta.SetWidth then
    row.meta:SetWidth(40)
  end
  if row.note and row.note.SetWidth then
    row.note:SetWidth(40)
  end
  if rawget(row, "trailChevron") then
    rawget(row, "trailChevron"):Hide()
  end
  if rawget(row, "countPill") then
    rawget(row, "countPill"):Hide()
  end
  if rawget(row, "demoTag") then
    rawget(row, "demoTag"):Hide()
  end
  if rawget(row, "guide") then
    rawget(row, "guide"):Hide()
    rawget(row, "guide"):ClearAllPoints()
  end
  if rawget(row, "countBadge") then
    rawget(row, "countBadge"):Hide()
    rawget(row, "countBadge"):SetText("")
    rawget(row, "countBadge"):ClearAllPoints()
  end
  if row.pin then
    row.pin:Hide()
    row.pin.waypoint = nil
    row.pin:ClearAllPoints()
    row.pin:SetPoint("RIGHT", -10, 0)
  end
  if row.whisper then
    row.whisper:Hide()
    row.whisper.peerName = nil
  end
  if row.invite then
    row.invite:Hide()
    row.invite.peerName = nil
  end
  if row.ask then
    row.ask:Hide()
    row.ask.peerName = nil
    row.ask.askWhy = nil
  end
  if row.accept then
    row.accept:Hide()
    row.accept.peerName = nil
  end
  if row.decline then
    row.decline:Hide()
    row.decline.peerName = nil
  end
  if row.whisper then
    row.whisper.whisperText = nil
  end
  -- rawget: the headless mock plants dummy functions for missing keys.
  if rawget(row, "guildBits") then
    rawget(row, "levelBadge"):Hide()
    rawget(row, "roleTex"):Hide()
    rawget(row, "roleLetter"):Hide()
    rawget(row, "statusDot"):Hide()
    rawget(row, "locIcon"):Hide()
    rawget(row, "chip1"):Hide()
    rawget(row, "chip2"):Hide()
  end
  if rawget(row, "moreBtn") then
    rawget(row, "moreBtn"):Hide()
  end
  if rawget(row, "accent") then
    rawget(row, "accent"):Hide()
  end
  if rawget(row, "bar") then
    rawget(row, "bar"):Hide()
    rawget(row, "bar"):ClearAllPoints()
  end
  if rawget(row, "tag") then
    rawget(row, "tag"):Hide()
    rawget(row, "tag"):SetText("")
  end
  row:SetScript("OnMouseUp", nil)
end

local Row = {}
local TRAIL_GAP = 4
local TRAIL_PAD = 10
local PARENT_H = 32
local CHILD_H = 24

function Row.MeasureText(fs, text, pad)
  pad = pad or 0
  if fs and text and fs.SetText then
    fs:SetText(text)
  end
  if fs and fs.GetStringWidth then
    local ok, w = pcall(fs.GetStringWidth, fs)
    if ok and type(w) == "number" then
      return math.max(0, w) + pad
    end
  end
  return (#(text or "") * 7) + pad
end

function Row.TryAtlas(tex, name)
  if not tex or not tex.SetAtlas or not (C_Texture and C_Texture.GetAtlasInfo) then
    return false
  end
  local okInfo, info = pcall(C_Texture.GetAtlasInfo, name)
  if okInfo and type(info) == "table" then
    return pcall(tex.SetAtlas, tex, name)
  end
  return false
end

function Row.EnsureTrailChevron(row)
  local existing = rawget(row, "trailChevron")
  if existing then
    return existing
  end
  local c = CreateFrame("Frame", nil, row)
  c:SetSize(12, 12)
  c.tex = c:CreateTexture(nil, "ARTWORK")
  c.tex:SetSize(10, 10)
  c.tex:SetPoint("CENTER", 0, 0)
  c.a = c:CreateTexture(nil, "ARTWORK")
  c.a:SetSize(7, 2)
  Paint(c.a, MUTED, 1)
  c.b = c:CreateTexture(nil, "ARTWORK")
  c.b:SetSize(7, 2)
  Paint(c.b, MUTED, 1)
  c.glyph = MakeFontString(c, 12, "GameFontHighlight")
  c.glyph:SetPoint("CENTER", 1, 0)
  c.glyph:SetTextColor(MUTED.r, MUTED.g, MUTED.b)
  row.trailChevron = c
  return c
end

function Row.SetChevronState(chev, expanded)
  if not chev then
    return
  end
  local atlas = expanded and "common-icon-dropdownarrow" or "common-icon-forwardarrow"
  local usedAtlas = Row.TryAtlas(chev.tex, atlas)
  if not usedAtlas then
    usedAtlas = Row.TryAtlas(chev.tex, expanded and "common-icon-backarrow" or "common-icon-forwardarrow")
  end
  if usedAtlas then
    chev.tex:Show()
    if chev.tex.SetRotation then
      -- Forward arrow points right; rotate to point down when expanded.
      pcall(chev.tex.SetRotation, chev.tex, expanded and (math.pi / 2) or 0)
    end
    chev.a:Hide()
    chev.b:Hide()
    chev.glyph:Hide()
    return
  end
  chev.tex:Hide()
  -- Two short line textures form a thin chevron. Prefer SetRotation;
  -- otherwise place them as a right (>) or down (v) arrow.
  local muted = MUTED
  Paint(chev.a, muted, 1)
  Paint(chev.b, muted, 1)
  if chev.a.SetRotation and chev.b.SetRotation then
    chev.a:ClearAllPoints()
    chev.b:ClearAllPoints()
    chev.a:SetPoint("CENTER", chev, "CENTER", 0, 0)
    chev.b:SetPoint("CENTER", chev, "CENTER", 0, 0)
    if expanded then
      pcall(chev.a.SetRotation, chev.a, 0.7)
      pcall(chev.b.SetRotation, chev.b, -0.7)
    else
      pcall(chev.a.SetRotation, chev.a, -0.7)
      pcall(chev.b.SetRotation, chev.b, 0.7)
    end
    chev.a:Show()
    chev.b:Show()
    chev.glyph:Hide()
    return
  end
  chev.a:ClearAllPoints()
  chev.b:ClearAllPoints()
  if expanded then
    chev.a:SetSize(7, 2)
    chev.b:SetSize(7, 2)
    chev.a:SetPoint("CENTER", chev, "CENTER", -2, 1)
    chev.b:SetPoint("CENTER", chev, "CENTER", 2, 1)
  else
    chev.a:SetSize(2, 7)
    chev.b:SetSize(2, 7)
    chev.a:SetPoint("CENTER", chev, "CENTER", -1, 2)
    chev.b:SetPoint("CENTER", chev, "CENTER", -1, -2)
  end
  chev.a:Show()
  chev.b:Show()
  chev.glyph:SetText(expanded and "v" or ">")
  chev.glyph:Hide()
end

function Row.EnsureCountPill(row)
  local existing = rawget(row, "countPill")
  if existing then
    return existing
  end
  local p = CreateFrame("Frame", nil, row)
  p:SetHeight(16)
  p.bg = p:CreateTexture(nil, "BACKGROUND")
  p.bg:SetAllPoints()
  Paint(p.bg, { r = 0.18, g = 0.18, b = 0.20 }, 1)
  p.label = MakeFontString(p, 10, "GameFontNormalSmall")
  p.label:SetPoint("CENTER", 0, 0)
  p.label:SetTextColor(MUTED.r, MUTED.g, MUTED.b)
  row.countPill = p
  return p
end

function Row.HideTrailAccessories(row)
  -- Use rawget so a missing accessory is not turned into a dummy method
  -- by a test mock (or any __index helper).
  local function hide(key)
    local f = rawget(row, key)
    if f and f.Hide then
      f:Hide()
    end
  end
  hide("check")
  hide("pin")
  hide("whisper")
  hide("invite")
  hide("ask")
  hide("accept")
  hide("decline")
  if rawget(row, "moreBtn") then
    rawget(row, "moreBtn"):Hide()
  end
  if rawget(row, "tag") then
    row.tag:Hide()
  end
  if rawget(row, "countBadge") then
    row.countBadge:Hide()
  end
  if rawget(row, "countPill") then
    row.countPill:Hide()
  end
  if rawget(row, "trailChevron") then
    row.trailChevron:Hide()
  end
  if rawget(row, "demoTag") then
    row.demoTag:Hide()
  end
  -- Left-side glyph from earlier versions is never shown.
  if row.chevron then
    row.chevron:Hide()
  end
end

-- Single shared right-to-left trail. Each visible accessory is anchored to
-- the LEFT of the previous (rightmost) one. Hidden frames reserve no space.
-- Returns the leftmost visible accessory (or nil) and the reserved width
-- from the row's right edge to the left of that accessory.
function Row.LayoutRowTrail(row, opts)
  opts = opts or {}
  Row.HideTrailAccessories(row)
  local items = {}

  local function add(frame, width, shown)
    if frame and shown and width and width > 0 then
      items[#items + 1] = { frame = frame, width = width }
    elseif frame then
      frame:Hide()
    end
  end

  -- Rightmost first: parent chevron, count pill, checks, pins, actions, tags.
  if opts.chevron or (opts.kind == "parent" or opts.parent) then
    local c = Row.EnsureTrailChevron(row)
    Row.SetChevronState(c, opts.expanded)
    add(c, 12, true)
  end

  if opts.count ~= nil and opts.count ~= false then
    local p = Row.EnsureCountPill(row)
    local text = tostring(opts.count)
    p.label:SetText(text)
    p.label:SetTextColor(MUTED.r, MUTED.g, MUTED.b)
    local w = math.max(18, Row.MeasureText(p.label, text, 10))
    p:SetWidth(w)
    p:SetHeight(16)
    add(p, w, true)
  end

  if opts.checkable and rawget(row, "check") then
    SetCheckVisual(row.check, opts.checked)
    row.check.onToggle = opts.onClick
    row.check.tip = opts.checkTip or { { "Mark done", GOLD.r, GOLD.g, GOLD.b }, "Tick the box when this is done." }
    add(row.check, 24, true)
  end

  if opts.waypoint and opts.waypoint.uiMapID and opts.waypoint.x and rawget(row, "pin") then
    row.pin.waypoint = opts.waypoint
    add(row.pin, 22, true)
  end

  if opts.decline and rawget(row, "decline") then
    row.decline.peerName = opts.decline
    add(row.decline, opts.declineWidth or 56, true)
  end
  if opts.accept and rawget(row, "accept") then
    row.accept.peerName = opts.accept
    add(row.accept, opts.acceptWidth or 54, true)
  end
  if opts.ask and rawget(row, "ask") then
    row.ask.peerName = opts.ask
    row.ask.askWhy = opts.askWhy
    add(row.ask, opts.askWidth or 40, true)
  end
  if opts.whisper and rawget(row, "whisper") then
    row.whisper.peerName = opts.whisper
    row.whisper.whisperText = opts.whisperText
    add(row.whisper, opts.whisperWidth or 56, true)
  end
  if opts.invite and rawget(row, "invite") then
    row.invite.peerName = opts.invite
    add(row.invite, opts.inviteWidth or 46, true)
  end

  -- Extra frames already configured by the caller (guild actions, badges).
  local extras = opts.trail or opts.extras
  if type(extras) == "table" then
    for i = 1, #extras do
      local ex = extras[i]
      if type(ex) == "table" and ex.frame then
        add(ex.frame, ex.width or 16, ex.shown ~= false)
      elseif ex then
        local w = 16
        if ex.GetWidth then
          w = ex:GetWidth() or 16
        end
        add(ex, w, true)
      end
    end
  end

  local tagText = opts.tag or (opts.demo and "Demo") or nil
  if tagText and tagText ~= "" and rawget(row, "tag") then
    local tc = opts.tagColor or (opts.demo and GOLD) or AccentColor()
    row.tag:SetTextColor(tc.r, tc.g, tc.b)
    row.tag:SetJustifyH("LEFT")
    -- Tags must stay fully visible at min width. Never run FitFontString
    -- on them (that is what turned "Upgrade" into "Upgr..."). Reserve the
    -- measured width, with a floor for the known gear tags.
    if row.tag.SetText then
      row.tag:SetText(tagText)
    end
    if row.tag.SetWordWrap then
      pcall(row.tag.SetWordWrap, row.tag, false)
    end
    local measured = Row.MeasureText(row.tag, tagText, 6)
    local floorW = 22
    if tagText == "Upgrade" then
      floorW = 58
    elseif tagText == "Best pick" then
      floorW = 68
    elseif tagText == "Demo" then
      floorW = 36
    end
    local w = math.min(110, math.max(floorW, measured))
    if row.tag.SetWidth then
      row.tag:SetWidth(w)
    end
    add(row.tag, w, true)
  end

  local prev = nil
  local leftmost = nil
  local reserved = TRAIL_PAD
  local topOff = (opts.trailTop ~= nil) and opts.trailTop or -8
  for i = 1, #items do
    local it = items[i]
    local f = it.frame
    if f.SetHeight and (f.GetHeight and (f:GetHeight() or 0) > 24) then
      -- Keep accessory glyphs/tags on the title line instead of stretching
      -- the full row height (the mock default height can be very tall).
      if f._kind == "FontString" or (f.GetObjectType and f:GetObjectType() == "FontString") then
        f:SetHeight(12)
      end
    end
    if f.SetHeight and f.GetObjectType then
      local ok, kind = pcall(f.GetObjectType, f)
      if ok and kind == "FontString" then
        f:SetHeight(12)
      end
    elseif f._kind == "FontString" and f.SetHeight then
      f:SetHeight(12)
    end
    f:ClearAllPoints()
    if not prev then
      f:SetPoint("TOPRIGHT", row, "TOPRIGHT", -TRAIL_PAD, topOff)
    else
      f:SetPoint("TOPRIGHT", prev, "TOPLEFT", -TRAIL_GAP, 0)
    end
    f:Show()
    reserved = reserved + it.width + (prev and TRAIL_GAP or 0)
    prev = f
    leftmost = f
  end
  if leftmost then
    reserved = reserved + TRAIL_GAP
  end

  row._trailLeft = leftmost
  row._trailReserve = reserved
  row._trailOpts = opts
  row._trailItems = items
  return leftmost, reserved
end

PC.LayoutRowTrail = function(row, opts) return Row.LayoutRowTrail(row, opts) end

function Row.TrailTextWidth(row, left)
  local rw = (row.GetWidth and row:GetWidth()) or ContentWidth()
  if rw <= 0 then
    rw = ContentWidth()
  end
  local reserve = row._trailReserve or TRAIL_PAD
  local w = rw - (left or 16) - reserve
  if w < 40 then
    w = 40
  end
  return w
end

function Row.AnchorToTrail(fs, row, left, top, trailLeft)
  fs:ClearAllPoints()
  fs:SetPoint("TOPLEFT", row, "TOPLEFT", left, top)
  if trailLeft then
    fs:SetPoint("RIGHT", trailLeft, "LEFT", -TRAIL_GAP, 0)
  else
    fs:SetPoint("RIGHT", row, "RIGHT", -TRAIL_PAD, 0)
  end
end

function Row.FitToTrail(fs, row, left, text, wrap)
  local maxW = Row.TrailTextWidth(row, left)
  if PC.FitFontString then
    PC:FitFontString(fs, text or "", maxW, wrap and true or false)
  else
    fs:SetText(text or "")
  end
  if fs.SetWidth then
    fs:SetWidth(maxW)
  end
  return maxW
end

function Row.FadeChildRow(row)
  if not row or not row.SetAlpha then
    return
  end
  row:SetAlpha(0)
  local done = false
  if row.CreateAnimationGroup then
    local ok, ag = pcall(row.CreateAnimationGroup, row)
    if ok and ag and ag.CreateAnimation then
      local okA, a = pcall(ag.CreateAnimation, ag, "Alpha")
      if okA and a then
        if a.SetFromAlpha then pcall(a.SetFromAlpha, a, 0) end
        if a.SetToAlpha then pcall(a.SetToAlpha, a, 1) end
        if a.SetDuration then pcall(a.SetDuration, a, 0.15) end
        if ag.SetScript then
          pcall(ag.SetScript, ag, "OnFinished", function()
            row:SetAlpha(1)
          end)
        end
        if ag.Play then
          pcall(ag.Play, ag)
          done = true
        end
      end
    end
  end
  if not done and C_Timer and C_Timer.After then
    pcall(C_Timer.After, 0.06, function()
      if row.SetAlpha then row:SetAlpha(0.55) end
    end)
    pcall(C_Timer.After, 0.14, function()
      if row.SetAlpha then row:SetAlpha(1) end
    end)
    done = true
  end
  if not done then
    row:SetAlpha(1)
  end
end

function Row.StripBands()
  ui.bands = ui.bands or {}
  for i = 1, #ui.bands do
    ui.bands[i]:Hide()
  end
  ui._openBand = nil
  ui._bandUsed = 0
end

function Row.AcquireBand()
  ui.bands = ui.bands or {}
  ui._bandUsed = (ui._bandUsed or 0) + 1
  local b = ui.bands[ui._bandUsed]
  if b then
    return b
  end
  b = CreateFrame("Frame", nil, ui.content)
  b.bg = b:CreateTexture(nil, "BACKGROUND")
  b.bg:SetAllPoints()
  Paint(b.bg, { r = 0.055, g = 0.055, b = 0.065 }, 1)
  ui.bands[ui._bandUsed] = b
  return b
end

function Row.CloseChildBand()
  local b = ui._openBand
  if not b then
    return
  end
  local h = (b.endY or b.startY or 0) - (b.startY or 0)
  if h < 6 then
    b:Hide()
    ui._openBand = nil
    return
  end
  b:ClearAllPoints()
  b:SetPoint("TOPLEFT", ui.content, "TOPLEFT", 8, -(b.startY or 0))
  b:SetWidth(math.max(40, ContentWidth() - 16))
  b:SetHeight(h)
  if b.SetFrameLevel and ui.content and ui.content.GetFrameLevel then
    local lvl = ui.content:GetFrameLevel() or 1
    b:SetFrameLevel(math.max(1, lvl))
  end
  b:Show()
  ui._openBand = nil
end

function Row.NoteChildSpan(startY, endY)
  if not ui._openBand then
    local b = Row.AcquireBand()
    b.startY = startY
    ui._openBand = b
  end
  ui._openBand.endY = endY
end

function Row.RelayoutRow(row)
  if not row or row._layingOut or not row:IsShown() then
    return
  end
  local opts = row._trailOpts
  if not opts then
    return
  end
  row._layingOut = true
  Row.LayoutRowTrail(row, opts)
  local left = row._textLeft or 16
  local trailLeft = row._trailLeft
  if row.title and row._titleText then
    Row.AnchorToTrail(row.title, row, left, row._titleTop or -8, trailLeft)
    Row.FitToTrail(row.title, row, left, row._titleText, false)
  end
  if row.meta and row._metaText and row._metaText ~= "" then
    Row.FitToTrail(row.meta, row, left, row._metaText, false)
  end
  if row.note and row._noteText and row._noteText ~= "" then
    Row.FitToTrail(row.note, row, left, row._noteText, true)
  end
  row._layingOut = false
end

local function ListRow(index, title, meta, note, y, opts)
  opts = opts or {}
  -- 1.21.0: on a wide window, rows inside a group (or a captured guide) go
  -- to the right pane instead of the left list.
  if DETAIL and DETAIL.Capture(title, meta, note, opts) then
    return y
  end
  local row = AcquireRow(index)
  ResetRow(row)
  if ui.split and DETAIL then
    local m2 = DETAIL.Register(row, title, meta, note, opts)
    if m2 then meta = m2 end
  end
  HideTooltip()
  row.useHighlight = true
  row.itemID = opts.itemID
  row.tip = opts.tip
  if opts.last then
    row.sep:Hide()
  end

  local kind = opts.kind
  if not kind then
    if opts.child or ((tonumber(opts.indent) or 0) >= 16 and not opts.chevron) then
      kind = "child"
    elseif opts.chevron or opts.parent then
      kind = "parent"
    end
  end
  opts.kind = kind
  if kind ~= "child" then
    Row.CloseChildBand()
  end

  local indent = tonumber(opts.indent) or 0
  if kind == "child" and indent < 12 then
    indent = 12
  end
  if indent < 0 then indent = 0 end
  if indent > 48 then indent = 48 end

  row:SetWidth(ContentWidth())
  row._layingOut = true
  local trailLeft = Row.LayoutRowTrail(row, opts)

  local left = 16 + indent
  if opts.icon or opts.dungeonId then
    row.icon:ClearAllPoints()
    row.icon:SetPoint("LEFT", row, "LEFT", left, 0)
    if kind == "parent" then
      row.icon:SetSize(22, 22)
    else
      row.icon:SetSize(20, 20)
    end
    if opts.dungeonId and PC.ApplyDungeonIcon then
      PC:ApplyDungeonIcon(row.icon, opts.dungeonId, row)
    elseif opts.icon then
      row.icon:SetTexture(opts.icon)
      if row.icon.SetTexCoord then
        pcall(row.icon.SetTexCoord, row.icon, 0.07, 0.93, 0.07, 0.93)
      end
    end
    row.icon:Show()
    left = left + 28
  end

  if kind == "parent" then
    ApplyFont(row.title, 13)
    row.title:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
    ApplyFont(row.meta, 10)
    if not opts.bgTint then
      opts.bgTint = { r = 0.12, g = 0.12, b = 0.14 }
    end
  elseif kind == "child" then
    ApplyFont(row.title, 12)
    row.title:SetTextColor(SUB.r, SUB.g, SUB.b)
    ApplyFont(row.meta, 10)
    row.meta:SetTextColor(MUTED.r, MUTED.g, MUTED.b)
    -- The inset group band is the background; keep the row itself quiet.
    if not opts.bgTint then
      opts.bgTint = { r = 0.055, g = 0.055, b = 0.065 }
    end
  end
  if opts.accent and rawget(row, "accent") then
    local c = opts.accentColor or AccentColor()
    Paint(row.accent, c, 1)
    row.accent:Show()
  end

  local titleTop = (kind == "parent" and -6) or (kind == "child" and -4) or -8
  row._textLeft = left
  row._titleTop = titleTop
  row._titleText = title or ""
  row._metaText = meta or ""
  row._noteText = note or ""

  Row.AnchorToTrail(row.title, row, left, titleTop, trailLeft)
  if opts.selected and row.rim then
    row._selected = true
    PC:ShowRoundFill(row.rim, true)
  end
  if opts.titleColor then
    row.title:SetTextColor(opts.titleColor.r, opts.titleColor.g, opts.titleColor.b)
  elseif opts.qualityColor then
    local c = opts.qualityColor
    row.title:SetTextColor(c.r, c.g, c.b)
  end
  if opts.bgTint then
    Paint(row.bg, opts.bgTint, 1)
  end
  Row.FitToTrail(row.title, row, left, title or "", false)

  local h = (kind == "child" and 16) or (kind == "parent" and 18) or 20
  if opts.progress and rawget(row, "bar") then
    local cur = opts.progress.cur or 0
    local maxv = opts.progress.max or 0
    row.bar:ClearAllPoints()
    row.bar:SetPoint("TOPLEFT", row.title, "BOTTOMLEFT", 0, -6)
    if trailLeft then
      row.bar:SetPoint("RIGHT", trailLeft, "LEFT", -TRAIL_GAP, 0)
    else
      row.bar:SetPoint("RIGHT", row, "RIGHT", -TRAIL_PAD, 0)
    end
    row.bar:SetHeight(6)
    SetBarProgress(row.bar, cur, maxv)
    local fill = opts.progress.color or AccentColor()
    if row.bar.SetStatusBarColor then
      row.bar:SetStatusBarColor(fill.r, fill.g, fill.b)
    end
    row.bar:Show()
    h = h + 12
  end
  if meta and meta ~= "" then
    local metaAnchor = (opts.progress and rawget(row, "bar")) and row.bar or row.title
    row.meta:ClearAllPoints()
    row.meta:SetPoint("TOPLEFT", metaAnchor, "BOTTOMLEFT", 0, -2)
    if trailLeft then
      row.meta:SetPoint("RIGHT", trailLeft, "LEFT", -TRAIL_GAP, 0)
    else
      row.meta:SetPoint("RIGHT", row, "RIGHT", -TRAIL_PAD, 0)
    end
    Row.FitToTrail(row.meta, row, left, meta, false)
    h = h + (row.meta:GetStringHeight() or 11) + 2
  end
  if note and note ~= "" then
    local anchor = (meta and meta ~= "") and row.meta or row.title
    row.note:ClearAllPoints()
    row.note:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -2)
    if trailLeft then
      row.note:SetPoint("RIGHT", trailLeft, "LEFT", -TRAIL_GAP, 0)
    else
      row.note:SetPoint("RIGHT", row, "RIGHT", -TRAIL_PAD, 0)
    end
    Row.FitToTrail(row.note, row, left, note, true)
    h = h + (row.note:GetStringHeight() or 12) + 2
  end
  if kind == "parent" then
    h = math.max(PARENT_H, h + 8)
  elseif kind == "child" then
    h = math.max(CHILD_H, h + 6)
  else
    h = math.max(36, h + 12)
  end

  if opts.onExpand then
    row:SetScript("OnMouseDown", function(self, button)
      if button and button ~= "LeftButton" then
        return
      end
      self._pressedTint = self._pressedTint or { r = 0.10, g = 0.10, b = 0.12 }
      local tint = opts.bgTint or { r = 0.12, g = 0.12, b = 0.14 }
      Paint(self.bg, { r = tint.r * 0.85, g = tint.g * 0.85, b = tint.b * 0.85 }, 1)
      if self.hl then
        self.hl:SetAlpha(0.5)
      end
    end)
    row:SetScript("OnMouseUp", function(self, button)
      if opts.bgTint then
        Paint(self.bg, opts.bgTint, 1)
      end
      if self.hl then
        self.hl:SetAlpha(self.useHighlight and 0.35 or 0)
      end
      if button and button ~= "LeftButton" then
        return
      end
      ui._fadeChildren = true
      opts.onExpand()
    end)
  end

  row:SetScript("OnSizeChanged", function(self, w, h0)
    if self._layingOut then
      return
    end
    Row.RelayoutRow(self)
  end)

  local nextY = PlaceRow(row, y, h)
  row._layingOut = false
  if kind == "child" then
    Row.NoteChildSpan(y, nextY)
    if ui._fadeChildren then
      Row.FadeChildRow(row)
    end
  end
  -- Re-fit after PlaceRow so GetLeft/GetWidth match the real row box.
  Row.RelayoutRow(row)
  return nextY
end



ui.StripBands = function() return Row.StripBands() end
ui.CloseChildBand = function() return Row.CloseChildBand() end
PC.TrailTextWidth = function(row, left) return Row.TrailTextWidth(row, left) end


local function Header(index, text, y)
  if DETAIL and DETAIL.CaptureHeader(text) then
    return y
  end
  local row = AcquireRow(index)
  ResetRow(row)
  row.bg:Hide()
  row.sep:Hide()
  row.title:SetPoint("BOTTOMLEFT", row, "BOTTOMLEFT", 16, 4)
  row.title:SetPoint("RIGHT", row, "RIGHT", -12, 0)
  ApplyFont(row.title, 11)
  row.title:SetTextColor(MUTED.r, MUTED.g, MUTED.b)
  local hw = math.max(40, ContentWidth() - 28)
  if PC.FitFontString then
    PC:FitFontString(row.title, string.upper(text or ""), hw, false)
  else
    row.title:SetText(string.upper(text or ""))
  end
  local topPad = (y == 0) and 10 or 18
  return PlaceRow(row, y, 22 + (topPad - 10))
end

local function Body(index, text, y)
  if DETAIL and DETAIL.CaptureBody(text) then
    return y
  end
  local row = AcquireRow(index)
  ResetRow(row)
  row.bg:Hide()
  row.sep:Hide()
  row.title:SetPoint("TOPLEFT", row, "TOPLEFT", 16, -4)
  row.title:SetPoint("RIGHT", row, "RIGHT", -12, 0)
  ApplyFont(row.title, 12)
  row.title:SetTextColor(SUB.r, SUB.g, SUB.b)
  local bw = math.max(40, ContentWidth() - 32)
  if PC.FitFontString then
    PC:FitFontString(row.title, text or "", bw, true)
  else
    row.title:SetText(text or "")
  end
  local h = math.max(22, (row.title:GetStringHeight() or 14) + 12)
  return PlaceRow(row, y, h)
end

local function SetContentHeight(y)
  if Row.CloseChildBand then
    Row.CloseChildBand()
  end
  ui._fadeChildren = nil
  local minH = 200
  if ui.scroll and ui.scroll.GetHeight then
    minH = ui.scroll:GetHeight() or 200
  end
  ui.content:SetWidth(ContentWidth())
  ui.content:SetHeight(math.max(y + 16, minH))
  if ui.scroll and ui.scroll.UpdateScrollChildRect then
    pcall(ui.scroll.UpdateScrollChildRect, ui.scroll)
  end
end

-- ---------------------------------------------------------------------------
-- Today card (Next tab)
-- ---------------------------------------------------------------------------

local function EnsureTodayCard()
  if ui.today then
    return ui.today
  end
  local card = CreateFrame("Frame", nil, ui.content)
  card.bg = card:CreateTexture(nil, "BACKGROUND")
  card.bg:SetAllPoints()
  Paint(card.bg, CARD, 1)

  card.kicker = MakeFontString(card, 11, "GameFontNormalSmall")
  card.kicker:SetTextColor(MUTED.r, MUTED.g, MUTED.b)
  card.kicker:SetPoint("TOPLEFT", 16, -14)
  card.kicker:SetText("TODAY")

  card.percent = MakeFontString(card, 22, "GameFontNormalLarge")
  card.percent:SetTextColor(EMERALD.r, EMERALD.g, EMERALD.b)
  card.percent:SetPoint("TOPRIGHT", -16, -10)

  card.level = MakeFontString(card, 16, "GameFontNormalLarge")
  card.level:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
  card.level:SetPoint("TOPLEFT", card.kicker, "BOTTOMLEFT", 0, -8)
  card.level:SetPoint("RIGHT", -16, 0)
  card.level:SetJustifyH("LEFT")

  card.zone = MakeFontString(card, 12)
  card.zone:SetPoint("TOPLEFT", card.level, "BOTTOMLEFT", 0, -4)
  card.zone:SetPoint("RIGHT", -16, 0)
  card.zone:SetJustifyH("LEFT")

  card.bar = CreateFillBar(card, 200, 6)
  card.bar:SetPoint("TOPLEFT", card.zone, "BOTTOMLEFT", 0, -10)
  card.bar:SetPoint("RIGHT", card, "RIGHT", -16, 0)
  card.bar.label = MakeFontString(card, 11, "GameFontNormalSmall")
  card.bar.label:SetTextColor(SUB.r, SUB.g, SUB.b)
  card.bar.label:SetPoint("TOPLEFT", card.bar, "BOTTOMLEFT", 0, -4)

  card.upNext = MakeFontString(card, 11, "GameFontNormalSmall")
  card.upNext:SetTextColor(MUTED.r, MUTED.g, MUTED.b)
  card.upNext:SetPoint("TOPLEFT", card.bar.label, "BOTTOMLEFT", 0, -14)
  card.upNext:SetText("UP NEXT")

  card.action = MakeFontString(card, 16, "GameFontNormalLarge")
  card.action:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
  card.action:SetPoint("TOPLEFT", card.upNext, "BOTTOMLEFT", 0, -6)
  card.action:SetPoint("RIGHT", -44, 0)
  card.action:SetJustifyH("LEFT")

  card.sub = MakeFontString(card, 12)
  card.sub:SetTextColor(SUB.r, SUB.g, SUB.b)
  card.sub:SetPoint("TOPLEFT", card.action, "BOTTOMLEFT", 0, -3)
  card.sub:SetPoint("RIGHT", -44, 0)
  card.sub:SetJustifyH("LEFT")

  local pin = CreateFrame("Button", nil, card)
  pin:SetSize(28, 28)
  pin:SetPoint("RIGHT", -14, 0)
  pin:SetPoint("TOP", card.action, "TOP", 0, 6)
  pin.icon = PC._DrawPin(pin, 28)
  pin:SetScript("OnClick", function(self)
    if self.waypoint and PC.SetWaypoint then
      PC:SetWaypoint(self.waypoint)
    end
  end)
  pin:SetScript("OnEnter", function(self)
    if not self.waypoint then
      ShowRowTooltip(self, { "No verified map pin for this step yet." })
      return
    end
    ShowRowTooltip(self, {
      { "Set a map pin", GOLD.r, GOLD.g, GOLD.b },
      "One tap places a waypoint for this next step.",
    })
  end)
  pin:SetScript("OnLeave", HideTooltip)
  card.pin = pin

  card:EnableMouse(true)
  card:SetScript("OnEnter", function(self)
    if self.tip then
      ShowRowTooltip(self, self.tip)
    end
  end)
  card:SetScript("OnLeave", HideTooltip)
  card:SetScript("OnMouseUp", function(self)
    if self.pin and self.pin.waypoint and PC.SetWaypoint then
      PC:SetWaypoint(self.pin.waypoint)
    end
  end)

  ui.today = card
  return card
end

local function HideTodayCard()
  if ui.today then
    ui.today:Hide()
  end
  if ui.gearFilters then
    ui.gearFilters:Hide()
  end
  if ui.tabFilters then
    ui.tabFilters:Hide()
  end
end

local function LayoutTodayCard()
  local card = EnsureTodayCard()
  local w = ContentWidth()
  card:ClearAllPoints()
  card:SetPoint("TOPLEFT", ui.content, "TOPLEFT", 0, 0)
  card:SetWidth(w)

  local done, total = PC:OverallProgress()
  local pct = 0
  if total and total > 0 then
    pct = math.floor((done / total) * 100 + 0.5)
  end
  card.percent:SetText(pct .. "%")
  SetBarProgress(card.bar, done, total)

  local bracket = PC:GetCurrentBracketLabel() or "No written bracket"
  card.level:SetText("Level " .. PC:PlayerLevel() .. "  ·  " .. bracket)

  local inZone, zoneName = PC:IsInRecommendedZone(true)
  if inZone then
    card.zone:SetTextColor(EMERALD.r, EMERALD.g, EMERALD.b)
    card.zone:SetText("You're in " .. (zoneName or "a recommended zone"))
  else
    card.zone:SetTextColor(DANGER.r, DANGER.g, DANGER.b)
    card.zone:SetText("Not in a recommended zone" .. (zoneName and ("  ·  " .. zoneName) or ""))
  end

  local action = PC:GetNextAction() or {}
  card.action:SetText(action.title or "No next step")
  card.sub:SetText(action.subtitle or "")
  if action.waypoint and action.waypoint.uiMapID and action.waypoint.x then
    card.pin.waypoint = action.waypoint
    card.pin:Show()
    card.tip = {
      { "Up next", GOLD.r, GOLD.g, GOLD.b },
      "Tap the pin (or this card) to set a map waypoint.",
    }
  else
    card.pin.waypoint = nil
    card.pin:Hide()
    card.tip = {
      { "Up next", GOLD.r, GOLD.g, GOLD.b },
      "No verified coordinates for this step yet. Open Path for the full route.",
    }
  end

  local h = 168
  if action.subtitle and action.subtitle ~= "" then
    h = h + 6
  end
  card:SetHeight(h)
  card:Show()
  return h + 8
end

-- ---------------------------------------------------------------------------
-- Tab layouts
-- ---------------------------------------------------------------------------

local function CheckTipFor(kind, locked)
  if locked then
    return { { "Completed", EMERALD.r, EMERALD.g, EMERALD.b }, "The client reports this as finished, so it stays checked." }
  end
  if kind == "dungeon" then
    return { { "Mark dungeon done", GOLD.r, GOLD.g, GOLD.b }, "Tick the box to tick this dungeon. The row itself expands quests and loot." }
  end
  if kind == "quest" then
    return { { "Mark quest done", GOLD.r, GOLD.g, GOLD.b }, "Quests with an ID auto-tick when completed. Others can be ticked by hand." }
  end
  if kind == "gear" then
    return { { "Mark acquired", GOLD.r, GOLD.g, GOLD.b }, "Tick the box to tick this piece. Hover the row for the item tooltip when an ID is known." }
  end
  if kind == "goal" then
    return { { "Mark goal done", GOLD.r, GOLD.g, GOLD.b }, "Trainer spells auto-tick when the client knows them. Purchases stay manual." }
  end
  return { { "Mark done", GOLD.r, GOLD.g, GOLD.b }, "Tick the box to tick or untick." }
end

local function LootOwned(it)
  if not it then
    return false
  end
  if it.itemID then
    return PC:PlayerHasGearItem({ itemID = it.itemID, name = it.name })
  end
  if it.name then
    return PC:PlayerHasItemByName(it.name)
  end
  return false
end

local EmitDungeonTips

local function LayoutDungeonBlock(n, y, d, last)
  local flags = {}
  if d.range then
    flags[#flags + 1] = d.range
  end
  if PC:IsDungeonVisited(d.id) then
    flags[#flags + 1] = "visited"
  end
  if d.skipped then
    flags[#flags + 1] = "optional"
  end
  local qDone, qTotal = PC:CountDungeonQuests(d.id)
  if qTotal > 0 then
    flags[#flags + 1] = qDone .. "/" .. qTotal .. " quests"
  end
  local questKey = "quests:" .. d.id
  local lootKey = "loot:" .. d.id
  local quests = PC:GetQuestList(d.id)
  local loot = PC:GetLootForDungeon(d.id)
  local canExpand = true
  local pending = false
  if PC._pendingPathDungeon and d and d.id then
    pending = tostring(PC._pendingPathDungeon) == tostring(d.id)
      or (d.name and string.lower(tostring(PC._pendingPathDungeon)) == string.lower(tostring(d.name)))
  end
  if pending then
    local dbx = PC:GetDB()
    if type(dbx.expanded) ~= "table" then
      dbx.expanded = {}
    end
    dbx.expanded[questKey] = true
    dbx.expanded[lootKey] = true
  end
  local open = PC:IsExpanded(questKey) or PC:IsExpanded(lootKey) or Searching()
  if ui.split then
    open = false -- details live in the right pane
  end

  n = n + 1
  local rowY = y
  y = ListRow(n, d.name, table.concat(flags, "  ·  "), nil, y, {
    icon = (PC.GetDungeonIcon and PC:GetDungeonIcon(d.id)) or ClassIcon("dungeons"),
    detailKey = "dungeon:" .. tostring(d.id),
    detail = function() return DETAIL.Dungeon(d.id, nil, d.name) end,
    dungeonId = d.id,
    accent = pending,
    titleColor = pending and AccentColor() or nil,
    checkable = true,
    checked = PC:IsDungeonChecked(d.id),
    onClick = function(checked)
      PC:SetDungeonChecked(d.id, checked)
    end,
    checkTip = CheckTipFor("dungeon"),
    waypoint = PC:GetEntranceWaypoint(d.id),
    chevron = canExpand,
    expanded = open,
    last = last and not open,
    tip = {
      { d.name, GOLD.r, GOLD.g, GOLD.b },
      "Tap the row to show or hide Alliance quests and loot. Tick the box to mark the dungeon done. Tap the pin to mark the entrance, when coordinates are verified.",
    },
    onExpand = function()
      -- One tap opens or closes both sections together, so the row behaves like a single disclosure.
      local nextState = not (PC:IsExpanded(questKey) or PC:IsExpanded(lootKey))
      local db = PC:GetDB()
      if type(db.expanded) ~= "table" then
        db.expanded = {}
      end
      db.expanded[questKey] = nextState or nil
      db.expanded[lootKey] = nextState or nil
      -- ToggleExpanded flips one key; keep the two sections in sync by writing both, then refresh.
      if PC.Refresh then
        PC:Refresh()
      end
    end,
  })
  if pending and not ui.pathFocusY then
    ui.pathFocusY = rowY
  end

  if not open then
    return n, y
  end

  if not quests then
    n = n + 1
    y = Body(n, "Quests not yet catalogued.", y)
  elseif #quests == 0 then
    n = n + 1
    y = Body(n, "No Alliance dungeon quests were found in Questie Forever for this instance.", y)
  else
    n = n + 1
    y = Header(n, "Alliance quests  " .. qDone .. " / " .. qTotal, y)
    for qi = 1, #quests do
      local q = quests[qi]
      local done = PC:IsQuestChecked(d.id, q)
      if Matches(done, q.name, q.giver, q.where, q.questID and tostring(q.questID) or nil) then
        local metaParts = {}
        if q.minLevel then
          metaParts[#metaParts + 1] = "Min " .. q.minLevel
        end
        if q.questID then
          metaParts[#metaParts + 1] = "ID " .. q.questID
        end
        if q.giver and q.where then
          metaParts[#metaParts + 1] = q.giver .. "  ·  " .. q.where
        elseif q.giver then
          metaParts[#metaParts + 1] = q.giver
        elseif q.where then
          metaParts[#metaParts + 1] = q.where
        end
        local locked = q.questID and PC:IsQuestFlaggedComplete(q.questID)
        if locked then
          metaParts[#metaParts + 1] = "completed"
        elseif PC:IsQuestInLog(q.questID, q.name) then
          metaParts[#metaParts + 1] = "in log"
        end
        n = n + 1
        y = ListRow(n, q.name, table.concat(metaParts, "  ·  "), q.note, y, {
          icon = ClassIcon("quests"),
          checkable = true,
          checked = done,
          onClick = function(checked)
            PC:SetQuestChecked(d.id, q, checked)
          end,
          checkTip = CheckTipFor("quest", locked),
          waypoint = PC:QuestWaypoint(q),
          last = (qi == #quests) and (not loot or #loot == 0),
          tip = {
            { q.name, GOLD.r, GOLD.g, GOLD.b },
            "Tick the box to mark this quest done. Tap the pin to mark the quest giver when coordinates are known.",
          },
        })
      end
    end
  end

  if not loot or #loot == 0 then
    n = n + 1
    y = Body(n, "No catalogued loot list for this dungeon yet. Tracker pieces still appear under Gear.", y)
  else
    n = n + 1
    y = Header(n, "Loot  " .. #loot, y)
    for li = 1, #loot do
      local it = loot[li]
      local owned = LootOwned(it)
      if Matches(owned, it.name, it.boss, it.slot) then
        local parts = {}
        if it.slot then parts[#parts + 1] = it.slot end
        if it.boss then parts[#parts + 1] = it.boss end
        if it.quest then parts[#parts + 1] = it.quest end
        if it.itemID then parts[#parts + 1] = "ID " .. it.itemID end
        if owned then parts[#parts + 1] = "acquired" end
        local icon = it.itemID and PC:GetItemIcon(it.itemID) or nil
        n = n + 1
        y = ListRow(n, it.name, table.concat(parts, "  ·  "), it.note, y, {
          icon = icon,
          itemID = it.itemID,
          checkable = it.tracker and true or false,
          checked = owned or (it.tracker and PC:IsGearChecked(it.tracker)),
          onClick = function(checked)
            if it.tracker then
              PC:SetGearChecked(it.tracker, checked)
            end
          end,
          checkTip = CheckTipFor("gear"),
          last = li == #loot,
          tip = it.itemID and nil or { { it.name, GOLD.r, GOLD.g, GOLD.b }, "No verified item ID, so this row has no item tooltip." },
        })
      end
    end
  end

  n, y = EmitDungeonTips(n, y, d.id)
  return n, y
end

local function ComingSoonBody(n, y, data)
  n = n + 1
  local note = (data and data.factionNote) or "A full class guide for this character is not in this version yet. The dungeon route, guild tab, and upgrade scorer still work."
  y = Body(n, "Class guide coming soon. " .. note, y)
  return n, y
end

local function GroupDefaultOn(group, level)
  if not group then
    return false
  end
  if group.default == "always" or group.defaultOn == true then
    return true
  end
  if group.default == false or group.defaultOn == false then
    return false
  end
  local range = group.defaultLevel
  if type(range) == "table" then
    local a = range[1] or 1
    local b = range[2] or 60
    return level >= a and level <= b
  end
  return false
end


local function LayoutTonightBlock(n, y)
  if not PC.GetTonightItems then
    return n, y
  end
  local items = PC:GetTonightItems(5) or {}
  n = n + 1
  local summary = PC.SessionSummaryLine and PC:SessionSummaryLine() or "Tonight"
  y = ListRow(n, "Tonight", summary, nil, y, {
    icon = ClassIcon("tonight"),
    last = #items == 0,
    titleColor = AccentColor(),
    tip = {
      { "Tonight", GOLD.r, GOLD.g, GOLD.b },
      "A short list from your current level, professions, dungeons, and guild. Check off what you finish this session.",
    },
  })
  for i = 1, #items do
    local it = items[i]
    local id = it.id
    n = n + 1
    y = ListRow(n, it.title, it.detail, nil, y, {
      icon = it.icon or ClassIcon("goals"),
      checkable = true,
      checked = it.checked,
      onClick = function(isChecked)
        if PC.SetTonightChecked then
          PC:SetTonightChecked(id, isChecked)
        end
      end,
      waypoint = it.waypoint,
      last = i == #items,
      tip = {
        { it.title, GOLD.r, GOLD.g, GOLD.b },
        it.detail or "A suggested next step for this session.",
      },
    })
  end
  return n, y
end

function EmitDungeonTips(n, y, dungeonId)
  if not dungeonId then
    return n, y
  end
  if PC.DungeonHasTips and not PC:DungeonHasTips(dungeonId) then
    return n, y
  end
  if not PC.GetDungeonTipSheet then
    return n, y
  end
  local sheet = PC:GetDungeonTipSheet(dungeonId)
  if not sheet or sheet.tipsComing or not sheet.bosses or #sheet.bosses == 0 then
    return n, y
  end
  n = n + 1
  y = Header(n, "Boss tips", y)
  if sheet.source then
    n = n + 1
    y = Body(n, sheet.source, y)
  end
  local bosses = sheet.bosses or {}
  for i = 1, #bosses do
    local b = bosses[i]
    local detail = b.tip
    if b.loot then
      detail = (detail or "") .. "  Loot: " .. b.loot .. "."
    end
    n = n + 1
    y = ListRow(n, b.name, detail, nil, y, {
      icon = (PC.GetDungeonIcon and PC:GetDungeonIcon(dungeonId)) or ClassIcon("dungeons"),
      dungeonId = dungeonId,
      last = i == #bosses,
      tip = {
        { b.name, GOLD.r, GOLD.g, GOLD.b },
        detail or "",
        sheet.source or "",
      },
    })
  end
  return n, y
end


local function ScrollContentTo(y)
  if not ui.scroll then
    return
  end
  if ui.scroll.UpdateScrollChildRect then
    pcall(ui.scroll.UpdateScrollChildRect, ui.scroll)
  end
  local range = 0
  if ui.scroll.GetVerticalScrollRange then
    range = ui.scroll:GetVerticalScrollRange() or 0
  end
  if type(y) ~= "number" then
    y = 0
  end
  if y < 0 then
    y = 0
  end
  if range and y > range then
    y = range
  end
  ui.scroll:SetVerticalScroll(y)
end

local ITEM_QUALITY_RGB = {
  [0] = { r = 0.62, g = 0.62, b = 0.62 },
  [1] = { r = 1.00, g = 1.00, b = 1.00 },
  [2] = { r = 0.12, g = 1.00, b = 0.00 },
  [3] = { r = 0.00, g = 0.44, b = 0.87 },
  [4] = { r = 0.64, g = 0.21, b = 0.93 },
  [5] = { r = 1.00, g = 0.50, b = 0.00 },
}

local function ItemQualityColor(itemID)
  if not itemID or not GetItemInfo then
    return nil
  end
  local ok, name, link, quality = pcall(GetItemInfo, itemID)
  if not ok or type(quality) ~= "number" then
    return nil
  end
  return ITEM_QUALITY_RGB[quality]
end

local GEAR_FILTERS = {
  { id = "all", label = "All" },
  { id = "weapons", label = "Weapons" },
  { id = "armor", label = "Armor" },
  { id = "jewelry", label = "Jewelry" },
  { id = "upgrades", label = "Upgrades" },
}

local function HideGearFilterBar()
  if ui.gearFilters then
    ui.gearFilters:Hide()
  end
end

local function CurrentGearFilter()
  if ui.gearFilter == "all" or ui.gearFilter == "weapons" or ui.gearFilter == "armor" or ui.gearFilter == "jewelry" or ui.gearFilter == "upgrades" then
    return ui.gearFilter
  end
  local db = PC:GetDB()
  if db and (db.gearFilter == "weapons" or db.gearFilter == "armor" or db.gearFilter == "jewelry" or db.gearFilter == "upgrades") then
    return db.gearFilter
  end
  return "all"
end

local function EnsureGearFilterBar()
  if ui.gearFilters then
    return ui.gearFilters
  end
  local bar = CreateFrame("Frame", "PhilosophersCodexGearFilters", ui.content)
  bar.buttons = {}
  for i = 1, #GEAR_FILTERS do
    local spec = GEAR_FILTERS[i]
    local btn = CreateFrame("Button", "PhilosophersCodexGearFilter" .. spec.id, bar)
    btn.id = spec.id
    btn:SetHeight(CARDS.chipH)
    btn.bg = btn:CreateTexture(nil, "BACKGROUND")
    btn.bg:SetAllPoints()
    Paint(btn.bg, { r = 0.07, g = 0.07, b = 0.08 }, 0.6)
    btn.label = MakeFontString(btn, 10, "GameFontNormalSmall")
    btn.label:SetPoint("CENTER", 0, 0)
    btn.label:SetText(spec.label)
    btn:SetScript("OnClick", function(self)
      ui.gearFilter = self.id
      local db = PC:GetDB()
      if db then
        db.gearFilter = self.id
      end
      if PC.Refresh then
        PC:Refresh()
      end
    end)
    bar.buttons[i] = btn
  end
  ui.gearFilters = bar
  return bar
end

local function LayoutGearFilterBar(y)
  local bar = EnsureGearFilterBar()
  local w = ContentWidth()
  bar:ClearAllPoints()
  bar:SetPoint("TOPLEFT", ui.content, "TOPLEFT", 0, -y)
  bar:SetWidth(w)
  local current = CurrentGearFilter()
  local gap = 6
  local x, rowH, rows = 0, CARDS.chipH, 1
  local inner = w - 8
  for i = 1, #bar.buttons do
    local btn = bar.buttons[i]
    local label = GEAR_FILTERS[i].label
    local bw = 64
    if btn.label and btn.label.GetStringWidth and btn.label:GetStringWidth() then
      bw = math.max(58, (btn.label:GetStringWidth() or 40) + 16)
    elseif #label > 6 then
      bw = 76
    end
    if x > 0 and (x + bw) > inner then
      x = 0
      rows = rows + 1
    end
    btn:ClearAllPoints()
    btn:SetPoint("TOPLEFT", bar, "TOPLEFT", 4 + x, -4 - (rows - 1) * (rowH + gap))
    btn:SetWidth(bw)
    btn:SetHeight(rowH)
    local on = btn.id == current
    CARDS.ChipStyle(btn, on, AccentColor())
    btn:Show()
    x = x + bw + gap
  end
  local h = 8 + rows * rowH + (rows - 1) * gap
  bar:SetHeight(h)
  bar:Show()
  return y + h + 4
end

-- Compact top-of-tab filter chips (toggles and actions). Persisted flags
-- live in SavedVariables; "Collapse all" is a one-shot action.
local function HideTabFilterBar()
  if ui.tabFilters then
    ui.tabFilters:Hide()
  end
end

local function EnsureTabFilterBar()
  if ui.tabFilters then
    return ui.tabFilters
  end
  local bar = CreateFrame("Frame", "PhilosophersCodexTabFilters", ui.content)
  bar.buttons = {}
  ui.tabFilters = bar
  return bar
end

local function AcquireFilterChip(bar, i)
  local btn = bar.buttons[i]
  if btn then
    return btn
  end
  btn = CreateFrame("Button", "PhilosophersCodexTabFilter" .. i, bar)
  btn:SetHeight(CARDS.chipH)
  btn.bg = btn:CreateTexture(nil, "BACKGROUND")
  btn.bg:SetAllPoints()
  Paint(btn.bg, { r = 0.07, g = 0.07, b = 0.08 }, 0.6)
  btn.label = MakeFontString(btn, 10, "GameFontNormalSmall")
  btn.label:SetPoint("CENTER", 0, 0)
  bar.buttons[i] = btn
  return btn
end

local function LayoutTabFilterBar(y, chips)
  chips = chips or {}
  if #chips == 0 then
    HideTabFilterBar()
    return y
  end
  local bar = EnsureTabFilterBar()
  local w = ContentWidth()
  bar:ClearAllPoints()
  bar:SetPoint("TOPLEFT", ui.content, "TOPLEFT", 0, -y)
  bar:SetWidth(w)
  local gap, rowH, x, rows = 6, CARDS.chipH, 0, 1
  local inner = w - 8
  local kept = {}
  for i = 1, #chips do
    if chips[i] and not chips[i].skip then kept[#kept + 1] = chips[i] end
  end
  chips = kept
  if #chips == 0 then
    HideTabFilterBar()
    return y
  end
  for i = 1, math.max(#chips, #(bar.buttons or {})) do
    local spec = chips[i]
    local btn = AcquireFilterChip(bar, i)
    if not spec then
      btn:Hide()
    else
      btn:Show()
      local on0 = spec.on and spec.toggle ~= false and spec.label ~= "Collapse all"
      btn.label:SetText(((on0 and "|TInterface\\Buttons\\UI-CheckBox-Check:12:12|t") or "") .. (spec.label or ""))
      local on = spec.on and true or false
      CARDS.ChipStyle(btn, on, AccentColor())
      local bw = 72
      if spec.label and #spec.label > 8 then
        bw = 88
      end
      if spec.label and #spec.label > 12 then
        bw = 100
      end
      -- Cap to the bar. Mock or client GetStringWidth can be far wider
      -- than the chip should ever be, which used to push labels off the tab.
      if bw > inner then
        bw = inner
      end
      if x > 0 and (x + bw) > inner then
        x = 0
        rows = rows + 1
      end
      if x + bw > inner then
        bw = math.max(48, inner - x)
      end
      btn:ClearAllPoints()
      btn:SetPoint("TOPLEFT", bar, "TOPLEFT", 4 + x, -4 - (rows - 1) * (rowH + gap))
      btn:SetWidth(bw)
      btn:SetHeight(rowH)
      if btn.label then
        btn.label:ClearAllPoints()
        btn.label:SetPoint("LEFT", 6, 0)
        btn.label:SetPoint("RIGHT", -6, 0)
        if btn.label.SetJustifyH then
          btn.label:SetJustifyH("CENTER")
        end
        if btn.label.SetWidth then
          btn.label:SetWidth(math.max(20, bw - 12))
        end
        if PC.FitFontString then
          PC:FitFontString(btn.label, ((on0 and "|TInterface\\Buttons\\UI-CheckBox-Check:12:12|t") or "") .. (spec.label or ""), math.max(20, bw - 12), false)
        end
      end
      btn:SetScript("OnClick", function()
        if spec.onClick then
          spec.onClick(not on)
        end
      end)
      btn:SetScript("OnEnter", function(self)
        if spec.tip then
          ShowRowTooltip(self, spec.tip)
        end
      end)
      btn:SetScript("OnLeave", HideTooltip)
      x = x + bw + gap
    end
  end
  local h = 8 + rows * rowH + (rows - 1) * gap
  bar:SetHeight(h)
  bar:Show()
  return y + h + 4
end

local function CollapseAllChip()
  return {
    label = "Collapse all",
    -- Nothing expands in the list + pane layout, so the chip is noise there.
    skip = ui.split and true or false,
    on = false,
    tip = { { "Collapse all", GOLD.r, GOLD.g, GOLD.b }, "Closes every open group on this tab." },
    onClick = function()
      if PC.ResetTabState then
        PC:ResetTabState(ui.tab)
      end
      if PC.Refresh then
        PC:Refresh()
      end
    end,
  }
end

local function LayoutCraftDetail(rec, n, y)
  local plan = PC.GetProfessionPlan and PC:GetProfessionPlan(rec) or nil
  local pack = rec.pack or (plan and plan.pack) or (PC.GetProfessionData and select(1, PC:GetProfessionData(rec.id or rec.name)))
  if rec.pack == nil and pack then
    rec.pack = pack
  end
  n = n + 1
  y = ListRow(n, "Back", "All professions", nil, y, {
    noDetail = true,
    chevron = true,
    expanded = false,
    last = true,
    tip = { { "Back", GOLD.r, GOLD.g, GOLD.b }, "Return to your profession list." },
    onExpand = function()
      ui.craftProf = nil
      if PC.Refresh then
        PC:Refresh()
      end
    end,
  })

  local skill = (plan and plan.skill) or rec.skill or 0
  local maxSkill = (plan and plan.maxSkill) or rec.maxSkill or 0
  local rankName = PC.ProfessionRankLabel and PC:ProfessionRankLabel(pack, skill, maxSkill) or nil
  local skillText = "Skill " .. tostring(skill)
  if maxSkill and maxSkill > 0 then
    skillText = skillText .. " / " .. tostring(maxSkill)
  end
  if rankName then
    skillText = skillText .. "  ·  " .. rankName
  end
  if rec.unlearned then
    skillText = "Not trained yet"
  end
  n = n + 1
  y = ListRow(n, rec.name or "Profession", skillText, pack and pack.source or nil, y, {
    icon = rec.icon or (pack and pack.icon) or ClassIcon("professions"),
    last = true,
    titleColor = AccentColor(),
    progress = (not rec.unlearned) and { cur = skill, max = (maxSkill > 0 and maxSkill) or 75 } or nil,
    tip = {
      { rec.name or "Profession", GOLD.r, GOLD.g, GOLD.b },
      skillText,
    },
  })

  -- Craft next (efficient plan)
  local eff = PC.GetCraftEfficiencyPlan and PC:GetCraftEfficiencyPlan(rec) or nil
  local highlight = ui.craftHighlight
  local function isHighlight(name)
    if not highlight or not name then
      return false
    end
    return string.lower(tostring(name)) == string.lower(tostring(highlight))
  end
  n = n + 1
  y = Header(n, "Craft next", y)
  if plan and plan.needTrain and plan.rank then
    local r = plan.rank
    local where = r.trainer and (r.trainer .. (r.zone and (", " .. r.zone) or "")) or (r.zone or "your trainer")
    local wp = r.zone and PC.GetZoneWaypoint and PC:GetZoneWaypoint(r.zone) or nil
    n = n + 1
    y = ListRow(n, "Train " .. (r.name or "the next rank"), where .. "  ·  at skill " .. tostring(r.trainAt or "?"), r.note, y, {
      icon = ClassIcon("trainer"),
      waypoint = wp,
      last = true,
      titleColor = AccentColor(),
      accent = true,
      tip = { { r.name or "Trainer", GOLD.r, GOLD.g, GOLD.b }, r.note or (where .. ".") },
    })
  end
  if not pack then
    n = n + 1
    y = Body(n, "No written guide for " .. (rec.name or "this profession") .. " yet.", y)
  elseif eff and eff.current then
    local cur = eff.current
    local rgb = PC.ProfessionColorRGB and PC:ProfessionColorRGB(cur.color) or AccentColor()
    local note = cur.why or cur.feeds
    local focus = isHighlight(cur.recipe)
    local rowY = y
    n = n + 1
    y = ListRow(n, cur.headline or cur.recipe or "Next recipe", cur.detail, note, y, {
      icon = ClassIcon("professions"),
      last = true,
      titleColor = rgb,
      accent = true,
      bgTint = focus and { r = 0.16, g = 0.18, b = 0.14 } or nil,
      tag = focus and "Next" or (cur.color and string.upper(cur.color) or nil),
      tip = { { cur.recipe or rec.name, GOLD.r, GOLD.g, GOLD.b }, cur.detail or "", note or "" },
    })
    if focus then
      ui.craftFocusY = rowY
    end
  elseif plan and plan.step then
    local step = plan.step
    local color = plan.color or "gray"
    local rgb = PC.ProfessionColorRGB and PC:ProfessionColorRGB(color) or nil
    local mid = (PC.ProfessionStepSummary and PC:ProfessionStepSummary(plan)) or color
    n = n + 1
    y = ListRow(n, step.recipe or "Next recipe", mid, step.note, y, {
      icon = ClassIcon("professions"),
      last = true,
      titleColor = rgb,
      accent = isHighlight(step.recipe),
      tip = { { step.recipe or rec.name, GOLD.r, GOLD.g, GOLD.b }, mid or "", step.note or "" },
    })
  else
    n = n + 1
    y = Body(n, (plan and PC.ProfessionStepSummary and PC:ProfessionStepSummary(plan)) or "Nothing to craft right now.", y)
  end
  if pack and pack.source then
    n = n + 1
    local src = pack.source
    if not (eff and eff.confirmed) then
      src = src .. " This path is a labeled baseline; confirm Forever recipes before buying a lot of mats."
    end
    y = Body(n, src, y)
  end
  if eff and eff.upcoming and #eff.upcoming > 0 then
    n = n + 1
    y = Header(n, "Then", y)
    for i = 1, #eff.upcoming do
      local row = eff.upcoming[i]
      n = n + 1
      y = ListRow(n, row.title or row.recipe, row.detail, nil, y, {
        last = i == #eff.upcoming,
        tip = { { row.recipe or "Later", GOLD.r, GOLD.g, GOLD.b }, row.detail or "" },
      })
    end
  end
  if eff and eff.save and #eff.save > 0 then
    n = n + 1
    y = Header(n, "Save for later", y)
    for i = 1, #eff.save do
      n = n + 1
      y = Body(n, eff.save[i], y)
    end
  end

  -- Buy or loot
  n = n + 1
  y = Header(n, "Buy or loot", y)
  local mats = plan and plan.mats or {}
  if #mats == 0 then
    n = n + 1
    y = Body(n, "No materials are listed for the next milestone. If you still need a trainer, that is the next step.", y)
  else
    for m = 1, #mats do
      local row = mats[m]
      local source = PC.GetMatSource and PC:GetMatSource(row) or "AH or loot"
      n = n + 1
      y = ListRow(n, row.name or "Material", PC:FormatMatLine(row), source, y, {
        icon = row.id and PC.GetItemIcon and PC:GetItemIcon(row.id) or ClassIcon("professions"),
        itemID = row.id,
        last = m == #mats,
        titleColor = row.short and DANGER or nil,
        tip = {
          { row.name or "Material", GOLD.r, GOLD.g, GOLD.b },
          PC:FormatMatLine(row),
          "Where: " .. source .. ". Counts include bags and a cached bank when the client has one.",
        },
      })
    end
  end

  -- Craft list by skill range
  if pack and type(pack.steps) == "table" and #pack.steps > 0 then
    n = n + 1
    y = Header(n, "Craft", y)
    for i = 1, #pack.steps do
      local step = pack.steps[i]
      local from = step.from or 0
      local to = step.to or from
      local range = tostring(from) .. "–" .. tostring(to)
      local color = PC.ProfessionColor and PC:ProfessionColor(skill, step) or "gray"
      local rgb = PC.ProfessionColorRGB and PC:ProfessionColorRGB(color) or nil
      local past = skill >= (step.to or 0)
      local current = plan and plan.step == step
      local meta = range .. "  ·  " .. color
      if current then
        meta = meta .. "  ·  now"
      elseif past then
        meta = meta .. "  ·  done"
      end
      n = n + 1
      y = ListRow(n, step.recipe or ("Recipe " .. range), meta, step.note, y, {
        icon = ClassIcon("professions"),
        last = i == #pack.steps,
        accent = current,
        titleColor = current and rgb or (past and MUTED or rgb),
        tip = {
          { step.recipe or "Recipe", GOLD.r, GOLD.g, GOLD.b },
          "Skill " .. range .. "  ·  " .. color,
          step.note or "",
        },
      })
    end
  end

  -- Next trainer / rank
  if pack and type(pack.ranks) == "table" then
    local rank, needTrain = nil, false
    if PC.GetNextProfessionRank then
      rank, needTrain = PC:GetNextProfessionRank(pack, skill, maxSkill)
    elseif plan then
      rank, needTrain = plan.rank, plan.needTrain
    end
    if rank then
      n = n + 1
      y = Header(n, "Next trainer", y)
      local where = rank.trainer and (rank.trainer .. (rank.zone and (", " .. rank.zone) or "")) or (rank.zone or "your trainer")
      local mid = (needTrain and "Train now" or ("Available at skill " .. tostring(rank.trainAt or "?"))) .. "  ·  " .. where
      local wp = rank.zone and PC.GetZoneWaypoint and PC:GetZoneWaypoint(rank.zone) or nil
      n = n + 1
      y = ListRow(n, rank.name or "Next rank", mid, rank.note, y, {
        icon = ClassIcon("trainer"),
        waypoint = wp,
        last = true,
        accent = needTrain and true or false,
        titleColor = needTrain and AccentColor() or nil,
        tip = { { rank.name or "Trainer", GOLD.r, GOLD.g, GOLD.b }, rank.note or mid },
      })
    end
  end
  return n, y
end

local function LayoutCraftLanding(n, y, profs)
  n = n + 1
  y = ListRow(n, "Professions", "Tap a profession to see what to craft, buy, or loot next.", nil, y, {
    icon = ClassIcon("professions"),
    last = true,
    titleColor = AccentColor(),
    tip = {
      { "Professions", GOLD.r, GOLD.g, GOLD.b },
      "The Codex reads your skill levels from the client. Open a profession for the next craft, materials, and trainer.",
    },
  })
  if not PC.HasProfessionAPI or not PC:HasProfessionAPI() then
    n = n + 1
    y = Body(n, "This client did not expose a profession API, so skills could not be read. Type /codex issues if this stays empty.", y)
    return n, y, profs
  end
  if #profs == 0 then
    n = n + 1
    y = Body(n, "No professions detected on this character. Train Tailoring, First Aid, Cooking, or Fishing in a capital city to start a track. Journeyman Tailoring is Jormund Stonebrow in Ironforge, at skill 75.", y)
  end
  for i = 1, #profs do
    local rec = profs[i]
    local status, mid, plan = nil, nil, nil
    if PC.ProfessionLandingStatus then
      status, mid, plan = PC:ProfessionLandingStatus(rec)
    end
    local skillText = "Skill " .. tostring(rec.skill or 0)
    if rec.maxSkill and rec.maxSkill > 0 then
      skillText = skillText .. " / " .. tostring(rec.maxSkill)
    end
    if mid and mid ~= "" then
      skillText = skillText .. "  ·  " .. mid
    end
    local id = rec.id or rec.name
    n = n + 1
    y = ListRow(n, rec.name, skillText, status, y, {
      icon = rec.icon or ClassIcon("professions"),
      detailKey = "prof:" .. tostring(id),
      detail = function() return DETAIL.Profession(rec, skillText) end,
      chevron = true,
      last = i == #profs,
      titleColor = { r = GOLD.r, g = GOLD.g, b = GOLD.b },
      progress = { cur = rec.skill or 0, max = (rec.maxSkill and rec.maxSkill > 0) and rec.maxSkill or 75 },
      onExpand = function()
        ui.craftProf = id
        if PC.Refresh then
          PC:Refresh()
        end
      end,
      tip = {
        { rec.name, GOLD.r, GOLD.g, GOLD.b },
        skillText,
        status or "Tap to open this profession.",
      },
    })
  end
  return n, y, profs
end

local function LayoutUnlearnedProfessions(n, y, profs)
  local extra = PC.GetUnlearnedProfessions and PC:GetUnlearnedProfessions() or {}
  if #extra == 0 then
    return n, y
  end
  local open = PC:IsExpanded("craft-unlearned", false)
  n = n + 1
  y = ListRow(n, "Other professions", open and "Tap to hide professions you have not trained" or "Tap to browse professions you can train", nil, y, {
    icon = ClassIcon("professions"),
    chevron = true,
    expanded = open,
    last = true,
    tip = { { "Other professions", GOLD.r, GOLD.g, GOLD.b }, "Guides for professions this character has not trained yet." },
    onExpand = function()
      PC:ToggleExpanded("craft-unlearned", false)
    end,
  })
  if open then
    for i = 1, #extra do
      local rec = extra[i]
      n = n + 1
      y = ListRow(n, rec.name, "Not trained", rec.pack and rec.pack.source or nil, y, {
        icon = rec.icon or ClassIcon("professions"),
        detailKey = "prof:" .. tostring(rec.id or rec.name),
        detail = function() return DETAIL.Profession(rec, "Not trained") end,
        chevron = true,
        last = i == #extra,
        onExpand = function()
          ui.craftProf = rec.id or rec.name
          if PC.Refresh then
            PC:Refresh()
          end
        end,
        tip = { { rec.name, GOLD.r, GOLD.g, GOLD.b }, "Open the guide for this profession." },
      })
    end
  end
  return n, y
end

local function FindProfessionRecord(id)
  if not id then
    return nil
  end
  local want = string.lower(tostring(id))
  local profs = PC.GetPlayerProfessions and PC:GetPlayerProfessions() or {}
  for i = 1, #profs do
    local rec = profs[i]
    if rec.id and string.lower(tostring(rec.id)) == want then
      return rec
    end
    if rec.name and string.lower(rec.name) == want then
      return rec
    end
  end
  local extra = PC.GetUnlearnedProfessions and PC:GetUnlearnedProfessions() or {}
  for i = 1, #extra do
    local rec = extra[i]
    if rec.id and string.lower(tostring(rec.id)) == want then
      return rec
    end
    if rec.name and string.lower(rec.name) == want then
      return rec
    end
  end
  if PC.GetProfessionData then
    local pack, key = PC:GetProfessionData(id)
    if pack then
      return { name = pack.name, id = key or pack.id, pack = pack, icon = pack.icon, skill = 0, maxSkill = 0, unlearned = true }
    end
  end
  return nil
end

local function LayoutCraft()
  HideTodayCard()
  HideGearFilterBar()
  ui.craftFocusY = nil
  local y = 0
  local n = 0
  local profs = PC.GetPlayerProfessions and PC:GetPlayerProfessions() or {}
  local openId = ui.craftProf
  local openRec = openId and FindProfessionRecord(openId) or nil
  if openId and not openRec then
    ui.craftProf = nil
  end
  if openRec then
    n, y = LayoutCraftDetail(openRec, n, y)
  else
    n, y = LayoutCraftLanding(n, y, profs)
    n, y = LayoutUnlearnedProfessions(n, y, profs)
  end
  SetContentHeight(y)
  if ui.craftFocusY then
    ScrollContentTo(math.max(0, ui.craftFocusY - 48))
  end
end


local function QuestStatusLabel(st)
  if st == "log" then
    return "In log"
  end
  if st == "complete" then
    return "Complete"
  end
  if st == "gray" then
    return "Gray  ·  not picked up"
  end
  if st == "available" then
    return "Not picked up"
  end
  return nil
end

local function EmitZoneQuestRow(n, y, quest, last, indent, isChild)
  local st = quest._status or (PC.GetZoneQuestStatus and PC:GetZoneQuestStatus(quest)) or "available"
  local parts = {}
  if quest.level then
    parts[#parts + 1] = "Level " .. tostring(quest.level)
  elseif quest.minLevel then
    parts[#parts + 1] = "Req " .. tostring(quest.minLevel)
  end
  if quest.giver and quest.giver ~= "" then
    parts[#parts + 1] = quest.giver
  end
  local statusText = QuestStatusLabel(st)
  if statusText then
    parts[#parts + 1] = statusText
  end
  local wp = PC.GetQuestWaypoint and PC:GetQuestWaypoint(quest) or nil
  n = n + 1
  y = ListRow(n, quest.name or "Quest", table.concat(parts, "  ·  "), quest.where, y, {
    icon = ClassIcon("zones"),
    detailKey = "quest:" .. tostring(quest.id or quest.name),
    detail = function() return DETAIL.Quest(quest, statusText, wp) end,
    indent = indent or 0,
    kind = isChild and "child" or "parent",
    chevron = false,
    waypoint = wp,
    last = last,
    checkable = (st == "log" or st == "available" or st == "gray"),
    checked = (st == "log"),
    tag = (st == "log" and "In log") or nil,
    tip = {
      { quest.name or "Quest", GOLD.r, GOLD.g, GOLD.b },
      statusText or "",
      quest.giver and ("Giver: " .. quest.giver) or "",
      quest.where or "",
      "Tap the pin to mark the giver when a location is known.",
    },
  })
  return n, y
end

local function EmitZoneQuestTree(n, y, zoneName)
  if not PC.GetZoneQuestTrees then
    return n, y
  end
  local trees, summary = PC:GetZoneQuestTrees(zoneName)
  summary = summary or { available = 0, log = 0, done = 0, total = 0 }
  local visible = {}
  local doneTrees = 0
  for i = 1, #trees do
    if trees[i].allDone or trees[i].hiddenDone then
      doneTrees = doneTrees + 1
    else
      visible[#visible + 1] = trees[i]
    end
  end
  if #visible == 0 and doneTrees == 0 and (summary.total or 0) == 0 then
    n = n + 1
    y = Body(n, "No quest list for this zone yet. Missing zones are logged under /codex issues.", y)
    if PC.LogMissing then
      PC:LogMissing("zone-quests", zoneName, "Path zone has no quest list yet: " .. tostring(zoneName))
    end
    return n, y
  end
  if #visible == 0 and doneTrees > 0 then
    n = n + 1
    y = Body(n, "All " .. tostring(summary.done or doneTrees) .. " catalogued quests in this zone are done.", y)
    return n, y
  end
  for i = 1, #visible do
    local tree = visible[i]
    local children = tree.children or {}
    -- Parent row: the chain starter, or the chain title if the starter is already done.
    if tree.parent and tree.parentVisible then
      n, y = EmitZoneQuestRow(n, y, tree.parent, (#children == 0 and i == #visible), 0, false)
    elseif tree.name and #children > 0 then
      n = n + 1
      y = ListRow(n, tree.name, "Chain  ·  " .. tostring(#children) .. " next", nil, y, {
        icon = ClassIcon("zones"),
        last = false,
        tip = { { tree.name, GOLD.r, GOLD.g, GOLD.b }, "The first quest in this line is done. Follow-ups are listed below." },
      })
    end
    for c = 1, #children do
      n, y = EmitZoneQuestRow(n, y, children[c], (c == #children and i == #visible and doneTrees == 0), 18, true)
    end
  end
  if doneTrees > 0 or (summary.done and summary.done > 0) then
    n = n + 1
    y = ListRow(n, "Done  ·  " .. tostring(summary.done or doneTrees), "Completed quests are hidden from the pick-up list.", nil, y, {
      last = true,
      tip = { { "Done", GOLD.r, GOLD.g, GOLD.b }, "Turned-in quests drop off this list so you can see what is still left to pick up." },
    })
  end
  return n, y
end

local function EmitPathZoneRow(n, y, zoneName, last, hereY)
  local isHere = PC.IsCurrentZoneName and PC:IsCurrentZoneName(zoneName) or false
  local pending = PC._pendingPathZone and zoneName and string.lower(tostring(PC._pendingPathZone)) == string.lower(tostring(zoneName))
  local focus = isHere or pending
  local open = PC.IsPathZoneExpanded and PC:IsPathZoneExpanded(zoneName) or false
  if ui.split then
    open = false -- quests and chains live in the right pane
  end
  local summary = PC.GetZoneQuestSummary and PC:GetZoneQuestSummary(zoneName) or nil
  local meta
  if isHere then
    meta = "You are here"
  elseif pending then
    meta = "From Next"
  else
    meta = "Tap to show quests  ·  pin to mark the zone"
  end
  if summary and (summary.total or 0) > 0 then
    local bits = {}
    if (summary.available or 0) > 0 then
      bits[#bits + 1] = tostring(summary.available) .. " to pick up"
    end
    if (summary.log or 0) > 0 then
      bits[#bits + 1] = tostring(summary.log) .. " in log"
    end
    if (summary.done or 0) > 0 then
      bits[#bits + 1] = tostring(summary.done) .. " done"
    end
    if #bits > 0 then
      meta = (isHere and "You are here  ·  " or "") .. table.concat(bits, "  ·  ")
    end
  end
  local tint
  if focus or open then
    local a = AccentColor()
    tint = { r = 0.08 + a.r * 0.18, g = 0.08 + a.g * 0.18, b = 0.08 + a.b * 0.18 }
  end
  n = n + 1
  local rowY = y
  y = ListRow(n, zoneName, meta, nil, y, {
    icon = ClassIcon("zones"),
    detailKey = "zone:" .. tostring(zoneName),
    detail = function() return DETAIL.Zone(zoneName, nil, meta) end,
    waypoint = PC:GetZoneWaypoint(zoneName),
    last = (not open) and last,
    accent = focus or open,
    kind = "parent",
    count = summary and (summary.available or 0) or nil,
    tag = isHere and "You are here" or (pending and "Next" or nil),
    titleColor = (focus or open) and AccentColor() or nil,
    bgTint = tint,
    chevron = true,
    expanded = open,
    onExpand = function()
      if PC.TogglePathZoneQuests then
        PC:TogglePathZoneQuests(zoneName)
      end
    end,
    tip = {
      { zoneName, GOLD.r, GOLD.g, GOLD.b },
      isHere and "This is your current zone." or "Tap to show or hide the quests to pick up here.",
      "The pin sets a map waypoint for a verified flight master or town NPC.",
    },
  })
  if isHere and hereY and hereY[1] == nil then
    hereY[1] = rowY
    hereY[2] = zoneName
  end
  if pending and not ui.pathFocusY then
    ui.pathFocusY = rowY
  end
  if open then
    n, y = EmitZoneQuestTree(n, y, zoneName)
  end
  return n, y
end

local function EmitPathBracket(n, y, b, hereY)
  n = n + 1
  y = Header(n, b.heading, y)
  local zones = b.zones or {}
  if #zones > 0 then
    n = n + 1
    y = Header(n, "Zones", y)
    for z = 1, #zones do
      if (not Searching()) or PC:TextMatches(Query(), zones[z]) then
        n, y = EmitPathZoneRow(n, y, zones[z], z == #zones, hereY)
      end
    end
  end
  if b.zoneHint and not Searching() then
    n = n + 1
    y = Body(n, b.zoneHint, y)
  end
  local dungeons = b.dungeons or {}
  local shown = {}
  for j = 1, #dungeons do
    if DungeonMatches(dungeons[j]) then
      shown[#shown + 1] = dungeons[j]
    end
  end
  for j = 1, #shown do
    n, y = LayoutDungeonBlock(n, y, shown[j], j == #shown)
  end
  return n, y
end

local function LayoutPath()
  local data = PC:GetClassData()
  local y = 0
  local n = 0
  local db = PC:GetDB()
  HideTodayCard()
  HideGearFilterBar()
  ui.pathHereY = nil
  ui.pathHereKey = nil
  ui.pathFocusY = nil

  if not data or not data.brackets or #data.brackets == 0 then
    n, y = ComingSoonBody(n, y, data)
    SetContentHeight(y)
    return
  end
  if not data.supported then
    n, y = ComingSoonBody(n, y, data)
  end
  -- 1.22.0: races without a starting route (Human, Dwarf so far) get a note
  -- instead of an empty list until the shared route starts at 21.
  if not data.startTitle and (PC:PlayerLevel() or 1) < 21 then
    n = n + 1
    local race = (UnitRace and select(1, UnitRace("player"))) or "your race"
    y = Body(n, "Starting zone guide for " .. tostring(race) .. " is coming soon. Until then, follow your starting zone's quests. The shared Alliance route below picks up at level 21, and the Gear, Craft, and Guild tabs work now.", y)
  end

  y = LayoutTabFilterBar(y, {
    {
      label = "All brackets",
      on = db and db.showAllBrackets and true or false,
      tip = { { "Show all level brackets", GOLD.r, GOLD.g, GOLD.b }, "On shows every bracket so you can plan ahead. Off keeps the list focused on your level." },
      onClick = function(on)
        local d = PC:GetDB()
        if d then
          d.showAllBrackets = on and true or false
        end
        if PC.Refresh then
          PC:Refresh()
        end
      end,
    },
    {
      label = "Gray quests",
      on = not (PC.IsHideGrayQuests and PC:IsHideGrayQuests()),
      tip = { { "Show gray quests", GOLD.r, GOLD.g, GOLD.b }, "Gray quests are six or more levels below you. Leave this off unless you are finishing leftover starters." },
      onClick = function(on)
        if PC.SetHideGrayQuests then
          PC:SetHideGrayQuests(not on)
        end
      end,
    },
    CollapseAllChip(),
  })

  local rec = PC.GetRecommendedZone and PC:GetRecommendedZone() or nil
  if rec then
    local title = rec.name or "No recommended zone"
    local mid = rec.here and "You're already in the recommended zone" or "Recommended zone"
    n = n + 1
    y = ListRow(n, "Recommended zone", title, rec.why, y, {
      icon = ClassIcon("zones"),
      waypoint = rec.waypoint,
      last = true,
      accent = true,
      kind = "parent",
      titleColor = AccentColor(),
      tip = {
        { "Recommended zone", GOLD.r, GOLD.g, GOLD.b },
        rec.name or "",
        rec.why or "Best zone for your current level on the Alliance route.",
      },
    })
  end

  local brackets
  if db.showAllBrackets then
    brackets = data.brackets
  else
    brackets = PC:GetCurrentBrackets()
  end

  if #brackets == 0 then
    n = n + 1
    y = Body(n, "No path is written for level " .. PC:PlayerLevel() .. ".", y)
  end

  local hereY = {}
  for i = 1, #brackets do
    local b = brackets[i]
    if Searching() then
      local any = false
      local dungeons = b.dungeons or {}
      for j = 1, #dungeons do
        if DungeonMatches(dungeons[j]) then
          any = true
          break
        end
      end
      local zones = b.zones or {}
      for z = 1, #zones do
        if PC:TextMatches(Query(), zones[z]) then
          any = true
          break
        end
      end
      if any then
        n, y = EmitPathBracket(n, y, b, hereY)
      end
    else
      n, y = EmitPathBracket(n, y, b, hereY)
    end
  end

  SetContentHeight(y)
  local focusY = ui.pathFocusY or hereY[1]
  if hereY[1] then
    ui.pathHereY = hereY[1]
    ui.pathHereKey = tostring(hereY[2] or "") .. ":" .. tostring(PC:PlayerLevel() or 0)
  end
  local pending = PC._pendingPathZone or PC._pendingPathDungeon
  local shouldScroll = ui.pendingPathScroll or pending or (hereY[1] and ui.lastPathHereKey ~= ui.pathHereKey)
  if shouldScroll and focusY then
    ScrollContentTo(math.max(0, focusY - 72))
    if ui.pathHereKey then
      ui.lastPathHereKey = ui.pathHereKey
    end
  end
  PC._pendingPathZone = nil
  PC._pendingPathDungeon = nil
  ui.pathFocusY = nil
  ui.pendingPathScroll = false
end


local WEAPON_ORDER = { "Main Hand", "Off Hand", "Two-Hand", "Ranged", "Wand" }
local ARMOR_ORDER = { "Head", "Shoulder", "Chest", "Wrist", "Hands", "Waist", "Legs", "Feet", "Back" }
local JEWELRY_ORDER = { "Neck", "Finger", "Trinket" }

local function GearItemIsUpgrade(item, recent)
  if not item then
    return false
  end
  for i = 1, #(recent or {}) do
    local rec = recent[i]
    if item.itemID and rec.itemID and rec.itemID == item.itemID then
      return true
    end
    if rec.name and item.name and rec.name == item.name then
      return true
    end
  end
  return false
end

local function LayoutGearItem(n, y, item, last, upgrade)
  local checked = PC:IsGearChecked(item.id)
  if not Matches(checked, item.name, item.source, item.boss, item.slot) then
    return n, y
  end
  local parts = {}
  if item.slot then parts[#parts + 1] = item.slot end
  if item.reqLevel then parts[#parts + 1] = "Req " .. tostring(item.reqLevel) end
  if item.where and item.where ~= "" then
    parts[#parts + 1] = item.where
  else
    if item.source then parts[#parts + 1] = item.source end
    if item.boss then parts[#parts + 1] = item.boss end
  end
  if item.itemID then
    if PC:GetItemCount(item.itemID, true) > 0 then
      parts[#parts + 1] = "in bags or bank"
    end
  elseif PC:PlayerHasItemByName(item.name) then
    parts[#parts + 1] = "name match in bags"
  end
  local icon = item.itemID and PC:GetItemIcon(item.itemID) or nil
  local meta = table.concat(parts, "  ·  ")
  n = n + 1
  y = ListRow(n, item.name, meta, item.note, y, {
    icon = icon,
    itemID = item.itemID,
    detailKey = "gearitem:" .. tostring(item.itemID or item.id or item.name),
    detail = function()
      local info = {}
      for k, v in pairs(item) do info[k] = v end
      info.meta = meta
      return DETAIL.Gear(info)
    end,
    checkable = true,
    checked = checked,
    onClick = function(isChecked)
      PC:SetGearChecked(item.id, isChecked)
    end,
    checkTip = CheckTipFor("gear"),
    last = last,
    qualityColor = ItemQualityColor(item.itemID),
    accent = (upgrade or item.bestPick) and true or false,
    tag = (item.bestPick and "Best pick") or (upgrade and "Upgrade") or nil,
    waypoint = item.waypoint,
  })
  return n, y
end

local function LayoutGear()
  local data = PC:GetClassData()
  local y = 0
  local n = 0
  HideTodayCard()
  y = LayoutGearFilterBar(y)
  y = LayoutTabFilterBar(y, { CollapseAllChip() })
  local filter = CurrentGearFilter()
  if not data then
    n, y = ComingSoonBody(n, y, data)
    SetContentHeight(y)
    return
  end
  if not data.supported then
    n, y = ComingSoonBody(n, y, data)
  end

  local level = PC:PlayerLevel() or 1
  local recs = PC.GetRecommendedGear and PC:GetRecommendedGear(level) or { soon = {}, later = {} }
  local soon = recs.soon or {}
  local later = recs.later or {}
  local recent = PC.GetRecentUpgrades and PC:GetRecentUpgrades() or {}

  local function passesFilter(item)
    if filter == "all" or filter == "upgrades" then
      return true
    end
    local cat = item.category
    if not cat and PC.ClassifyGearSlot then
      cat = PC:ClassifyGearSlot(item.slot)
    end
    return filter == cat
  end

  local function emitRec(item, last)
    local row = {
      id = item.id,
      name = item.name,
      itemID = item.itemID,
      slot = item.subslot or item.slot,
      source = item.source,
      boss = item.boss,
      reqLevel = item.reqLevel,
      note = item.note,
      where = item.where,
      waypoint = item.waypoint,
      bestPick = item.bestPick,
      upgrade = item.upgrade,
    }
    n, y = LayoutGearItem(n, y, row, last, item.upgrade or item.bestPick or GearItemIsUpgrade(row, recent))
  end

  local showRecent = (filter == "all" or filter == "upgrades") and #recent > 0
  if showRecent then
    n = n + 1
    y = Header(n, "Recent upgrades", y)
    for i = 1, #recent do
      local rec = recent[i]
      if not Searching() or PC:TextMatches(Query(), rec.name, rec.text) then
        local meta = rec.text or ""
        if rec.tooHigh then
          meta = (meta ~= "" and (meta .. "  ·  ") or "") .. "Upgrade at level " .. tostring(rec.tooHigh)
        end
        local icon = rec.itemID and PC:GetItemIcon(rec.itemID) or nil
        n = n + 1
        y = ListRow(n, rec.name or "Upgrade", meta, nil, y, {
          icon = icon,
          itemID = rec.itemID,
          detailKey = "gear:" .. tostring(rec.itemID or rec.name),
          detail = function()
            return DETAIL.Gear({ name = rec.name, itemID = rec.itemID, meta = meta })
          end,
          last = i == #recent,
          accent = true,
          tag = "Upgrade",
          qualityColor = ItemQualityColor(rec.itemID),
          tip = { { rec.name or "Upgrade", GOLD.r, GOLD.g, GOLD.b }, "A recent Codex upgrade alert. Hover for the item tooltip when an ID is known." },
        })
      end
    end
  end

  -- Recommended (soon) list, grouped by slot and sorted by upgrade score.
  local soonFiltered = {}
  for i = 1, #soon do
    if passesFilter(soon[i]) then
      if filter ~= "upgrades" or soon[i].upgrade then
        if not Searching() or PC:TextMatches(Query(), soon[i].name, soon[i].source, soon[i].where, soon[i].slot) then
          soonFiltered[#soonFiltered + 1] = soon[i]
        end
      end
    end
  end

  n = n + 1
  y = Header(n, "Recommended for level " .. tostring(level), y)
  if #soonFiltered == 0 then
    n = n + 1
    local empty = "No on-level upgrades in the catalog right now. Items more than a few levels above you are hidden, including later dungeons such as Stratholme."
    if filter == "upgrades" then
      empty = "No scored upgrades in the current level window. Inspect or loot something on-level, or switch the filter to All."
    end
    y = Body(n, empty, y)
  else
    local groups = { weapons = {}, armor = {}, jewelry = {}, other = {} }
    for i = 1, #soonFiltered do
      local item = soonFiltered[i]
      local cat, sub = item.category or "other", item.subslot or item.slot or "Other"
      local bucket = groups[cat] or groups.other
      bucket[sub] = bucket[sub] or {}
      bucket[sub][#bucket[sub] + 1] = item
    end
    local function emitCategory(title, order, bucket)
      if not bucket then
        return
      end
      local any = false
      for i = 1, #order do
        if bucket[order[i]] and #bucket[order[i]] > 0 then
          any = true
          break
        end
      end
      if not any then
        for _, list in pairs(bucket) do
          if #list > 0 then
            any = true
            break
          end
        end
      end
      if not any then
        return
      end
      n = n + 1
      y = Header(n, title, y)
      local function emitSub(label)
        local list = bucket[label]
        if not list or #list == 0 then
          return
        end
        n = n + 1
        y = Header(n, label, y)
        for i = 1, #list do
          emitRec(list[i], i == #list)
        end
        bucket[label] = nil
      end
      for i = 1, #order do
        emitSub(order[i])
      end
      local leftovers = {}
      for label, list in pairs(bucket) do
        if list and #list > 0 then
          leftovers[#leftovers + 1] = label
        end
      end
      table.sort(leftovers)
      for i = 1, #leftovers do
        emitSub(leftovers[i])
      end
    end
    if filter == "all" or filter == "weapons" or filter == "upgrades" then
      emitCategory("Weapons", WEAPON_ORDER, groups.weapons)
    end
    if filter == "all" or filter == "armor" or filter == "upgrades" then
      emitCategory("Armor", ARMOR_ORDER, groups.armor)
    end
    if filter == "all" or filter == "jewelry" or filter == "upgrades" then
      emitCategory("Jewelry", JEWELRY_ORDER, groups.jewelry)
    end
    if filter == "all" or filter == "upgrades" then
      emitCategory("Other", {}, groups.other)
    end
  end

  -- Collapsed Later: only the next bracket / window, never far-future raids.
  local laterFiltered = {}
  for i = 1, #later do
    if passesFilter(later[i]) then
      if not Searching() or PC:TextMatches(Query(), later[i].name, later[i].source, later[i].where) then
        laterFiltered[#laterFiltered + 1] = later[i]
      end
    end
  end
  if #laterFiltered > 0 then
    local laterKey = "gear-later"
    local open = PC:IsExpanded(laterKey, false)
    n = n + 1
    y = ListRow(n, "Later  ·  " .. tostring(#laterFiltered) .. " in the next window", open and "Tap to hide" or "A few levels out. Far-future dungeons stay hidden.", nil, y, {
      chevron = true,
      expanded = open,
      last = not open,
      onExpand = function()
        PC:ToggleExpanded(laterKey, false)
      end,
      tip = { { "Later", GOLD.r, GOLD.g, GOLD.b }, "The next level window only. Pieces like Stratholme loot stay hidden until you are close enough to run that dungeon." },
    })
    if open then
      for i = 1, #laterFiltered do
        emitRec(laterFiltered[i], i == #laterFiltered)
      end
    end
  end
  SetContentHeight(y)
end

local function LayoutGoals(mode)
  local data = PC:GetClassData()
  local y = 0
  local n = 0
  ui.goalFocusY = nil
  HideTodayCard()
  if ui.gearFilters then
    ui.gearFilters:Hide()
  end
  if not data or not data.supported then
    n, y = ComingSoonBody(n, y, data)
    SetContentHeight(y)
    return
  end

  y = LayoutTabFilterBar(y, { CollapseAllChip() })

  local level = PC:PlayerLevel() or 1
  local groups = data.goalGroups or {}
  local currentGoalIcon = ClassIcon("goals")

  local byId = {}
  for i = 1, #(data.milestones or {}) do
    local m = data.milestones[i]
    byId[m.id] = m
  end

  local function emitMilestone(m, last)
    local checked = PC:IsMilestoneChecked(m.id)
    if not Matches(checked, m.name, m.note, m.spellName) then
      return
    end
    local parts = {}
    if m.level then
      if PC:MilestoneLevelReached(m) then
        parts[#parts + 1] = "Level " .. m.level .. " reached"
      else
        parts[#parts + 1] = "Level " .. m.level
      end
    end
    if m.spellName and PC:PlayerKnowsSpell(m.spellName) then
      parts[#parts + 1] = "spell detected"
    end
    local wp
    if (m.id == "riding" or m.id == "first-mount") and PC.GetRaceFile and PC:GetRaceFile() == "NightElf" then
      wp = PC:GetTrainerWaypoint("jartsam")
    elseif m.spellName then
      wp = PC.GetClassTrainerWaypoint and PC:GetClassTrainerWaypoint() or nil
    end
    n = n + 1
    y = ListRow(n, m.name, table.concat(parts, "  ·  "), m.note, y, {
      icon = (m.spellName or m.spellID) and SpellIcon({ n = m.spellName, id = m.spellID, spellName = m.spellName }) or (currentGoalIcon or ClassIcon("goals")),
      checkable = true,
      checked = checked,
      onClick = function(isChecked)
        PC:SetMilestoneChecked(m.id, isChecked)
      end,
      checkTip = CheckTipFor("goal"),
      waypoint = wp,
      last = last,
      tip = {
        { m.name, GOLD.r, GOLD.g, GOLD.b },
        "Tick the box to mark this goal done. Trainer pins, when shown, use only verified coordinates.",
      },
    })
  end

  local function emitTrainer()
    local summary = PC.GetTrainerVisitSummary and PC:GetTrainerVisitSummary(level) or { groups = {}, role = 0, available = 0 }
    local pack = PC.GetSpellPack and PC:GetSpellPack() or nil
    local src = pack and pack.source or (PhilosophersCodexData and PhilosophersCodexData.SPELL_SOURCE)
    n = n + 1
    y = Body(n, "Must train and current-role ranks still to learn: " .. tostring(summary.role or 0) .. ". Available at your level now: " .. tostring(summary.available or 0) .. ". Training prices are not in the Forever client (they live on Blizzard's servers). Official note: all class abilities from 1 to 60 cost about 206-207 gold total.", y)
    if not pack or not pack.list or (summary.total or 0) == 0 then
      n = n + 1
      y = Body(n, "No trainer spells loaded for this class. If this stays empty, type /codex issues, copy the log, and send it so the spell list can be fixed.", y)
    end
    local wp = PC.GetClassTrainerWaypoint and PC:GetClassTrainerWaypoint() or nil
    if wp then
      n = n + 1
      y = ListRow(n, "Pin your class trainer", wp.note or "Coordinates verified in this addon.", nil, y, {
        waypoint = wp,
        last = true,
        tip = {
          { wp.title or "Class trainer", GOLD.r, GOLD.g, GOLD.b },
          (wp.zone and (wp.title or "Trainer") .. " in " .. wp.zone) or (wp.title or "Verified trainer pin."),
        },
      })
    end
    local buckets = summary.groups or {}
    for i = 1, #buckets do
      local bucket = buckets[i]
      local lvl = bucket.level
      local spells = bucket.spells or {}
      local visible = {}
      for j = 1, #spells do
        local sp = spells[j]
        local known = PC:PlayerKnowsTrainerSpell(sp)
        local tag, reason = PC:RecommendTrainerSpell(sp)
        local available = (not known) and (sp.l or 99) <= level
        local label = PC:TrainerSpellLabel(sp)
        if Matches(known, label, reason, tag, sp.note) then
          visible[#visible + 1] = { sp = sp, known = known, tag = tag, reason = reason, available = available, label = label }
        end
      end
      if #visible > 0 then
        n = n + 1
        y = Header(n, "Level " .. tostring(lvl) .. (lvl <= level and "  ·  available" or "  ·  upcoming"), y)
        for j = 1, #visible do
          local v = visible[j]
          local recLabel = PC:RecommendLabel(v.tag)
          local parts = { recLabel }
          if v.known then
            parts[#parts + 1] = "already known"
          elseif v.available then
            parts[#parts + 1] = "Available to train now"
          else
            parts[#parts + 1] = "at " .. tostring(v.sp.l)
          end
          local note = v.reason
          if v.sp.note then
            note = (note and (note .. "  ") or "") .. v.sp.note
          end
          if v.sp.new then
            note = (note and (note .. "  ") or "") .. "New in Forever."
          end
          local titleColor
          if v.known then
            titleColor = { r = SUB.r, g = SUB.g, b = SUB.b }
          elseif v.available and v.tag ~= "skip" then
            titleColor = { r = EMERALD.r, g = EMERALD.g, b = EMERALD.b }
          elseif v.tag == "skip" then
            titleColor = { r = MUTED.r, g = MUTED.g, b = MUTED.b }
          end
          local focus = PC._pendingGoalSpell and v.sp and v.sp.n and string.lower(tostring(PC._pendingGoalSpell)) == string.lower(tostring(v.sp.n))
          if focus then
            titleColor = AccentColor()
          end
          n = n + 1
          local rowY = y
          local rowMeta, rowNote = table.concat(parts, "  ·  "), note
          local spellOpts = {
            icon = SpellIcon(v.sp),
            titleColor = titleColor,
            last = j == #visible,
            accent = focus,
            detailKey = "spell:" .. tostring(v.sp.n) .. ":" .. tostring(v.sp.r or 0),
            tip = {
              { v.label, GOLD.r, GOLD.g, GOLD.b },
              recLabel .. ". " .. (v.reason or ""),
              v.sp.note or (src and src.totalGoldNote) or "",
            },
          }
          spellOpts.detail = function()
            local spec = DETAIL.FromRow(v.label, rowMeta, rowNote, spellOpts)
            spec.icon = SpellIcon(v.sp)
            if wp and PC.SetWaypoint then
              table.insert(spec.actions, 1, { label = "Pin trainer", run = function() PC:SetWaypoint(wp) end,
                tip = { { "Pin trainer", GOLD.r, GOLD.g, GOLD.b }, wp.title or "Your class trainer." } })
            end
            local what = PC.GetSpellText and PC:GetSpellText(v.sp.n) or nil
            if what then
              table.insert(spec.sections, 1, { title = "What it does", text = what })
            end
            spec.sections[#spec.sections + 1] = { title = "Train at", lines = { { text = "Level " .. tostring(v.sp.l or "?") } } }
            return spec
          end
          y = ListRow(n, v.label, rowMeta, rowNote, y, spellOpts)
          if focus and not ui.goalFocusY then
            ui.goalFocusY = rowY
          end
        end
      end
    end
  end

  local function emitGear()
    local lines = data.gearPriorities
    if type(lines) == "table" then
      for i = 1, #lines do
        n = n + 1
        y = Body(n, lines[i], y)
      end
    else
      n = n + 1
      y = Body(n, "No written stat priorities for this class yet. Use the upgrade scorer on items you inspect.", y)
    end
  end

  local function emitZones()
    local brackets = data.brackets or {}
    local level = PC:PlayerLevel() or 1
    for i = 1, #brackets do
      local b = brackets[i]
      local title = b.heading or (("Levels " .. tostring(b.min or "?") .. "-" .. tostring(b.max or "?")))
      local parts = {}
      if b.min and b.max then
        parts[#parts + 1] = "Levels " .. tostring(b.min) .. "-" .. tostring(b.max)
        if level >= b.min and level <= b.max then
          parts[#parts + 1] = "current"
        elseif level > b.max then
          parts[#parts + 1] = "past"
        else
          parts[#parts + 1] = "upcoming"
        end
      end
      local mid = table.concat(parts, "  ·  ")
      if mid == "" then mid = nil end
      local note = b.zoneHint
      if (not note or note == "") and type(b.zones) == "table" and #b.zones > 0 then
        note = table.concat(b.zones, ", ")
      end
      local wp
      if type(b.zones) == "table" and b.zones[1] and PC.GetZoneWaypoint then
        wp = PC:GetZoneWaypoint(b.zones[1])
      end
      local id = "zone-" .. tostring(b.id or i)
      local checked = PC:IsMilestoneChecked(id)
      if Matches(checked, title, mid, note) then
        n = n + 1
        y = ListRow(n, title, mid, note, y, {
          icon = ClassIcon("zones"),
          checkable = true,
          checked = checked,
          onClick = function(isChecked)
            PC:SetMilestoneChecked(id, isChecked)
          end,
          checkTip = CheckTipFor("goal"),
          waypoint = wp,
          last = i == #brackets,
          tip = {
            { title, GOLD.r, GOLD.g, GOLD.b },
            note or "Leveling zone band on the Alliance route.",
          },
        })
      end
    end
  end

  local function dungeonRangeLooksReal(range)
    if type(range) ~= "string" or range == "" then
      return false
    end
    if range:find("already completed", 1, true) or range == "skipped" then
      return false
    end
    return range:find("%d") and true or false
  end

  local function goalDungeons()
    local data = PC:GetClassData()
    local best = {}
    local order = {}
    for i = 1, #((data and data.brackets) or {}) do
      local dungeons = data.brackets[i].dungeons or {}
      for j = 1, #dungeons do
        local d = dungeons[j]
        local id = d and (d.id or d.name)
        if id then
          local cur = best[id]
          if not cur then
            best[id] = d
            order[#order + 1] = id
          elseif (not dungeonRangeLooksReal(cur.range) and dungeonRangeLooksReal(d.range))
              or (cur.skipped and not d.skipped and dungeonRangeLooksReal(d.range)) then
            best[id] = d
          end
        end
      end
    end
    local list = {}
    for i = 1, #order do
      list[#list + 1] = best[order[i]]
    end
    return list
  end

  local function emitDungeons()
    local list = goalDungeons()
    for i = 1, #list do
      local d = list[i]
      local title = d.name or d.id or "Dungeon"
      local parts = {}
      if d.range and d.range ~= "" then
        parts[#parts + 1] = d.range
      end
      if d.skipped then
        parts[#parts + 1] = "optional / skipped"
      end
      local mid = table.concat(parts, "  ·  ")
      if mid == "" then mid = nil end
      local wp = PC.GetEntranceWaypoint and d.id and PC:GetEntranceWaypoint(d.id) or nil
      local checked = d.id and PC:IsDungeonChecked(d.id)
      if Matches(checked, title, mid, d.note) then
        n = n + 1
        y = ListRow(n, title, mid, d.note, y, {
          icon = (PC.GetDungeonIcon and d.id and PC:GetDungeonIcon(d.id)) or ClassIcon("dungeons"),
          dungeonId = d.id,
          checkable = d.id and true or false,
          checked = checked,
          onClick = d.id and function(isChecked)
            PC:SetDungeonChecked(d.id, isChecked)
          end or nil,
          checkTip = CheckTipFor("dungeon"),
          waypoint = wp,
          last = i == #list,
          tip = {
            { title, GOLD.r, GOLD.g, GOLD.b },
            d.note or (mid or "Dungeon on the Alliance leveling path."),
          },
        })
      end
    end
  end

  -- 1.20.0: trainer spells live on their own Abilities tab.
  if mode == "abilities" then
    emitTrainer()
    SetContentHeight(y)
    if ui.goalFocusY then
      ScrollContentTo(math.max(0, ui.goalFocusY - 72))
    end
    PC._pendingGoalSpell = nil
    ui.goalFocusY = nil
    return
  end
  -- Accordion: at most one Goals group is open. All groups start collapsed.
  -- Tapping an open group closes it.
  for g = 1, #groups do
    local group = groups[g]
    if group.kind == "trainer" then
      -- Shown on the Abilities tab instead.
    else
    currentGoalIcon = ClassIcon(group.key or group.kind or "goals")
    local open = PC:IsExpanded(group.key, false)
    n = n + 1
    y = ListRow(n, group.title, open and "Tap to close" or "Tap to show this group", nil, y, {
      icon = currentGoalIcon,
      chevron = true,
      expanded = open,
      last = true,
      titleColor = { r = GOLD.r, g = GOLD.g, b = GOLD.b },
      onExpand = function()
        if PC.SelectGoalGroup then
          if PC:IsExpanded(group.key, false) then
            PC:SelectGoalGroup(nil)
          else
            PC:SelectGoalGroup(group.key)
          end
        else
          PC:ToggleExpanded(group.key, false)
        end
      end,
      tip = { { group.title, GOLD.r, GOLD.g, GOLD.b }, "Tap to open this group. Tap it again to close it. Other groups collapse so the list stays easy to scan." },
    })
    if open then
      local before = n
      if group.kind == "trainer" then
        emitTrainer()
      elseif group.kind == "gear" then
        emitGear()
      elseif group.kind == "zones" then
        emitZones()
      elseif group.kind == "dungeons" then
        emitDungeons()
      else
        local ids = group.ids or {}
        for i = 1, #ids do
          local m = byId[ids[i]]
          if m then
            emitMilestone(m, i == #ids)
          end
        end
      end
      if n == before then
        n = n + 1
        y = Body(n, "Nothing to show in this group right now. Clear the search box or turn off Hide completed if you expected items here.", y)
      end
    end
    end
  end
  SetContentHeight(y)
  if ui.goalFocusY then
    ScrollContentTo(math.max(0, ui.goalFocusY - 72))
  end
  PC._pendingGoalSpell = nil
  ui.goalFocusY = nil
end

-- ---------------------------------------------------------------------------
-- 1.20.0 detail pane, every tab. On a window 700+ wide each tab shows its
-- list on the left and the selected row's details on the right. A row opts
-- in with opts.detail (a function returning a spec); any other row gets a
-- spec built from its own title, meta, note, pin, item, and checkmark.
-- Spec: { title, titleColor, sub, icon, itemID, actions = { { label, run, tip, on } },
--   sections = { { title, lines = { { text, sub } }, icons = { { itemID, name } },
--   paras = { { head, body } }, text } } }
-- ---------------------------------------------------------------------------

PANE = {
  minW = 700, pad = 14,
  bg = { r = 0.10, g = 0.08, b = 0.06 },
  chip = { r = 0.16, g = 0.16, b = 0.18 },
  chipOn = { r = 0.12, g = 0.22, b = 0.16 },
  sel = {}, rows = {}, tips = {},
  btns = {}, fs = {}, icons = {},
}
DETAIL = {}

function DETAIL.Width(fw)
  return math.floor(((fw or FRAME_WIDTH) - 24) * 0.48)
end

-- Rounded pill background for any button whose code paints btn.bg.
function DETAIL.Roundify(btn, color)
  if not btn or not PC.BuildRoundFill or rawget(btn, "_round") then
    return
  end
  local ok = pcall(function()
    local fill = PC:BuildRoundFill(btn, color or CARD, 1, "BACKGROUND", 0)
    local raw = rawget(btn, "bg")
    if raw and raw.Hide then
      raw:Hide()
      raw.Show = raw.Hide
    end
    btn._round = fill
    btn.bg = CARDS.Proxy(fill)
    local function relayout(self)
      local h = (self.GetHeight and self:GetHeight()) or 20
      pcall(PC.LayoutRoundFill, PC, fill, self, math.max(4, math.floor(h / 2)), 0)
    end
    relayout(btn)
    if btn.HookScript then
      btn:HookScript("OnSizeChanged", relayout)
    end
  end)
  return ok
end
PC._RoundifyButton = DETAIL.Roundify

function DETAIL.Ensure()
  if ui.detail or not ui.frame then
    return ui.detail
  end
  local d = CreateFrame("Frame", "PhilosophersCodexDetail", ui.frame)
  d:Hide()
  if PC.BuildRoundFill then
    pcall(function()
      d.round = PC:BuildRoundFill(d, PANE.bg, 1, "BACKGROUND", 2)
    end)
  end
  if not d.round then
    local bg = d:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    Paint(bg, PANE.bg, 1)
  end
  local sc = CreateFrame("ScrollFrame", "PhilosophersCodexDetailScroll", d, "UIPanelScrollFrameTemplate")
  sc:SetPoint("TOPLEFT", d, "TOPLEFT", 0, -8)
  sc:SetPoint("BOTTOMRIGHT", d, "BOTTOMRIGHT", -26, 8)
  sc:EnableMouseWheel(true)
  sc:SetScript("OnMouseWheel", function(self, delta)
    local cur = self:GetVerticalScroll() or 0
    local max = (self.GetVerticalScrollRange and self:GetVerticalScrollRange()) or 0
    local v = math.max(0, math.min(max, cur - delta * 40))
    self:SetVerticalScroll(v)
  end)
  local body = CreateFrame("Frame", "PhilosophersCodexDetailBody", sc)
  body:SetSize(200, 200)
  sc:SetScrollChild(body)
  d.scroll, d.body = sc, body
  d.head = CreateFrame("Button", "PhilosophersCodexDetailIcon", body)
  d.head:SetSize(36, 36)
  d.head.tex = d.head:CreateTexture(nil, "ARTWORK")
  d.head.tex:SetAllPoints()
  d.head.tex:SetTexCoord(0.08, 0.92, 0.08, 0.92)
  d.head:SetScript("OnEnter", function(self)
    if self.itemID and PC.ShowItemTooltip then
      PC:ShowItemTooltip(self, self.itemID)
    end
  end)
  d.head:SetScript("OnLeave", HideTooltip)
  d.head:Hide()
  d.title = MakeFontString(body, 15, "GameFontHighlight")
  d.title:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
  d.sub = MakeFontString(body, 11, "GameFontNormalSmall")
  d.sub:SetTextColor(SUB.r, SUB.g, SUB.b)
  ui.detail = d
  return d
end

function DETAIL.Button(i)
  local b = PANE.btns[i]
  if b then
    return b
  end
  b = CreateFrame("Button", "PhilosophersCodexDetailAction" .. i, ui.detail.body)
  b:SetHeight(22)
  b.bg = b:CreateTexture(nil, "BACKGROUND")
  b.bg:SetAllPoints()
  Paint(b.bg, PANE.chip, 1)
  DETAIL.Roundify(b, PANE.chip)
  b.label = MakeFontString(b, 11, "GameFontNormalSmall")
  b.label:SetPoint("CENTER", b, "CENTER", 0, 0)
  b:SetScript("OnClick", function(self)
    HideTooltip()
    if self.run then
      local ok, err = pcall(self.run)
      if not ok and PC.LogError then
        PC:LogError(tostring(err), "", "ui:detail-action")
      end
    end
  end)
  b:SetScript("OnEnter", function(self)
    Paint(self.bg, self.on and PANE.chipOn or { r = 0.22, g = 0.22, b = 0.25 }, 1)
    if self.tip then
      ShowRowTooltip(self, self.tip)
    end
  end)
  b:SetScript("OnLeave", function(self)
    Paint(self.bg, self.on and PANE.chipOn or PANE.chip, 1)
    HideTooltip()
  end)
  PANE.btns[i] = b
  return b
end

function DETAIL.Icon(i)
  local b = PANE.icons[i]
  if b then
    return b
  end
  b = CreateFrame("Button", "PhilosophersCodexDetailItem" .. i, ui.detail.body)
  b:SetSize(34, 34)
  b.edge = b:CreateTexture(nil, "BACKGROUND")
  b.edge:SetAllPoints()
  Paint(b.edge, { r = 0.25, g = 0.22, b = 0.16 }, 1)
  b.tex = b:CreateTexture(nil, "ARTWORK")
  b.tex:SetPoint("TOPLEFT", b, "TOPLEFT", 1, -1)
  b.tex:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", -1, 1)
  b.tex:SetTexCoord(0.08, 0.92, 0.08, 0.92)
  b:SetScript("OnEnter", function(self)
    if self.itemID and PC.ShowItemTooltip then
      PC:ShowItemTooltip(self, self.itemID)
    elseif self.name then
      ShowRowTooltip(self, { { self.name, GOLD.r, GOLD.g, GOLD.b } })
    end
  end)
  b:SetScript("OnLeave", HideTooltip)
  PANE.icons[i] = b
  return b
end

function DETAIL.Text(i)
  local fs = PANE.fs[i]
  if not fs then
    fs = MakeFontString(ui.detail.body, 12, "GameFontHighlightSmall")
    PANE.fs[i] = fs
  end
  return fs
end

-- A tappable pane line: optional icon, text with a muted tail, a done check
-- or next-step dot, and a chevron when it opens more detail.
function DETAIL.Line(i)
  PANE.lineBtns = PANE.lineBtns or {}
  local b = PANE.lineBtns[i]
  if b then
    return b
  end
  b = CreateFrame("Button", "PhilosophersCodexDetailLine" .. i, ui.detail.body)
  b:SetHeight(22)
  b.hl = b:CreateTexture(nil, "BACKGROUND")
  b.hl:SetAllPoints()
  Paint(b.hl, { r = 1, g = 1, b = 1 }, 0.06)
  b.hl:Hide()
  b.icon = b:CreateTexture(nil, "ARTWORK")
  b.icon:SetSize(18, 18)
  b.icon:SetPoint("LEFT", b, "LEFT", 2, 0)
  b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
  b.mark = MakeFontString(b, 12, "GameFontHighlightSmall")
  b.mark:SetPoint("RIGHT", b, "RIGHT", -4, 0)
  b.text = MakeFontString(b, 12, "GameFontHighlightSmall")
  b:SetScript("OnEnter", function(self)
    if self.open then self.hl:Show() end
    if self.itemID and PC.ShowItemTooltip then
      PC:ShowItemTooltip(self, self.itemID)
    end
  end)
  b:SetScript("OnLeave", function(self)
    self.hl:Hide()
    HideTooltip()
  end)
  b:SetScript("OnClick", function(self)
    if not self.open then
      return
    end
    HideTooltip()
    PANE.stack = PANE.stack or {}
    PANE.stack[#PANE.stack + 1] = { build = self.open, title = self.label }
    DETAIL.Finish()
  end)
  PANE.lineBtns[i] = b
  return b
end

function DETAIL.Fit(fs, text, w, wrap)
  if PC.FitFontString then
    return PC:FitFontString(fs, text, w, wrap)
  end
  fs:SetText(text or "")
end

function DETAIL.ItemIcon(itemID)
  if itemID and PC.GetItemIcon then
    local ok, icon = pcall(PC.GetItemIcon, PC, itemID)
    if ok and icon then
      return icon
    end
  end
  return "Interface\\Icons\\INV_Misc_QuestionMark"
end

-- Turns the split on or off. Off restores the full-width list.
function DETAIL.ApplySplit(on)
  local f, scroll = ui.frame, ui.scroll
  if not f or not scroll then
    return
  end
  on = on and true or false
  local fw = f:GetWidth() or FRAME_WIDTH
  if on then
    local d = DETAIL.Ensure()
    local pw = DETAIL.Width(fw)
    d:ClearAllPoints()
    d:SetPoint("TOPRIGHT", f, "TOPRIGHT", -12, -78)
    d:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -12, 16)
    d:SetWidth(pw)
    d:Show()
    if d.round and PC.LayoutRoundFill then
      pcall(PC.LayoutRoundFill, PC, d.round, d, 10, 0)
    end
    scroll:ClearAllPoints()
    scroll:SetPoint("TOPLEFT", f, "TOPLEFT", 12, -78)
    scroll:SetPoint("BOTTOMRIGHT", d, "BOTTOMLEFT", -28, 0)
    ui.splitListW = fw - 12 - 28 - pw - 12
  else
    if ui.detail then
      ui.detail:Hide()
    end
    if ui.split then
      scroll:ClearAllPoints()
      scroll:SetPoint("TOPLEFT", f, "TOPLEFT", 12, -78)
      scroll:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -28, 16)
    end
    ui.splitListW = nil
  end
  ui.split = on
end
PC._ApplySplit = DETAIL.ApplySplit

-- Called by ListRow for each row while the split is on. Returns a new meta
-- line for group rows (their items move to the pane).
function DETAIL.Register(row, title, meta, note, opts)
  if opts.noDetail or not title or title == "" then
    return nil
  end
  local key = opts.detailKey or (tostring(ui.tab) .. ":" .. tostring(title))
  local entry = { key = key, row = row, opts = opts, title = title, meta = meta, note = note, explicit = opts.detail and true or false }
  -- A group row (it toggles a list under itself) becomes one tap target;
  -- the rows that follow it are captured as its items.
  local group = (opts.expanded ~= nil) and not opts.detail
  if group then
    entry.children = {}
    entry.group = true
    PANE.parent = entry
  else
    PANE.parent = nil
  end
  entry.build = opts.detail or function()
    if entry.group then
      return DETAIL.GroupSpec(entry)
    end
    return DETAIL.FromRow(title, meta, note, opts)
  end
  PANE.rows[#PANE.rows + 1] = entry
  if PANE.sel[ui.tab] == key then
    opts.selected = true
    PANE.cur = entry
  end
  local prev = opts.onExpand
  local runPrev = prev and (not group) and ((not opts.detail) or opts.detailExpands)
  opts.onExpand = function()
    PANE.sel[ui.tab] = key
    if runPrev then
      prev()
    end
    PC:Refresh()
  end
  if group then
    opts.chevron = false
    opts.expanded = nil
    return "…"
  end
  return nil
end

-- Capture hooks. While a guide is being captured (PANE.capture) every row
-- becomes pane content. While the split is on and a group row is open,
-- rows after it become that group's items.
function DETAIL.Capture(title, meta, note, opts)
  local cap = PANE and PANE.capture
  if cap then
    if opts.noDetail then
      return true
    end
    local sec = cap[#cap]
    sec.lines[#sec.lines + 1] = DETAIL.LineFromRow(title, meta, note, opts)
    return true
  end
  if ui.split and PANE.parent and not Searching() then
    local group = (opts.expanded ~= nil) and not opts.detail
    if not group then
      local kids = PANE.parent.children
      kids[#kids + 1] = { title = title, meta = meta, note = note, opts = opts }
      return true
    end
  end
  return false
end

function DETAIL.CaptureHeader(text)
  local cap = PANE and PANE.capture
  if cap then
    cap[#cap + 1] = { title = text, lines = {} }
    return true
  end
  if PANE then
    PANE.parent = nil
  end
  return false
end

function DETAIL.CaptureBody(text)
  local cap = PANE and PANE.capture
  if cap then
    local sec = cap[#cap]
    sec.text = sec.text and (sec.text .. "\n" .. text) or text
    return true
  end
  if ui.split and PANE.parent and not Searching() then
    local kids = PANE.parent.children
    kids[#kids + 1] = { body = text }
    return true
  end
  return false
end

-- Runs a list layout and returns what it drew as pane sections.
function DETAIL.RunCapture(fn)
  local prevCap, prevParent = PANE.capture, PANE.parent
  PANE.capture = { { lines = {} } }
  local ok, err = pcall(fn)
  local cap = PANE.capture
  PANE.capture, PANE.parent = prevCap, prevParent
  if not ok and PC.LogError then
    PC:LogError(tostring(err), "", "ui:detail-capture")
  end
  local out = {}
  for i = 1, #cap do
    local sec = cap[i]
    if #sec.lines > 0 or sec.text then
      out[#out + 1] = sec
    end
  end
  return out
end

-- One pane line from a list row: icon, text, muted tail, done mark, and a
-- drill-in to the row's own details.
function DETAIL.LineFromRow(title, meta, note, opts)
  local icon
  if opts.itemID then
    icon = DETAIL.ItemIcon(opts.itemID)
  elseif type(opts.icon) == "string" or type(opts.icon) == "number" then
    icon = opts.icon
  end
  local line = { text = title or "", sub = meta, icon = icon, done = opts.checked and true or false, itemID = opts.itemID }
  line.open = function()
    if opts.detail then
      return opts.detail()
    end
    return DETAIL.FromRow(title, meta, note, opts)
  end
  return line
end

function DETAIL.GroupSpec(entry)
  local spec = { title = entry.title, actions = {}, sections = {} }
  local o = entry.opts or {}
  if type(o.icon) == "string" or type(o.icon) == "number" then
    spec.icon = o.icon
  end
  local kids = entry.children or {}
  local lines, texts = {}, {}
  for i = 1, #kids do
    local k = kids[i]
    if k.body then
      texts[#texts + 1] = k.body
    else
      lines[#lines + 1] = DETAIL.LineFromRow(k.title, k.meta, k.note, k.opts or {})
    end
  end
  local done = 0
  for i = 1, #lines do
    if lines[i].done then done = done + 1 end
  end
  spec.sub = tostring(#lines) .. (#lines == 1 and " item" or " items") .. ((done > 0) and ("  ·  " .. done .. " done") or "")
  if #lines > 0 then
    spec.sections[#spec.sections + 1] = { lines = lines }
  end
  if #texts > 0 then
    spec.sections[#spec.sections + 1] = { text = table.concat(texts, "\n") }
  end
  return spec
end

function DETAIL.Profession(rec, sub)
  local spec = { title = rec.name or "Profession", sub = sub, icon = rec.icon or (rec.pack and rec.pack.icon), actions = {}, sections = {} }
  local tp = PC.GetProfessionTierPlan and PC:GetProfessionTierPlan(rec) or nil
  if not tp then
    spec.sections[1] = { text = "No written plan for this profession yet." }
    return spec
  end
  spec.icon = spec.icon or tp.pack.icon
  local learned = (tonumber(rec.maxSkill) or 0) > 0 or (tonumber(rec.skill) or 0) > 0
  if learned then
    spec.title = (rec.name or tp.pack.name or "Profession") .. "  ·  " .. tostring(tp.skill) .. " to " .. tostring(tp.target)
    local togo = tp.target - tp.skill
    spec.sub = (togo > 0) and ("About " .. togo .. " skill-ups to " .. tp.target) or "You're at the top of this tier"
  end
  if tp.trainNow then
    local r = tp.trainNow
    spec.sections[#spec.sections + 1] = { title = "Do this first", lines = { { text = "Train " .. (r.name or "the next rank"), sub = r.trainer and (r.trainer .. (r.zone and (", " .. r.zone) or "")) or (r.zone or "at your trainer"), current = true } } }
  end
  local crafts = {}
  for i = 1, #tp.crafts do
    local c = tp.crafts[i]
    local m = {}
    for j = 1, #c.mats do
      m[#m + 1] = tostring(c.mats[j].per) .. " " .. (c.mats[j].name or "mat")
    end
    local verb = c.gather and "Gather" or ("About " .. c.count .. " crafts")
    crafts[#crafts + 1] = { head = tostring(i) .. ".  " .. (c.recipe or "Next recipe") .. "   (" .. c.from .. " to " .. c.to .. ")",
      body = verb .. ((#m > 0) and ("  ·  each uses " .. table.concat(m, ", ")) or "") .. (c.note and ("\n" .. c.note) or "") }
  end
  if #crafts > 0 then
    spec.sections[#spec.sections + 1] = { title = learned and ("Get to " .. tp.target) or "How to start", paras = crafts }
  end
  if #tp.shopping > 0 then
    local lines, where = {}, {}
    for i = 1, #tp.shopping do
      local t = tp.shopping[i]
      local icon
      if t.id and (C_Item and C_Item.GetItemIconByID or GetItemIcon) then
        local ok, tex = pcall(C_Item and C_Item.GetItemIconByID or GetItemIcon, t.id)
        if ok then icon = tex end
      end
      local left = math.max(0, t.need - t.have)
      lines[#lines + 1] = { text = tostring(t.need) .. "  " .. (t.name or "item"), sub = "have " .. t.have .. ((left > 0) and ("  ·  " .. left .. " more") or ""), done = not t.short, itemID = t.id, icon = icon }
      where[#where + 1] = { head = t.name, body = t.source }
    end
    spec.sections[#spec.sections + 1] = { title = "Shopping list", lines = lines }
    spec.sections[#spec.sections + 1] = { title = "Where to get it", paras = where }
  end
  if tp.nextRank then
    local r = tp.nextRank
    spec.sections[#spec.sections + 1] = { title = "At " .. tostring(r.trainAt), lines = { { text = "Train " .. (r.name or "the next rank"), sub = r.trainer and (r.trainer .. (r.zone and (", " .. r.zone) or "")) or "trainer not confirmed for Forever" } } }
  end
  if #tp.tips > 0 then
    local paras = {}
    for i = 1, #tp.tips do paras[i] = { body = tp.tips[i] } end
    spec.sections[#spec.sections + 1] = { title = "Tips", paras = paras }
  end
  if tp.source then
    spec.sections[#spec.sections + 1] = { text = tp.source }
  end
  return spec
end

function DETAIL.QuestState(q)
  local st = q._status or (PC.GetZoneQuestStatus and PC:GetZoneQuestStatus(q)) or "available"
  return st, QuestStatusLabel(st)
end

function DETAIL.ChainSteps(tree)
  local list = { tree.parent }
  for i = 1, #(tree.allChildren or {}) do
    list[#list + 1] = tree.allChildren[i]
  end
  return list
end

function DETAIL.Chain(tree, zone)
  local steps = DETAIL.ChainSteps(tree)
  local spec = { title = tree.name or (tree.parent and tree.parent.name) or "Quest chain", icon = QUEST_ICON, actions = {}, sections = {} }
  local lines, nextStep = {}, nil
  for i = 1, #steps do
    local q = steps[i]
    local st, label = DETAIL.QuestState(q)
    if not nextStep and st ~= "complete" then
      nextStep = i
    end
    local lv = q.level or q.minLevel
    lines[#lines + 1] = { text = tostring(i) .. ".  " .. (q.name or "Quest"), sub = (lv and ("Lv " .. tostring(lv)) or "") .. (label and ("  ·  " .. label) or ""),
      done = st == "complete", current = (i == nextStep),
      open = function() return DETAIL.Quest(q, label, PC.GetQuestWaypoint and PC:GetQuestWaypoint(q) or nil, tree, i) end }
  end
  spec.sub = tostring(#steps) .. " quests" .. (zone and ("  ·  " .. zone) or "") .. (nextStep and ("  ·  next: step " .. nextStep) or "  ·  all done")
  local first = nextStep and steps[nextStep] or steps[1]
  local wp = first and PC.GetQuestWaypoint and PC:GetQuestWaypoint(first) or nil
  if wp and PC.SetWaypoint then
    spec.actions[#spec.actions + 1] = { label = "Pin next step", run = function() PC:SetWaypoint(wp) end,
      tip = { { "Pin next step", GOLD.r, GOLD.g, GOLD.b }, "Puts a map pin on the next quest giver in this chain." } }
  end
  spec.sections[#spec.sections + 1] = { title = "Steps", lines = lines }
  return spec
end

function DETAIL.FromRow(title, meta, note, opts)
  local spec = { title = title, titleColor = opts.qualityColor or opts.titleColor, sub = meta, itemID = opts.itemID, actions = {}, sections = {} }
  if opts.itemID then
    spec.icon = DETAIL.ItemIcon(opts.itemID)
  elseif type(opts.icon) == "string" or type(opts.icon) == "number" then
    spec.icon = opts.icon
  end
  if opts.waypoint and PC.SetWaypoint then
    local wp = opts.waypoint
    spec.actions[#spec.actions + 1] = { label = "Pin on map", run = function() PC:SetWaypoint(wp) end,
      tip = { { "Pin on map", GOLD.r, GOLD.g, GOLD.b }, wp.title or wp.note or "Puts a map pin here." } }
  end
  if opts.checkable and opts.onClick then
    local checked = opts.checked and true or false
    spec.actions[#spec.actions + 1] = { label = checked and "Done" or "Mark done", on = checked, run = function()
      opts.onClick(not checked)
      PC:Refresh()
    end, tip = { { checked and "Marked done" or "Mark done", GOLD.r, GOLD.g, GOLD.b }, "Same as the box on the row." } }
  end
  if opts.tag and opts.tag ~= "" then
    spec.sections[#spec.sections + 1] = { lines = { { text = "|cff3fbf7f" .. tostring(opts.tag) .. "|r" } } }
  end
  if note and note ~= "" then
    spec.sections[#spec.sections + 1] = { title = "Notes", text = note }
  end
  local about = {}
  if type(opts.tip) == "table" then
    for i = 2, #opts.tip do
      local t = opts.tip[i]
      if type(t) == "table" then t = t[1] end
      if type(t) == "string" and t ~= "" and t ~= note and t ~= meta then
        about[#about + 1] = t
      end
    end
  end
  if #about > 0 then
    spec.sections[#spec.sections + 1] = { title = "About", text = table.concat(about, " ") }
  end
  if opts.itemID then
    spec.sections[#spec.sections + 1] = { title = "Item", icons = { { itemID = opts.itemID, name = title } } }
  end
  return spec
end

function DETAIL.Dungeon(id, wp, fallbackTitle, withOpen)
  local d = PC.FindDungeon and PC:FindDungeon(id) or nil
  local spec = { title = (d and d.name) or fallbackTitle or id, actions = {}, sections = {} }
  local bits = {}
  if d and d.zone then bits[#bits + 1] = d.zone end
  if d and d.range then bits[#bits + 1] = "Lv " .. tostring(d.range) end
  spec.sub = (#bits > 0) and table.concat(bits, "  ·  ") or nil
  if PC.GetDungeonIcon then
    local ok, icon = pcall(PC.GetDungeonIcon, PC, id)
    if ok and icon then spec.icon = icon end
  end
  wp = wp or (PC.GetEntranceWaypoint and PC:GetEntranceWaypoint(id)) or nil
  if wp and PC.SetWaypoint then
    spec.actions[#spec.actions + 1] = { label = "Pin entrance", run = function() PC:SetWaypoint(wp) end,
      tip = { { "Pin entrance", GOLD.r, GOLD.g, GOLD.b }, "Puts a map pin on the dungeon entrance." } }
  end
  local loot = PC.GetLootForDungeon and PC:GetLootForDungeon(id) or {}
  local icons = {}
  for i = 1, #loot do
    icons[#icons + 1] = { itemID = loot[i].itemID, name = loot[i].name }
  end
  if #icons > 0 then
    spec.sections[#spec.sections + 1] = { title = "Loot", icons = icons }
  end
  do
    local sheet = PC.GetDungeonTipSheet and PC:GetDungeonTipSheet(id) or nil
    local paras = {}
    for i = 1, #((sheet and sheet.bosses) or {}) do
      local b = sheet.bosses[i]
      paras[#paras + 1] = { head = b.name, body = b.tip }
    end
    if #paras == 0 then
      paras[1] = { body = (sheet and sheet.note) or "No boss notes for this dungeon yet." }
    end
    spec.sections[#spec.sections + 1] = { title = "Boss tips", paras = paras }
  end
  local e = PC.GetLocations and PC:GetLocations()
  e = e and e.entrances and e.entrances[id]
  local dz = (e and e.zone) or (d and d.zone)
  local steps = PC.GetTravelSteps and PC:GetTravelSteps(dz, id) or {}
  if #steps > 0 then
    spec.sections[#spec.sections + 1] = { title = "Getting there", paras = DETAIL.StepParas(steps) }
  end
  local qn = PC.CountDungeonQuests and PC:CountDungeonQuests(id)
  if type(qn) == "number" and qn > 0 then
    spec.sections[#spec.sections + 1] = { title = "Quests", lines = { { text = tostring(qn) .. (qn == 1 and " quest" or " quests") .. " for this dungeon", sub = "In Path" } } }
  end
  return spec
end

-- 1.23.0: Gear pane: what the item is, then equipped vs this item.
function DETAIL.Gear(item)
  local spec = { title = item.name or "Item", sub = item.meta, itemID = item.itemID, actions = {}, sections = {} }
  if item.itemID then
    local ok, tex = pcall(DETAIL.ItemIcon, item.itemID)
    if ok then spec.icon = tex end
  end
  local function qcol(r)
    local q = r and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[r]
    return q and { r = q.r, g = q.g, b = q.b } or nil
  end
  local cmp = item.itemID and PC.GetGearCompare and select(2, pcall(PC.GetGearCompare, PC, item.itemID)) or nil
  if type(cmp) == "table" and cmp.loading then
    spec.sections[#spec.sections + 1] = { title = "Compare", text = "Loading this item from the game. The compare shows in a moment." }
    -- One retry per item, so an item the client never loads can't loop.
    PANE.gearTried = rawget(PANE, "gearTried") or {}
    if not PANE.gearTried[item.itemID] and C_Timer and C_Timer.After then
      PANE.gearTried[item.itemID] = true
      C_Timer.After(0.6, function()
        if ui.frame and ui.frame:IsShown() and ui.tab == TAB_GEAR and PC.Refresh then PC:Refresh() end
      end)
    end
  elseif type(cmp) == "table" then
    spec.sections[#spec.sections + 1] = { title = "Compare", compare = {
      left = { title = "Wearing now", name = cmp.old and cmp.old.name or "Nothing equipped", itemID = cmp.old and cmp.old.itemID, icon = cmp.old and cmp.old.icon, color = cmp.old and qcol(cmp.old.rarity) },
      right = { title = "This item", name = cmp.new.name or item.name, itemID = cmp.new.itemID, icon = cmp.new.icon, color = qcol(cmp.new.rarity) },
      rows = cmp.rows, verdict = cmp.verdict, good = cmp.good,
    } }
    if #cmp.rows == 0 then
      spec.sections[#spec.sections + 1] = { text = "Stats load once the game has seen this item. Hover its icon, then reopen." }
    end
  else
    spec.sections[#spec.sections + 1] = { text = "No item ID, so there is nothing to compare yet." }
  end
  local where = {}
  if item.source then where[#where + 1] = { text = item.source, sub = item.boss } end
  if item.where and item.where ~= "" then where[#where + 1] = { text = item.where } end
  if #where > 0 then
    spec.sections[#spec.sections + 1] = { title = "Where it drops", lines = where }
  end
  if item.note and item.note ~= "" then
    spec.sections[#spec.sections + 1] = { title = "Why", text = item.note }
  end
  if item.waypoint and PC.SetWaypoint then
    spec.actions[#spec.actions + 1] = { label = "Pin it", run = function() PC:SetWaypoint(item.waypoint) end }
  end
  return spec
end

function DETAIL.StepParas(steps)
  local paras = {}
  for i = 1, #steps do
    paras[i] = { body = tostring(i) .. ".  " .. steps[i] }
  end
  return paras
end

function DETAIL.Zone(zone, wp, sub, withOpen)
  local spec = { title = zone, sub = sub, actions = {}, sections = {} }
  wp = wp or (PC.GetZoneWaypoint and PC:GetZoneWaypoint(zone)) or nil
  if wp and PC.SetWaypoint then
    spec.actions[#spec.actions + 1] = { label = "Pin zone", run = function() PC:SetWaypoint(wp) end,
      tip = { { "Pin zone", GOLD.r, GOLD.g, GOLD.b }, "Puts a map pin on the zone." } }
  end
  if withOpen then
    spec.actions[#spec.actions + 1] = withOpen
  end
  local level = PC.PlayerLevel and PC:PlayerLevel() or 1
  local trees = PC.GetZoneQuestTrees and PC:GetZoneQuestTrees(zone, level) or {}
  local chains, singles, doneCount = {}, {}, 0
  local zsteps = PC.GetTravelSteps and not (PC.IsCurrentZoneName and PC:IsCurrentZoneName(zone)) and PC:GetTravelSteps(zone) or {}
  if #zsteps > 0 then
    spec.sections[#spec.sections + 1] = { title = "Getting there", paras = DETAIL.StepParas(zsteps) }
  end
  for i = 1, #trees do
    local t = trees[i]
    if t.allDone then
      doneCount = doneCount + 1
    elseif t.parent then
      local steps = 1 + #(t.allChildren or {})
      local q = t.parent
      if steps > 1 then
        chains[#chains + 1] = { text = t.name or q.name or "Quest chain", sub = tostring(t.done or 0) .. " of " .. tostring(t.total or steps) .. " done",
          icon = QUEST_ICON, open = function() return DETAIL.Chain(t, zone) end }
      else
        local st, label = DETAIL.QuestState(q)
        local lv = q.level or q.minLevel
        singles[#singles + 1] = { text = q.name or "Quest", sub = (lv and ("Lv " .. tostring(lv)) or "") .. (label and ("  ·  " .. label) or ""),
          icon = QUEST_ICON, done = st == "complete",
          open = function() return DETAIL.Quest(q, label, PC.GetQuestWaypoint and PC:GetQuestWaypoint(q) or nil) end }
      end
    end
  end
  if #chains > 0 then
    spec.sections[#spec.sections + 1] = { title = "Quest chains", lines = chains }
  end
  if #singles > 0 then
    spec.sections[#spec.sections + 1] = { title = "Quests", lines = singles }
  end
  if #chains + #singles == 0 then
    spec.sections[#spec.sections + 1] = { text = (#trees == 0) and "No quest list for this zone yet." or "Every catalogued quest here is done." }
  elseif doneCount > 0 then
    spec.sections[#spec.sections + 1] = { text = tostring(doneCount) .. " finished chains are hidden." }
  end
  return spec
end

function DETAIL.Quest(quest, statusText, wp, tree, idx)
  local bits = {}
  if quest.level then bits[#bits + 1] = "Level " .. tostring(quest.level)
  elseif quest.minLevel then bits[#bits + 1] = "Requires " .. tostring(quest.minLevel) end
  if statusText then bits[#bits + 1] = statusText end
  local steps = tree and DETAIL.ChainSteps(tree) or nil
  if steps and idx then bits[#bits + 1] = "step " .. idx .. " of " .. #steps end
  local spec = { title = quest.name or "Quest", sub = table.concat(bits, "  ·  "), icon = QUEST_ICON, actions = {}, sections = {} }
  if wp and PC.SetWaypoint then
    spec.actions[#spec.actions + 1] = { label = "Pin quest giver", run = function() PC:SetWaypoint(wp) end,
      tip = { { "Pin quest giver", GOLD.r, GOLD.g, GOLD.b }, "Puts a map pin on the giver." } }
  end
  local lines = {}
  if quest.giver and quest.giver ~= "" then lines[#lines + 1] = { text = quest.giver, sub = "Giver" } end
  if quest.zone then lines[#lines + 1] = { text = quest.zone, sub = "Zone" } end
  if #lines > 0 then
    spec.sections[#spec.sections + 1] = { title = "Start", lines = lines }
  end
  if quest.where and quest.where ~= "" then
    spec.sections[#spec.sections + 1] = { title = "Where", text = quest.where }
  end
  local id = quest.id or quest.questID
  local rw = id and PC.GetQuestRewards and PC:GetQuestRewards(id) or nil
  if type(rw) == "table" then
    local icons = {}
    for _, list in pairs(rw) do
      if type(list) == "table" then
        for i = 1, #list do
          if tonumber(list[i]) then
            icons[#icons + 1] = { itemID = tonumber(list[i]) }
          end
        end
      end
    end
    if #icons > 0 then
      spec.sections[#spec.sections + 1] = { title = "Rewards", icons = icons }
    end
  end
  if steps and #steps > 1 then
    local chain = {}
    for i = 1, #steps do
      local q = steps[i]
      local st, label = DETAIL.QuestState(q)
      chain[#chain + 1] = { text = tostring(i) .. ".  " .. (q.name or "Quest"), sub = label, done = st == "complete", current = (i == idx),
        open = (i ~= idx) and function() return DETAIL.Quest(q, label, PC.GetQuestWaypoint and PC:GetQuestWaypoint(q) or nil, tree, i) end or nil }
    end
    spec.sections[#spec.sections + 1] = { title = "In this chain", lines = chain }
  end
  return spec
end

-- What the pane shows for one Next card.
function DETAIL.Next(it)
  local function openTab(label, tabKey)
    return { label = label, run = function()
      if tabKey and it.id then
        PANE.sel[tabKey] = it.id
      end
      if PC.FollowNextItem then
        PC:FollowNextItem(it)
      end
    end, tip = { { label, GOLD.r, GOLD.g, GOLD.b }, "Switches to that tab with this selected." } }
  end
  if it.kind == "dungeon" and it.dungeonId then
    return DETAIL.Dungeon(it.dungeonId, it.waypoint, it.title)
  elseif it.kind == "zone" and it.zone then
    return DETAIL.Zone(it.zone, it.waypoint, it.detail)
  end
  local spec = { title = it.title or "Next", sub = it.detail, icon = it.icon, actions = {}, sections = {} }
  if it.waypoint and PC.SetWaypoint then
    local label = (it.kind == "spell") and "Pin trainer" or "Pin on map"
    spec.actions[#spec.actions + 1] = { label = label, run = function() PC:SetWaypoint(it.waypoint) end }
  end
  if it.kind == "spell" then
    spec.actions[#spec.actions + 1] = openTab("Open in Abilities")
  elseif it.kind == "profession" then
    local rec = it.profId and FindProfessionRecord(it.profId) or nil
    if rec then
      local ps = DETAIL.Profession(rec)
      ps.actions = spec.actions
      ps.actions[#ps.actions + 1] = openTab("Open in Craft")
      return ps
    end
    if it.progress and it.progress.max then
      spec.sections[#spec.sections + 1] = { title = "Skill", lines = { { text = tostring(it.progress.cur or 0) .. " / " .. tostring(it.progress.max) } } }
    end
    spec.actions[#spec.actions + 1] = openTab("Open in Craft")
  elseif it.kind == "gear" and it.id == "gear:recent" then
    spec.title = "Recent upgrades"
    spec.sub = "Newest first. Hover an item for its tooltip."
    local recent = PC.GetRecentUpgrades and PC:GetRecentUpgrades() or {}
    local lines = {}
    for i = 1, #recent do
      local u = recent[i]
      if u and (u.name or u.itemID) then
        local icon
        if u.itemID then
          local ok, tex = pcall(DETAIL.ItemIcon, u.itemID)
          if ok then icon = tex end
        end
        lines[#lines + 1] = { text = u.name or ("Item " .. tostring(u.itemID)), sub = u.text, itemID = u.itemID, icon = icon, current = (#lines == 0) }
      end
    end
    spec.sections[#spec.sections + 1] = { title = "Upgrades", lines = lines }
    spec.actions[#spec.actions + 1] = { label = "Open in Gear", run = function()
      local top = recent[1]
      PC._gearHighlight = top and top.itemID or nil
      if top and top.itemID then
        PANE.sel.gear = "gear:" .. tostring(top.itemID)
      end
      if PC.FollowNextItem then PC:FollowNextItem(it) end
    end, tip = { { "Open in Gear", GOLD.r, GOLD.g, GOLD.b }, "Opens Gear with the newest upgrade selected." } }
  else
    spec.actions[#spec.actions + 1] = openTab("Open")
  end
  return spec
end

function DETAIL.Render(spec)
  local d = DETAIL.Ensure()
  if not d then
    return
  end
  local pw = (d:GetWidth() and d:GetWidth() > 0) and d:GetWidth() or DETAIL.Width(ui.frame and ui.frame:GetWidth())
  local bodyW = math.max(140, pw - 26)
  local inner = bodyW - PANE.pad * 2
  d.body:SetWidth(bodyW)
  for i = 1, #PANE.btns do PANE.btns[i]:Hide() end
  for i = 1, #PANE.fs do PANE.fs[i]:Hide() end
  for i = 1, #PANE.icons do PANE.icons[i]:Hide() end
  for i = 1, #(PANE.lineBtns or {}) do PANE.lineBtns[i]:Hide() end
  if rawget(d, "back") then d.back:Hide() end
  d.head:Hide()
  PANE.info = { actions = {}, lines = {}, icons = 0, sections = {} }
  local key = PANE.sel[ui.tab]
  if PANE.lastKey ~= key then
    PANE.lastKey = key
    if d.scroll.SetVerticalScroll then d.scroll:SetVerticalScroll(0) end
  end
  local P = PANE.pad
  local y = P
  if not spec then
    d.title:ClearAllPoints()
    d.title:SetPoint("TOPLEFT", d.body, "TOPLEFT", P, -y)
    d.title:SetWidth(inner)
    d.title:SetTextColor(SUB.r, SUB.g, SUB.b)
    local msg = (#PANE.rows > 0) and "Tap an item on the left to see it here" or "Nothing to show on this tab yet"
    if ui.tab == TAB_GUILD and #PANE.rows == 0 then
      msg = "Pick a status to see guildmates here"
    end
    DETAIL.Fit(d.title, msg, inner, false)
    d.sub:Hide()
    d.body:SetHeight(60)
    return
  end
  PANE.info.title = spec.title
  PANE.info.depth = #(PANE.stack or {})
  -- Back pill when we've drilled into an item.
  if spec.backTo then
    if not rawget(d, "back") then
      d.back = CreateFrame("Button", "PhilosophersCodexDetailBack", d.body)
      d.back:SetHeight(20)
      d.back.bg = d.back:CreateTexture(nil, "BACKGROUND")
      d.back.bg:SetAllPoints()
      Paint(d.back.bg, PANE.chip, 1)
      DETAIL.Roundify(d.back, PANE.chip)
      d.back.label = MakeFontString(d.back, 11, "GameFontNormalSmall")
      d.back.label:SetPoint("CENTER", d.back, "CENTER", 0, 0)
      d.back:SetScript("OnClick", function()
        if PANE.stack and #PANE.stack > 0 then
          table.remove(PANE.stack)
        end
        DETAIL.Finish()
      end)
    end
    local label = "‹  " .. tostring(spec.backTo)
    d.back.label:SetText(label)
    local bw = 90
    local okW, sw = pcall(d.back.label.GetStringWidth, d.back.label)
    if okW and type(sw) == "number" and sw > 0 then bw = math.ceil(sw) + 22 end
    bw = math.min(bw, inner)
    d.back:ClearAllPoints()
    d.back:SetPoint("TOPLEFT", d.body, "TOPLEFT", P, -y)
    d.back:SetSize(bw, 20)
    DETAIL.Fit(d.back.label, label, bw - 12, false)
    d.back:Show()
    y = y + 28
  end
  -- Header: optional icon, then title and subtitle.
  local textX = P
  if spec.icon then
    d.head:ClearAllPoints()
    d.head:SetPoint("TOPLEFT", d.body, "TOPLEFT", P, -y)
    local okT = pcall(d.head.tex.SetTexture, d.head.tex, spec.icon)
    d.head.itemID = spec.itemID
    if okT then
      d.head:Show()
      textX = P + 44
    end
  end
  local textW = math.max(60, inner - (textX - P))
  d.title:ClearAllPoints()
  d.title:SetPoint("TOPLEFT", d.body, "TOPLEFT", textX, -y)
  d.title:SetWidth(textW)
  d.title:SetHeight(18)
  local tc = spec.titleColor or TEXT
  d.title:SetTextColor(tc.r, tc.g, tc.b)
  DETAIL.Fit(d.title, spec.title, textW, false)
  local headH = 20
  if spec.sub and spec.sub ~= "" then
    d.sub:ClearAllPoints()
    d.sub:SetPoint("TOPLEFT", d.body, "TOPLEFT", textX, -(y + 20))
    d.sub:SetWidth(textW)
    d.sub:SetHeight(28)
    DETAIL.Fit(d.sub, spec.sub, textW, true)
    d.sub:Show()
    headH = 48
  else
    d.sub:Hide()
  end
  if d.head:IsShown() then
    headH = math.max(headH, 40)
  end
  y = y + headH + 6
  -- Action pills, wrapping onto new rows.
  local x = 0
  for i = 1, #(spec.actions or {}) do
    local a = spec.actions[i]
    local b = DETAIL.Button(i)
    b.label:SetText(a.label)
    local bw = 96
    if b.label.GetStringWidth then
      local ok, sw = pcall(b.label.GetStringWidth, b.label)
      if ok and type(sw) == "number" and sw > 0 then
        bw = math.ceil(sw) + 26
      end
    end
    bw = math.min(bw, inner)
    if x > 0 and x + bw > inner then
      x = 0
      y = y + 28
    end
    b:ClearAllPoints()
    b:SetPoint("TOPLEFT", d.body, "TOPLEFT", P + x, -y)
    b:SetSize(bw, 22)
    DETAIL.Fit(b.label, a.label, bw - 12, false)
    b.on = a.on and true or false
    Paint(b.bg, b.on and PANE.chipOn or PANE.chip, 1)
    if b.on then
      b.label:SetTextColor(EMERALD.r, EMERALD.g, EMERALD.b)
    else
      b.label:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
    end
    b.run, b.tip = a.run, a.tip
    b:Show()
    PANE.info.actions[#PANE.info.actions + 1] = a.label
    x = x + bw + 6
  end
  if #(spec.actions or {}) > 0 then
    y = y + 34
  end
  local fi, ii, li = 0, 0, 0
  local function text(str, color, size, wrap, x, w, keepY)
    fi = fi + 1
    local fs = DETAIL.Text(fi)
    if fs.SetFont then pcall(fs.SetFont, fs, FRIZ, size or 12, "") end
    fs:ClearAllPoints()
    fs:SetPoint("TOPLEFT", d.body, "TOPLEFT", P + (x or 0), -y)
    local inner = w or inner
    fs:SetWidth(inner)
    if fs.SetJustifyH then pcall(fs.SetJustifyH, fs, "LEFT") end
    fs:SetTextColor(color.r, color.g, color.b)
    local h = (size or 12) + 2
    if wrap then
      fs:SetText(str or "")
      if fs.SetWordWrap then pcall(fs.SetWordWrap, fs, true) end
      local okH, sh = pcall(fs.GetStringHeight, fs)
      if okH and type(sh) == "number" and sh > h then h = math.ceil(sh) end
      fs:SetHeight(h)
    else
      fs:SetHeight(h)
      DETAIL.Fit(fs, str, inner, false)
    end
    fs:Show()
    PANE.info.lines[#PANE.info.lines + 1] = str
    if keepY then
      return h
    end
    y = y + h + 4
    return h
  end
  for s = 1, #(spec.sections or {}) do
    local sec = spec.sections[s]
    PANE.info.sections[#PANE.info.sections + 1] = sec.title or ""
    if sec.title then
      text(sec.title, GOLD, 12, false)
    end
    if sec.compare then
      -- 1.23.0: side-by-side item compare (equipped vs this item).
      local c = sec.compare
      local labelW = math.floor(inner * 0.34)
      local colW = math.floor((inner - labelW) / 2)
      local cols = { c.left or {}, c.right or {} }
      local tallest = 0
      for k = 1, 2 do
        local e = cols[k]
        local x = labelW + (k - 1) * colW
        text(e.title or "", SUB, 10, false, x, colW - 4, true)
        local y0 = y
        y = y + 14
        if e.itemID or e.icon then
          ii = ii + 1
          local b = DETAIL.Icon(ii)
          b:ClearAllPoints()
          b:SetPoint("TOPLEFT", d.body, "TOPLEFT", P + x, -y)
          b.itemID, b.name = e.itemID, e.name
          pcall(b.tex.SetTexture, b.tex, e.icon or DETAIL.ItemIcon(e.itemID))
          b:Show()
          PANE.info.icons = PANE.info.icons + 1
        end
        y = y + 38
        local nc = e.color or TEXT
        local hN = text(e.name or "Nothing equipped", nc, 11, true, x, colW - 6, true)
        tallest = math.max(tallest, 14 + 38 + hN)
        y = y0
      end
      y = y + tallest + 8
      for k = 1, #(c.rows or {}) do
        local r = c.rows[k]
        text(r.label or "", SUB, 11, false, 0, labelW - 4, true)
        local ca = (r.win == "a") and EMERALD or ((r.win == "b") and SUB or TEXT)
        local cb = (r.win == "b") and EMERALD or ((r.win == "a") and SUB or TEXT)
        text(tostring(r.a or "-"), ca, 11, false, labelW, colW - 4, true)
        text(tostring(r.b or "-"), cb, 11, false, labelW + colW, colW - 4, true)
        y = y + 17
      end
      if c.verdict then
        y = y + 4
        text(c.verdict, c.good and EMERALD or GOLD, 12, true)
      end
    end
    if sec.icons and #sec.icons > 0 then
      local per = math.max(1, math.floor((inner + 6) / 40))
      for k = 1, #sec.icons do
        ii = ii + 1
        local e = sec.icons[k]
        local b = DETAIL.Icon(ii)
        local col = (k - 1) % per
        local rowI = math.floor((k - 1) / per)
        b:ClearAllPoints()
        b:SetPoint("TOPLEFT", d.body, "TOPLEFT", P + col * 40, -(y + rowI * 40))
        b.itemID, b.name = e.itemID, e.name
        pcall(b.tex.SetTexture, b.tex, DETAIL.ItemIcon(e.itemID))
        b:Show()
      end
      PANE.info.icons = PANE.info.icons + #sec.icons
      y = y + math.ceil(#sec.icons / per) * 40 + 2
    end
    for k = 1, #(sec.lines or {}) do
      local e = sec.lines[k]
      li = li + 1
      local b = DETAIL.Line(li)
      b:ClearAllPoints()
      b:SetPoint("TOPLEFT", d.body, "TOPLEFT", P - 4, -y)
      b:SetSize(inner + 8, 22)
      local tx = 4
      if e.icon and pcall(b.icon.SetTexture, b.icon, e.icon) then
        b.icon:Show()
        tx = 26
      else
        b.icon:Hide()
      end
      local markText = (e.open and ">") or ""
      if e.done then
        markText = "|cff3fbf7fdone|r" .. (e.open and "  >" or "")
      elseif e.current then
        markText = "|cffd4af37next|r" .. (e.open and "  >" or "")
      end
      b.mark:SetText(markText)
      b.mark:SetTextColor(SUB.r, SUB.g, SUB.b)
      local markW = 0
      local okM, mw = pcall(b.mark.GetStringWidth, b.mark)
      if okM and type(mw) == "number" then markW = math.ceil(mw) + 8 end
      local str = e.text or ""
      if e.sub and e.sub ~= "" then
        str = str .. "  |cff8f8f99" .. e.sub .. "|r"
      end
      local tw = math.max(40, inner + 8 - tx - markW - 4)
      b.text:ClearAllPoints()
      b.text:SetPoint("LEFT", b, "LEFT", tx, 0)
      b.text:SetWidth(tw)
      b.text:SetHeight(14)
      local col = e.done and SUB or (e.current and GOLD or TEXT)
      b.text:SetTextColor(col.r, col.g, col.b)
      DETAIL.Fit(b.text, str, tw, false)
      b.open, b.label, b.itemID = e.open, e.text, e.itemID
      b:Show()
      PANE.info.lines[#PANE.info.lines + 1] = e.text
      PANE.info.opens = (PANE.info.opens or 0) + (e.open and 1 or 0)
      y = y + 24
    end
    for k = 1, #(sec.paras or {}) do
      local e = sec.paras[k]
      if e.head then text(e.head, TEXT, 12, false) end
      if e.body then text(e.body, SUB, 11, true) end
      y = y + 2
    end
    if sec.text and sec.text ~= "" then
      text(sec.text, SUB, 11, true)
    end
    y = y + 8
  end
  d.body:SetHeight(y + P)
end

-- After a tab lays out: pick the selection and draw the pane.
function DETAIL.Finish()
  if not ui.split then
    return
  end
  local cur = PANE.cur
  if not cur then
    -- Prefer a purpose-built detail, then any item that isn't a group.
    for i = 1, #PANE.rows do
      if PANE.rows[i].explicit then
        cur = PANE.rows[i]
        break
      end
    end
    cur = cur or PANE.rows[1]
    if cur then
      PANE.sel[ui.tab] = cur.key
      PANE.cur = cur
      cur.row._selected = true
      if cur.row.rim and PC.ShowRoundFill then
        PC:ShowRoundFill(cur.row.rim, true)
      end
    end
  end
  -- Group rows show how many items they hold.
  for i = 1, #PANE.rows do
    local e = PANE.rows[i]
    if e.group and e.row and e.row.meta then
      local n = 0
      for k = 1, #e.children do
        if not e.children[k].body then n = n + 1 end
      end
      e.row.meta:SetText(tostring(n) .. (n == 1 and " item" or " items"))
    end
  end
  -- Drill-down stack belongs to the selected row.
  local key = cur and cur.key or nil
  if PANE.stackFor ~= key then
    PANE.stack = {}
    PANE.stackFor = key
  end
  local spec
  local function build(fn)
    local ok, res = pcall(fn)
    if ok then
      return res
    end
    if PC.LogError then
      PC:LogError(tostring(res), "", "ui:detail-build")
    end
    return nil
  end
  if cur then
    spec = build(cur.build)
    local stack = PANE.stack or {}
    if #stack > 0 then
      local parentTitle = spec and spec.title or "Back"
      for i = 1, #stack - 1 do
        parentTitle = stack[i].title or parentTitle
      end
      local top = build(stack[#stack].build)
      if top then
        top.backTo = parentTitle
        spec = top
      else
        table.remove(stack)
      end
    end
  end
  local okR, errR = pcall(DETAIL.Render, spec)
  if not okR and PC.LogError then
    PC:LogError(tostring(errR), "", "ui:RenderDetail")
  end
end

function DETAIL.Begin()
  PANE.rows = {}
  PANE.cur = nil
  PANE.parent = nil
end

-- Guild cards are drawn by LayoutPersonRow; they register here.
function DETAIL.Person(rec)
  local spec = { title = rec.name or "Guildmate", actions = {}, sections = {} }
  if rec.classFile and PC.ClassColor then
    local r, g, b = PC:ClassColor(rec.classFile)
    spec.titleColor = { r = r, g = g, b = b }
  end
  local bits = {}
  if rec.level then bits[#bits + 1] = "Level " .. tostring(rec.level) end
  if rec.role then bits[#bits + 1] = (rec.role == "healer" and "Healer") or (rec.role == "tank" and "Tank") or "DPS" end
  if rec.zone then bits[#bits + 1] = rec.zone end
  spec.sub = table.concat(bits, "  ·  ")
  if not rec.demo then
    if PC.WhisperPeer then
      spec.actions[#spec.actions + 1] = { label = "Whisper", run = function() PC:WhisperPeer(rec.name) end }
    end
    if PC.InvitePeer then
      spec.actions[#spec.actions + 1] = { label = "Invite", run = function() PC:InvitePeer(rec.name) end }
    end
  end
  local status = PC.StatusLabel and rec.status and PC:StatusLabel(rec.status) or rec.status
  local lines = {}
  if status then lines[#lines + 1] = { text = tostring(status), sub = "Status" } end
  if rec.canHelp then lines[#lines + 1] = { text = "Can help", sub = "Helper" } end
  if rec.demo then lines[#lines + 1] = { text = "Demo player", sub = "Preview only" } end
  if #lines > 0 then spec.sections[#spec.sections + 1] = { title = "Now", lines = lines } end
  local ids = PC.PeerDungeonList and PC:PeerDungeonList(rec) or {}
  local dl = {}
  for i = 1, #ids do
    local dd = PC.FindDungeon and PC:FindDungeon(ids[i]) or nil
    local mine = PC.IsDungeonSelected and PC:IsDungeonSelected(ids[i])
    dl[#dl + 1] = { text = (dd and dd.name) or ids[i], sub = mine and "You picked it too" or nil }
  end
  if #dl > 0 then spec.sections[#spec.sections + 1] = { title = "Dungeon picks", lines = dl } end
  if rec.note and rec.note ~= "" then spec.sections[#spec.sections + 1] = { title = "Note", text = rec.note } end
  return spec
end

function PC:DebugDetailPane()
  return {
    split = ui.split and true or false,
    shown = ui.detail and ui.detail:IsShown() and true or false,
    selected = PANE.sel[ui.tab],
    rows = #PANE.rows,
    listWidth = ui.splitListW,
    paneWidth = ui.detail and ui.detail:GetWidth() or nil,
    info = PANE.info,
    depth = #(PANE.stack or {}),
  }
end

do
  local base = PC.IsExpanded
  if base and not PC._isExpandedWrapped then
    PC._isExpandedWrapped = true
    function PC:IsExpanded(key, defaultOn)
      if ui.split and ui.layingOut and not Searching() then
        return true
      end
      return base(self, key, defaultOn)
    end
  end
end

function PC._PaneBackForTest()
  if PANE.stack and #PANE.stack > 0 then table.remove(PANE.stack) end
  DETAIL.Finish()
end

function PC._SelectDetailForTest(key)
  PANE.sel[ui.tab] = key
  PC:Refresh()
end

function PC._DetailRowsForTest()
  local out = {}
  for i = 1, #PANE.rows do
    out[i] = { key = PANE.rows[i].key, explicit = PANE.rows[i].explicit, row = PANE.rows[i].row }
  end
  return out
end

function PC:GetCurrentTabForTest()
  return ui.tab
end

function PC._SelectNextForTest(id)
  PC._SelectDetailForTest(id)
end

-- 1.23.0: the Next tab's level banner is its own shape, not a list card.
function CARDS.Banner(y, title, line2, line3)
  local b = rawget(ui, "nextBanner")
  if not b then
    b = CreateFrame("Frame", "PhilosophersCodexNextBanner", ui.content)
    b.bg = b:CreateTexture(nil, "BACKGROUND")
    b.bg:SetAllPoints()
    b.bar = b:CreateTexture(nil, "BORDER")
    b.bar:SetPoint("TOPLEFT", b, "TOPLEFT", 0, 0)
    b.bar:SetPoint("BOTTOMLEFT", b, "BOTTOMLEFT", 0, 0)
    b.bar:SetWidth(3)
    b.line = b:CreateTexture(nil, "BORDER")
    b.line:SetPoint("BOTTOMLEFT", b, "BOTTOMLEFT", 0, 0)
    b.line:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", 0, 0)
    b.line:SetHeight(1)
    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetSize(40, 40)
    b.icon:SetPoint("LEFT", b, "LEFT", 14, 0)
    ApplyCircleMask(b.icon, b)
    b.title = MakeFontString(b, 18, "GameFontNormalLarge")
    b.title:SetPoint("TOPLEFT", b, "TOPLEFT", 66, -12)
    b.title:SetJustifyH("LEFT")
    b.l2 = MakeFontString(b, 12)
    b.l2:SetPoint("TOPLEFT", b.title, "BOTTOMLEFT", 0, -3)
    b.l2:SetJustifyH("LEFT")
    b.l3 = MakeFontString(b, 11, "GameFontNormalSmall")
    b.l3:SetPoint("TOPLEFT", b.l2, "BOTTOMLEFT", 0, -2)
    b.l3:SetJustifyH("LEFT")
    ui.nextBanner = b
  end
  local w = ContentWidth()
  local accent = AccentColor()
  local h = line3 and line3 ~= "" and 72 or 58
  b:ClearAllPoints()
  b:SetPoint("TOPLEFT", ui.content, "TOPLEFT", 0, -y)
  b:SetSize(w, h)
  Paint(b.bg, { r = accent.r * 0.14, g = accent.g * 0.14, b = accent.b * 0.14 }, 0.95)
  Paint(b.bar, accent, 1)
  Paint(b.line, accent, 0.35)
  pcall(b.icon.SetTexture, b.icon, ClassIcon("class"))
  local tw = math.max(60, w - 80)
  b.title:SetWidth(tw); b.l2:SetWidth(tw); b.l3:SetWidth(tw)
  b.title:SetTextColor(accent.r, accent.g, accent.b)
  b.l2:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
  b.l3:SetTextColor(SUB.r, SUB.g, SUB.b)
  if PC.FitFontString then
    PC:FitFontString(b.title, title or "", tw, false)
    PC:FitFontString(b.l2, line2 or "", tw, false)
    PC:FitFontString(b.l3, line3 or "", tw, false)
  else
    b.title:SetText(title or ""); b.l2:SetText(line2 or ""); b.l3:SetText(line3 or "")
  end
  b:Show()
  return y + h + 10
end

local function LayoutNext()
  HideTodayCard()
  HideGearFilterBar()
  local y = 0
  local n = 0
  local data = PC:GetClassData()

  local bracket = PC.GetCurrentBracketLabel and PC:GetCurrentBracketLabel() or nil
  local session = PC.SessionSummaryLine and PC:SessionSummaryLine() or nil
  y = CARDS.Banner(y, "Level " .. tostring(PC:PlayerLevel() or 1), bracket or "", session)

  if not data or (not data.brackets or #data.brackets == 0) then
    n, y = ComingSoonBody(n, y, data)
    SetContentHeight(y)
    return
  end
  if not data.supported then
    n, y = ComingSoonBody(n, y, data)
  end

  local groups = PC.GetNextGroups and PC:GetNextGroups() or {}
  if #groups == 0 then
    n = n + 1
    y = Body(n, "Nothing lined up right now. Open Path for the full route, or Craft if you have a profession to level.", y)
  end
  for i = 1, #groups do
    local group = groups[i]
    n = n + 1
    y = Header(n, group.title or group.id, y)
    local items = group.items or {}
    for j = 1, #items do
      local it = items[j]
      local id = it.id
      n = n + 1
      y = ListRow(n, it.title, it.detail, nil, y, {
        icon = it.icon or ClassIcon(group.id),
        detailKey = it.id,
        detail = function() return DETAIL.Next(it) end,
        checkable = true,
        checked = it.checked,
        onClick = function(isChecked)
          if PC.SetTonightChecked then
            PC:SetTonightChecked(id, isChecked)
          end
        end,
        waypoint = it.waypoint,
        last = j == #items,
        progress = it.progress,
        chevron = true,
        expanded = false,
        tip = {
          { it.title or "Next", GOLD.r, GOLD.g, GOLD.b },
          it.detail or "Tap to open the full details.",
        },
        onExpand = function()
          if PC.FollowNextItem then
            PC:FollowNextItem(it)
          end
        end,
      })
    end
  end
  SetContentHeight(y)
end

local CLASS_TCOORDS = {
  WARRIOR = { 0, 0.25, 0, 0.25 },
  MAGE = { 0.25, 0.49609375, 0, 0.25 },
  ROGUE = { 0.49609375, 0.7421875, 0, 0.25 },
  DRUID = { 0.7421875, 0.98828125, 0, 0.25 },
  HUNTER = { 0, 0.25, 0.25, 0.5 },
  SHAMAN = { 0.25, 0.49609375, 0.25, 0.5 },
  PRIEST = { 0.49609375, 0.7421875, 0.25, 0.5 },
  WARLOCK = { 0.7421875, 0.98828125, 0.25, 0.5 },
  PALADIN = { 0, 0.25, 0.5, 0.75 },
  DEATHKNIGHT = { 0.25, 0.49609375, 0.5, 0.75 },
  MONK = { 0.49609375, 0.7421875, 0.5, 0.75 },
  DEMONHUNTER = { 0.7421875, 0.98828125, 0.5, 0.75 },
  EVOKER = { 0, 0.25, 0.75, 1 },
}

-- Documented GetTexCoordsForRoleSmallCircle (FrameXML Utility.lua / Role.lua;
-- Warcraft Wiki "API GetTexCoordsForRoleSmallCircle") for the 64x64 sheet
-- Interface/LFGFrame/UI-LFG-ICON-PORTRAITROLES:
--   TANK:    0,     19/64, 22/64, 41/64
--   HEALER: 20/64,  39/64,  1/64, 20/64
--   DAMAGER:20/64,  39/64, 22/64, 41/64
-- Do not use these coords on UI-LFG-ICON-ROLES (that's GetTexCoordsForRole
-- on a 256x256 sheet); that mismatch caused neighbor-sprite bleed in 1.8.0.
local ROLE_TCOORDS = {
  tank = { 0, 19 / 64, 22 / 64, 41 / 64 },
  healer = { 20 / 64, 39 / 64, 1 / 64, 20 / 64 },
  dps = { 20 / 64, 39 / 64, 22 / 64, 41 / 64 },
}
local ROLE_ATLAS = {
  tank = "roleicon-tiny-tank",
  healer = "roleicon-tiny-healer",
  dps = "roleicon-tiny-dps",
}

local ROLE_LETTER = { tank = "T", healer = "H", dps = "D" }
local ROLE_COLOR = {
  tank = { r = 0.78, g = 0.61, b = 0.43 },
  healer = { r = 0.10, g = 0.80, b = 0.40 },
  dps = { r = 0.80, g = 0.30, b = 0.30 },
}
local STATUS_COLOR = {
  questing = EMERALD,
  dungeon = GOLD,
  help = { r = 0.90, g = 0.72, b = 0.22 },
  open = { r = 0.40, g = 0.70, b = 0.95 },
  busy = { r = 0.70, g = 0.30, b = 0.30 },
}

local function ClassTexCoords(classFile)
  if CLASS_ICON_TCOORDS and classFile and CLASS_ICON_TCOORDS[classFile] then
    return CLASS_ICON_TCOORDS[classFile]
  end
  return CLASS_TCOORDS[classFile or ""]
end

local function ApplyClassIcon(tex, classFile)
  if not tex then
    return
  end
  local path = "Interface\\GLUES\\CHARACTERCREATE\\UI-CHARACTERCREATE-CLASSES"
  local ok = tex.SetTexture and tex:SetTexture(path)
  local coords = ClassTexCoords(classFile)
  if ok ~= false and coords and tex.SetTexCoord then
    tex:SetTexCoord(coords[1], coords[2], coords[3], coords[4])
    -- The character-create sheet is already tinted per class.
    if tex.SetVertexColor then
      tex:SetVertexColor(1, 1, 1, 1)
    end
    tex:Show()
    return true
  end
  tex:Hide()
  return false
end

local function TextureOk(tex)
  if not tex then
    return false
  end
  if tex.GetTexture then
    local ok, got = pcall(tex.GetTexture, tex)
    if ok and type(got) == "string" and got ~= "" then
      return true
    end
    if ok and type(got) == "number" and got ~= 0 then
      return true
    end
  end
  return tex._texture and true or false
end

local function TrySetTexture(tex, path)
  if type(tex) ~= "table" or not path or not tex.SetTexture then
    return false
  end
  local ok, result = pcall(tex.SetTexture, tex, path)
  if not ok or result == false then
    return false
  end
  return TextureOk(tex) or ok
end

local function ApplyRoleIcon(tex, letter, role)
  role = role or "dps"
  local shown = false
  if type(tex) == "table" then
    if tex.SetSize then
      tex:SetSize(18, 18)
    end
    local atlas = ROLE_ATLAS[role] or ROLE_ATLAS.dps
    local hasAtlas = false
    if tex.SetAtlas and C_Texture and C_Texture.GetAtlasInfo then
      local okInfo, info = pcall(C_Texture.GetAtlasInfo, atlas)
      if okInfo and type(info) == "table" then
        hasAtlas = pcall(tex.SetAtlas, tex, atlas)
      end
    end
    if hasAtlas then
      tex:Show()
      shown = true
    else
      local path = "Interface\\LFGFrame\\UI-LFG-ICON-PORTRAITROLES"
      local ok = TrySetTexture(tex, path)
      local l, r, t, b
      local token = (role == "tank" and "TANK") or (role == "healer" and "HEALER") or "DAMAGER"
      if GetTexCoordsForRoleSmallCircle then
        local cok, a1, a2, a3, a4 = pcall(GetTexCoordsForRoleSmallCircle, token)
        if cok and type(a1) == "number" then
          l, r, t, b = a1, a2, a3, a4
        end
      end
      if not l then
        local c = ROLE_TCOORDS[role] or ROLE_TCOORDS.dps
        l, r, t, b = c[1], c[2], c[3], c[4]
      end
      -- Half-texel inset on the 64px sheet keeps neighboring role art from bleeding.
      local inset = 0.5 / 64
      l, r, t, b = l + inset, r - inset, t + inset, b - inset
      if ok and tex.SetTexCoord then
        tex:SetTexCoord(l, r, t, b)
        tex:Show()
        shown = true
      else
        tex:Hide()
      end
    end
  end
  if letter then
    if shown then
      letter:Hide()
    else
      letter:SetText(ROLE_LETTER[role] or "D")
      local col = ROLE_COLOR[role] or ROLE_COLOR.dps
      letter:SetTextColor(col.r, col.g, col.b)
      letter:Show()
    end
  end
end

local function ApplyButtonIcon(btn, paths, fallback)
  if not btn then
    return false
  end
  if type(rawget(btn, "iconTex")) ~= "table" then
    btn.iconTex = btn:CreateTexture(nil, "ARTWORK")
    btn.iconTex:SetSize(16, 16)
    btn.iconTex:SetPoint("CENTER", 0, 0)
  end
  for i = 1, #paths do
    if TrySetTexture(btn.iconTex, paths[i]) then
      btn.iconTex:Show()
      if btn.label then
        btn.label:SetText("")
        btn.label:Hide()
      end
      return true
    end
  end
  if btn.iconTex then
    btn.iconTex:Hide()
  end
  if btn.label then
    btn.label:SetText(fallback or "")
    btn.label:Show()
  end
  return false
end

PC.ApplyRoleIcon = ApplyRoleIcon
PC.TrySetTexture = TrySetTexture

local function MakeIconBtn(parent, name, w, label)
  local b = CreateFrame("Button", name, parent)
  b:SetSize(w or 24, 24)
  b.bg = b:CreateTexture(nil, "BACKGROUND")
  b.bg:SetAllPoints()
  Paint(b.bg, { r = 0.16, g = 0.16, b = 0.18 }, 1)
  if PC._RoundifyButton then PC._RoundifyButton(b) end
  b.label = MakeFontString(b, 11, "GameFontNormalSmall")
  b.label:SetPoint("CENTER")
  b.label:SetText(label or "")
  b.label:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
  b:SetScript("OnLeave", HideTooltip)
  return b
end

local function FrameIsOrContains(frame, target)
  if not frame or not target then
    return false
  end
  local cur = frame
  local hops = 0
  while cur and hops < 12 do
    if cur == target then
      return true
    end
    cur = cur.GetParent and cur:GetParent() or nil
    hops = hops + 1
  end
  return false
end

-- Forever is mainline-family (Interface 16001). GetMouseFocus is often
-- nil or missing (replaced by GetMouseFoci). Never trust it alone.
local function MouseFocusFrames()
  local out = {}
  if GetMouseFoci then
    local ok, foci = pcall(GetMouseFoci)
    if ok and type(foci) == "table" then
      for i = 1, #foci do
        out[#out + 1] = foci[i]
      end
    end
  end
  if GetMouseFocus then
    local ok, focus = pcall(GetMouseFocus)
    if ok and focus then
      out[#out + 1] = focus
    end
  end
  return out
end

local function MenuRegionHit(region)
  local m = ui.dropMenu
  if not m or not region then
    return false
  end
  if FrameIsOrContains(region, m) then
    return true
  end
  if m.anchor and FrameIsOrContains(region, m.anchor) then
    return true
  end
  return false
end

local function IsOverMenu()
  local m = ui.dropMenu
  if not m or not m:IsShown() then
    return false
  end
  -- Prefer the frame's own hit test. This works when GetMouseFocus is nil,
  -- which is the real Forever case that made the 1.14 fix fail.
  if m.IsMouseOver and m:IsMouseOver() then
    return true
  end
  if m.anchor and m.anchor.IsMouseOver and m.anchor:IsMouseOver() then
    return true
  end
  if m.buttons then
    for i = 1, #m.buttons do
      local b = m.buttons[i]
      if b and b.IsShown and b:IsShown() and b.IsMouseOver and b:IsMouseOver() then
        return true
      end
    end
  end
  local foci = MouseFocusFrames()
  for i = 1, #foci do
    if MenuRegionHit(foci[i]) then
      return true
    end
  end
  if MouseIsOver then
    if MouseIsOver(m) then
      return true
    end
    if m.anchor and MouseIsOver(m.anchor) then
      return true
    end
    if m.buttons then
      for i = 1, #m.buttons do
        local b = m.buttons[i]
        if b and b.IsShown and b:IsShown() and MouseIsOver(b) then
          return true
        end
      end
    end
  end
  return false
end

local function HideMenu()
  if ui.dropMenu then
    ui.dropMenu:Hide()
    ui.dropMenu.anchor = nil
  end
  if ui.menuCatcher then
    ui.menuCatcher:Hide()
  end
  ui.nativeMenuOpen = nil
end

local function EnsureMenuCatcher()
  if ui.menuCatcher then
    return ui.menuCatcher
  end
  -- Full-screen catcher sits just below the menu so item clicks never hit it.
  -- Strata is FULLSCREEN; the menu is FULLSCREEN_DIALOG (one step higher).
  local c = CreateFrame("Button", "PhilosophersCodexMenuCatcher", UIParent)
  c:SetAllPoints(UIParent)
  if c.SetFrameStrata then
    c:SetFrameStrata("FULLSCREEN")
  end
  c:SetFrameLevel(1)
  c:EnableMouse(true)
  if c.RegisterForClicks then
    pcall(c.RegisterForClicks, c, "AnyUp", "AnyDown")
  end
  local function dismiss()
    if IsOverMenu() then
      return
    end
    HideMenu()
  end
  -- Close on mouse down so we don't depend on a later OnClick, but never
  -- when the cursor is over the menu itself.
  c:SetScript("OnMouseDown", dismiss)
  c:SetScript("OnClick", dismiss)
  if c.EnableKeyboard then
    pcall(c.EnableKeyboard, c, true)
  end
  if c.SetPropagateKeyboardInput then
    pcall(c.SetPropagateKeyboardInput, c, true)
  end
  c:SetScript("OnKeyDown", function(self, key)
    if key == "ESCAPE" or key == "Esc" then
      HideMenu()
      if self.SetPropagateKeyboardInput then
        pcall(self.SetPropagateKeyboardInput, self, false)
      end
    end
  end)
  c:Hide()
  ui.menuCatcher = c
  -- Do not register GLOBAL_MOUSE_DOWN. On Forever that event fires before
  -- the item's OnMouseDown/OnClick, GetMouseFocus is often nil, and hiding
  -- the menu here swallowed the pick (the 1.14 IsOverMenu guard failed
  -- for the same reason). Outside clicks are handled by this catcher.
  return c
end

local function EnsureDropMenu()
  if ui.dropMenu then
    return ui.dropMenu
  end
  local m = CreateFrame("Frame", "PhilosophersCodexDropMenu", UIParent)
  if m.SetFrameStrata then
    m:SetFrameStrata("FULLSCREEN_DIALOG")
  end
  m:SetFrameLevel(100)
  m:SetToplevel(true)
  m:EnableMouse(true)
  m:SetWidth(180)
  m.bg = m:CreateTexture(nil, "BACKGROUND")
  m.bg:SetAllPoints()
  Paint(m.bg, { r = 0.08, g = 0.08, b = 0.09 }, 0.97)
  m.edge = m:CreateTexture(nil, "BORDER")
  Paint(m.edge, EMERALD, 0.5)
  m.edge:SetPoint("TOPLEFT", 0, 0)
  m.edge:SetPoint("TOPRIGHT", 0, 0)
  m.edge:SetHeight(2)
  m.buttons = {}
  m:Hide()
  ui.dropMenu = m
  return m
end

local function ShowNativeMenu(anchor, items)
  if MenuUtil and MenuUtil.CreateContextMenu then
    local ok = pcall(function()
      MenuUtil.CreateContextMenu(anchor, function(_, root)
        for i = 1, #items do
          local item = items[i]
          root:CreateButton(item.label or "", function()
            if item.onClick then
              item.onClick()
            end
          end)
        end
      end)
    end)
    if ok then
      ui.nativeMenuOpen = anchor
      return true
    end
  end
  if EasyMenu and UIDropDownMenu_Initialize then
    local ok = pcall(function()
      if not ui.blizDrop then
        ui.blizDrop = CreateFrame("Frame", "PhilosophersCodexBlizDrop", UIParent, "UIDropDownMenuTemplate")
      end
      local list = {}
      for i = 1, #items do
        local item = items[i]
        list[#list + 1] = {
          text = item.label or "",
          checked = item.checked and true or false,
          func = function()
            if item.onClick then
              item.onClick()
            end
          end,
          notCheckable = not item.checked,
        }
      end
      EasyMenu(list, ui.blizDrop, anchor, 0, 0, "MENU")
    end)
    if ok then
      ui.nativeMenuOpen = anchor
      return true
    end
  end
  return false
end

local function ShowMenu(anchor, items)
  items = items or {}
  if ui.dropMenu and ui.dropMenu:IsShown() and ui.dropMenu.anchor == anchor then
    HideMenu()
    return
  end
  if ui.nativeMenuOpen == anchor then
    HideMenu()
    if CloseDropDownMenus then
      pcall(CloseDropDownMenus)
    end
    return
  end
  -- Prefer the client's own dropdown when it exists; it already handles
  -- outside clicks correctly. Fall back to our custom menu otherwise.
  if ShowNativeMenu(anchor, items) then
    return
  end
  local m = EnsureDropMenu()
  local catcher = EnsureMenuCatcher()
  if m.SetFrameStrata then
    m:SetFrameStrata("FULLSCREEN_DIALOG")
  end
  if catcher.SetFrameStrata then
    catcher:SetFrameStrata("FULLSCREEN")
  end
  catcher:SetFrameLevel(1)
  m:SetFrameLevel(100)
  catcher:Show()
  m.anchor = anchor
  local count = #items
  for i = 1, math.max(count, #m.buttons) do
    local b = m.buttons[i]
    if not b then
      b = CreateFrame("Button", "PhilosophersCodexDropMenuBtn" .. i, m)
      b:SetHeight(22)
      b:SetPoint("TOPLEFT", 4, -4 - (i - 1) * 22)
      b:SetPoint("RIGHT", -4, 0)
      b:EnableMouse(true)
      if b.RegisterForClicks then
        pcall(b.RegisterForClicks, b, "AnyUp", "AnyDown")
      end
      b.label = MakeFontString(b, 12, "GameFontHighlight")
      b.label:SetPoint("LEFT", 6, 0)
      b.label:SetPoint("RIGHT", -6, 0)
      b.label:SetJustifyH("LEFT")
      b.hl = b:CreateTexture(nil, "HIGHLIGHT")
      b.hl:SetAllPoints()
      b.hl:SetTexture(HIGHLIGHT)
      if b.hl.SetBlendMode then
        b.hl:SetBlendMode("ADD")
      end
      b.hl:SetAlpha(0.35)
      m.buttons[i] = b
    end
    local item = items[i]
    if item then
      b:Show()
      b.label:SetText(item.label or "")
      if item.checked then
        b.label:SetTextColor(EMERALD.r, EMERALD.g, EMERALD.b)
      else
        b.label:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
      end
      -- Capture the item in a per-button field so a later ShowMenu rebuild
      -- cannot change which row this click applies. Apply on mouse down
      -- (AnyDown) so the choice is saved even if a later event hides us
      -- before OnClick. GLOBAL_MOUSE_DOWN is no longer used to close.
      b._item = item
      b._menuFired = nil
      b:SetScript("OnMouseDown", function(self)
        local chosen = self._item
        self._menuFired = true
        if chosen and chosen.onClick then
          chosen.onClick()
        end
        HideMenu()
      end)
      b:SetScript("OnClick", function(self)
        if self._menuFired then
          self._menuFired = nil
          return
        end
        local chosen = self._item
        if chosen and chosen.onClick then
          chosen.onClick()
        end
        HideMenu()
      end)
    else
      b._item = nil
      b:Hide()
    end
  end
  m:ClearAllPoints()
  m:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -2)
  m:SetHeight(8 + count * 22)
  m:Show()
end

local function EnsureNoteEditor()
  if ui.noteEditor then
    return ui.noteEditor
  end
  local f = CreateFrame("Frame", "PhilosophersCodexNoteEditor", UIParent)
  f:SetFrameStrata("DIALOG")
  f:SetSize(260, 54)
  f.bg = f:CreateTexture(nil, "BACKGROUND")
  f.bg:SetAllPoints()
  Paint(f.bg, { r = 0.08, g = 0.08, b = 0.09 }, 0.97)
  local box = CreateFrame("EditBox", "PhilosophersCodexNoteEditBox", f)
  if box.SetFontObject then
    pcall(box.SetFontObject, box, GameFontHighlight)
  end
  if box.SetAutoFocus then
    box:SetAutoFocus(false)
  end
  box:SetHeight(20)
  box:SetPoint("TOPLEFT", 12, -8)
  box:SetPoint("RIGHT", -12, 0)
  if box.SetMaxLetters then
    box:SetMaxLetters(40)
  end
  f.box = box
  local save = MakeIconBtn(f, "PhilosophersCodexNoteSave", 48, "Save")
  save:SetPoint("BOTTOMLEFT", 12, 6)
  save:SetScript("OnClick", function()
    local text = ""
    if box.GetText then
      text = box:GetText() or ""
    end
    if PC.SetSocialNote then
      PC:SetSocialNote(text)
    end
    f:Hide()
    if PC.Refresh then
      PC:Refresh()
    end
  end)
  local cancel = MakeIconBtn(f, "PhilosophersCodexNoteCancel", 56, "Cancel")
  cancel:SetPoint("LEFT", save, "RIGHT", 8, 0)
  cancel:SetScript("OnClick", function()
    f:Hide()
  end)
  f:Hide()
  ui.noteEditor = f
  return f
end

local function EnsureGuildStrip()
  if ui.guildStrip then
    return ui.guildStrip
  end
  local s = CreateFrame("Frame", "PhilosophersCodexGuildStrip", ui.content)
  s:SetHeight(32)
  s.bg = s:CreateTexture(nil, "BACKGROUND")
  s.bg:SetAllPoints()
  Paint(s.bg, CARD, 1)

  s.status = MakeIconBtn(s, "PhilosophersCodexStripStatusPill", 128, "Questing")
  s.status:SetPoint("LEFT", 8, 0)
  s.status:SetWidth(118)
  s.status.label:SetPoint("LEFT", 8, 0)
  s.status.label:SetJustifyH("LEFT")
  s.status.dot = s.status:CreateTexture(nil, "OVERLAY")
  s.status.dot:SetSize(8, 8)
  s.status.dot:SetPoint("LEFT", 6, 0)
  Paint(s.status.dot, EMERALD, 1)

  s.role = MakeIconBtn(s, "PhilosophersCodexRoleToggle", 28, "H")
  s.role:SetPoint("LEFT", s.status, "RIGHT", 6, 0)
  s.role.icon = s.role:CreateTexture(nil, "ARTWORK")
  s.role.icon:SetSize(16, 16)
  s.role.icon:SetPoint("CENTER", 0, 0)

  s.segGroup = MakeIconBtn(s, "PhilosophersCodexSegGroup", 28, "G")
  s.segEveryone = MakeIconBtn(s, "PhilosophersCodexSegEveryone", 28, "E")
  s.segRequests = MakeIconBtn(s, "PhilosophersCodexSegRequests", 28, "R")
  ApplyButtonIcon(s.segGroup, {
    "Interface\\FriendsFrame\\UI-Toast-ChatInviteIcon",
    "Interface\\LFGFrame\\LFG-Eye",
    "Interface\\LFGFRAME\\LFG-Eye",
  }, "G")
  ApplyButtonIcon(s.segEveryone, {
    "Interface\\FriendsFrame\\UI-FriendsList-Large",
    "Interface\\Icons\\INV_Shirt_GuildTabard_01",
  }, "E")
  ApplyButtonIcon(s.segRequests, {
    "Interface\\Icons\\INV_Letter_15",
    "Interface\\Minimap\\Tracking\\Mailbox",
  }, "R")
  s.segGroup:SetPoint("LEFT", s.role, "RIGHT", 10, 0)
  s.segEveryone:SetPoint("LEFT", s.segGroup, "RIGHT", 2, 0)
  s.segRequests:SetPoint("LEFT", s.segEveryone, "RIGHT", 2, 0)
  s.badge = MakeFontString(s.segRequests, 9, "GameFontNormalSmall")
  s.badge:SetPoint("TOPRIGHT", 4, 4)
  s.badge:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
  s.badge:Hide()

  s.pencil = MakeIconBtn(s, "PhilosophersCodexNotePencil", 22, "N")
  s.share = MakeIconBtn(s, "PhilosophersCodexShareMini", 22, "S")
  ApplyButtonIcon(s.pencil, { "Interface\\MINIMAP\\TRACKING\\None", "Interface\\Buttons\\UI-GuildButton-PublicNote-Up" }, "N")
  ApplyButtonIcon(s.share, { "Interface\\Buttons\\UI-GuildButton-MOTD-Up" }, "S")
  s.pencil:SetPoint("RIGHT", -6, 0)
  s.share:SetPoint("RIGHT", s.pencil, "LEFT", -2, 0)
  -- Legend button removed in 1.9.0; tooltips on the icons are enough.

  ui.guildStrip = s
  return s
end

local function StyleSeg(btn, on)
  if on then
    Paint(btn.bg, { r = 0.12, g = 0.22, b = 0.16 }, 1)
    if btn.label then
      btn.label:SetTextColor(EMERALD.r, EMERALD.g, EMERALD.b)
    end
    local icon = rawget(btn, "iconTex")
    if type(icon) == "table" and icon.SetVertexColor then
      icon:SetVertexColor(EMERALD.r, EMERALD.g, EMERALD.b, 1)
    end
  else
    Paint(btn.bg, { r = 0.16, g = 0.16, b = 0.18 }, 1)
    if btn.label then
      btn.label:SetTextColor(SUB.r, SUB.g, SUB.b)
    end
    local icon = rawget(btn, "iconTex")
    if type(icon) == "table" and icon.SetVertexColor then
      icon:SetVertexColor(0.75, 0.75, 0.78, 1)
    end
  end
end

local function PlaceStrip(y)
  local s = EnsureGuildStrip()
  s:ClearAllPoints()
  s:SetPoint("TOPLEFT", ui.content, "TOPLEFT", 0, -y)
  s:SetWidth(ContentWidth())
  s:Show()
  return y + 36
end

local function AcquireGuildCard(i)
  ui.guildCards = ui.guildCards or {}
  if ui.guildCards[i] then
    return ui.guildCards[i]
  end
  local c = CreateFrame("Frame", nil, ui.content)
  c:SetHeight(52)
  c.bg = c:CreateTexture(nil, "BACKGROUND")
  c.bg:SetAllPoints()
  Paint(c.bg, CARD, 1)
  c.name = MakeFontString(c, 13)
  c.name:SetPoint("TOPLEFT", 12, -8)
  c.name:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
  c.leader = MakeFontString(c, 11, "GameFontNormalSmall")
  c.leader:SetPoint("TOPLEFT", c.name, "BOTTOMLEFT", 0, -2)
  c.leader:SetTextColor(SUB.r, SUB.g, SUB.b)
  c.join = MakeIconBtn(c, nil, 48, "Join")
  c.join:SetPoint("RIGHT", -10, 8)
  c.slots = {}
  for k = 1, 5 do
    local slot = CreateFrame("Frame", nil, c)
    slot:SetSize(18, 18)
    if k == 1 then
      slot:SetPoint("BOTTOMLEFT", 12, 8)
    else
      slot:SetPoint("LEFT", c.slots[k - 1], "RIGHT", 4, 0)
    end
    slot.icon = slot:CreateTexture(nil, "ARTWORK")
    slot.icon:SetAllPoints()
    slot.letter = MakeFontString(slot, 10, "GameFontNormalSmall")
    slot.letter:SetPoint("CENTER")
    c.slots[k] = slot
  end
  ui.guildCards[i] = c
  return c
end

local function LayoutLfgCard(i, group, y)
  local c = AcquireGuildCard(i)
  c:ClearAllPoints()
  c:SetPoint("TOPLEFT", ui.content, "TOPLEFT", 0, -y)
  c:SetWidth(ContentWidth())
  local nameW = ContentWidth() - 70
  if PC.FitFontString then
    PC:FitFontString(c.name, group.name or "Dungeon", nameW, false)
    local lead = (group.leader and group.leader.name) or "Unknown"
    PC:FitFontString(c.leader, "Lead: " .. lead, nameW, false)
  else
    c.name:SetText(group.name or "Dungeon")
    c.leader:SetText("Lead: " .. ((group.leader and group.leader.name) or "Unknown"))
  end
  for k = 1, 5 do
    local slot = c.slots[k]
    local info = group.slots and group.slots[k]
    local role = info and info.role or "dps"
    ApplyRoleIcon(slot.icon, slot.letter, role)
    if info and info.filled then
      slot:SetAlpha(1)
    else
      slot:SetAlpha(0.28)
    end
  end
  if group.mine then
    c.join.label:SetText("Leave")
    c.join:SetScript("OnClick", function()
      if PC.SetSocialLfg then
        PC:SetSocialLfg(nil)
      end
    end)
    c.join:SetScript("OnEnter", function(self)
      ShowRowTooltip(self, { { "Leave this group post", GOLD.r, GOLD.g, GOLD.b }, "Stops broadcasting this dungeon." })
    end)
  else
    c.join.label:SetText("Join")
    local leader = group.leader and group.leader.name
    c.join:SetScript("OnClick", function()
      if leader and PC.SendJoinRequest then
        PC:SendJoinRequest(leader, group.name or group.id)
      end
    end)
    c.join:SetScript("OnEnter", function(self)
      ShowRowTooltip(self, { { "Join this group", GOLD.r, GOLD.g, GOLD.b }, "Sends a Codex request to the leader. They invite you only when they accept." })
    end)
  end
  c:Show()
  return y + 56
end

local function EnsureGuildBits(row)
  if rawget(row, "guildBits") == true then
    return
  end
  row.levelBadge = MakeFontString(row, 10, "GameFontNormalSmall")
  row.levelBadge:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
  row.roleTex = row:CreateTexture(nil, "ARTWORK")
  row.roleTex:SetSize(18, 18)
  row.roleLetter = MakeFontString(row, 10, "GameFontNormalSmall")
  row.statusDot = row:CreateTexture(nil, "OVERLAY")
  row.statusDot:SetSize(8, 8)
  row.locIcon = row:CreateTexture(nil, "ARTWORK")
  row.locIcon:SetSize(10, 10)
  row.chip1 = MakeFontString(row, 10, "GameFontNormalSmall")
  row.chip2 = MakeFontString(row, 10, "GameFontNormalSmall")
  row.demoTag = MakeFontString(row, 9, "GameFontNormalSmall")
  row.demoTag:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
  row.guildBits = true
end

local function HideGuildBits(row)
  if rawget(row, "guildBits") ~= true then
    return
  end
  row.levelBadge:Hide()
  row.roleTex:Hide()
  row.roleLetter:Hide()
  row.statusDot:Hide()
  row.locIcon:Hide()
  row.chip1:Hide()
  row.chip2:Hide()
  if row.demoTag then
    row.demoTag:Hide()
  end
end

local function EnsureRowMore(row)
  local existing = rawget(row, "moreBtn")
  if existing then
    return existing
  end
  local b = MakeIconBtn(row, nil, 22, "...")
  b:Hide()
  row.moreBtn = b
  return b
end

local function CompactActions(row, rec, includeAsk)
  if rec and (rec.demo or (PC.IsDemoPeer and rec.name and PC:IsDemoPeer(rec.name))) then
    if row.invite then
      row.invite:Hide()
    end
    if row.whisper then
      row.whisper:Hide()
    end
    if row.ask then
      row.ask:Hide()
    end
    local more = rawget(row, "moreBtn")
    if more then
      more:Hide()
    end
    return {}
  end
  local buttons = {}
  if row.invite then
    buttons[#buttons + 1] = { btn = row.invite, tips = { { "Invite " .. (rec.name or ""), GOLD.r, GOLD.g, GOLD.b }, "Sends a group invite. This only happens when you tap the button." }, icon = { "Interface\\FriendsFrame\\UI-Toast-FriendRequestIcon", "Interface\\Buttons\\UI-PlusButton-Up" }, fallback = "+" }
    row.invite.peerName = rec.name
  end
  if row.whisper then
    buttons[#buttons + 1] = { btn = row.whisper, tips = { { "Whisper " .. (rec.name or ""), GOLD.r, GOLD.g, GOLD.b }, "Opens a tell to this guildmate." }, icon = { "Interface\\ChatFrame\\UI-ChatWhisperIcon", "Interface\\Buttons\\UI-GuildButton-MOTD-Up" }, fallback = "W" }
    row.whisper.peerName = rec.name
    row.whisper.whisperText = PC.PrefillWhisper and PC:PrefillWhisper(rec) or nil
  end
  if includeAsk and row.ask then
    buttons[#buttons + 1] = { btn = row.ask, tips = { { "Ask to join " .. (rec.name or ""), GOLD.r, GOLD.g, GOLD.b }, "Sends a Codex request. They get Accept (invites you, click-only) or Decline." }, icon = { "Interface\\Buttons\\UI-AttributeButton-Encourage-Up", "Interface\\LFGFrame\\LFG-Eye" }, fallback = "J" }
    row.ask.peerName = rec.name
    row.ask.askWhy = rec.lfg or rec.nextDungeon or rec.note or "group up"
  end
  local more = EnsureRowMore(row)
  more:Hide()
  local width = ContentWidth()
  local collapse = width < 300
  local shown = {}
  if collapse then
    for i = 1, #buttons do
      buttons[i].btn:Hide()
    end
    more:SetSize(22, 22)
    more:Show()
    more:SetScript("OnClick", function(self)
      local items = {}
      for i = 1, #buttons do
        local info = buttons[i]
        local label = (info.fallback == "+" and "Invite") or (info.fallback == "W" and "Whisper") or "Ask to join"
        local btn = info.btn
        items[#items + 1] = {
          label = label,
          onClick = function()
            if label == "Invite" and btn.peerName and PC.InvitePeer then
              PC:InvitePeer(btn.peerName)
            elseif label == "Whisper" and btn.peerName and PC.WhisperPeer then
              PC:WhisperPeer(btn.peerName, btn.whisperText)
            elseif btn.peerName and PC.SendJoinRequest then
              PC:SendJoinRequest(btn.peerName, btn.askWhy)
            end
          end,
        }
      end
      ShowMenu(self, items)
    end)
    more:SetScript("OnEnter", function(self)
      ShowRowTooltip(self, { { "Actions", GOLD.r, GOLD.g, GOLD.b }, "Invite, Whisper, and Join. Opens a small menu." })
    end)
    return { { frame = more, width = 22 } }
  end
  local trail = {}
  for i = #buttons, 1, -1 do
    local info = buttons[i]
    local btn = info.btn
    btn:SetSize(22, 22)
    ApplyButtonIcon(btn, info.icon, info.fallback)
    btn:Show()
    btn:SetScript("OnEnter", function(self)
      ShowRowTooltip(self, info.tips)
    end)
    trail[#trail + 1] = { frame = btn, width = 22 }
  end
  return trail
end

local function LayoutPersonRow(n, rec, y, last, withAsk)
  local row = AcquireRow(n)
  ResetRow(row)
  EnsureGuildBits(row)
  row.useHighlight = true
  if last then
    row.sep:Hide()
  end
  local r, g, b = 0.95, 0.95, 0.97
  if PC.ClassColor then
    r, g, b = PC:ClassColor(rec.classFile)
  end
  row.icon:Show()
  if not ApplyClassIcon(row.icon, rec.classFile) then
    row.icon:SetTexture(ALCHEMY_ICON)
    row.icon:Show()
  end
  -- Class icon in a circle (other players have no unit token for a portrait).
  row.icon:ClearAllPoints()
  row.icon:SetSize(28, 28)
  row.icon:SetPoint("LEFT", 10, 0)
  ApplyCircleMask(row.icon, row)

  local actions = CompactActions(row, rec, withAsk) or {}
  local left = 46
  row:SetWidth(ContentWidth())

  local sc = STATUS_COLOR[rec.status or "questing"] or EMERALD
  Paint(row.statusDot, sc, 1)
  row.statusDot:SetSize(8, 8)
  row.statusDot:Show()
  ApplyRoleIcon(row.roleTex, row.roleLetter, rec.role or "dps")
  row.roleLetter:ClearAllPoints()
  row.roleLetter:SetPoint("CENTER", row.roleTex, "CENTER", 0, 0)
  local lv = rec.level and tostring(rec.level) or ""
  row.levelBadge:SetText(lv)
  local lw = 16
  if row.levelBadge.GetStringWidth then
    lw = math.max(14, (row.levelBadge:GetStringWidth() or 14) + 2)
  end
  if row.levelBadge.SetWidth then
    row.levelBadge:SetWidth(lw)
  end
  row.levelBadge:Show()

  local extras = {}
  for i = 1, #actions do
    extras[#extras + 1] = actions[i]
  end
  extras[#extras + 1] = { frame = row.statusDot, width = 8 }
  extras[#extras + 1] = { frame = row.roleTex, width = 18 }
  extras[#extras + 1] = { frame = row.levelBadge, width = lw }

  local trailLeft = Row.LayoutRowTrail(row, {
    demo = rec.demo and true or false,
    tag = rec.demo and "Demo" or nil,
    tagColor = GOLD,
    trail = extras,
  })

  row.title:SetTextColor(r, g, b)
  row._textLeft = left
  row._titleText = rec.name or "?"
  row._trailOpts = {
    demo = rec.demo and true or false,
    tag = rec.demo and "Demo" or nil,
    tagColor = GOLD,
    trail = extras,
  }
  row.title:ClearAllPoints()
  row.title:SetPoint("TOPLEFT", row, "TOPLEFT", left, -6)
  if trailLeft then
    row.title:SetPoint("RIGHT", trailLeft, "LEFT", -4, 0)
  else
    row.title:SetPoint("RIGHT", row, "RIGHT", -10, 0)
  end
  local nameMax = Row.TrailTextWidth(row, left)
  if PC.FitFontString then
    PC:FitFontString(row.title, rec.name or "?", nameMax, false)
  else
    row.title:SetText(rec.name or "?")
  end
  if row.title.SetWidth then
    row.title:SetWidth(nameMax)
  end
  if row.demoTag then
    row.demoTag:Hide()
  end

  local myZone = "-"
  if PC.CurrentZoneNames then
    local names = PC:CurrentZoneNames()
    myZone = names and names[1] or "-"
  end
  local same = PC.ZonesAreRelated and PC:ZonesAreRelated(myZone, rec.zone) == "same"
  row.locIcon:ClearAllPoints()
  row.locIcon:SetPoint("TOPLEFT", row, "TOPLEFT", left, -24)
  row.locIcon:SetTexture(ZONE_ICON)
  if same then
    row.locIcon:SetVertexColor(EMERALD.r, EMERALD.g, EMERALD.b, 1)
    row.meta:SetTextColor(EMERALD.r, EMERALD.g, EMERALD.b)
  else
    row.locIcon:SetVertexColor(SUB.r, SUB.g, SUB.b, 1)
    row.meta:SetTextColor(SUB.r, SUB.g, SUB.b)
  end
  if rec.zone and rec.zone ~= "-" then
    row.locIcon:Show()
  else
    row.locIcon:Hide()
  end
  row.meta:ClearAllPoints()
  row.meta:SetPoint("LEFT", row.locIcon, "RIGHT", 3, 0)
  row.meta:SetPoint("TOP", row.locIcon, "TOP", 0, 2)
  -- Do not stretch meta to the trail; chips sit after the zone text.
  local lineW = Row.TrailTextWidth(row, left)
  local zoneW = math.max(40, math.floor(lineW * 0.42))
  local zoneText = (rec.zone and rec.zone ~= "-") and rec.zone or ""
  if PC.FitFontString then
    PC:FitFontString(row.meta, zoneText, zoneW, false)
  else
    row.meta:SetText(zoneText)
  end

  local chips = PC.MatchChips and PC:MatchChips(rec) or {}
  row.chip1:Hide()
  row.chip2:Hide()
  local remain = math.max(0, lineW - zoneW - 10)
  if chips[1] and remain >= 36 then
    local chipW = math.min(90, remain)
    row.chip1:ClearAllPoints()
    row.chip1:SetPoint("LEFT", row.meta, "RIGHT", 8, 0)
    row.chip1:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
    if PC.FitFontString then
      PC:FitFontString(row.chip1, chips[1], chipW, false)
    else
      row.chip1:SetText(chips[1])
    end
    if row.chip1.SetWidth then
      row.chip1:SetWidth(chipW)
    end
    row.chip1:Show()
    remain = remain - chipW - 6
  end
  if chips[2] and remain >= 36 and ContentWidth() >= 360 then
    local chipW = math.min(90, remain)
    row.chip2:ClearAllPoints()
    row.chip2:SetPoint("LEFT", row.chip1, "RIGHT", 6, 0)
    row.chip2:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
    if PC.FitFontString then
      PC:FitFontString(row.chip2, chips[2], chipW, false)
    else
      row.chip2:SetText(chips[2])
    end
    if row.chip2.SetWidth then
      row.chip2:SetWidth(chipW)
    end
    row.chip2:Show()
  end

  local why = rec.matchWhy or ""
  local tipZone = (rec.zone and rec.zone ~= "-") and ("In " .. rec.zone) or nil
  row.tip = {
    { rec.name or "Guildmate", GOLD.r, GOLD.g, GOLD.b },
    why,
    tipZone or "Invite, Whisper, and Join are click-only.",
  }
  -- 1.20.0: guildmate cards open their details in the right pane.
  if ui.split and DETAIL then
    local key = "person:" .. tostring(rec.name)
    local entry = { key = key, explicit = true, row = row, build = function() return DETAIL.Person(rec) end }
    PANE.rows[#PANE.rows + 1] = entry
    if PANE.sel[ui.tab] == key then
      PANE.cur = entry
      row._selected = true
      if row.rim and PC.ShowRoundFill then PC:ShowRoundFill(row.rim, true) end
    end
    row:SetScript("OnMouseUp", function(self, button)
      if button and button ~= "LeftButton" then
        return
      end
      PANE.sel[ui.tab] = key
      PC:Refresh()
    end)
  end
  return PlaceRow(row, y, 40)
end

local function BindStrip()
  local s = EnsureGuildStrip()
  local status = PC.GetSocialStatus and PC:GetSocialStatus() or "questing"
  local role = PC.GetSocialRole and PC:GetSocialRole() or "healer"
  local segment = PC.GetGuildSegment and PC:GetGuildSegment() or "group"
  local sharing = PC.IsShareEnabled and PC:IsShareEnabled()

  local short = PC.StatusShortLabel and PC:StatusShortLabel(status) or status
  s.status.label:ClearAllPoints()
  s.status.label:SetPoint("LEFT", 18, 0)
  s.status.label:SetPoint("RIGHT", -4, 0)
  if PC.FitFontString then
    PC:FitFontString(s.status.label, short, 96, false)
  else
    s.status.label:SetText(short)
  end
  local sc = STATUS_COLOR[status] or EMERALD
  Paint(s.status.dot, sc, 1)
  s.status:SetScript("OnClick", function(self)
    local items = {}
    local order = { "questing", "dungeon", "help", "open", "busy" }
    for i = 1, #order do
      local st = order[i]
      items[#items + 1] = {
        label = PC.StatusShortLabel and PC:StatusShortLabel(st) or st,
        checked = st == status,
        onClick = function()
          if PC.SetSocialStatus then
            PC:SetSocialStatus(st)
          end
        end,
      }
    end
    ShowMenu(self, items)
  end)
  s.status:SetScript("OnEnter", function(self)
    ShowRowTooltip(self, { { "Your status", GOLD.r, GOLD.g, GOLD.b }, "Click to choose Questing, Looking for dungeon, Need help, Open to help, or Busy." })
  end)

  ApplyRoleIcon(s.role.icon, s.role.label, role)
  s.role:SetScript("OnClick", function()
    local nextRole = (role == "tank" and "healer") or (role == "healer" and "dps") or "tank"
    if PC.SetSocialRole then
      PC:SetSocialRole(nextRole)
    end
  end)
  s.role:SetScript("OnEnter", function(self)
    ShowRowTooltip(self, { { "Role: " .. (PC:RoleLabel(role)), GOLD.r, GOLD.g, GOLD.b }, "Click to cycle Tank, Healer, and DPS." })
  end)

  local function bindSeg(btn, id, title, tip)
    StyleSeg(btn, segment == id)
    btn:SetScript("OnClick", function()
      if PC.SetGuildSegment then
        PC:SetGuildSegment(id)
      end
    end)
    btn:SetScript("OnEnter", function(self)
      ShowRowTooltip(self, { { title, GOLD.r, GOLD.g, GOLD.b }, tip })
    end)
  end
  bindSeg(s.segGroup, "group", "Group up", "People you can group with, plus dungeon groups.")
  bindSeg(s.segEveryone, "everyone", "Everyone", "Every guildmate using the Codex.")
  bindSeg(s.segRequests, "requests", "Requests", "Incoming and outgoing group requests.")
  local req = PC.CountJoinRequests and PC:CountJoinRequests() or 0
  if req > 0 then
    s.badge:SetText(tostring(req))
    s.badge:Show()
  else
    s.badge:Hide()
  end

  s.pencil:SetScript("OnClick", function(self)
    local ed = EnsureNoteEditor()
    ed:ClearAllPoints()
    ed:SetPoint("TOPLEFT", self, "BOTTOMLEFT", -80, -4)
    if ed.box and ed.box.SetText then
      ed.box:SetText((PC.GetSocialNote and PC:GetSocialNote()) or "")
    end
    ed:Show()
    if ed.box and ed.box.SetFocus then
      pcall(ed.box.SetFocus, ed.box)
    end
  end)
  s.pencil:SetScript("OnEnter", function(self)
    local note = PC.GetSocialNote and PC:GetSocialNote() or ""
    ShowRowTooltip(self, { { "Edit your note", GOLD.r, GOLD.g, GOLD.b }, note ~= "" and note or "A short note other Alchemists can see (40 characters)." })
  end)

  if sharing then
    Paint(s.share.bg, { r = 0.12, g = 0.22, b = 0.16 }, 1)
    s.share.label:SetTextColor(EMERALD.r, EMERALD.g, EMERALD.b)
  else
    Paint(s.share.bg, { r = 0.16, g = 0.16, b = 0.18 }, 1)
    s.share.label:SetTextColor(SUB.r, SUB.g, SUB.b)
  end
  s.share:SetScript("OnClick", function()
    if PC.SetShareEnabled then
      PC:SetShareEnabled(not sharing)
    end
  end)
  s.share:SetScript("OnEnter", function(self)
    ShowRowTooltip(self, { { "Guild sharing", GOLD.r, GOLD.g, GOLD.b }, sharing and "On. Status is sent only to your guild." or "Off. Nothing is sent. Tap to turn sharing on." })
  end)
end

local function HidePooled(list)
  if type(list) ~= "table" then
    return
  end
  for i = 1, #list do
    if list[i] and list[i].Hide then
      list[i]:Hide()
    end
  end
end

local function EnsureMyCard()
  if ui.guildMyCard then
    return ui.guildMyCard
  end
  local c = CreateFrame("Frame", "PhilosophersCodexGuildMyCard", ui.content)
  c:SetHeight(80)
  c.bg = c:CreateTexture(nil, "BACKGROUND")
  c.bg:SetAllPoints()
  Paint(c.bg, CARD, 1)
  c.portrait = c:CreateTexture(nil, "ARTWORK")
  c.portrait:SetSize(48, 48)
  c.portrait:SetPoint("LEFT", 10, 2)
  ApplyCircleMask(c.portrait, c)
  c.name = MakeFontString(c, 13, "GameFontHighlight")
  c.name:SetPoint("TOPLEFT", c.portrait, "TOPRIGHT", 10, 4)
  c.name:SetJustifyH("LEFT")
  c.sub = MakeFontString(c, 11, "GameFontNormalSmall")
  c.sub:SetPoint("TOPLEFT", c.name, "BOTTOMLEFT", 0, -2)
  c.sub:SetTextColor(SUB.r, SUB.g, SUB.b)
  c.sub:SetJustifyH("LEFT")
  c.status = MakeIconBtn(c, "PhilosophersCodexStatusPill", 118, "Questing")
  c.status:SetHeight(22)
  c.status.label:ClearAllPoints()
  c.status.label:SetPoint("LEFT", 18, 0)
  c.status.label:SetPoint("RIGHT", -4, 0)
  c.status.label:SetJustifyH("LEFT")
  c.status.dot = c.status:CreateTexture(nil, "OVERLAY")
  c.status.dot:SetSize(8, 8)
  c.status.dot:SetPoint("LEFT", 6, 0)
  Paint(c.status.dot, EMERALD, 1)
  c.roles = {}
  local roleIds = { "tank", "healer", "dps" }
  local roleNames = { tank = "PhilosophersCodexRoleTank", healer = "PhilosophersCodexRoleHealer", dps = "PhilosophersCodexRoleDps" }
  for i = 1, #roleIds do
    local id = roleIds[i]
    local b = MakeIconBtn(c, roleNames[id], 24, ROLE_LETTER[id] or "D")
    b:SetSize(24, 24)
    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetSize(16, 16)
    b.icon:SetPoint("CENTER", 0, 0)
    b.roleId = id
    c.roles[id] = b
  end
  c.pencil = MakeIconBtn(c, "PhilosophersCodexNotePencil", 22, "N")
  ApplyButtonIcon(c.pencil, { "Interface\\MINIMAP\\TRACKING\\None", "Interface\\Buttons\\UI-GuildButton-PublicNote-Up" }, "N")
  c.inbox = MakeIconBtn(c, "PhilosophersCodexGuildInbox", 22, "R")
  ApplyButtonIcon(c.inbox, { "Interface\\Icons\\INV_Letter_15", "Interface\\Minimap\\Tracking\\Mailbox" }, "R")
  c.badge = MakeFontString(c.inbox, 9, "GameFontNormalSmall")
  c.badge:SetPoint("TOPRIGHT", 4, 4)
  c.badge:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
  c.badge:Hide()
  ui.guildMyCard = c
  return c
end

local function EnsureGuildBar()
  if ui.guildBar then
    return ui.guildBar
  end
  local b = CreateFrame("Frame", "PhilosophersCodexGuildBar", ui.content)
  b:SetHeight(26)
  b.match = MakeIconBtn(b, "PhilosophersCodexGuildMatchSeg", 88, "Matches")
  b.all = MakeIconBtn(b, "PhilosophersCodexGuildAllSeg", 88, "All guild")
  b.match:SetPoint("LEFT", 0, 0)
  b.match:SetWidth(88)
  b.all:SetPoint("LEFT", b.match, "RIGHT", 6, 0)
  b.all:SetWidth(88)
  b.demo = MakeIconBtn(b, "PhilosophersCodexGuildDemoChip", 64, "Demo")
  b.demo:SetPoint("LEFT", b.all, "RIGHT", 6, 0)
  b.demo:SetWidth(64)
  if b.match.label then
    b.match.label:ClearAllPoints()
    b.match.label:SetPoint("CENTER")
  end
  if b.all.label then
    b.all.label:ClearAllPoints()
    b.all.label:SetPoint("CENTER")
  end
  if b.demo.label then
    b.demo.label:ClearAllPoints()
    b.demo.label:SetPoint("CENTER")
  end
  ui.guildBar = b
  return b
end

local function EnsureHint()
  if ui.guildHint then
    return ui.guildHint
  end
  local h = CreateFrame("Frame", "PhilosophersCodexGuildHint", ui.content)
  h:SetHeight(18)
  h.label = MakeFontString(h, 11, "GameFontNormalSmall")
  h.label:SetPoint("LEFT", 4, 0)
  h.label:SetPoint("RIGHT", -4, 0)
  h.label:SetJustifyH("LEFT")
  h.label:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
  ui.guildHint = h
  return h
end

local function AcquireChip(i)
  ui.guildChips = ui.guildChips or {}
  local b = ui.guildChips[i]
  if b then
    return b
  end
  b = CreateFrame("Button", nil, ui.content)
  b:SetHeight(22)
  b.bg = b:CreateTexture(nil, "BACKGROUND")
  b.bg:SetAllPoints()
  Paint(b.bg, { r = 0.16, g = 0.16, b = 0.18 }, 1)
  if PC._RoundifyButton then PC._RoundifyButton(b) end
  b.icon = b:CreateTexture(nil, "ARTWORK")
  b.icon:SetSize(16, 16)
  b.icon:SetPoint("LEFT", 4, 0)
  b.label = MakeFontString(b, 11, "GameFontNormalSmall")
  b.label:SetPoint("LEFT", 24, 0)
  b.label:SetPoint("RIGHT", -8, 0)
  b.label:SetJustifyH("CENTER")
  ui.guildChips[i] = b
  return b
end

local function BindMyCard()
  local c = EnsureMyCard()
  local name = (UnitName and UnitName("player")) or "You"
  local classFile = PC.GetClassFile and PC:GetClassFile() or nil
  local level = PC.PlayerLevel and PC:PlayerLevel() or 1
  local className = classFile and (classFile:sub(1, 1) .. string.lower(classFile:sub(2))) or ""
  if UnitClass then
    local ok, loc = pcall(UnitClass, "player")
    if ok and type(loc) == "string" then
      className = loc
    end
  end
  local zone = "-"
  if PC.GetCurrentZoneName then
    zone = PC:GetCurrentZoneName() or "-"
  elseif PC.CurrentZoneNames then
    local names = PC:CurrentZoneNames()
    zone = names and names[1] or "-"
  end
  local r, g, b = 0.95, 0.95, 0.97
  if PC.ClassColor then
    r, g, b = PC:ClassColor(classFile)
  end
  local usedPortrait = false
  if SetPortraitTexture then
    pcall(SetPortraitTexture, c.portrait, "player")
    usedPortrait = TextureOk(c.portrait)
  end
  if not usedPortrait then
    if not ApplyClassIcon(c.portrait, classFile) then
      c.portrait:SetTexture(ALCHEMY_ICON)
    end
    c.portrait:Show()
  end
  ApplyCircleMask(c.portrait, c)
  c.name:SetTextColor(r, g, b)
  if PC.FitFontString then
    PC:FitFontString(c.name, name, math.max(80, ContentWidth() - 200), false)
  else
    c.name:SetText(name)
  end
  local sub = "Lv " .. tostring(level)
  if className and className ~= "" then
    sub = sub .. "  " .. className
  end
  if zone and zone ~= "-" then
    sub = sub .. "  ·  " .. zone
  end
  if PC.FitFontString then
    PC:FitFontString(c.sub, sub, math.max(80, ContentWidth() - 200), false)
  else
    c.sub:SetText(sub)
  end

  -- 1.16.0: status is a pill row under the card, not a dropdown on it.
  if c.status then
    c.status:Hide()
  end

  local role = PC.GetSocialRole and PC:GetSocialRole() or "dps"
  local roleIds = { "tank", "healer", "dps" }
  local prev
  for i = 1, #roleIds do
    local id = roleIds[i]
    local btn = c.roles[id]
    ApplyRoleIcon(btn.icon, btn.label, id)
    local allowed = (not PC.ClassCanUseRole) or PC:ClassCanUseRole(id)
    if allowed then
      btn:SetAlpha(id == role and 1 or 0.42)
      if btn.Enable then
        btn:Enable()
      end
      if btn.EnableMouse then
        btn:EnableMouse(true)
      end
    else
      -- Keep the button enabled so the "Mages can't tank" tooltip still shows.
      -- OnClick is ignored below when not allowed.
      btn:SetAlpha(0.28)
      if btn.Enable then
        btn:Enable()
      end
      if btn.EnableMouse then
        btn:EnableMouse(true)
      end
    end
    if id == role then
      Paint(btn.bg, { r = 0.12, g = 0.22, b = 0.16 }, 1)
    else
      Paint(btn.bg, { r = 0.16, g = 0.16, b = 0.18 }, 1)
    end
    btn:ClearAllPoints()
    if i == 1 then
      btn:SetPoint("BOTTOMLEFT", c.portrait, "BOTTOMRIGHT", 10, -2)
    else
      btn:SetPoint("LEFT", prev, "RIGHT", 4, 0)
    end
    prev = btn
    btn:SetScript("OnClick", function()
      if allowed and PC.SetSocialRole then
        PC:SetSocialRole(id)
      end
    end)
    btn:SetScript("OnEnter", function(self)
      local title = (PC.RoleLabel and PC:RoleLabel(id)) or id
      local tip
      if allowed then
        tip = "Tap to select this role. It is saved and shared with your guild."
      else
        local who = className or (classFile and (classFile:sub(1, 1) .. string.lower(classFile:sub(2)))) or "This class"
        if who ~= "" and who:sub(-1) ~= "s" then
          who = who .. "s"
        end
        local verb = (id == "tank" and "tank") or (id == "healer" and "heal") or "do this"
        tip = who .. " can't " .. verb
      end
      ShowRowTooltip(self, { { title, GOLD.r, GOLD.g, GOLD.b }, tip })
    end)
  end
  c.inbox:ClearAllPoints()
  c.inbox:SetPoint("TOPRIGHT", -8, -8)
  local req = PC.CountJoinRequests and PC:CountJoinRequests() or 0
  if req > 0 then
    c.badge:SetText(tostring(req))
    c.badge:Show()
  else
    c.badge:Hide()
  end
  local showingReq = ui.guildShowRequests and true or false
  if showingReq then
    Paint(c.inbox.bg, { r = 0.12, g = 0.22, b = 0.16 }, 1)
  else
    Paint(c.inbox.bg, { r = 0.16, g = 0.16, b = 0.18 }, 1)
  end
  c.inbox:SetScript("OnClick", function()
    ui.guildShowRequests = not ui.guildShowRequests
    if PC.Refresh then
      PC:Refresh()
    end
  end)
  c.inbox:SetScript("OnEnter", function(self)
    ShowRowTooltip(self, { { "Requests", GOLD.r, GOLD.g, GOLD.b }, req > 0 and (tostring(req) .. " open group requests.") or "Incoming and outgoing group requests." })
  end)
  c.pencil:ClearAllPoints()
  c.pencil:SetPoint("RIGHT", c.inbox, "LEFT", -4, 0)
  c.pencil:SetScript("OnClick", function(self)
    local ed = EnsureNoteEditor()
    ed:ClearAllPoints()
    ed:SetPoint("TOPLEFT", self, "BOTTOMLEFT", -80, -4)
    if ed.box and ed.box.SetText then
      ed.box:SetText((PC.GetSocialNote and PC:GetSocialNote()) or "")
    end
    ed:Show()
    if ed.box and ed.box.SetFocus then
      pcall(ed.box.SetFocus, ed.box)
    end
  end)
  c.pencil:SetScript("OnEnter", function(self)
    local note = PC.GetSocialNote and PC:GetSocialNote() or ""
    ShowRowTooltip(self, { { "Edit your note", GOLD.r, GOLD.g, GOLD.b }, note ~= "" and note or "A short note other Alchemists can see (40 characters)." })
  end)
end

local GUILD_CARD_H = 56
local GUILD_POOL = 16

local function PaintGuildVirtual()
  local virt = ui.guildVirt
  if not virt or not virt.items then
    return
  end
  local items = virt.items
  local startY = virt.startY or 0
  local scrollY = (ui.scroll and ui.scroll.GetVerticalScroll and ui.scroll:GetVerticalScroll()) or 0
  local viewH = (ui.scroll and ui.scroll.GetHeight and ui.scroll:GetHeight()) or 400
  local first = math.floor((scrollY - startY) / GUILD_CARD_H) - 1
  if first < 1 then
    first = 1
  end
  local last = math.ceil((scrollY + viewH - startY) / GUILD_CARD_H) + 1
  if last > #items then
    last = #items
  end
  if last < first then
    last = first - 1
  end
  local used = 0
  local startIndex = virt.startIndex or 1
  for i = first, last do
    used = used + 1
    local y = startY + (i - 1) * GUILD_CARD_H
    local card = items[i]
    local rec = card.rec or card
    rec.demo = rec.demo or card.demo
    rec.role = rec.role or card.role
    rec.matchWhy = (#(card.shared or {}) > 0) and "Shared dungeon" or rec.matchWhy
    LayoutPersonRow(startIndex + used - 1, rec, y, i == #items, not rec.demo)
  end
  -- Hide leftover pool rows that were acquired but are not in this window.
  for i = used + 1, GUILD_POOL do
    local row = ui.rows[startIndex + i - 1]
    if row then
      row:Hide()
    end
  end
  virt.created = math.max(virt.created or 0, used)
  virt.visible = used
  virt.total = #items
  virt.first = first
end

function PC:DebugGuildVirtual()
  local virt = ui and ui.guildVirt or nil
  if not virt then
    return { created = 0, visible = 0, total = 0 }
  end
  return { created = virt.created or 0, visible = virt.visible or 0, total = virt.total or 0, first = virt.first }
end

local LayoutDungeonChips
local STATUS_PILL_DEFS = {
  { id = "dungeon", label = "Dungeon", name = "PhilosophersCodexStatusDungeon", tip = "Looking for dungeon. Pick the dungeons you want to run." },
  { id = "questing", label = "Questing", name = "PhilosophersCodexStatusQuesting", tip = "Questing buddy. Guildmates questing in your level range show up below." },
  { id = "help", label = "Need help", name = "PhilosophersCodexStatusHelp", tip = "Need help. Higher-level guildmates who can come help will show up." },
  { id = "busy", label = "Not looking", name = "PhilosophersCodexStatusBusy", tip = "Not looking. You stay hidden from group lists." },
}

local function EnsureStatusPills()
  if ui.guildStatusRow then
    return ui.guildStatusRow
  end
  local row = CreateFrame("Frame", "PhilosophersCodexGuildStatusRow", ui.content)
  row:SetHeight(26)
  row.label = MakeFontString(row, 11, "GameFontNormalSmall")
  row.label:SetText("Status")
  row.label:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
  if row.label.SetJustifyH then
    row.label:SetJustifyH("LEFT")
  end
  row.pills = {}
  for i = 1, #STATUS_PILL_DEFS do
    local def = STATUS_PILL_DEFS[i]
    local b = MakeIconBtn(row, def.name, 90, def.label)
    b:SetHeight(24)
    b.statusId = def.id
    b.tip = def.tip
    if b.label then
      b.label:ClearAllPoints()
      b.label:SetPoint("CENTER")
      b.label:SetJustifyH("CENTER")
    end
    row.pills[def.id] = b
    row.pills[i] = b
  end
  ui.guildStatusRow = row
  return row
end

local function BindStatusPills()
  local row = EnsureStatusPills()
  local status = PC.GetSocialStatus and PC:GetSocialStatus() or "busy"
  local width = ContentWidth()
  local gap = 6
  local n = #STATUS_PILL_DEFS
  local labelW = 48
  if row.label then
    row.label:ClearAllPoints()
    row.label:SetPoint("LEFT", row, "LEFT", 0, 0)
    row.label:SetWidth(labelW)
    row.label:SetText("Status")
    row.label:Show()
    if PC.FitFontString then
      -- Don't truncate the Status label; reserve a fixed width.
      row.label:SetText("Status")
    end
  end
  local rest = math.max(80, width - labelW - 8)
  local pw = math.floor((rest - gap * (n - 1)) / n)
  if pw < 58 then
    -- Stack the label above the pills when the row is too tight.
    if row.label then
      row:SetHeight(44)
      row.label:ClearAllPoints()
      row.label:SetPoint("TOPLEFT", row, "TOPLEFT", 0, 0)
      row.label:SetWidth(math.max(48, width))
    end
    pw = math.floor((width - gap * (n - 1)) / n)
    if pw < 58 then
      pw = 58
    end
    for i = 1, n do
      local def = STATUS_PILL_DEFS[i]
      local b = row.pills[def.id]
      b:ClearAllPoints()
      b:SetPoint("BOTTOMLEFT", row, "BOTTOMLEFT", (i - 1) * (pw + gap), 0)
      b:SetWidth(pw)
      b:Show()
      local on = (def.id == status)
      StyleSeg(b, on)
      if PC.FitFontString and b.label then
        PC:FitFontString(b.label, def.label, pw - 8, false)
      elseif b.label then
        b.label:SetText(def.label)
      end
      b:SetScript("OnClick", function()
        if PC.SetSocialStatus then
          PC:SetSocialStatus(def.id)
        end
      end)
      b:SetScript("OnEnter", function(self)
        ShowRowTooltip(self, { { (PC.StatusLabel and PC:StatusLabel(def.id)) or def.label, GOLD.r, GOLD.g, GOLD.b }, def.tip })
      end)
    end
    return
  end
  if row.label then
    row:SetHeight(26)
  end
  for i = 1, n do
    local def = STATUS_PILL_DEFS[i]
    local b = row.pills[def.id]
    b:ClearAllPoints()
    b:SetPoint("LEFT", row, "LEFT", labelW + 8 + (i - 1) * (pw + gap), 0)
    b:SetWidth(pw)
    b:Show()
    local on = (def.id == status)
    StyleSeg(b, on)
    if PC.FitFontString and b.label then
      PC:FitFontString(b.label, def.label, pw - 8, false)
    elseif b.label then
      b.label:SetText(def.label)
    end
    b:SetScript("OnClick", function()
      if PC.SetSocialStatus then
        PC:SetSocialStatus(def.id)
      end
    end)
    b:SetScript("OnEnter", function(self)
      ShowRowTooltip(self, { { (PC.StatusLabel and PC:StatusLabel(def.id)) or def.label, GOLD.r, GOLD.g, GOLD.b }, def.tip })
    end)
  end
end

local function EnsureGuildContext()
  if ui.guildContext then
    return ui.guildContext
  end
  local c = CreateFrame("Frame", "PhilosophersCodexGuildContext", ui.content)
  c:SetHeight(22)
  c.label = MakeFontString(c, 11, "GameFontNormalSmall")
  c.label:SetPoint("TOPLEFT", 4, 0)
  c.label:SetPoint("TOPRIGHT", -4, 0)
  c.label:SetJustifyH("LEFT")
  c.label:SetTextColor(SUB.r, SUB.g, SUB.b)
  c.note = MakeFontString(c, 11, "GameFontHighlight")
  c.note:SetPoint("TOPLEFT", c.label, "BOTTOMLEFT", 0, -4)
  c.note:SetPoint("RIGHT", -4, 0)
  c.note:SetJustifyH("LEFT")
  c.note:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
  c.noteBtn = MakeIconBtn(c, "PhilosophersCodexGuildHelpNote", 70, "Add note")
  c.canHelp = MakeIconBtn(c, "PhilosophersCodexGuildCanHelp", 90, "Can help")
  c.canHelp:SetHeight(22)
  if c.canHelp.label then
    c.canHelp.label:ClearAllPoints()
    c.canHelp.label:SetPoint("CENTER")
  end
  ui.guildContext = c
  return c
end

local function EnsureHiddenMsg()
  if ui.guildHidden then
    return ui.guildHidden
  end
  local h = CreateFrame("Frame", "PhilosophersCodexGuildHidden", ui.content)
  h:SetHeight(36)
  h.label = MakeFontString(h, 12, "GameFontHighlight")
  h.label:SetPoint("TOPLEFT", 4, -4)
  h.label:SetPoint("BOTTOMRIGHT", -4, 4)
  h.label:SetJustifyH("LEFT")
  h.label:SetJustifyV("TOP")
  h.label:SetTextColor(SUB.r, SUB.g, SUB.b)
  if h.label.SetWordWrap then
    h.label:SetWordWrap(true)
  end
  h.label:SetText("You're hidden from group lists.")
  ui.guildHidden = h
  return h
end

local function AcquireZoneChip(i)
  ui.guildZoneChips = ui.guildZoneChips or {}
  local b = ui.guildZoneChips[i]
  if b then
    return b
  end
  b = CreateFrame("Button", nil, ui.content)
  b:SetHeight(22)
  b.bg = b:CreateTexture(nil, "BACKGROUND")
  b.bg:SetAllPoints()
  Paint(b.bg, { r = 0.16, g = 0.16, b = 0.18 }, 1)
  if PC._RoundifyButton then PC._RoundifyButton(b) end
  b.label = MakeFontString(b, 11, "GameFontNormalSmall")
  b.label:SetPoint("LEFT", 8, 0)
  b.label:SetPoint("RIGHT", -8, 0)
  b.label:SetJustifyH("CENTER")
  ui.guildZoneChips[i] = b
  return b
end

local function LayoutZoneChips(y, selected)
  local zones = PC.GetQuestingZoneOptions and PC:GetQuestingZoneOptions() or {}
  local x = 0
  local maxW = ContentWidth()
  local gap = 6
  local rowH = 26
  local used = 0
  if ui.guildZoneChips then
    for i = 1, #ui.guildZoneChips do
      ui.guildZoneChips[i]:Hide()
    end
  end
  for i = 1, #zones do
    local name = zones[i]
    used = used + 1
    local btn = AcquireZoneChip(used)
    local w = 96
    if btn.label then
      btn.label:SetText(name)
      if btn.label.GetStringWidth then
        w = math.min(160, math.max(72, (btn.label:GetStringWidth() or 80) + 20))
      end
    end
    if x + w > maxW and x > 0 then
      x = 0
      y = y + rowH
    end
    btn:ClearAllPoints()
    btn:SetPoint("TOPLEFT", ui.content, "TOPLEFT", x, -y)
    btn:SetWidth(w)
    btn:SetHeight(22)
    btn:Show()
    local on = selected and string.lower(tostring(selected)) == string.lower(name)
    if on then
      Paint(btn.bg, { r = 0.12, g = 0.22, b = 0.16 }, 1)
      btn.label:SetTextColor(EMERALD.r, EMERALD.g, EMERALD.b)
    else
      Paint(btn.bg, { r = 0.16, g = 0.16, b = 0.18 }, 1)
      btn.label:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
    end
    if PC.FitFontString then
      PC:FitFontString(btn.label, name, w - 16, false)
    end
    btn:SetScript("OnClick", function()
      -- Zone chips are a live snapshot of nearby zones. The activity
      -- zone always follows where the player is standing, so a click
      -- does not pin a stale override.
      if PC.SyncLiveActivityZone then
        PC:SyncLiveActivityZone("chip")
      end
    end)
    x = x + w + gap
  end
  if x > 0 then
    y = y + rowH + 4
  end
  return y
end

local function LayoutGuildContext(n, y, status)
  local ctx = EnsureGuildContext()
  local hidden = EnsureHiddenMsg()
  ctx.mode = status
  ctx:ClearAllPoints()
  ctx:SetPoint("TOPLEFT", ui.content, "TOPLEFT", 0, -y)
  ctx:SetWidth(ContentWidth())
  ctx:Show()
  ctx.note:Hide()
  ctx.noteBtn:Hide()
  ctx.canHelp:Hide()
  hidden:Hide()
  if ui.guildZoneChips then
    for i = 1, #ui.guildZoneChips do
      ui.guildZoneChips[i]:Hide()
    end
  end

  if status == "busy" then
    ctx.label:SetText("")
    hidden:ClearAllPoints()
    hidden:SetPoint("TOPLEFT", ui.content, "TOPLEFT", 0, -y)
    hidden:SetWidth(ContentWidth())
    if PC.FitFontString then
      PC:FitFontString(hidden.label, "You're hidden from group lists.", ContentWidth() - 8, true)
    else
      hidden.label:SetText("You're hidden from group lists.")
    end
    hidden:Show()
    ctx:SetHeight(4)
    y = y + 40
    return n, y
  end

  if status == "dungeon" then
    local zone = PC.GetActivityZone and PC:GetActivityZone() or ""
    ctx.label:SetText("Pick the dungeons you want to run.")
    if PC.FitFontString then
      PC:FitFontString(ctx.label, "Pick the dungeons you want to run.", ContentWidth() - 8, false)
    end
    ctx:SetHeight(18)
    y = y + 22
    n, y = LayoutDungeonChips(n, y)
    return n, y
  end

  if status == "questing" then
    local here = (PC.GetLiveZoneName and PC:GetLiveZoneName())
      or (PC.GetCurrentZoneName and PC:GetCurrentZoneName())
      or "this zone"
    local selected = (PC.GetActivityZone and PC:GetActivityZone()) or here
    local text = "Questing in " .. tostring(here) .. "."
    ctx.label:SetText(text)
    if PC.FitFontString then
      PC:FitFontString(ctx.label, text, ContentWidth() - 8, false)
    end
    ctx:SetHeight(18)
    y = y + 22
    y = LayoutZoneChips(y, selected)
    return n, y
  end

  if status == "help" then
    local here = (PC.GetLiveZoneName and PC:GetLiveZoneName())
      or (PC.GetActivityZone and PC:GetActivityZone())
      or (PC.GetCurrentZoneName and PC:GetCurrentZoneName())
      or "this zone"
    local need = PC.GetHelpRequiredLevel and PC:GetHelpRequiredLevel() or (PC.PlayerLevel and PC:PlayerLevel()) or 1
    local text = "Need help in " .. tostring(here) .. " (level " .. tostring(need) .. "+)."
    ctx.label:SetText(text)
    if PC.FitFontString then
      PC:FitFontString(ctx.label, text, ContentWidth() - 8, false)
    end
    local note = (PC.GetSocialNote and PC:GetSocialNote()) or ""
    ctx.note:ClearAllPoints()
    ctx.note:SetPoint("TOPLEFT", ctx.label, "BOTTOMLEFT", 0, -4)
    ctx.note:SetPoint("RIGHT", ctx, "RIGHT", -110, 0)
    if note ~= "" then
      if PC.FitFontString then
        PC:FitFontString(ctx.note, "Note: " .. note, ContentWidth() - 120, false)
      else
        ctx.note:SetText("Note: " .. note)
      end
    else
      ctx.note:SetText("Add a short note, like an elite quest name.")
    end
    ctx.note:Show()
    ctx.noteBtn:ClearAllPoints()
    ctx.noteBtn:SetPoint("TOPRIGHT", ctx, "TOPRIGHT", 0, -20)
    ctx.noteBtn:Show()
    ctx.noteBtn:SetScript("OnClick", function(self)
      local ed = EnsureNoteEditor()
      ed:ClearAllPoints()
      ed:SetPoint("TOPLEFT", self, "BOTTOMLEFT", -80, -4)
      if ed.box and ed.box.SetText then
        ed.box:SetText(note)
      end
      ed:Show()
      if ed.box and ed.box.SetFocus then
        pcall(ed.box.SetFocus, ed.box)
      end
    end)
    local can = PC.GetCanHelp and PC:GetCanHelp()
    ctx.canHelp:ClearAllPoints()
    ctx.canHelp:SetPoint("TOPLEFT", ctx.note, "BOTTOMLEFT", 0, -6)
    StyleSeg(ctx.canHelp, can)
    if ctx.canHelp.label then
      ctx.canHelp.label:SetText("Can help")
    end
    ctx.canHelp:Show()
    ctx.canHelp:SetScript("OnClick", function()
      if PC.SetCanHelp then
        PC:SetCanHelp(not can)
      end
    end)
    ctx.canHelp:SetScript("OnEnter", function(self)
      ShowRowTooltip(self, { { "Can help", GOLD.r, GOLD.g, GOLD.b }, "Stay on other people's Need help lists even if your status is Not looking." })
    end)
    ctx:SetHeight(64)
    y = y + 70
    y = LayoutZoneChips(y, here)
    return n, y
  end

  ctx:SetHeight(4)
  return n, y
end

function LayoutDungeonChips(n, y)

  local dungeons = PC.GetLevelDungeons and PC:GetLevelDungeons() or {}
  n = n + 1
  y = Header(n, "Dungeons", y)
  if #dungeons == 0 then
    n = n + 1
    y = Body(n, "No dungeons in your level range right now.", y)
    HidePooled(ui.guildChips)
    return n, y
  end
  local x = 0
  local maxW = ContentWidth()
  local gap = 6
  local rowH = 26
  local used = 0
  for i = 1, #dungeons do
    local d = dungeons[i]
    used = used + 1
    local btn = AcquireChip(used)
    local label = d.name or d.id
    local w = 112
    if btn.icon then
      if PC.ApplyDungeonIcon then
        PC:ApplyDungeonIcon(btn.icon, d.id, btn)
      elseif PC.GetDungeonIcon then
        btn.icon:SetTexture(PC:GetDungeonIcon(d.id))
      end
      btn.icon:Show()
    end
    if btn.label then
      btn.label:ClearAllPoints()
      btn.label:SetPoint("LEFT", btn, "LEFT", btn.icon and 24 or 8, 0)
      btn.label:SetPoint("RIGHT", -8, 0)
      btn.label:SetText(label)
      if btn.label.GetStringWidth then
        w = math.min(180, math.max(88, (btn.label:GetStringWidth() or 80) + (btn.icon and 36 or 20)))
      elseif PC.FitFontString then
        PC:FitFontString(btn.label, label, 140, false)
        w = 132
      end
    end
    if x + w > maxW and x > 0 then
      x = 0
      y = y + rowH
    end
    btn:ClearAllPoints()
    btn:SetPoint("TOPLEFT", ui.content, "TOPLEFT", x, -y)
    btn:SetWidth(w)
    btn:SetHeight(22)
    btn:Show()
    local selected = PC.IsDungeonSelected and PC:IsDungeonSelected(d.id)
    if selected then
      Paint(btn.bg, { r = 0.12, g = 0.22, b = 0.16 }, 1)
      btn.label:SetTextColor(EMERALD.r, EMERALD.g, EMERALD.b)
    else
      Paint(btn.bg, { r = 0.16, g = 0.16, b = 0.18 }, 1)
      btn.label:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
    end
    if PC.FitFontString then
      PC:FitFontString(btn.label, label, math.max(40, w - (btn.icon and 32 or 16)), false)
    end
    btn:SetScript("OnClick", function()
      if PC.ToggleSelectedDungeon then
        PC:ToggleSelectedDungeon(d.id)
      end
    end)
    x = x + w + gap
  end
  if ui.guildChips then
    for i = used + 1, #ui.guildChips do
      ui.guildChips[i]:Hide()
    end
  end
  if x > 0 then
    y = y + rowH + 4
  end
  return n, y
end

local function LayoutRequests(n, y)
  local incoming, outgoing = {}, {}
  if PC.GetJoinRequests then
    incoming, outgoing = PC:GetJoinRequests()
  end
  n = n + 1
  y = Header(n, "Requests", y)
  local any = false
  if type(incoming) == "table" then
    for name, rec in pairs(incoming) do
      any = true
      n = n + 1
      y = ListRow(n, rec.name or name, rec.why or "wants to group up", "Accept invites them (click-only). Decline sends a no.", y, {
        accept = rec.name or name,
        decline = rec.name or name,
        last = false,
      })
    end
  end
  if type(outgoing) == "table" then
    for name, rec in pairs(outgoing) do
      any = true
      local ans = rec.answer and ("They " .. rec.answer) or "Waiting for a reply"
      n = n + 1
      y = ListRow(n, "You asked " .. (rec.name or name), ans, nil, y, { last = false })
    end
  end
  if not any then
    n = n + 1
    y = Body(n, "No open requests. From a guildmate card, tap Join to ask. They will see Accept (invites you) or Decline.", y)
  end
  return n, y
end

local function LayoutGuild()
  local y = 0
  local n = 0
  HideTodayCard()
  HideMenu()
  ui.guildVirt = nil
  if ui.guildStrip then
    ui.guildStrip:Hide()
  end

  local card = EnsureMyCard()
  card:ClearAllPoints()
  card:SetPoint("TOPLEFT", ui.content, "TOPLEFT", 0, -y)
  card:SetWidth(ContentWidth())
  card:Show()
  BindMyCard()
  y = y + 86

  local status = PC.GetSocialStatus and PC:GetSocialStatus() or "busy"
  local pills = EnsureStatusPills()
  pills:ClearAllPoints()
  pills:SetPoint("TOPLEFT", ui.content, "TOPLEFT", 0, -y)
  pills:SetWidth(ContentWidth())
  pills:Show()
  BindStatusPills()
  y = y + (pills:GetHeight() or 26) + 6

  n, y = LayoutGuildContext(n, y, status)

  local hint = EnsureHint()
  local hintText = PC.GetPartyNeedHint and PC:GetPartyNeedHint() or nil
  if hintText and not ui.guildShowRequests and status == "dungeon" then
    hint:ClearAllPoints()
    hint:SetPoint("TOPLEFT", ui.content, "TOPLEFT", 0, -y)
    hint:SetWidth(ContentWidth())
    if PC.FitFontString then
      PC:FitFontString(hint.label, hintText, ContentWidth() - 8, false)
    else
      hint.label:SetText(hintText)
    end
    hint:Show()
    y = y + 20
  else
    hint:Hide()
  end

  if ui.guildShowRequests then
    if ui.guildBar then
      ui.guildBar:Hide()
    end
    n, y = LayoutRequests(n, y)
    SetContentHeight(y)
    return
  end

  local bar = EnsureGuildBar()
  bar:ClearAllPoints()
  bar:SetPoint("TOPLEFT", ui.content, "TOPLEFT", 0, -y)
  bar:SetWidth(ContentWidth())
  bar:Show()
  -- 1.16.0: Matches / All guild are gone. Only the Demo chip stays.
  if bar.match then
    bar.match:Hide()
  end
  if bar.all then
    bar.all:Hide()
  end
  if bar.demo then
    bar.demo:ClearAllPoints()
    bar.demo:SetPoint("LEFT", 0, 0)
    local demoOn = PC.IsDemoGuildOn and PC:IsDemoGuildOn()
    StyleSeg(bar.demo, demoOn)
    bar.demo:SetScript("OnClick", function()
      if PC.SetDemoGuild then
        PC:SetDemoGuild(not demoOn)
      end
      if PC.Refresh then
        PC:Refresh()
      end
    end)
    bar.demo:SetScript("OnEnter", function(self)
      ShowRowTooltip(self, {
        { "Demo guildmates", GOLD.r, GOLD.g, GOLD.b },
        demoOn and "On. Fake, tagged Demo players fill the list so you can preview the layout. They are never broadcast or invited."
          or "Off. Turn on to preview the Guild tab with fake, tagged Demo players. They are never broadcast or invited.",
      })
    end)
    bar.demo:Show()
  end
  y = y + 30

  if status == "busy" then
    SetContentHeight(y)
    return
  end

  local cards = PC.GetGuildmateCards and PC:GetGuildmateCards() or {}
  n = n + 1
  local title = "Available guildmates"
  y = Header(n, title .. "  " .. tostring(#cards), y)
  if #cards == 0 then
    n = n + 1
    local empty
    if status == "dungeon" then
      empty = "No guildmates are looking for the same dungeon right now. Pick one or more dungeons above. To preview the layout, turn on Demo or type /codex demo on."
    elseif status == "questing" then
      empty = "No questing buddies in your level range yet. To preview the layout, turn on Demo or type /codex demo on."
    else
      empty = "No one is available to help yet. Helpers are guildmates who aren't hidden and are at least your level. To preview the layout, turn on Demo or type /codex demo on."
    end
    y = Body(n, empty, y)
    SetContentHeight(y)
    return
  end

  local startIndex = n + 1
  -- Pre-acquire a fixed pool so a 50+ roster does not create a row per person.
  for i = 1, math.min(GUILD_POOL, #cards) do
    AcquireRow(startIndex + i - 1)
  end
  ui.guildVirt = { startY = y, items = cards, startIndex = startIndex, created = math.min(GUILD_POOL, #cards), visible = 0, total = #cards, first = 1 }
  PaintGuildVirtual()
  SetContentHeight(y + #cards * GUILD_CARD_H)
end

-- ---------------------------------------------------------------------------
-- -- Tabs, search, resize, scale
-- ---------------------------------------------------------------------------

local function ColorTab(btn, selected)
  if not btn then
    return
  end
  local accent = AccentColor()
  if btn.pill and PC.ShowRoundFill then
    pcall(PC.ShowRoundFill, PC, btn.pill, true, selected and PILL_ON or PANE.chip, 1)
  end
  if selected then
    if btn.indicator and not btn.pill then
      btn.indicator:Show()
      if btn.indicator.SetVertexColor then
        btn.indicator:SetVertexColor(accent.r, accent.g, accent.b, 1)
      end
    end
    if btn.iconTex then
      btn.iconTex:SetVertexColor(accent.r, accent.g, accent.b, 1)
    end
    if btn.label then
      if btn.pill then
        btn.label:SetTextColor(EMERALD.r, EMERALD.g, EMERALD.b)
      else
        btn.label:SetTextColor(accent.r, accent.g, accent.b)
      end
    end
  else
    if btn.indicator then
      btn.indicator:Hide()
    end
    if btn.iconTex then
      btn.iconTex:SetVertexColor(MUTED.r, MUTED.g, MUTED.b, 1)
    end
    if btn.label then
      btn.label:SetTextColor(SUB.r, SUB.g, SUB.b)
    end
  end
end

local function ResetCraftLanding()
  ui.craftProf = nil
  ui.craftHighlight = nil
  local db = PC.GetDB and PC:GetDB() or nil
  if db then
    if type(db.expanded) ~= "table" then
      db.expanded = {}
    end
    db.expanded["craft-unlearned"] = false
  end
end

function PC:ResetCraftLanding()
  ResetCraftLanding()
end

local function SetTab(tab)
  -- 1.23.0: the Goals tab is gone; anything that pointed there opens Abilities.
  if tab == TAB_GOALS then
    tab = "abilities"
  end
  if ui.tab and ui.tab ~= tab then
    if PC.ResetTabState then
      PC:ResetTabState(ui.tab)
    elseif ui.tab == TAB_CRAFT and not ui.keepCraftProf then
      ResetCraftLanding()
    end
  end
  ui.tab = tab
  local db = PC:GetDB()
  if db then
    db.tab = tab
  end
  ColorTab(ui.tabNext, tab == TAB_NEXT)
  ColorTab(ui.tabPath, tab == TAB_PATH)
  ColorTab(ui.tabCraft, tab == TAB_CRAFT)
  ColorTab(ui.tabGear, tab == TAB_GEAR)
  ColorTab(ui.tabGoals, tab == TAB_GOALS)
  ColorTab(ui.tabGuild, tab == TAB_GUILD)
  ColorTab(ui.tabAbilities, tab == "abilities")
  if ui.scroll then
    ui.scroll:SetVerticalScroll(0)
  end
  if tab == TAB_PATH then
    ui.pendingPathScroll = true
  end
  HideMenu()
  PC:Refresh()
end

function PC:OpenTab(tab)
  SetTab(tab)
end

function PC:SetGearFilter(id)
  if id ~= "all" and id ~= "weapons" and id ~= "armor" and id ~= "jewelry" and id ~= "upgrades" then
    id = "all"
  end
  ui.gearFilter = id
  local db = self:GetDB()
  if db then
    db.gearFilter = id
  end
  if self.Refresh then
    self:Refresh()
  end
end

function PC:GetGearFilter()
  if ui.gearFilter == "all" or ui.gearFilter == "weapons" or ui.gearFilter == "armor" or ui.gearFilter == "jewelry" or ui.gearFilter == "upgrades" then
    return ui.gearFilter
  end
  local db = self:GetDB()
  if db and db.gearFilter then
    return db.gearFilter
  end
  return "all"
end

function PC:OpenCraftProfession(id)
  ui.craftProf = id
  if self._pendingCraftRecipe then
    ui.craftHighlight = self._pendingCraftRecipe
    self._pendingCraftRecipe = nil
  end
  ui.keepCraftProf = true
  if self.OpenTab then
    -- OpenTab calls SetTab which Refresh; keep craft tab and selection.
    if ui.tab ~= TAB_CRAFT then
      self:OpenTab(TAB_CRAFT)
    elseif self.Refresh then
      self:Refresh()
    end
  elseif self.Refresh then
    self:Refresh()
  end
  ui.keepCraftProf = nil
end

function PC:CloseCraftProfession()
  ui.craftProf = nil
  ui.craftHighlight = nil
  ui.craftFocusY = nil
  if self.Refresh then
    self:Refresh()
  end
end

function PC:GetOpenCraftProfession()
  return ui.craftProf
end

function PC:DebugScrollToHere()
  return ui.pathHereY, ui.pathHereKey, ui.scroll and ui.scroll.GetVerticalScroll and ui.scroll:GetVerticalScroll() or nil
end

local PILL_ON = { r = 0.12, g = 0.22, b = 0.16 }
local function MakeTabButton(parent, label, icon)
  local b = CreateFrame("Button", nil, parent)
  b:SetHeight(24)
  b:EnableMouse(true)

  b.indicator = b:CreateTexture(nil, "ARTWORK")
  b.indicator:SetHeight(2)
  b.indicator:SetPoint("TOPLEFT", 12, 0)
  b.indicator:SetPoint("TOPRIGHT", -12, 0)
  Paint(b.indicator, EMERALD, 1)
  b.indicator:Hide()

  -- 1.19.0: rounded pill behind the selected tab (same green as the tracker).
  if PC.BuildRoundFill then
    pcall(function()
      b.pill = PC:BuildRoundFill(b, PILL_ON, 1, "BACKGROUND", 1)
      PC:ShowRoundFill(b.pill, false)
    end)
  end

  b.iconTex = b:CreateTexture(nil, "ARTWORK")
  b.iconTex:SetSize(20, 20)
  b.iconTex:SetPoint("TOP", 0, -8)
  b.iconTex:SetTexture(icon)
  b.iconTex:SetTexCoord(0.08, 0.92, 0.08, 0.92)
  -- 1.20.0: text-only tabs. Keep the texture (other code tints it) but never show it.
  b.iconTex:Hide()
  b.iconTex.Show = b.iconTex.Hide
  b.iconTex.SetAlpha = function() end

  b.label = MakeFontString(b, 12, "GameFontNormalSmall")
  b.label:SetPoint("CENTER", b, "CENTER", 0, 0)
  b.label:SetText(label)
  b.baseLabel = label
  b.count = MakeFontString(b, 11, "GameFontNormalSmall")
  b.count:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
  b.count:Hide()

  local hl = b:CreateTexture(nil, "HIGHLIGHT")
  hl:SetAllPoints()
  hl:SetTexture(HIGHLIGHT)
  if hl.SetBlendMode then
    hl:SetBlendMode("ADD")
  end
  hl:SetAlpha(0.12)

  b:SetScript("OnEnter", function(self)
    if self.tip then
      ShowRowTooltip(self, self.tip)
    end
  end)
  b:SetScript("OnLeave", HideTooltip)
  return b
end

local function LayoutTabBar()
  if not ui.tabBar or not ui.frame then
    return
  end
  if ui.tabGoals then ui.tabGoals:Hide() end
  local tabs = { ui.tabNext, ui.tabPath, ui.tabGear, ui.tabCraft, ui.tabAbilities, ui.tabGuild }
  -- 1.19.1: left-aligned text pills sized to their labels. When they don't
  -- fit (narrow window), drop the Guild count, then share the width evenly.
  local avail = ((ui.frame:GetWidth() or FRAME_WIDTH) - 12 - 104)
  local function measure()
    local widths, total = {}, 0
    for i = 1, #tabs do
      local w = 56
      local lab = tabs[i].label
      if lab and lab.GetStringWidth then
        local ok, sw = pcall(lab.GetStringWidth, lab)
        if ok and type(sw) == "number" and sw > 0 then
          w = math.max(52, math.ceil(sw) + 26)
        end
      end
      local cnt = rawget(tabs[i], "count")
      if cnt and cnt:IsShown() and cnt.GetStringWidth then
        local ok, cw = pcall(cnt.GetStringWidth, cnt)
        if ok and type(cw) == "number" then
          w = w + math.ceil(cw) + 5
        end
      end
      widths[i] = w
      total = total + w + (i > 1 and 4 or 0)
    end
    return widths, total
  end
  local widths, total = measure()
  local gc = ui.tabGuild and rawget(ui.tabGuild, "count")
  if total > avail and gc and gc:IsShown() then
    gc:Hide()
    ui.tabCountHidden = true
    widths, total = measure()
  end
  if total > avail then
    local each = math.max(40, math.floor((avail - 4 * (#tabs - 1)) / #tabs))
    for i = 1, #tabs do widths[i] = each end
  end
  local x = 0
  for i = 1, #tabs do
    local t = tabs[i]
    local w = widths[i]
    if t.label and PC.FitFontString and total > avail then
      PC:FitFontString(t.label, t.baseLabel or t.label:GetText(), w - 8, false)
    end
    t:ClearAllPoints()
    t:SetPoint("TOPLEFT", ui.tabBar, "TOPLEFT", x, 0)
    t:SetSize(w, 24)
    local cnt = rawget(t, "count")
    t.label:ClearAllPoints()
    if cnt and cnt:IsShown() then
      local okC, cw = pcall(cnt.GetStringWidth, cnt)
      cw = (okC and type(cw) == "number") and math.ceil(cw) or 8
      t.label:SetPoint("CENTER", t, "CENTER", -math.floor((cw + 5) / 2), 0)
      cnt:ClearAllPoints()
      cnt:SetPoint("LEFT", t.label, "RIGHT", 5, 0)
    else
      t.label:SetPoint("CENTER", t, "CENTER", 0, 0)
    end
    if t.pill and PC.LayoutRoundFill then
      pcall(PC.LayoutRoundFill, PC, t.pill, t, 12, 0)
    end
    x = x + w + 4
  end
end

-- Guild tab shows how many guildmates match your status, in gold.
local function UpdateTabCounts()
  local t = ui.tabGuild
  if not t or not t.label then
    return
  end
  local n = 0
  if PC.GetGuildmateCards then
    local ok, cards = pcall(PC.GetGuildmateCards, PC)
    if ok and type(cards) == "table" then
      n = #cards
    end
  end
  local cnt = rawget(t, "count")
  if cnt then
    if n > 0 then
      cnt:SetText(tostring(n))
      cnt:Show()
    else
      cnt:Hide()
    end
  end
  ui.tabCountHidden = false
  LayoutTabBar()
  ui.guildCount = n
end
PC._UpdateTabCounts = UpdateTabCounts

local function UpdateHideButton()
  if not ui.hideBtn then
    return
  end
  local on = PC:IsHideCompleted()
  if on then
    ui.hideBtn.bg:SetVertexColor(EMERALD.r * 0.25, EMERALD.g * 0.25, EMERALD.b * 0.25, 1)
    ui.hideBtn.label:SetTextColor(EMERALD.r, EMERALD.g, EMERALD.b)
  else
    ui.hideBtn.bg:SetVertexColor(CARD.r, CARD.g, CARD.b, 1)
    ui.hideBtn.label:SetTextColor(SUB.r, SUB.g, SUB.b)
  end
end

local function RefreshClassChrome()
  local classPath = ClassIcon("class")
  if ui.headerIcon then
    ApplyPathIcon(ui.headerIcon, classPath)
  end
  local accent = AccentColor()
  if ui.headerGuild and ui.headerGuild.SetTextColor then
    ui.headerGuild:SetTextColor(accent.r, accent.g, accent.b)
  end
  if ui.tabNext and ui.tabNext.iconTex then
    ApplyPathIcon(ui.tabNext.iconTex, ClassIcon("next"))
  end
  if ui.tabPath and ui.tabPath.iconTex then
    ApplyPathIcon(ui.tabPath.iconTex, ClassIcon("zones"))
  end
  if ui.tabCraft and ui.tabCraft.iconTex then
    ApplyPathIcon(ui.tabCraft.iconTex, ClassIcon("professions"))
  end
  if ui.tabGear and ui.tabGear.iconTex then
    ApplyPathIcon(ui.tabGear.iconTex, ClassIcon("gear"))
  end
  if ui.tabGoals and ui.tabGoals.iconTex then
    ApplyPathIcon(ui.tabGoals.iconTex, ClassIcon("goals"))
  end
  if ui.tabGuild and ui.tabGuild.iconTex then
    ApplyPathIcon(ui.tabGuild.iconTex, ClassIcon("guild"))
  end
  if ui.tab then
    ColorTab(ui.tabNext, ui.tab == TAB_NEXT)
    ColorTab(ui.tabPath, ui.tab == TAB_PATH)
    ColorTab(ui.tabCraft, ui.tab == TAB_CRAFT)
    ColorTab(ui.tabGear, ui.tab == TAB_GEAR)
    ColorTab(ui.tabGoals, ui.tab == TAB_GOALS)
    ColorTab(ui.tabGuild, ui.tab == TAB_GUILD)
  end
  if ui.minimap and ui.minimap.icon then
    ApplyPathIcon(ui.minimap.icon, classPath, 0.05)
  end
  if ui.ldbObject then
    ui.ldbObject.icon = classPath
  end
end

function PC:Refresh()
  if self.RefreshMiniTracker then
    pcall(self.RefreshMiniTracker, self)
  end
  if not ui.created then
    return
  end
  RefreshClassChrome()
  UpdateHideButton()
  pcall(UpdateTabCounts)
  if not ui.frame:IsShown() then
    return
  end
  if not ui.content then
    return
  end
  if PC._ApplySplit then
    local wide = (ui.frame:GetWidth() or 0) >= 700
    pcall(PC._ApplySplit, wide and not Searching())
  end
  if rawget(ui, "nextBanner") then ui.nextBanner:Hide() end
  DETAIL.Begin()
  ui.layingOut = true
  ui.content:SetWidth(ContentWidth())
  StripRows()
  if Searching() and ui.tab == TAB_NEXT then
    -- Typing in search from Next jumps to a Path-style filter so dungeons,
    -- quests, and items are all reachable from one box.
    LayoutPath()
  elseif ui.tab == TAB_NEXT then
    LayoutNext()
  elseif ui.tab == TAB_PATH then
    LayoutPath()
  elseif ui.tab == TAB_CRAFT then
    LayoutCraft()
  elseif ui.tab == TAB_GEAR then
    LayoutGear()
  elseif ui.tab == TAB_GUILD then
    LayoutGuild()
  elseif ui.tab == "abilities" then
    LayoutGoals("abilities")
  else
    LayoutGoals()
  end
  ui.layingOut = false
  DETAIL.Finish()
end

local function SaveWindow()
  if not ui.frame then
    return
  end
  local db = PC:GetDB()
  if not db then
    return
  end
  if type(db.window) ~= "table" then
    db.window = {}
  end
  db.window.x = ui.frame:GetLeft()
  db.window.y = ui.frame:GetBottom()
  db.window.w = ui.frame:GetWidth()
  db.window.h = ui.frame:GetHeight()
end

-- Default size, clamped so the window never exceeds 85% of the screen height.
local function DefaultFrameSize()
  local w, h = FRAME_WIDTH, FRAME_HEIGHT
  local sh = UIParent and UIParent.GetHeight and UIParent:GetHeight() or nil
  sh = tonumber(sh)
  if sh and sh > 0 then
    local cap = math.floor(sh * 0.85)
    if h > cap then h = math.max(MIN_H, cap) end
  end
  local sw = UIParent and UIParent.GetWidth and UIParent:GetWidth() or nil
  sw = tonumber(sw)
  if sw and sw > 0 then
    local capW = math.floor(sw * 0.9)
    if w > capW then w = math.max(MIN_W, capW) end
  end
  return w, h
end
PC.DefaultFrameSize = DefaultFrameSize

local function RestoreWindow(f)
  local db = PC:GetDB()
  if not db or type(db.window) ~= "table" then
    return
  end
  local w, h = db.window.w, db.window.h
  if w and h then
    if w < MIN_W then w = MIN_W end
    if h < MIN_H then h = MIN_H end
    if w > MAX_W then w = MAX_W end
    if h > MAX_H then h = MAX_H end
    -- A migrated default should not run off a short screen.
    if w == FRAME_WIDTH and h == FRAME_HEIGHT then
      w, h = DefaultFrameSize()
    end
    f:SetSize(w, h)
  end
  if db.window.x and db.window.y then
    f:ClearAllPoints()
    f:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", db.window.x, db.window.y)
  end
  local scale = db.window.scale or 1
  if scale < 0.8 then scale = 0.8 end
  if scale > 1.4 then scale = 1.4 end
  f:SetScale(scale)
end

function PC:SetUIScale(scale)
  if ui.frame and scale then
    ui.frame:SetScale(scale)
  end
end

function PC:ResetMainWindowPosition()
  if not ui.frame then
    return
  end
  ui.frame:ClearAllPoints()
  ui.frame:SetSize(DefaultFrameSize())
  ui.frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
  local db = PC:GetDB()
  local scale = db and db.window and db.window.scale or 1
  ui.frame:SetScale(scale)
end

-- ---------------------------------------------------------------------------
-- Minimap button
-- ---------------------------------------------------------------------------

local minimapShapes = {
  ["ROUND"] = { true, true, true, true },
  ["SQUARE"] = { false, false, false, false },
  ["CORNER-TOPLEFT"] = { false, false, false, true },
  ["CORNER-TOPRIGHT"] = { false, false, true, false },
  ["CORNER-BOTTOMLEFT"] = { true, false, false, false },
  ["CORNER-BOTTOMRIGHT"] = { false, true, false, false },
  ["SIDE-LEFT"] = { true, false, false, true },
  ["SIDE-RIGHT"] = { false, true, true, false },
  ["SIDE-TOP"] = { false, false, true, true },
  ["SIDE-BOTTOM"] = { true, true, false, false },
  ["TRICORNER-TOPLEFT"] = { false, true, false, true },
  ["TRICORNER-TOPRIGHT"] = { true, false, true, false },
  ["TRICORNER-BOTTOMLEFT"] = { true, false, false, true },
  ["TRICORNER-BOTTOMRIGHT"] = { true, true, false, false },
}

local function PositionMinimapButton(btn, angleDeg)
  if not Minimap then
    return
  end
  local angle = math.rad(angleDeg or 200)
  local x, y, q = math.cos(angle), math.sin(angle), 1
  if x < 0 then
    q = q + 1
  end
  if y > 0 then
    q = q + 2
  end
  local shape = "ROUND"
  if GetMinimapShape then
    local ok, result = pcall(GetMinimapShape)
    if ok and type(result) == "string" then
      shape = result
    end
  end
  local quad = minimapShapes[shape] or minimapShapes.ROUND
  local w = (Minimap:GetWidth() / 2) + 5
  local h = (Minimap:GetHeight() / 2) + 5
  local px, py
  if quad[q] then
    px, py = x * w, y * h
  else
    local diagW = math.sqrt(2 * (w ^ 2)) - 10
    local diagH = math.sqrt(2 * (h ^ 2)) - 10
    px = math.max(-w, math.min(x * diagW, w))
    py = math.max(-h, math.min(y * diagH, h))
  end
  btn:ClearAllPoints()
  btn:SetPoint("CENTER", Minimap, "CENTER", px, py)
end

local function MinimapOnClick(_, button)
  if button == "RightButton" then
    local db = PC:GetDB()
    db.minimap.hide = true
    PC:UpdateMinimapButton()
    PC:Print("The minimap button is hidden. Type |cffffffff/codex minimap|r to show it.")
  else
    PC:ToggleUI()
  end
end

local function MinimapTooltip(tt)
  if not tt or not tt.AddLine then
    return
  end
  tt:AddLine("Philosopher's Codex", GOLD.r, GOLD.g, GOLD.b)
  tt:AddLine("Alchemists", EMERALD.r, EMERALD.g, EMERALD.b)
  tt:AddLine("Left-click: open", 1, 1, 1)
  tt:AddLine("Right-click: hide this button", 1, 1, 1)
  tt:AddLine("Drag to move. Slash: /codex or /pc", SUB.r, SUB.g, SUB.b)
  if PC.GetAvailableUpdate then
    local ver = PC:GetAvailableUpdate()
    if ver then
      tt:AddLine("Update available: v" .. ver, GOLD.r, GOLD.g, GOLD.b)
      tt:AddLine("Type /codex update for the download link.", SUB.r, SUB.g, SUB.b)
    end
  end
end

local function StyleLibDBIconButton(btn)
  if not btn or not btn.icon then
    return
  end
  if btn.icon.SetTexCoord then
    btn.icon:SetTexCoord(0.05, 0.95, 0.05, 0.95)
  end
  ApplyCircleMask(btn.icon, btn)
end

local function CreateManualMinimapButton()
  local btn = CreateFrame("Button", "PhilosophersCodexMinimapButton", Minimap)
  btn:SetSize(31, 31)
  btn:SetFrameStrata("MEDIUM")
  btn:SetFrameLevel(8)
  if btn.SetFixedFrameStrata then
    pcall(btn.SetFixedFrameStrata, btn, true)
  end
  btn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

  local background = btn:CreateTexture(nil, "BACKGROUND")
  background:SetSize(20, 20)
  background:SetPoint("TOPLEFT", 7, -5)
  background:SetTexture("Interface\\Minimap\\UI-Minimap-Background")

  local icon = btn:CreateTexture(nil, "ARTWORK")
  icon:SetSize(17, 17)
  icon:SetPoint("TOPLEFT", 7, -6)
  ApplyPathIcon(icon, ClassIcon("class"), 0.05)
  ApplyCircleMask(icon, btn)
  btn.icon = icon

  local overlay = btn:CreateTexture(nil, "OVERLAY")
  overlay:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
  overlay:SetSize(53, 53)
  overlay:SetPoint("TOPLEFT")

  btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  btn:RegisterForDrag("LeftButton")
  btn:SetScript("OnClick", MinimapOnClick)
  btn:SetScript("OnDragStart", function(self)
    self:SetScript("OnUpdate", function()
      if not Minimap then
        return
      end
      local mx, my = Minimap:GetCenter()
      local cx, cy = GetCursorPosition()
      local scale = Minimap:GetEffectiveScale()
      cx, cy = cx / scale, cy / scale
      local angle = math.deg(math.atan2(cy - my, cx - mx))
      local db = PC:GetDB()
      db.minimap.angle = angle
      db.minimap.minimapPos = angle
      PC:UpdateMinimapButton()
    end)
  end)
  btn:SetScript("OnDragStop", function(self)
    self:SetScript("OnUpdate", nil)
  end)
  btn:SetScript("OnEnter", function(self)
    if not GameTooltip then
      return
    end
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    MinimapTooltip(GameTooltip)
    GameTooltip:Show()
  end)
  btn:SetScript("OnLeave", HideTooltip)
  ui.minimap = btn
  if PC.AttachMinimapBadge then
    PC:AttachMinimapBadge(btn)
  end
end

local function CreateMinimapButton()
  if ui.minimap or ui.usedLibDBIcon then
    return
  end
  local LibStub = _G.LibStub
  local LDB = LibStub and LibStub("LibDataBroker-1.1", true)
  local LDBIcon = LibStub and LibStub("LibDBIcon-1.0", true)
  if LDB and LDBIcon and LDB.NewDataObject and LDBIcon.Register then
    local db = PC:GetDB()
    if db.minimap.minimapPos == nil then
      db.minimap.minimapPos = db.minimap.angle or 200
    end
    local obj = LDB:NewDataObject("PhilosophersCodex", {
      type = "launcher",
      icon = ClassIcon("class"),
      OnClick = MinimapOnClick,
      OnTooltipShow = MinimapTooltip,
    })
    if obj then
      ui.ldbObject = obj
      local ok = pcall(LDBIcon.Register, LDBIcon, "PhilosophersCodex", obj, db.minimap)
      if ok then
        ui.usedLibDBIcon = true
        ui.ldbIcon = LDBIcon
        if LDBIcon.GetMinimapButton then
          local btn = LDBIcon:GetMinimapButton("PhilosophersCodex")
          StyleLibDBIconButton(btn)
          if PC.AttachMinimapBadge then
            PC:AttachMinimapBadge(btn)
          end
        end
        return
      end
    end
  end
  CreateManualMinimapButton()
end

function PC:UpdateMinimapButton()
  local db = PC:GetDB()
  if not db then
    return
  end
  if type(db.minimap) ~= "table" then
    db.minimap = { angle = 200, hide = false }
  end
  if ui.usedLibDBIcon and ui.ldbIcon then
    if db.minimap.hide then
      if ui.ldbIcon.Hide then
        pcall(ui.ldbIcon.Hide, ui.ldbIcon, "PhilosophersCodex")
      end
    else
      if ui.ldbIcon.Show then
        pcall(ui.ldbIcon.Show, ui.ldbIcon, "PhilosophersCodex")
      end
      if ui.ldbIcon.Refresh then
        pcall(ui.ldbIcon.Refresh, ui.ldbIcon, "PhilosophersCodex")
      end
    end
    return
  end
  if not ui.minimap then
    return
  end
  if db.minimap.hide then
    ui.minimap:Hide()
    return
  end
  ui.minimap:Show()
  PositionMinimapButton(ui.minimap, db.minimap.angle or db.minimap.minimapPos or 200)
end

-- ---------------------------------------------------------------------------
-- Frame construction
-- ---------------------------------------------------------------------------

local function LayoutHeaderChrome()
  if not ui.frame or not ui.headerTitle then
    return
  end
  local fw = ui.frame:GetWidth() or FRAME_WIDTH
  -- Room left of the search pill (200) and the round buttons (~4 x 28).
  local avail = math.max(80, fw - 16 - 8 - 200 - 120)
  ui.headerTitle:ClearAllPoints()
  ui.headerTitle:SetPoint("TOPLEFT", ui.frame, "TOPLEFT", 16, -15)
  local titleW = math.min(avail, 170)
  ui.headerTitle:SetWidth(titleW)
  if PC.FitFontString then
    PC:FitFontString(ui.headerTitle, "Philosopher's Codex", titleW, false)
  end
  if ui.headerTitle.GetStringWidth then
    local ok, sw = pcall(ui.headerTitle.GetStringWidth, ui.headerTitle)
    if ok and type(sw) == "number" and sw > 0 and sw < titleW then
      titleW = math.ceil(sw) + 2
      ui.headerTitle:SetWidth(titleW)
    end
  end
  if ui.headerGuild then
    local gw = math.max(30, avail - titleW - 8)
    ui.headerGuild:ClearAllPoints()
    ui.headerGuild:SetPoint("LEFT", ui.headerTitle, "RIGHT", 8, 0)
    ui.headerGuild:SetWidth(gw)
    if PC.FitFontString then
      PC:FitFontString(ui.headerGuild, "Alchemists  ·  v" .. tostring(PC.VERSION or "?"), gw, false)
    end
    if avail - titleW < 60 then
      ui.headerGuild:Hide()
    else
      ui.headerGuild:Show()
    end
  end
  -- Narrow windows shrink the search pill instead of overlapping the title.
  if ui.searchHolder then
    local sw = math.max(110, math.min(200, fw - 16 - titleW - 8 - 120 - 16))
    ui.searchHolder:SetWidth(sw)
    if ui.searchHolder.round and PC.LayoutRoundFill then
      pcall(PC.LayoutRoundFill, PC, ui.searchHolder.round, ui.searchHolder, 11, 0)
    end
  end
end

function PC:CreateUI()
  local existing = ui.frame or rawget(_G, "PhilosophersCodexFrame")
  if existing and ui.content and ui.created then
    ui.frame = existing
    if not ui.minimap and not ui.usedLibDBIcon then
      pcall(CreateMinimapButton)
      pcall(function() PC:UpdateMinimapButton() end)
    end
    return
  end

  local template = BackdropTemplateMixin and "BackdropTemplate" or nil
  local f = CreateFrame("Frame", "PhilosophersCodexFrame", UIParent, template)
  ui.frame = f
  f:SetSize(DefaultFrameSize())
  f:SetPoint("CENTER")
  f:SetFrameStrata("HIGH")
  f:SetToplevel(true)
  f:SetMovable(true)
  f:SetResizable(true)
  f:EnableMouse(true)
  f:SetClampedToScreen(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    SaveWindow()
  end)
  -- Mainline only: SetMinResize/SetMaxResize were removed in 10.0.
  if f.SetResizeBounds then
    pcall(f.SetResizeBounds, f, MIN_W, MIN_H, MAX_W, MAX_H)
  end
  f:SetScript("OnSizeChanged", function(self, w, h)
    if not ui.created or ui._inRelayout then
      return
    end
    w = tonumber(w) or self:GetWidth()
    h = tonumber(h) or self:GetHeight()
    if ui.sizing then
      -- 1.23.0: while dragging, only move the cheap chrome and redraw the
      -- lists at most ~8 times a second. Fighting the drag with SetSize and a
      -- full refresh on every pixel is what made resizing jumpy.
      ui._inRelayout = true
      if ui.shape and PC.LayoutRoundCard then
        pcall(PC.LayoutRoundCard, PC, ui.shape, self, 12)
      end
      LayoutTabBar()
      if LayoutHeaderChrome then LayoutHeaderChrome() end
      ui._inRelayout = false
      if not ui._sizeQueued and C_Timer and C_Timer.After then
        ui._sizeQueued = true
        C_Timer.After(0.12, function()
          ui._sizeQueued = false
          if ui.frame and ui.frame:IsShown() and PC.Refresh then PC:Refresh() end
        end)
      end
      return
    end
    local cw, ch = w, h
    if cw < MIN_W then cw = MIN_W end
    if ch < MIN_H then ch = MIN_H end
    if cw > MAX_W then cw = MAX_W end
    if ch > MAX_H then ch = MAX_H end
    if cw ~= w or ch ~= h then
      ui._inRelayout = true
      self:SetSize(cw, ch)
      ui._inRelayout = false
    end
    ui._inRelayout = true
    if ui.shape and PC.LayoutRoundCard then
      pcall(PC.LayoutRoundCard, PC, ui.shape, self, 12)
    end
    LayoutTabBar()
    if LayoutHeaderChrome then
      LayoutHeaderChrome()
    end
    if self:IsShown() and PC.Refresh then
      PC:Refresh()
    else
      local width = ContentWidth()
      if ui.content then
        ui.content:SetWidth(width)
      end
    end
    ui._inRelayout = false
  end)
  f:SetScript("OnShow", function()
    PC:ScanGear()
    PC:ScanMilestones()
    PC:Refresh()
  end)
  f:SetScript("OnHide", function()
    SaveWindow()
    HideMenu()
    if PC.ResetTabState then
      PC:ResetTabState(ui.tab)
      PC:ResetTabState("all")
    elseif not ui.keepCraftProf then
      ResetCraftLanding()
    end
  end)
  f:Hide()

  -- 1.19.0: the same rounded dark card and gold rim as the tracker.
  local okRound = false
  if PC.BuildRoundCard then
    okRound = pcall(function()
      ui.shape = PC:BuildRoundCard(f)
      PC:LayoutRoundCard(ui.shape, f, 12)
    end)
  end
  if not okRound then
    -- Dark surface, thin gold hairline instead of a heavy dialog border.
    if f.SetBackdrop then
      f:SetBackdrop({
        bgFile = SOLID,
        tile = true,
        tileSize = 16,
        insets = { left = 0, right = 0, top = 0, bottom = 0 },
      })
      if f.SetBackdropColor then
        f:SetBackdropColor(SURFACE.r, SURFACE.g, SURFACE.b, 0.97)
      end
    else
      local bg = f:CreateTexture(nil, "BACKGROUND")
      bg:SetAllPoints()
      Paint(bg, SURFACE, 0.97)
    end
    local function Edge(pointA, x1, y1, pointB, x2, y2)
      local e = f:CreateTexture(nil, "BORDER")
      Paint(e, GOLD, 0.28)
      e:SetPoint(pointA, x1, y1)
      e:SetPoint(pointB, x2, y2)
      return e
    end
    Edge("TOPLEFT", 0, 0, "TOPRIGHT", 0, 0):SetHeight(1)
    Edge("BOTTOMLEFT", 0, 0, "BOTTOMRIGHT", 0, 0):SetHeight(1)
    Edge("TOPLEFT", 0, 0, "BOTTOMLEFT", 0, 0):SetWidth(1)
    Edge("TOPRIGHT", 0, 0, "BOTTOMRIGHT", 0, 0):SetWidth(1)
  end

  -- ESC closes. Guard against inserting twice on a mid-session reload of this file.
  if UISpecialFrames then
    local already = false
    for i = 1, #UISpecialFrames do
      if UISpecialFrames[i] == "PhilosophersCodexFrame" then
        already = true
        break
      end
    end
    if not already then
      tinsert(UISpecialFrames, "PhilosophersCodexFrame")
    end
  end

  RestoreWindow(f)

  -- Compact header
  local iconFrame = CreateFrame("Frame", nil, f)
  iconFrame:SetSize(32, 32)
  iconFrame:SetPoint("TOPLEFT", 16, -12)
  local icon = iconFrame:CreateTexture(nil, "ARTWORK")
  icon:SetAllPoints()
  ApplyPathIcon(icon, ClassIcon("class"), 0.07)
  ApplyCircleMask(icon, iconFrame)
  ui.headerIcon = icon
  -- 1.19.1: header is one line (title, version, search, round buttons).
  iconFrame:Hide()

  local title = MakeFontString(f, 15, "GameFontNormalLarge")
  title:SetPoint("TOPLEFT", f, "TOPLEFT", 16, -15)
  title:SetJustifyH("LEFT")
  title:SetText("Philosopher's Codex")
  title:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
  ui.headerTitle = title

  local guild = MakeFontString(f, 11, "GameFontNormalSmall")
  guild:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -1)
  guild:SetPoint("RIGHT", title, "RIGHT", 0, 0)
  guild:SetJustifyH("LEFT")
  guild:SetText("Alchemists  ·  v" .. tostring(PC.VERSION or "?"))
  guild:SetTextColor(SUB.r, SUB.g, SUB.b)
  ui.headerGuild = guild

  local close = CreateFrame("Button", nil, f)
  close:SetSize(22, 22)
  close:SetPoint("TOPRIGHT", f, "TOPRIGHT", -12, -12)
  close.bg = close:CreateTexture(nil, "BACKGROUND")
  close.bg:SetAllPoints()
  Paint(close.bg, { r = 0.16, g = 0.16, b = 0.17 }, 1)
  ApplyCircleMask(close.bg, close)
  close.label = MakeFontString(close, 11)
  close.label:SetPoint("CENTER", 0, 1)
  close.label:SetText("x")
  close.label:SetTextColor(SUB.r, SUB.g, SUB.b)
  close:SetScript("OnClick", function()
    f:Hide()
  end)
  close:SetScript("OnEnter", function(self)
    self.label:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
    ShowRowTooltip(self, { "Close  ·  Esc also closes this window." })
  end)
  close:SetScript("OnLeave", function(self)
    self.label:SetTextColor(SUB.r, SUB.g, SUB.b)
    HideTooltip()
  end)
  ui.closeBtn = close

  local gear = CreateFrame("Button", "PhilosophersCodexHeaderSettings", f)
  gear:SetSize(22, 22)
  gear:SetPoint("RIGHT", close, "LEFT", -6, 0)
  gear.bg = gear:CreateTexture(nil, "BACKGROUND")
  gear.bg:SetAllPoints()
  Paint(gear.bg, { r = 0.16, g = 0.16, b = 0.17 }, 1)
  ApplyCircleMask(gear.bg, gear)
  -- 1.23.0: a plain cog glyph, not the gear item icon.
  gear.icon = gear:CreateTexture(nil, "ARTWORK")
  gear.icon:SetSize(14, 14)
  gear.icon:SetPoint("CENTER")
  local cogAtlas = false
  if gear.icon.SetAtlas and C_Texture and C_Texture.GetAtlasInfo then
    for _, a in ipairs({ "QuestLog-icon-setting", "GM-icon-settings", "mechagon-projects" }) do
      local okA, infoA = pcall(C_Texture.GetAtlasInfo, a)
      if okA and infoA then
        cogAtlas = pcall(gear.icon.SetAtlas, gear.icon, a)
        if cogAtlas then break end
      end
    end
  end
  if not cogAtlas then
    gear.icon:SetSize(16, 16)
    gear.icon:SetTexture("Interface\\Buttons\\UI-OptionsButton")
  end
  gear.icon:SetVertexColor(SUB.r, SUB.g, SUB.b, 1)
  gear:HookScript("OnEnter", function(self) self.icon:SetVertexColor(TEXT.r, TEXT.g, TEXT.b, 1) end)
  gear:HookScript("OnLeave", function(self) self.icon:SetVertexColor(SUB.r, SUB.g, SUB.b, 1) end)
  gear:SetScript("OnClick", function()
    if PC.OpenSettings then
      PC:OpenSettings()
    end
  end)
  gear:SetScript("OnEnter", function(self)
    ShowRowTooltip(self, { { "Settings", GOLD.r, GOLD.g, GOLD.b }, "Open the Codex options. /codex settings" })
  end)
  gear:SetScript("OnLeave", HideTooltip)

  if PC.AttachHeaderUpdateControls then
    PC:AttachHeaderUpdateControls(f, gear)
  end
  -- 1.20.0: no update button in the header; /codex update still works.
  if PC._updateBtn then
    PC._updateBtn:Hide()
    PC._updateBtn.Show = PC._updateBtn.Hide
  end
  -- Show tracker: rebuilds and shows the namecard through the same path as
  -- /codex mini reset, so nobody needs a slash command to get it back.
  local trackerBtn = CreateFrame("Button", "PhilosophersCodexShowTrackerButton", f)
  trackerBtn:SetSize(22, 22)
  trackerBtn:SetPoint("RIGHT", gear, "LEFT", -6, 0)
  trackerBtn.bg = trackerBtn:CreateTexture(nil, "BACKGROUND")
  trackerBtn.bg:SetAllPoints()
  Paint(trackerBtn.bg, { r = 0.16, g = 0.16, b = 0.17 }, 1)
  pcall(ApplyCircleMask, trackerBtn.bg, trackerBtn)
  -- 1.23.0: a plain "o" like the close button's "x".
  trackerBtn.label = MakeFontString(trackerBtn, 12)
  trackerBtn.label:SetPoint("CENTER", 0, 1)
  trackerBtn.label:SetText("o")
  trackerBtn.label:SetTextColor(SUB.r, SUB.g, SUB.b)
  trackerBtn:SetScript("OnClick", function()
    if PC.ResetMiniTracker then
      PC:ResetMiniTracker()
      local mf = _G.PhilosophersCodexMini
      if mf and mf.IsVisible and mf:IsVisible() then
        PC:Print("The tracker card is shown under the minimap.")
      else
        PC:Print("The tracker card still is not visible. Type /codex mini debug and send the lines.")
      end
    else
      PC:Print("The mini tracker file did not load. Version " .. tostring(PC.VERSION or "?") .. ".")
    end
  end)
  trackerBtn:SetScript("OnEnter", function(self)
    self.label:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
    ShowRowTooltip(self, { { "Show tracker", GOLD.r, GOLD.g, GOLD.b }, "Rebuild the namecard tracker and place it under the minimap. /codex mini reset" })
  end)
  trackerBtn:SetScript("OnLeave", function(self)
    self.label:SetTextColor(SUB.r, SUB.g, SUB.b)
    HideTooltip()
  end)
  ui.trackerBtn = trackerBtn

  ui.settingsBtn = gear

  local headerLine = f:CreateTexture(nil, "ARTWORK")
  headerLine:SetHeight(1)
  headerLine:SetPoint("TOPLEFT", 0, -54)
  headerLine:SetPoint("TOPRIGHT", 0, -54)
  Paint(headerLine, HAIRLINE, 1)
  headerLine:Hide()

  -- Search + Hide completed
  local searchHolder = CreateFrame("Frame", nil, f)
  searchHolder:SetSize(200, 22)
  searchHolder:SetPoint("RIGHT", trackerBtn, "LEFT", -8, 0)
  if PC.BuildRoundFill then
    pcall(function()
      searchHolder.round = PC:BuildRoundFill(searchHolder, PANE.chip, 1, "BACKGROUND", 0)
      PC:LayoutRoundFill(searchHolder.round, searchHolder, 11, 0)
    end)
  end
  if not searchHolder.round then
    searchHolder.bg = searchHolder:CreateTexture(nil, "BACKGROUND")
    searchHolder.bg:SetAllPoints()
    Paint(searchHolder.bg, CARD, 1)
  end
  searchHolder.icon = searchHolder:CreateTexture(nil, "ARTWORK")
  searchHolder.icon:SetSize(12, 12)
  searchHolder.icon:SetPoint("LEFT", searchHolder, "LEFT", 9, 0)
  if not pcall(searchHolder.icon.SetTexture, searchHolder.icon, "Interface\\Common\\UI-Searchbox-Icon") then
    searchHolder.icon:Hide()
  end
  searchHolder.icon:SetVertexColor(SUB.r, SUB.g, SUB.b, 1)
  ui.searchHolder = searchHolder
  ui.headerRight = searchHolder
  LayoutHeaderChrome()

  local search = CreateFrame("EditBox", "PhilosophersCodexSearchBox", searchHolder)
  search:SetAutoFocus(false)
  search:SetAltArrowKeyMode(false)
  search:EnableMouse(true)
  if search.SetFontObject then
    search:SetFontObject(GameFontHighlight)
  end
  ApplyFont(search, 12)
  search:SetTextColor(TEXT.r, TEXT.g, TEXT.b, 1)
  search:SetPoint("TOPLEFT", searchHolder, "TOPLEFT", 26, 0)
  search:SetPoint("BOTTOMRIGHT", searchHolder, "BOTTOMRIGHT", -10, 0)
  search:SetMaxLetters(60)
  if search.SetTextInsets then
    search:SetTextInsets(0, 0, 0, 0)
  end
  local placeholder = MakeFontString(searchHolder, 12)
  placeholder:SetTextColor(MUTED.r, MUTED.g, MUTED.b)
  placeholder:SetPoint("LEFT", search, "LEFT", 0, 0)
  placeholder:SetText("Search")
  search:SetScript("OnTextChanged", function(self)
    local text = self:GetText() or ""
    if text == "" then
      placeholder:Show()
    else
      placeholder:Hide()
    end
    if PC.searchQuery ~= text then
      PC:SetSearchQuery(text)
    end
  end)
  search:SetScript("OnEscapePressed", function(self)
    if (self:GetText() or "") ~= "" then
      self:SetText("")
      PC:SetSearchQuery("")
    end
    self:ClearFocus()
  end)
  search:SetScript("OnEnterPressed", function(self)
    self:ClearFocus()
  end)
  ui.search = search

  local hideBtn = CreateFrame("Button", nil, f)
  hideBtn:SetSize(84, 24)
  hideBtn:SetPoint("TOPRIGHT", f, "TOPRIGHT", -12, -44)
  local hideRound
  if PC.BuildRoundFill then
    pcall(function()
      hideRound = PC:BuildRoundFill(hideBtn, CARD, 1, "BACKGROUND", 0)
      PC:LayoutRoundFill(hideRound, hideBtn, 12, 0)
    end)
  end
  if hideRound then
    hideBtn.bg = CARDS.Proxy(hideRound)
  else
    hideBtn.bg = hideBtn:CreateTexture(nil, "BACKGROUND")
    hideBtn.bg:SetAllPoints()
  end
  Paint(hideBtn.bg, CARD, 1)
  hideBtn.label = MakeFontString(hideBtn, 11, "GameFontNormalSmall")
  hideBtn.label:SetPoint("CENTER")
  hideBtn.label:SetText("Hide done")
  hideBtn:SetScript("OnClick", function()
    PC:SetHideCompleted(not PC:IsHideCompleted())
  end)
  hideBtn:SetScript("OnEnter", function(self)
    ShowRowTooltip(self, { { "Hide completed", GOLD.r, GOLD.g, GOLD.b }, "Hides ticked dungeons, quests, gear, and goals. Off by default." })
  end)
  hideBtn:SetScript("OnLeave", HideTooltip)
  ui.hideBtn = hideBtn

  -- Bottom tab bar
  local tabBar = CreateFrame("Frame", nil, f)
  tabBar:SetHeight(24)
  tabBar:SetPoint("TOPLEFT", f, "TOPLEFT", 12, -44)
  tabBar:SetPoint("TOPRIGHT", f, "TOPRIGHT", -104, -44)
  tabBar.bg = tabBar:CreateTexture(nil, "BACKGROUND")
  tabBar.bg:SetAllPoints()
  Paint(tabBar.bg, { r = 0.09, g = 0.09, b = 0.10 }, 1)
  tabBar.line = tabBar:CreateTexture(nil, "ARTWORK")
  tabBar.line:SetHeight(1)
  tabBar.line:SetPoint("TOPLEFT")
  tabBar.line:SetPoint("TOPRIGHT")
  Paint(tabBar.line, HAIRLINE, 1)
  tabBar.bg:Hide()
  tabBar.line:Hide()
  ui.tabBar = tabBar

  ui.tabNext = MakeTabButton(tabBar, "Next", ClassIcon("next"))
  ui.tabPath = MakeTabButton(tabBar, "Path", ClassIcon("zones"))
  ui.tabCraft = MakeTabButton(tabBar, "Craft", ClassIcon("professions"))
  ui.tabGear = MakeTabButton(tabBar, "Gear", ClassIcon("gear"))
  ui.tabGoals = MakeTabButton(tabBar, "Goals", ClassIcon("goals"))
  ui.tabGuild = MakeTabButton(tabBar, "Guild", ClassIcon("guild"))
  ui.tabAbilities = MakeTabButton(tabBar, "Abilities", ClassIcon("goals"))
  ui.tabAbilities.tip = { { "Abilities", GOLD.r, GOLD.g, GOLD.b }, "Trainer spells by level: what to train now and what's coming." }
  ui.tabAbilities:SetScript("OnClick", function() SetTab("abilities") end)
  ui.tabNext.tip = { { "Next", GOLD.r, GOLD.g, GOLD.b }, "What to work on next, grouped by dungeons, quests, professions, training, gear, and group." }
  ui.tabPath.tip = { { "Path", GOLD.r, GOLD.g, GOLD.b }, "The leveling route, zones, dungeons, quests, loot, and boss tips." }
  ui.tabCraft.tip = { { "Craft", GOLD.r, GOLD.g, GOLD.b }, "Your professions, the next skill-up craft, mats you still need, and where to train the next rank." }
  ui.tabGear.tip = { { "Gear", GOLD.r, GOLD.g, GOLD.b }, "Healer gear targets and recent upgrade alerts." }
  ui.tabGoals.tip = { { "Goals", GOLD.r, GOLD.g, GOLD.b }, "Forms, riding, dual spec, zones, and dungeons to finish. Trainer spells are on Abilities." }
  ui.tabGuild.tip = { { "Guild", GOLD.r, GOLD.g, GOLD.b }, "Group up with Alchemists who also run the Codex. Set a status, see who is close in level and zone, then whisper, invite, or ask to join." }
  ui.tabNext:SetScript("OnClick", function() SetTab(TAB_NEXT) end)
  ui.tabPath:SetScript("OnClick", function() SetTab(TAB_PATH) end)
  ui.tabCraft:SetScript("OnClick", function() SetTab(TAB_CRAFT) end)
  ui.tabGear:SetScript("OnClick", function() SetTab(TAB_GEAR) end)
  ui.tabGoals:SetScript("OnClick", function() SetTab(TAB_GOALS) end)
  ui.tabGuild:SetScript("OnClick", function() SetTab(TAB_GUILD) end)
  LayoutTabBar()

  -- Scrollable content (mouse wheel supported explicitly).
  local scroll = CreateFrame("ScrollFrame", "PhilosophersCodexScrollFrame", f, "UIPanelScrollFrameTemplate")
  scroll:SetPoint("TOPLEFT", f, "TOPLEFT", 12, -78)
  scroll:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -28, 16)
  scroll:EnableMouseWheel(true)
  scroll:SetScript("OnMouseWheel", function(self, delta)
    local step = 44
    local current = self:GetVerticalScroll() or 0
    local max = 0
    if self.GetVerticalScrollRange then
      max = self:GetVerticalScrollRange() or 0
    end
    local new = current - (delta * step)
    if new < 0 then
      new = 0
    elseif new > max then
      new = max
    end
    self:SetVerticalScroll(new)
    if ui.tab == TAB_GUILD and ui.guildVirt then
      PaintGuildVirtual()
    end
  end)
  scroll:SetScript("OnVerticalScroll", function()
    if ui.tab == TAB_GUILD and ui.guildVirt then
      PaintGuildVirtual()
    end
  end)
  local content = CreateFrame("Frame", "PhilosophersCodexScrollChild", scroll)
  content:SetSize(FRAME_WIDTH - 40, 200)
  scroll:SetScrollChild(content)
  ui.scroll = scroll
  ui.content = content

  -- Resize grip
  local grip = CreateFrame("Button", nil, f)
  grip:SetSize(16, 16)
  grip:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -5, 5)
  local gripTex = "Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up"
  grip:SetNormalTexture(gripTex)
  grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
  grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
  grip:SetFrameLevel(f:GetFrameLevel() + 6)
  grip:SetScript("OnMouseDown", function()
    -- Pin the top-left corner first: sizing a CENTER-anchored frame grows it
    -- in both directions, so the grip slid away from the cursor.
    local l, t = f:GetLeft(), f:GetTop()
    if l and t then
      f:ClearAllPoints()
      f:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", l, t)
    end
    ui.sizing = true
    f:StartSizing("BOTTOMRIGHT")
  end)
  local function endSizing()
    if not ui.sizing then return end
    ui.sizing = false
    f:StopMovingOrSizing()
    local w, h = f:GetWidth(), f:GetHeight()
    local cw = math.floor(math.max(MIN_W, math.min(MAX_W, w or MIN_W)) + 0.5)
    local ch = math.floor(math.max(MIN_H, math.min(MAX_H, h or MIN_H)) + 0.5)
    f:SetSize(cw, ch)
    SaveWindow()
    LayoutTabBar()
    PC:Refresh()
  end
  grip:SetScript("OnMouseUp", endSizing)
  grip:SetScript("OnHide", endSizing)
  grip:SetScript("OnEnter", function(self)
    ShowRowTooltip(self, { "Drag to resize. Scale: /codex scale 0.8-1.4" })
  end)
  grip:SetScript("OnLeave", HideTooltip)
  ui.grip = grip

  local okMini, errMini = pcall(CreateMinimapButton)
  if not okMini then
    PC:Print("The minimap button failed to create: " .. tostring(errMini))
  else
    pcall(function() PC:UpdateMinimapButton() end)
  end

  local db = PC:GetDB()
  local startTab = (db and db.tab) or TAB_NEXT
  if startTab ~= TAB_NEXT and startTab ~= TAB_PATH and startTab ~= TAB_CRAFT and startTab ~= TAB_GEAR and startTab ~= TAB_GOALS and startTab ~= TAB_GUILD and startTab ~= "abilities" then
    startTab = TAB_NEXT
  end
  -- Accept a 1.2.0 saved tab name if someone had one in memory; otherwise Next.
  if startTab == "reagents" then
    startTab = TAB_GEAR
  elseif startTab == "transmute" or startTab == TAB_GOALS then
    startTab = "abilities"
  elseif startTab == "path" then
    startTab = TAB_PATH
  end
  local okTab, errTab = pcall(SetTab, startTab)
  if not okTab then
    PC:Print("The window opened, but the first tab failed to draw: " .. tostring(errTab))
  end
  ui.created = true
end

local function ReportUIError(err)
  local text = "The Codex window failed to build: " .. tostring(err)
  if PC.Print then
    PC:Print(text)
  elseif DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
    DEFAULT_CHAT_FRAME:AddMessage("|cffd4af37[Philosopher's Codex]|r " .. text)
  else
    print("|cffd4af37[Philosopher's Codex]|r " .. text)
  end
end

function PC:SafeCreateUI()
  if ui.frame and ui.created then
    return true
  end
  local ok, err = pcall(function()
    PC:CreateUI()
  end)
  if not ok then
    ReportUIError(err)
    if PC.LogError then
      PC:LogError(tostring(err), "", "CreateUI")
    end
    return ui.frame ~= nil
  end
  if ui.frame and PC.ProtectFrameTree then
    pcall(function() PC:ProtectFrameTree(ui.frame) end)
  end
  if ui.minimap and PC.ProtectFrameTree then
    pcall(function() PC:ProtectFrameTree(ui.minimap) end)
  end
  return ui.frame ~= nil
end

function PC:ToggleUI()
  if not self:SafeCreateUI() then
    return
  end
  if ui.frame:IsShown() then
    ui.frame:Hide()
  else
    ui.frame:Show()
    local ok, err = pcall(function() self:Refresh() end)
    if not ok then
      ReportUIError(err)
    end
  end
end

function PC:ShowUI()
  if not self:SafeCreateUI() then
    return
  end
  ui.frame:Show()
  local ok, err = pcall(function() self:Refresh() end)
  if not ok then
    ReportUIError(err)
  end
end


function PC:DebugContentRows()
  local out = {}
  for i = 1, table.maxn(ui.rows) do
    local row = ui.rows[i]
    if row and row:IsShown() then
      local p, rel, rp, x, y = row:GetPoint(1)
      local ancestorsOk = true
      local f = row
      while f do
        if f.IsShown and not f:IsShown() then
          ancestorsOk = false
          break
        end
        f = f.GetParent and f:GetParent() or nil
        if f == ui.content or (f and f.GetName and f:GetName() == "PhilosophersCodexScrollChild") then
          break
        end
      end
      out[#out + 1] = {
        index = i,
        title = (row.title and row.title.GetText and row.title:GetText()) or "",
        meta = (row.meta and row.meta.GetText and row.meta:GetText()) or "",
        note = (row.note and row.note.GetText and row.note:GetText()) or "",
        accent = (rawget(row, "accent") and row.accent.IsShown and row.accent:IsShown()) and true or false,
        tag = (rawget(row, "tag") and row.tag.IsShown and row.tag:IsShown() and row.tag.GetText and row.tag:GetText()) or nil,
        icon = (row.icon and row.icon.IsShown and row.icon:IsShown() and row.icon.GetTexture and row.icon:GetTexture()) or nil,
        height = row:GetHeight() or 0,
        shown = row:IsShown() and true or false,
        ancestorsShown = ancestorsOk,
        parent = row:GetParent(),
        rel = rel,
        y = y,
        left = row.GetLeft and row:GetLeft() or nil,
        right = row.GetRight and row:GetRight() or nil,
        top = row.GetTop and row:GetTop() or nil,
        bottom = row.GetBottom and row:GetBottom() or nil,
        row = row,
      }
    end
  end
  return out, ui.content, ui.scroll
end

function PC:DebugGuildRowRects()
  local list = {}
  for i = 1, table.maxn(ui.rows) do
    local row = ui.rows[i]
    if row and row:IsShown() and rawget(row, "guildBits") then
      local rec = {
        title = row.title,
        levelBadge = rawget(row, "levelBadge"),
        roleTex = rawget(row, "roleTex"),
        invite = row.invite,
        whisper = row.whisper,
        ask = row.ask,
        moreBtn = rawget(row, "moreBtn"),
        row = row,
      }
      list[#list + 1] = rec
    end
  end
  return list
end

function PC:DebugHideMenu()
  HideMenu()
end

function PC:DebugIconAudit()
  local paths = {}
  local function add(path, where)
    if path and path ~= "" then
      paths[#paths + 1] = { path = path, where = where }
    end
  end
  if ui.headerIcon and ui.headerIcon.GetTexture then
    add(ui.headerIcon:GetTexture(), "header")
  end
  if ui.minimap and ui.minimap.icon and ui.minimap.icon.GetTexture then
    add(ui.minimap.icon:GetTexture(), "minimap")
  end
  if ui.ldbObject and ui.ldbObject.icon then
    add(ui.ldbObject.icon, "ldb")
  end
  local tabs = {
    { ui.tabNext, "tab-next" },
    { ui.tabPath, "tab-path" },
    { ui.tabCraft, "tab-craft" },
    { ui.tabGear, "tab-gear" },
    { ui.tabGoals, "tab-goals" },
    { ui.tabGuild, "tab-guild" },
  }
  for i = 1, #tabs do
    local btn, where = tabs[i][1], tabs[i][2]
    if btn and btn.iconTex and btn.iconTex.GetTexture then
      add(btn.iconTex:GetTexture(), where)
    end
  end
  for i = 1, table.maxn(ui.rows) do
    local row = ui.rows[i]
    if row and row:IsShown() and row.icon and row.icon.IsShown and row.icon:IsShown() and row.icon.GetTexture then
      local title = (row.title and row.title.GetText and row.title:GetText()) or ("row-" .. i)
      add(row.icon:GetTexture(), "row:" .. tostring(title))
    end
  end
  return paths
end


function PC:EnsureDungeonTipFrame()
  if ui.tipFrame then
    return ui.tipFrame
  end
  local f = CreateFrame("Frame", "PhilosophersCodexDungeonTips", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
  f:SetSize(340, 280)
  f:SetPoint("CENTER", UIParent, "CENTER", 40, 40)
  f:SetFrameStrata("DIALOG")
  f:Hide()
  f:SetMovable(true)
  f:EnableMouse(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", function(self) self:StartMoving() end)
  f:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
  local bg = f:CreateTexture(nil, "BACKGROUND")
  bg:SetAllPoints()
  Paint(bg, SURFACE, 0.96)
  local title = MakeFontString(f, 15, "GameFontNormalLarge")
  title:SetPoint("TOPLEFT", 16, -12)
  title:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
  f.title = title
  local sub = MakeFontString(f, 11, "GameFontNormalSmall")
  sub:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -2)
  sub:SetPoint("RIGHT", f, "RIGHT", -16, 0)
  sub:SetTextColor(SUB.r, SUB.g, SUB.b)
  f.sub = sub
  local body = MakeFontString(f, 12, "GameFontHighlight")
  body:SetPoint("TOPLEFT", 16, -52)
  body:SetPoint("BOTTOMRIGHT", -16, 48)
  body:SetJustifyH("LEFT")
  body:SetJustifyV("TOP")
  if body.SetWordWrap then
    body:SetWordWrap(true)
  end
  f.body = body
  local close = CreateFrame("Button", nil, f)
  close:SetSize(80, 24)
  close:SetPoint("BOTTOMRIGHT", -12, 12)
  close.label = MakeFontString(close, 12)
  close.label:SetPoint("CENTER")
  close.label:SetText("Close")
  close.label:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
  close:SetScript("OnClick", function() f:Hide() end)
  local opt = CreateFrame("Button", nil, f)
  opt:SetSize(200, 24)
  opt:SetPoint("BOTTOMLEFT", 12, 12)
  opt.label = MakeFontString(opt, 11, "GameFontNormalSmall")
  opt.label:SetPoint("LEFT")
  opt.label:SetTextColor(SUB.r, SUB.g, SUB.b)
  f.opt = opt
  local function paintOpt()
    local on = PC.IsDungeonTipsAutoPop and PC:IsDungeonTipsAutoPop()
    opt.label:SetText(on and "Auto-show is on  ·  tap to turn off" or "Auto-show is off  ·  tap to turn on")
  end
  opt:SetScript("OnClick", function()
    if PC.SetDungeonTipsAutoPop then
      PC:SetDungeonTipsAutoPop(not (PC.IsDungeonTipsAutoPop and PC:IsDungeonTipsAutoPop()))
    end
    paintOpt()
  end)
  f.paintOpt = paintOpt
  ui.tipFrame = f
  if PC.ProtectFrame then
    PC:ProtectFrame(f)
  end
  return f
end

function PC:OpenDungeonTips(dungeonId, reason)
  if self.DungeonHasTips and not self:DungeonHasTips(dungeonId) then
    if ui.tipFrame then
      ui.tipFrame:Hide()
    end
    return
  end
  -- Deep-link navigation must never auto-pop this card.
  if reason == "deeplink" then
    return
  end
  local sheet = self.GetDungeonTipSheet and self:GetDungeonTipSheet(dungeonId)
  if not sheet or sheet.tipsComing then
    if ui.tipFrame then
      ui.tipFrame:Hide()
    end
    return
  end
  local bosses = sheet.bosses or {}
  if #bosses == 0 then
    if ui.tipFrame then
      ui.tipFrame:Hide()
    end
    return
  end
  local f = self:EnsureDungeonTipFrame()
  f.title:SetText(sheet.name or "Boss tips")
  f.sub:SetText(sheet.source or "Boss tips")
  local lines = {}
  for i = 1, #bosses do
    local b = bosses[i]
    local line = (b.name or "Boss") .. "  —  " .. (b.tip or "")
    if b.loot then
      line = line .. "  Loot: " .. b.loot .. "."
    end
    lines[#lines + 1] = line
  end
  f.body:SetText(table.concat(lines, "\n\n"))
  if f.paintOpt then
    f.paintOpt()
  end
  f:Show()
end


Row.OVERLAP_SKIP = {
  bg = true, sep = true, hl = true, accent = true, guide = true,
}

function Row.RegionKind(obj)
  if type(obj) ~= "table" then
    return nil
  end
  if obj.GetObjectType then
    local ok, got = pcall(obj.GetObjectType, obj)
    if ok then
      return got
    end
  end
  return obj._kind
end

function Row.RegionShown(obj)
  if type(obj) ~= "table" or not obj.IsShown then
    return false
  end
  local ok, shown = pcall(obj.IsShown, obj)
  return ok and shown
end

function Row.InkRect(obj)
  if type(obj) ~= "table" or not obj.GetLeft then
    return nil
  end
  local okL, l = pcall(obj.GetLeft, obj)
  local okR, r = pcall(obj.GetRight, obj)
  local okB, b = pcall(obj.GetBottom, obj)
  local okT, t = pcall(obj.GetTop, obj)
  if not (okL and okR and okB and okT) or l == nil or r == nil or b == nil or t == nil then
    return nil
  end
  local kind = Row.RegionKind(obj)
  if kind == "FontString" then
    local sw, sh = 0, 0
    if obj.GetStringWidth then
      local ok, w = pcall(obj.GetStringWidth, obj)
      if ok and type(w) == "number" then
        sw = w
      end
    end
    if obj.GetStringHeight then
      local ok, h = pcall(obj.GetStringHeight, obj)
      if ok and type(h) == "number" then
        sh = h
      end
    end
    local text = ""
    if obj.GetText then
      local ok, s = pcall(obj.GetText, obj)
      if ok then text = s or "" end
    end
    if text == "" or not tostring(text):find("%S") then
      return nil
    end
    if (not sw or sw == 0) and text ~= "" then
      sw = #text * 7
    end
    -- Vertical extent comes from the laid-out box, not GetStringHeight,
    -- which the headless mock inflates for long wrapped strings.
    local boxL, boxR, boxH = l, r, t - b
    if boxH < 4 then
      boxH = 12
      t = b + boxH
    end
    local justify = (obj._justifyH or "LEFT")
    if obj.GetJustifyH then
      local ok, j = pcall(obj.GetJustifyH, obj)
      if ok and type(j) == "string" then
        justify = j
      end
    end
    local wrap = obj._wordWrap
    if obj.GetWordWrap then
      local ok, w = pcall(obj.GetWordWrap, obj)
      if ok then wrap = w end
    end
    -- Horizontal ink uses the string width so overflow into trailing
    -- accessories is still detected. Wrapped text is clipped to its box.
    if justify == "RIGHT" then
      l = r - sw
    elseif justify == "CENTER" then
      local mid = (l + r) / 2
      l, r = mid - sw / 2, mid + sw / 2
    else
      r = l + sw
    end
    if wrap then
      if l < boxL then l = boxL end
      if r > boxR then r = boxR end
    end
  end
  if r - l < 1 or t - b < 1 then
    return nil
  end
  return { l = l, r = r, b = b, t = t, obj = obj, kind = kind, text = (obj.GetText and obj:GetText()) or obj._name or obj._key }
end

function Row.IntersectRects(a, b, slack)
  slack = slack or 1
  return a.l < b.r - slack and b.l < a.r - slack and a.b < b.t - slack and b.b < a.t - slack
end

function Row.WalkRowRegions(row, out)
  if not row then
    return
  end
  local kids = row._children or {}
  -- Also look up named bits the mock/store may not list as children.
  local named = {
    row.title, row.meta, row.note, row.tag, row.check, row.pin,
    row.invite, row.whisper, row.ask, row.accept, row.decline,
    rawget(row, "countPill"), rawget(row, "countBadge"), rawget(row, "trailChevron"),
    rawget(row, "demoTag"), rawget(row, "moreBtn"), rawget(row, "levelBadge"),
    rawget(row, "roleTex"), rawget(row, "roleLetter"), rawget(row, "statusDot"),
    rawget(row, "chip1"), rawget(row, "chip2"), rawget(row, "locIcon"),
    row.icon, rawget(row, "bar"),
  }
  local seen = {}
  local function consider(obj)
    if type(obj) ~= "table" or seen[obj] then
      return
    end
    seen[obj] = true
    if not Row.RegionShown(obj) then
      return
    end
    -- Skip full-bleed backgrounds and separators.
    for key, flag in pairs(Row.OVERLAP_SKIP) do
      if rawget(row, key) == obj then
        return
      end
    end
    out[#out + 1] = obj
    -- Labels inside buttons/pills should be checked against other row regions
    -- but not against their own parent. Walk FontString children of frames.
    if obj.GetRegions or obj._children then
      local inner = obj._children or {}
      for i = 1, #inner do
        local ch = inner[i]
        if Row.RegionShown(ch) and Row.RegionKind(ch) == "FontString" then
          if not seen[ch] then
            seen[ch] = true
            out[#out + 1] = ch
            out[#out]._parentRegion = obj
          end
        end
      end
    end
  end
  for i = 1, #named do
    consider(named[i])
  end
  for i = 1, #kids do
    consider(kids[i])
  end
end

function PC:CollectRowOverlaps(row, slack)
  slack = tonumber(slack) or 1
  local hits = {}
  if not row or (row.IsShown and not row:IsShown()) then
    return hits
  end
  local objs = {}
  Row.WalkRowRegions(row, objs)
  local rects = {}
  for i = 1, #objs do
    local rec = Row.InkRect(objs[i])
    if rec then
      rec.parentRegion = rawget(objs[i], "_parentRegion")
      rects[#rects + 1] = rec
    end
  end
  for i = 1, #rects do
    if rects[i].kind == "FontString" then
      for j = 1, #rects do
        if i ~= j then
          local a, b = rects[i], rects[j]
          -- A label sitting inside its own button/pill is not an overlap.
          if a.parentRegion == b.obj or b.parentRegion == a.obj then
            -- skip
          elseif Row.IntersectRects(a, b, slack) then
            hits[#hits + 1] = {
              a = a.text or "fs",
              b = b.text or b.kind or "region",
              al = a.l, ar = a.r, at = a.t, ab = a.b,
              bl = b.l, br = b.r, bt = b.t, bb = b.b,
            }
          end
        end
      end
    end
  end
  return hits
end

function PC:AuditVisibleRowOverlaps(slack)
  local hits = {}
  if ui and ui.rows then
    for i = 1, table.maxn(ui.rows) do
      local row = ui.rows[i]
      if row and row:IsShown() then
        local found = self:CollectRowOverlaps(row, slack)
        for k = 1, #found do
          found[k].row = (row.title and row.title.GetText and row.title:GetText()) or ("row-" .. i)
          found[k].index = i
          hits[#hits + 1] = found[k]
        end
      end
    end
  end
  if self.CollectMiniOverlaps then
    local miniHits = self:CollectMiniOverlaps(slack)
    for i = 1, #miniHits do
      hits[#hits + 1] = miniHits[i]
    end
  end
  return hits
end

