-- Philosopher's Codex: version checks, error log, Issues page, Update dialog.
-- All APIs are guarded. Messages stay on the existing guild share channel.

local PC = PhilosophersCodex

PC.RELEASES_URL = "https://github.com/uriahgibsonai/PhilosophersCodex-Releases"
PC.RELEASES_PAGE = "https://github.com/uriahgibsonai/PhilosophersCodex-Releases/releases/latest"
PC.LATEST_JSON_URL = "https://raw.githubusercontent.com/uriahgibsonai/PhilosophersCodex-Releases/main/latest.json"
PC.KNOWN_LATEST = PC.KNOWN_LATEST or "1.25.0"

local GOLD = { r = 0.831, g = 0.686, b = 0.216 }
local EMERALD = { r = 0.247, g = 0.749, b = 0.498 }
local TEXT = { r = 0.95, g = 0.95, b = 0.97 }
local SUB = { r = 0.56, g = 0.56, b = 0.60 }
local MUTED = { r = 0.42, g = 0.42, b = 0.46 }
local SURFACE = { r = 0.09, g = 0.09, b = 0.10 }
local CARD = { r = 0.14, g = 0.14, b = 0.15 }
local HAIRLINE = { r = 0.22, g = 0.22, b = 0.24 }

local LOG_CAP = 100
local STACK_MAX = 900
local issuesFrame
local updateFrame
local wrapping

local function Paint(tex, color, a)
  if not tex then
    return
  end
  if tex.SetColorTexture then
    tex:SetColorTexture(color.r, color.g, color.b, a or 1)
  elseif tex.SetTexture then
    tex:SetTexture("Interface\\Buttons\\WHITE8X8")
    if tex.SetVertexColor then
      tex:SetVertexColor(color.r, color.g, color.b, a or 1)
    end
  end
end

local function ApplyFont(fs, inherit)
  inherit = inherit or "GameFontHighlight"
  if fs and fs.SetFontObject then
    pcall(fs.SetFontObject, fs, _G[inherit] or GameFontHighlight or inherit)
  end
end

local function Label(parent, inherit)
  local fs = parent:CreateFontString(nil, "ARTWORK", inherit or "GameFontHighlight")
  ApplyFont(fs, inherit or "GameFontHighlight")
  if fs.SetTextColor then
    fs:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
  end
  return fs
end

local function NowStamp()
  if time then
    return time()
  end
  if GetTime then
    return math.floor(GetTime())
  end
  return 0
end

local function FormatTime(ts)
  if not ts or ts == 0 then
    return "-"
  end
  if date then
    local ok, s = pcall(date, "%Y-%m-%d %H:%M:%S", ts)
    if ok and type(s) == "string" then
      return s
    end
  end
  return tostring(ts)
end

local function ShortStack(stack)
  if type(stack) ~= "string" then
    return ""
  end
  stack = string.gsub(stack, "\r\n", "\n")
  local lines = {}
  for line in string.gmatch(stack, "([^\n]+)") do
    if not string.find(line, "xpcall", 1, true) and not string.find(line, "PhilosophersCodexDiagnostics.lua") then
      lines[#lines + 1] = line
    end
    if #lines >= 12 then
      break
    end
  end
  local s = table.concat(lines, "\n")
  if string.len(s) > STACK_MAX then
    s = string.sub(s, 1, STACK_MAX) .. "…"
  end
  return s
end

function PC:CaptureStack()
  if debugstack then
    local ok, s = pcall(debugstack, 3)
    if ok and type(s) == "string" and s ~= "" then
      return ShortStack(s)
    end
  end
  if debug and debug.traceback then
    local ok, s = pcall(debug.traceback, "", 3)
    if ok and type(s) == "string" then
      return ShortStack(s)
    end
  end
  return ""
end

function PC:InitLog()
  if type(PhilosophersCodexLog) ~= "table" then
    PhilosophersCodexLog = {}
  end
  local log = PhilosophersCodexLog
  if type(log.errors) ~= "table" then
    log.errors = {}
  end
  if type(log.missing) ~= "table" then
    log.missing = {}
  end
  if log.debug ~= true then
    log.debug = false
  end
  return log
end

function PC:GetLog()
  return self:InitLog()
end

function PC:IsDebugMode()
  local log = self:InitLog()
  return log.debug and true or false
end

function PC:SetDebugMode(on)
  local log = self:InitLog()
  log.debug = on and true or false
  return log.debug
end

local function TrimList(list, cap)
  while #list > cap do
    local oldest, idx = nil, 1
    for i = 1, #list do
      local ts = list[i].last or list[i].first or 0
      if not oldest or ts < oldest then
        oldest = ts
        idx = i
      end
    end
    table.remove(list, idx)
  end
end

local function ContextNow()
  local class = "-"
  local level = 0
  local zone = "-"
  if PC.GetClassFile then
    class = PC:GetClassFile() or "-"
  end
  if PC.PlayerLevel then
    level = PC:PlayerLevel() or 0
  end
  if PC.CurrentZoneNames then
    local names = PC:CurrentZoneNames()
    zone = names and names[1] or "-"
  elseif GetZoneText then
    local ok, z = pcall(GetZoneText)
    if ok then
      zone = z or "-"
    end
  end
  return class, level, zone
end

local function NormalizeError(msg)
  msg = tostring(msg or "unknown error")
  local rest = string.match(msg, "^.-:%d+:%s*(.*)$")
  if rest and rest ~= "" then
    return rest
  end
  return msg
end

function PC:LogError(message, stack, context)
  local log = self:InitLog()
  message = NormalizeError(message)
  context = tostring(context or "addon")
  stack = ShortStack(stack or "")
  -- Dedupe on context + message so the same fault is counted, not split by stack line.
  local key = context .. "|" .. message
  local class, level, zone = ContextNow()
  local now = NowStamp()
  for i = 1, #log.errors do
    local e = log.errors[i]
    if e.key == key then
      e.count = (e.count or 1) + 1
      e.last = now
      e.class = class
      e.level = level
      e.zone = zone
      e.version = self.VERSION or e.version
      if self:IsDebugMode() and self.Print then
        self:Print("Error (" .. tostring(e.count) .. "x) in " .. context .. ": " .. message)
      end
      if self.RefreshIssuesFrame then
        self:RefreshIssuesFrame()
      end
      return e
    end
  end
  local rec = {
    key = key,
    kind = "error",
    context = context,
    message = message,
    stack = stack,
    count = 1,
    first = now,
    last = now,
    version = self.VERSION or "?",
    class = class,
    level = level,
    zone = zone,
  }
  log.errors[#log.errors + 1] = rec
  TrimList(log.errors, LOG_CAP)
  if self:IsDebugMode() and self.Print then
    self:Print("Error in " .. context .. ": " .. message)
  end
  if self.RefreshIssuesFrame then
    self:RefreshIssuesFrame()
  end
  return rec
end

function PC:LogMissing(kind, id, message)
  if not kind or not id or id == "" then
    return nil
  end
  local log = self:InitLog()
  kind = tostring(kind)
  id = tostring(id)
  message = tostring(message or kind)
  local key = kind .. "|" .. id
  local class, level, zone = ContextNow()
  local now = NowStamp()
  for i = 1, #log.missing do
    local e = log.missing[i]
    if e.key == key then
      e.count = (e.count or 1) + 1
      e.last = now
      return e
    end
  end
  local rec = {
    key = key,
    kind = kind,
    id = id,
    message = message,
    count = 1,
    first = now,
    last = now,
    version = self.VERSION or "?",
    class = class,
    level = level,
    zone = zone,
  }
  log.missing[#log.missing + 1] = rec
  TrimList(log.missing, LOG_CAP)
  if self.RefreshIssuesFrame then
    self:RefreshIssuesFrame()
  end
  return rec
end

function PC:ClearIssueLog()
  local log = self:InitLog()
  log.errors = {}
  log.missing = {}
  if self.RefreshIssuesFrame then
    self:RefreshIssuesFrame()
  end
end

function PC:CountIssues()
  local log = self:InitLog()
  return #(log.errors or {}), #(log.missing or {})
end

function PC:FormatIssueReport()
  local log = self:InitLog()
  local class, level, zone = ContextNow()
  local lines = {
    "Philosopher's Codex " .. tostring(self.VERSION or "?") .. " issue report",
    "Class: " .. tostring(class) .. "  Race: " .. tostring((UnitRace and select(2, UnitRace("player"))) or "?") .. "  Level: " .. tostring(level) .. "  Zone: " .. tostring(zone),
    "Tab: " .. tostring(self.GetCurrentTabForTest and self:GetCurrentTabForTest() or "?") .. "  Window: " .. tostring(PhilosophersCodexFrame and PhilosophersCodexFrame.GetWidth and math.floor(PhilosophersCodexFrame:GetWidth() or 0) or "?"),
    "Generated: " .. FormatTime(NowStamp()),
    "",
  }
  local errors = log.errors or {}
  lines[#lines + 1] = "ERRORS (" .. tostring(#errors) .. ")"
  if #errors == 0 then
    lines[#lines + 1] = "(none)"
  end
  for i = 1, #errors do
    local e = errors[i]
    lines[#lines + 1] = string.format(
      "[%dx] %s: %s",
      e.count or 1,
      e.context or "addon",
      e.message or ""
    )
    lines[#lines + 1] = string.format(
      "  version=%s class=%s level=%s zone=%s",
      tostring(e.version or "-"),
      tostring(e.class or "-"),
      tostring(e.level or "-"),
      tostring(e.zone or "-")
    )
    lines[#lines + 1] = "  first=" .. FormatTime(e.first) .. "  last=" .. FormatTime(e.last)
    if e.stack and e.stack ~= "" then
      lines[#lines + 1] = "  stack:"
      for line in string.gmatch(e.stack, "([^\n]+)") do
        lines[#lines + 1] = "    " .. line
      end
    end
    lines[#lines + 1] = ""
  end
  local missing = log.missing or {}
  lines[#lines + 1] = "MISSING DATA (" .. tostring(#missing) .. ")"
  if #missing == 0 then
    lines[#lines + 1] = "(none)"
  end
  for i = 1, #missing do
    local e = missing[i]
    lines[#lines + 1] = string.format(
      "[%dx] %s %s: %s",
      e.count or 1,
      e.kind or "data",
      e.id or "?",
      e.message or ""
    )
    lines[#lines + 1] = string.format(
      "  version=%s class=%s",
      tostring(e.version or "-"),
      tostring(e.class or "-")
    )
  end
  return table.concat(lines, "\n")
end

-- ---------------------------------------------------------------------------
-- Version compare and update notice (once per session)
-- ---------------------------------------------------------------------------

function PC:ParseVersion(s)
  s = tostring(s or "")
  local a, b, c = string.match(s, "(%d+)%.(%d+)%.(%d+)")
  if not a then
    a, b = string.match(s, "(%d+)%.(%d+)")
    c = 0
  end
  return tonumber(a) or 0, tonumber(b) or 0, tonumber(c) or 0
end

function PC:IsVersionNewer(theirs, mine)
  local a1, b1, c1 = self:ParseVersion(theirs)
  local a2, b2, c2 = self:ParseVersion(mine or self.VERSION)
  if a1 ~= a2 then
    return a1 > a2
  end
  if b1 ~= b2 then
    return b1 > b2
  end
  return c1 > c2
end

function PC:GetAvailableUpdate()
  return self._updateAvailable
end

function PC:DebugResetUpdateNotice()
  self._updateAvailable = nil
  self._updateSource = nil
  self._updateNoticeShown = false
  if self.RefreshUpdateBadge then
    self:RefreshUpdateBadge()
  end
end

function PC:NoteNewerVersion(ver, source)
  if type(ver) ~= "string" or ver == "" or ver == "-" then
    return false
  end
  if not self:IsVersionNewer(ver, self.VERSION) then
    return false
  end
  if not self._updateAvailable or self:IsVersionNewer(ver, self._updateAvailable) then
    self._updateAvailable = ver
    self._updateSource = source
  end
  if not self._updateNoticeShown then
    self._updateNoticeShown = true
    if self.Print then
      self:Print("Update available: v" .. self._updateAvailable .. ". Tap Update or type |cffffffff/codex update|r for the download link.")
    end
  end
  if self.RefreshUpdateBadge then
    self:RefreshUpdateBadge()
  end
  return true
end

function PC:CheckKnownLatest()
  if self.KNOWN_LATEST then
    self:NoteNewerVersion(self.KNOWN_LATEST, "known")
  end
end

-- ---------------------------------------------------------------------------
-- Safe call wrapper for entry points
-- ---------------------------------------------------------------------------

local SAFE_HANDLERS = {
  OnEvent = true,
  OnClick = true,
  OnUpdate = true,
  OnEnter = true,
  OnLeave = true,
  OnShow = true,
  OnHide = true,
  OnDragStart = true,
  OnDragStop = true,
  OnMouseUp = true,
  OnMouseDown = true,
  OnMouseWheel = true,
  OnValueChanged = true,
  OnTextChanged = true,
  OnEnterPressed = true,
  OnEscapePressed = true,
  OnSizeChanged = true,
}

function PC:SafeCall(context, fn, ...)
  if type(fn) ~= "function" then
    return false
  end
  local n = select("#", ...)
  local args = { ... }
  local function runner()
    return fn(unpack(args, 1, n))
  end
  local owner = self
  local function onerr(err)
    local stack = ""
    if owner.CaptureStack then
      stack = owner:CaptureStack()
    end
    if owner.LogError then
      owner:LogError(tostring(err), stack, context or "addon")
    elseif owner.ReportError then
      owner:ReportError(err)
    end
    return err
  end
  return xpcall(runner, onerr)
end

function PC:ProtectFrame(frame)
  if not frame or type(frame.SetScript) ~= "function" or frame._pcDecorated then
    return
  end
  frame._pcDecorated = true
  local rawSet = frame.SetScript
  frame.SetScript = function(self, ev, script)
    if type(script) == "function" and ev and SAFE_HANDLERS[ev] then
      local ctx = ev
      if self.GetName then
        local ok, name = pcall(self.GetName, self)
        if ok and type(name) == "string" and name ~= "" then
          ctx = ev .. ":" .. name
        end
      end
      local wrapped = function(...)
        return PC:SafeCall(ctx, script, ...)
      end
      return rawSet(self, ev, wrapped)
    end
    return rawSet(self, ev, script)
  end
  if frame.GetScript and not wrapping then
    for ev in pairs(SAFE_HANDLERS) do
      local fn = frame:GetScript(ev)
      if type(fn) == "function" and not (frame._pcSafe and frame._pcSafe[ev]) then
        frame._pcSafe = frame._pcSafe or {}
        -- The current script is the original. Re-set so the decorated SetScript wraps it.
        -- Mark first so a recursive walk does not loop.
        frame._pcSafe[ev] = true
        frame:SetScript(ev, fn)
      end
    end
  end
end

function PC:ProtectFrameTree(frame, seen)
  if not frame then
    return
  end
  seen = seen or {}
  if seen[frame] then
    return
  end
  seen[frame] = true
  self:ProtectFrame(frame)
  if frame.GetChildren then
    local kids = { frame:GetChildren() }
    for i = 1, #kids do
      local child = kids[i]
      if type(child) == "table" and child.SetScript then
        self:ProtectFrameTree(child, seen)
      end
    end
  end
end

-- ---------------------------------------------------------------------------
-- Missing-data audit
-- ---------------------------------------------------------------------------

function PC:AuditMissingData()
  local data = self.GetClassData and self:GetClassData() or nil
  local seen = {}
  if data and type(data.brackets) == "table" then
    for i = 1, #data.brackets do
      local dungeons = data.brackets[i].dungeons or {}
      for j = 1, #dungeons do
        local d = dungeons[j]
        local id = d and (d.id or d.key)
        if id and not seen[id] then
          seen[id] = true
          if self.GetEntranceWaypoint then
            self:GetEntranceWaypoint(id)
          end
        end
      end
    end
  end
  local classFile = self.GetClassFile and self:GetClassFile()
  if classFile == "DRUID" or classFile == "MAGE" or classFile == "WARLOCK" then
    local pin = self.GetClassTrainerWaypoint and self:GetClassTrainerWaypoint()
    if not pin then
      local key = (data and data.trainerWaypoint) or classFile
      self:LogMissing("trainer", key, "Missing trainer pin for " .. tostring(classFile))
    end
  end
  local quests = PhilosophersCodexData and PhilosophersCodexData.QUESTS
  if type(quests) == "table" then
    for dungeonId, list in pairs(quests) do
      if type(list) == "table" then
        for i = 1, #list do
          local q = list[i]
          if type(q) == "table" then
            if not q.questID and not q.id then
              self:LogMissing("quest", dungeonId .. ":" .. tostring(q.name or i), "Quest entry has no questID in " .. tostring(dungeonId))
            elseif q.name == nil or q.name == "" then
              self:LogMissing("quest", q.questID or q.id, "Unknown quest name for " .. tostring(q.questID or q.id))
            end
          end
        end
      end
    end
  end
  local loot = PhilosophersCodexData and PhilosophersCodexData.LOOT
  if type(loot) == "table" then
    for i = 1, #loot do
      local it = loot[i]
      if type(it) == "table" then
        if not it.itemID and not it.id then
          self:LogMissing("item", it.name or ("loot-" .. i), "Loot entry has no itemID: " .. tostring(it.name or i))
        end
      end
    end
  end
  if self.AuditZoneQuestCoverage then
    self:AuditZoneQuestCoverage()
  end
end

function PC:NoteUnknownQuest(questID, label)
  if not questID then
    return
  end
  self:LogMissing("quest", questID, "Unknown quest: " .. tostring(label or questID))
end

function PC:NoteUnknownItem(itemID, label)
  if not itemID then
    return
  end
  self:LogMissing("item", itemID, "Unknown item: " .. tostring(label or itemID))
end

-- ---------------------------------------------------------------------------
-- Dialogs: Update and Issues
-- ---------------------------------------------------------------------------

local function MakeDialog(name, width, height, titleText)
  local f = CreateFrame("Frame", name, UIParent)
  f:SetSize(width, height)
  f:SetPoint("CENTER", UIParent, "CENTER", 0, 40)
  f:SetFrameStrata("DIALOG")
  f:SetMovable(true)
  f:EnableMouse(true)
  if f.RegisterForDrag then
    f:RegisterForDrag("LeftButton")
  end
  f:SetScript("OnDragStart", function(self)
    self:StartMoving()
  end)
  f:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
  end)
  f.bg = f:CreateTexture(nil, "BACKGROUND")
  f.bg:SetAllPoints()
  Paint(f.bg, SURFACE, 1)
  local function Edge(a, x1, y1, b, x2, y2)
    local e = f:CreateTexture(nil, "BORDER")
    e:SetPoint(a, x1, y1)
    e:SetPoint(b, x2, y2)
    Paint(e, HAIRLINE, 1)
    return e
  end
  Edge("TOPLEFT", 0, 0, "TOPRIGHT", 0, 0):SetHeight(1)
  Edge("BOTTOMLEFT", 0, 0, "BOTTOMRIGHT", 0, 0):SetHeight(1)
  Edge("TOPLEFT", 0, 0, "BOTTOMLEFT", 0, 0):SetWidth(1)
  Edge("TOPRIGHT", 0, 0, "BOTTOMRIGHT", 0, 0):SetWidth(1)

  local title = Label(f, "GameFontNormalLarge")
  title:SetPoint("TOPLEFT", 16, -14)
  title:SetText(titleText)
  if title.SetTextColor then
    title:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
  end
  f.title = title

  local close = CreateFrame("Button", name .. "Close", f)
  close:SetSize(28, 28)
  close:SetPoint("TOPRIGHT", -8, -10)
  close.bg = close:CreateTexture(nil, "BACKGROUND")
  close.bg:SetAllPoints()
  Paint(close.bg, CARD, 1)
  close.label = Label(close, "GameFontHighlight")
  close.label:SetPoint("CENTER", 0, 1)
  close.label:SetText("X")
  if close.label.SetTextColor then
    close.label:SetTextColor(SUB.r, SUB.g, SUB.b)
  end
  close:SetScript("OnClick", function()
    f:Hide()
  end)
  f.close = close

  if UISpecialFrames then
    local already = false
    for i = 1, #UISpecialFrames do
      if UISpecialFrames[i] == name then
        already = true
        break
      end
    end
    if not already then
      tinsert(UISpecialFrames, name)
    end
  end
  f:Hide()
  return f
end

local function MakePill(parent, name, text, width)
  local b = CreateFrame("Button", name, parent)
  b:SetSize(width or 120, 28)
  b.bg = b:CreateTexture(nil, "BACKGROUND")
  b.bg:SetAllPoints()
  Paint(b.bg, CARD, 1)
  b.label = Label(b, "GameFontHighlight")
  b.label:SetPoint("CENTER")
  b.label:SetText(text)
  if b.label.SetTextColor then
    b.label:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
  end
  b:SetScript("OnEnter", function(self)
    if self.label and self.label.SetTextColor then
      self.label:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
    end
  end)
  b:SetScript("OnLeave", function(self)
    if self.label and self.label.SetTextColor then
      self.label:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
    end
  end)
  return b
end

function PC:EnsureUpdateFrame()
  if updateFrame then
    return updateFrame
  end
  local f = MakeDialog("PhilosophersCodexUpdateFrame", 440, 420, "Update")
  local sub = Label(f, "GameFontHighlightSmall")
  sub:SetPoint("TOPLEFT", 16, -44)
  sub:SetPoint("TOPRIGHT", -16, -44)
  if sub.SetJustifyH then
    sub:SetJustifyH("LEFT")
  end
  if sub.SetWordWrap then
    pcall(sub.SetWordWrap, sub, true)
  end
  f.sub = sub

  local body = Label(f, "GameFontHighlightSmall")
  body:SetPoint("TOPLEFT", 16, -88)
  body:SetPoint("TOPRIGHT", -16, -88)
  if body.SetJustifyH then
    body:SetJustifyH("LEFT")
  end
  if body.SetJustifyV then
    body:SetJustifyV("TOP")
  end
  if body.SetWordWrap then
    pcall(body.SetWordWrap, body, true)
  end
  if body.SetTextColor then
    body:SetTextColor(SUB.r, SUB.g, SUB.b)
  end
  body:SetText("WoW addons cannot download files themselves.\n\n1. Open the page below in a browser (it is already copied).\n2. Download PhilosophersCodex.zip.\n3. Extract it into World of Warcraft\\_forever_\\Interface\\AddOns\\, replacing the old PhilosophersCodex folder.\n\nOr use the PC updater: double-click Update-PhilosophersCodex.bat (in the zip or the Releases repo). It reads latest.json, backs up your current folder, and installs the new copy. It can also copy your error log into a reports folder.")
  f.body = body

  local box = CreateFrame("EditBox", "PhilosophersCodexUpdateBox", f)
  box:SetAutoFocus(false)
  if box.SetAltArrowKeyMode then
    box:SetAltArrowKeyMode(false)
  end
  box:EnableMouse(true)
  ApplyFont(box, "GameFontHighlightSmall")
  if box.SetTextColor then
    box:SetTextColor(TEXT.r, TEXT.g, TEXT.b, 1)
  end
  box:SetPoint("BOTTOMLEFT", 16, 16)
  box:SetPoint("BOTTOMRIGHT", -16, 16)
  box:SetHeight(28)
  if box.SetMaxLetters then
    box:SetMaxLetters(250)
  end
  box:SetText(PC.RELEASES_PAGE)
  box:SetScript("OnEscapePressed", function(self)
    self:ClearFocus()
  end)
  box:SetScript("OnEnterPressed", function(self)
    self:ClearFocus()
  end)
  f.box = box
  updateFrame = f
  if self.ProtectFrameTree then
    self:ProtectFrameTree(f)
  end
  return f
end

function PC:OpenUpdateDialog()
  local f = self:EnsureUpdateFrame()
  local available = self:GetAvailableUpdate()
  local sub = "Your version: v" .. tostring(self.VERSION or "?")
  if available then
    sub = sub .. "   ·   Update available: v" .. available
    if self._updateSource and self._updateSource ~= "known" then
      sub = sub .. "  (seen on " .. tostring(self._updateSource) .. ")"
    end
  else
    sub = sub .. "   ·   You are on the latest version this copy knows about."
  end
  f.sub:SetText(sub)
  f.box:SetText(self.RELEASES_PAGE or "")
  f:Show()
  f.box:SetFocus()
  if f.box.HighlightText then
    pcall(f.box.HighlightText, f.box)
  end
end

function PC:EnsureIssuesFrame()
  if issuesFrame then
    return issuesFrame
  end
  local f = MakeDialog("PhilosophersCodexIssuesFrame", 440, 460, "Issues")
  local summary = Label(f, "GameFontHighlightSmall")
  summary:SetPoint("TOPLEFT", 16, -44)
  summary:SetPoint("TOPRIGHT", -16, -44)
  if summary.SetJustifyH then
    summary:SetJustifyH("LEFT")
  end
  if summary.SetTextColor then
    summary:SetTextColor(SUB.r, SUB.g, SUB.b)
  end
  f.summary = summary

  local copyBtn = MakePill(f, "PhilosophersCodexIssuesCopy", "Copy", 90)
  copyBtn:SetPoint("TOPLEFT", 16, -68)
  copyBtn:SetScript("OnClick", function()
    PC:CopyIssueReport()
  end)
  f.copyBtn = copyBtn

  local clearBtn = MakePill(f, "PhilosophersCodexIssuesClear", "Clear", 90)
  clearBtn:SetPoint("LEFT", copyBtn, "RIGHT", 8, 0)
  clearBtn:SetScript("OnClick", function()
    PC:ClearIssueLog()
    if PC.Print then
      PC:Print("The issue log has been cleared.")
    end
  end)
  f.clearBtn = clearBtn

  local hint = Label(f, "GameFontHighlightSmall")
  hint:SetPoint("LEFT", clearBtn, "RIGHT", 10, 0)
  hint:SetPoint("RIGHT", f, "RIGHT", -16, 0)
  if hint.SetJustifyH then hint:SetJustifyH("LEFT") end
  if hint.SetTextColor then hint:SetTextColor(SUB.r, SUB.g, SUB.b) end
  hint:SetText("Copy, press Ctrl+C, then paste it to Uriah.")
  f.hint = hint

  local box = CreateFrame("EditBox", "PhilosophersCodexIssuesBox", f)
  box:SetAutoFocus(false)
  if box.SetAltArrowKeyMode then
    box:SetAltArrowKeyMode(false)
  end
  box:EnableMouse(true)
  ApplyFont(box, "GameFontHighlightSmall")
  if box.SetTextColor then
    box:SetTextColor(TEXT.r, TEXT.g, TEXT.b, 1)
  end
  box:SetPoint("TOPLEFT", 16, -104)
  box:SetPoint("BOTTOMRIGHT", -16, 16)
  if box.SetMaxLetters then
    box:SetMaxLetters(20000)
  end
  if box.SetMultiLine then
    pcall(box.SetMultiLine, box, true)
  end
  if box.SetJustifyV then
    pcall(box.SetJustifyV, box, "TOP")
  end
  if box.SetJustifyH then
    pcall(box.SetJustifyH, box, "LEFT")
  end
  box:SetScript("OnEscapePressed", function(self)
    self:ClearFocus()
  end)
  f.box = box
  issuesFrame = f
  if self.ProtectFrameTree then
    self:ProtectFrameTree(f)
  end
  return f
end

-- ---------------------------------------------------------------------------
-- First-run welcome (1.22.0). Shows once per account; /codex welcome reopens.
-- ---------------------------------------------------------------------------

local welcomeFrame
local WELCOME_LINES = {
  { "Your Alchemist ID badge", "The card near the minimap. Set your status there (Dungeon, Questing, Need help) so guildmates can find you. Turn on Can help to show up for anyone who needs a hand." },
  { "Open the Codex", "Type /codex, or tap the alchemy circle on the badge. Tap anything on the left of a tab to see its details on the right." },
  { "Pick your dungeons", "With Dungeon status on, tap the dungeons you want to run. Guildmates see your picks." },
  { "Something wrong?", "Type /codex bug, press Ctrl+C, and paste the report to Uriah." },
}

function PC:ShowWelcome(force)
  local db = self.GetDB and self:GetDB() or nil
  local acct = rawget(_G, "PhilosophersCodexLog")
  if not force then
    if (acct and acct.welcomeSeen) or (db and db.welcomeSeen) then
      return false
    end
  end
  if not welcomeFrame then
    local f = MakeDialog("PhilosophersCodexWelcome", 420, 340, "Welcome to the Codex")
    f.rows = {}
    local y = -48
    for i = 1, #WELCOME_LINES do
      local head = Label(f, "GameFontHighlight")
      head:SetPoint("TOPLEFT", f, "TOPLEFT", 16, y)
      head:SetPoint("TOPRIGHT", f, "TOPRIGHT", -16, y)
      if head.SetJustifyH then head:SetJustifyH("LEFT") end
      head:SetText(WELCOME_LINES[i][1])
      local body = Label(f, "GameFontHighlightSmall")
      body:SetPoint("TOPLEFT", head, "BOTTOMLEFT", 0, -3)
      body:SetPoint("TOPRIGHT", head, "BOTTOMRIGHT", 0, -3)
      body:SetHeight(30)
      if body.SetJustifyH then body:SetJustifyH("LEFT") end
      if body.SetJustifyV then body:SetJustifyV("TOP") end
      if body.SetWordWrap then pcall(body.SetWordWrap, body, true) end
      if body.SetTextColor then body:SetTextColor(SUB.r, SUB.g, SUB.b) end
      body:SetText(WELCOME_LINES[i][2])
      f.rows[i] = { head = head, body = body }
      y = y - 62
    end
    local open = MakePill(f, "PhilosophersCodexWelcomeOpen", "Open the Codex", 140)
    open:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 16, 16)
    open:SetScript("OnClick", function()
      PC:DismissWelcome()
      if PC.ShowUI then
        PC:ShowUI()
      end
    end)
    local ok = MakePill(f, "PhilosophersCodexWelcomeOk", "Got it", 90)
    ok:SetPoint("LEFT", open, "RIGHT", 8, 0)
    ok:SetScript("OnClick", function()
      PC:DismissWelcome()
    end)
    f:SetScript("OnHide", function()
      PC:MarkWelcomeSeen()
    end)
    welcomeFrame = f
    if self.ProtectFrameTree then
      self:ProtectFrameTree(f)
    end
  end
  welcomeFrame:Show()
  return true
end

function PC:MarkWelcomeSeen()
  local db = self.GetDB and self:GetDB() or nil
  if db then db.welcomeSeen = true end
  local acct = rawget(_G, "PhilosophersCodexLog")
  if type(acct) == "table" then acct.welcomeSeen = true end
end

function PC:DismissWelcome()
  self:MarkWelcomeSeen()
  if welcomeFrame then welcomeFrame:Hide() end
end

function PC:RefreshIssuesFrame()
  if not issuesFrame or (issuesFrame.IsShown and not issuesFrame:IsShown()) then
    -- Still keep the text current if the frame exists and is shown later.
    if not issuesFrame then
      return
    end
  end
  local errors, missing = self:CountIssues()
  issuesFrame.summary:SetText(tostring(errors) .. " errors  ·  " .. tostring(missing) .. " missing data")
  if issuesFrame.box then
    issuesFrame.box:SetText(self:FormatIssueReport())
  end
end

function PC:OpenIssues()
  local f = self:EnsureIssuesFrame()
  f:Show()
  self:RefreshIssuesFrame()
end

function PC:CopyIssueReport()
  local f = self:EnsureIssuesFrame()
  f:Show()
  self:RefreshIssuesFrame()
  if f.box then
    f.box:SetText(self:FormatIssueReport())
    f.box:SetFocus()
    if f.box.HighlightText then
      pcall(f.box.HighlightText, f.box)
    end
  end
  if self.Print then
    self:Print("Issue report is selected. Press Ctrl+C to copy it.")
  end
end

-- Called from the UI after the main window and minimap exist.
function PC:RefreshUpdateBadge()
  local ver = self:GetAvailableUpdate()
  local text = ver and ("Update available: v" .. ver) or ""
  if self._updateBadge then
    if ver then
      local badge = self._updateBadge
      local maxW = 240
      local parent = badge.GetParent and badge:GetParent()
      local fw = parent and parent.GetWidth and parent:GetWidth() or (self.FRAME_WIDTH or 460)
      -- Leave room for the icon (58) and the header buttons (~120).
      maxW = math.max(160, (tonumber(fw) or 460) - 58 - 130)
      if self.FitFontString then
        self:FitFontString(badge, text, maxW, false)
      else
        badge:SetText(text)
      end
      self._updateBadge:Show()
      if self._updateBadge.SetTextColor then
        self._updateBadge:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
      end
    else
      self._updateBadge:SetText("")
      self._updateBadge:Hide()
    end
  end
  if self._updateBtn then
    self._updateBtn:Show()
    if self._updateBtn.dot then
      if ver then
        self._updateBtn.dot:Show()
      else
        self._updateBtn.dot:Hide()
      end
    end
  end
  if self._minimapBadge then
    if ver then
      self._minimapBadge:SetText("!")
      self._minimapBadge:Show()
    else
      self._minimapBadge:Hide()
    end
  end
  if self.RefreshOptionsPanel then
    -- Counts and update label in Settings, if the panel is up.
    self:RefreshOptionsPanel()
  end
end

function PC:AttachHeaderUpdateControls(frame, gear)
  if not frame or self._updateBtn then
    return
  end
  local btn = CreateFrame("Button", "PhilosophersCodexUpdateButton", frame)
  btn:SetSize(28, 28)
  if gear then
    btn:SetPoint("RIGHT", gear, "LEFT", -6, 0)
  else
    btn:SetPoint("TOPRIGHT", -72, -10)
  end
  btn.bg = btn:CreateTexture(nil, "BACKGROUND")
  btn.bg:SetAllPoints()
  Paint(btn.bg, CARD, 1)
  btn.label = Label(btn, "GameFontHighlight")
  btn.label:SetPoint("CENTER", 0, 1)
  btn.label:SetText("U")
  if btn.label.SetTextColor then
    btn.label:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
  end
  btn.dot = btn:CreateTexture(nil, "OVERLAY")
  btn.dot:SetSize(7, 7)
  btn.dot:SetPoint("TOPRIGHT", -2, -2)
  Paint(btn.dot, GOLD, 1)
  btn.dot:Hide()
  btn:SetScript("OnClick", function()
    PC:OpenUpdateDialog()
  end)
  btn:SetScript("OnEnter", function(self)
    if GameTooltip and GameTooltip.SetOwner then
      pcall(GameTooltip.SetOwner, GameTooltip, self, "ANCHOR_LEFT")
      if GameTooltip.AddLine then
        local ver = PC:GetAvailableUpdate()
        if ver then
          GameTooltip:AddLine("Update available: v" .. ver, GOLD.r, GOLD.g, GOLD.b)
        else
          GameTooltip:AddLine("Update", GOLD.r, GOLD.g, GOLD.b)
        end
        GameTooltip:AddLine("Opens the public download link. Addons cannot install themselves.", SUB.r, SUB.g, SUB.b)
        if GameTooltip.Show then
          GameTooltip:Show()
        end
      end
    end
  end)
  btn:SetScript("OnLeave", function()
    if GameTooltip and GameTooltip.Hide then
      GameTooltip:Hide()
    end
  end)
  self._updateBtn = btn

  local badge = Label(frame, "GameFontHighlightSmall")
  badge:SetPoint("TOPLEFT", 58, -40)
  badge:SetPoint("RIGHT", btn, "LEFT", -8, 0)
  if badge.SetJustifyH then
    badge:SetJustifyH("LEFT")
  end
  if badge.SetTextColor then
    badge:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
  end
  badge:SetText("")
  badge:Hide()
  self._updateBadge = badge
  self:RefreshUpdateBadge()
end

function PC:AttachMinimapBadge(btn)
  if not btn then
    return
  end
  local badge = Label(btn, "GameFontNormalSmall")
  badge:SetPoint("TOPRIGHT", 2, 2)
  badge:SetText("!")
  if badge.SetTextColor then
    badge:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
  end
  badge:Hide()
  self._minimapBadge = badge
  self:RefreshUpdateBadge()
end

-- Init the account-wide log as soon as this file loads so later files can log.
PC:InitLog()

-- ---------------------------------------------------------------------------
-- 1.24.0: automatic guild reports. Every client queues its own errors and
-- missing-data lines and sends a short summary over the guild addon channel
-- whenever a collector (turned on with /codex collect on) is online. The
-- collector keeps them, deduped, in PhilosophersCodexLog.reports so they
-- land in SavedVariables on /reload or logout. No chat, no names unless the
-- sender turns "include my name" on.
-- ---------------------------------------------------------------------------
local REPORT_CAP = 300
local sendQueue, sending = {}, false

local function CleanField(v, max)
  v = tostring(v == nil and "" or v)
  v = v:gsub("|", "/"):gsub("[\r\n]+", " ")
  if max and #v > max then v = v:sub(1, max) end
  return v
end

local function ShortHash(s)
  local h = 5381
  s = tostring(s or "")
  for i = 1, #s do
    h = (h * 33 + s:byte(i)) % 4294967296
  end
  return string.format("%08x", h)
end

function PC:IsReportCollector()
  return self:InitLog().collector == true
end

function PC:SetReportCollector(on)
  local log = self:InitLog()
  log.collector = on and true or false
  if on then self:AnnounceCollector() end
end

function PC:GetReportIncludeName()
  return self:InitLog().reportName == true
end

function PC:SetReportIncludeName(on)
  self:InitLog().reportName = on and true or false
end

function PC:AreReportsEnabled()
  return self:InitLog().reportsOff ~= true
end

function PC:SetReportsEnabled(on)
  self:InitLog().reportsOff = not on
end

function PC:AnnounceCollector()
  if self:IsReportCollector() and self.SendGuildAddon then
    self:SendGuildAddon("RC")
  end
end

-- Everything this client has logged that the collector hasn't seen yet.
function PC:PendingReportRecords()
  local log = self:InitLog()
  local out = {}
  for _, list in ipairs({ log.errors or {}, log.missing or {} }) do
    for i = 1, #list do
      local e = list[i]
      if (e.count or 1) > (e.sentCount or 0) then
        out[#out + 1] = e
      end
    end
  end
  return out
end

function PC:BuildReportMessage(e)
  local race = UnitRace and select(2, UnitRace("player")) or "?"
  local who = self:GetReportIncludeName() and (UnitName and UnitName("player") or "") or ""
  local kind = e.kind == "error" and "E" or "M"
  local what = e.kind == "error" and ((e.context or "addon") .. ": " .. (e.message or "")) or ((e.kind or "missing") .. " " .. (e.id or "") .. ": " .. (e.message or ""))
  local head = table.concat({ "R", CleanField(self.VERSION, 10), kind, CleanField(e.class, 12), CleanField(race, 12),
    CleanField(e.level, 3), CleanField(e.zone, 30), CleanField(e.count or 1, 5), CleanField(who, 24) }, "|")
  local room = 250 - #head - 1
  return head .. "|" .. CleanField(what, math.max(20, room))
end

local function SendNext()
  local item = table.remove(sendQueue, 1)
  if not item then
    sending = false
    return
  end
  local ok = PC:SendGuildAddon(PC:BuildReportMessage(item))
  if ok then
    item.sentCount = item.count or 1
  end
  if C_Timer and C_Timer.After then
    C_Timer.After(1.2, SendNext)
  else
    SendNext()
  end
end

-- Called when a collector says it is online.
function PC:FlushReports()
  if not self:AreReportsEnabled() or self:IsReportCollector() then
    return 0
  end
  if sending then
    return #sendQueue
  end
  local pending = self:PendingReportRecords()
  for i = 1, math.min(#pending, 20) do
    sendQueue[#sendQueue + 1] = pending[i]
  end
  if #sendQueue > 0 then
    sending = true
    SendNext()
  end
  return #pending
end

function PC:StoreGuildReport(sender, parts)
  if not self:IsReportCollector() then
    return nil
  end
  local log = self:InitLog()
  if type(log.reports) ~= "table" then log.reports = {} end
  local version, kind, class, race, level, zone, count, who, what =
    parts[2], parts[3], parts[4], parts[5], parts[6], parts[7], tonumber(parts[8]) or 1, parts[9], parts[10]
  if not what or what == "" then
    return nil
  end
  local key = (kind or "?") .. "|" .. what
  local reporter = ShortHash(sender)
  local now = NowStamp()
  local list = log.reports
  local rec
  for i = 1, #list do
    if list[i].key == key then rec = list[i] break end
  end
  if not rec then
    rec = { key = key, kind = kind == "E" and "error" or "missing", what = what, first = now, reporters = {}, names = {}, total = 0 }
    list[#list + 1] = rec
    TrimList(list, REPORT_CAP)
  end
  rec.last = now
  rec.version, rec.class, rec.race, rec.level, rec.zone = version, class, race, level, zone
  local prev = rec.reporters[reporter] or 0
  rec.reporters[reporter] = math.max(prev, count)
  local total, people = 0, 0
  for _, c in pairs(rec.reporters) do total = total + c; people = people + 1 end
  rec.total, rec.people = total, people
  if who and who ~= "" then rec.names[who] = true end
  return rec
end

function PC:HandleReportMessage(sender, parts)
  local kind = parts[1]
  if kind == "RC" then
    -- A collector is online: send anything new, a few seconds later.
    if C_Timer and C_Timer.After then
      C_Timer.After(3 + math.random() * 5, function() PC:FlushReports() end)
    else
      self:FlushReports()
    end
    return true
  elseif kind == "R" then
    self:StoreGuildReport(sender, parts)
    return true
  elseif kind == "H" and self:IsReportCollector() then
    self:AnnounceCollector()
  end
  return false
end

function PC:FormatGuildReports()
  local log = self:InitLog()
  local list = log.reports or {}
  table.sort(list, function(a, b) return (a.people or 0) * 1000 + (a.total or 0) > (b.people or 0) * 1000 + (b.total or 0) end)
  local lines = { "Philosopher's Codex guild reports (" .. #list .. ")", "Collector: " .. (self:IsReportCollector() and "on" or "off") .. "  Generated: " .. FormatTime(NowStamp()), "" }
  if #list == 0 then
    lines[#lines + 1] = self:IsReportCollector() and "(no reports yet)" or "Turn collecting on with /codex collect on."
  end
  for i = 1, #list do
    local r = list[i]
    local names = {}
    for n in pairs(r.names or {}) do names[#names + 1] = n end
    lines[#lines + 1] = string.format("[%s] %dx from %d %s: %s", r.kind == "error" and "ERR" or "MISS", r.total or 0, r.people or 0, (r.people == 1) and "player" or "players", r.what or "")
    lines[#lines + 1] = string.format("  last: v%s %s %s lv%s in %s, %s%s", tostring(r.version or "?"), tostring(r.race or "?"), tostring(r.class or "?"), tostring(r.level or "?"), tostring(r.zone or "?"), FormatTime(r.last), (#names > 0) and ("  names: " .. table.concat(names, ", ")) or "")
  end
  return table.concat(lines, "\n")
end

function PC:ShowGuildReports()
  local f = self:EnsureIssuesFrame()
  f:Show()
  self:RefreshIssuesFrame()
  if f.box then
    f.box:SetText(self:FormatGuildReports())
    f.box:SetFocus()
    if f.box.HighlightText then pcall(f.box.HighlightText, f.box) end
  end
  if self.Print then
    local n = #(self:InitLog().reports or {})
    self:Print("Guild reports: " .. n .. ". They save to your PC on /reload or logout.")
  end
end

function PC:ClearGuildReports()
  self:InitLog().reports = {}
end
