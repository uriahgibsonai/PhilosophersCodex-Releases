-- Philosopher's Codex dungeon boss cheat sheets.
-- Classic dungeons use well-known mechanics (Classic Era baseline). Notable
-- loot named here is either in this addon's Forever loot index or a widely
-- known Classic drop; unlisted Forever-only loot is omitted.
-- Forever-specific dungeons only include confirmed notes; otherwise tipsComing.

PhilosophersCodexData = PhilosophersCodexData or {}

local function B(name, tip, extras)
  local row = { name = name, tip = tip }
  if extras then
    for k, v in pairs(extras) do
      row[k] = v
    end
  end
  return row
end

PhilosophersCodexData.DUNGEON_TIPS = {
  ["deadmines"] = {
    id = "deadmines",
    name = "The Deadmines",
    source = "Classic Era baseline.",
    bosses = {
      B("Rhahk'Zor", "Cleave. Tanks face him away from the group. Healer: the pack before him can spike."),
      B("Sneed's Shredder", "Kill the shredder first, then Sneed. The shredder knocks back; don't stand with your back to a drop."),
      B("Mr. Smite", "At roughly two-thirds and one-third he slams and stuns the melee. Stop DPS or be ready to wait it out. Healer: pre-hot before the slam."),
      B("Cookie", "Optional. Interrupt or burn him quickly if you want the food and his trinket."),
      B("Edwin VanCleef", "He summons adds as his health drops. CC or burn adds, then finish him. Cloth chest: Corsair's Overshirt.", { loot = "Corsair's Overshirt" }),
    },
  },
  ["shadowfang-keep"] = {
    id = "shadowfang-keep",
    name = "Shadowfang Keep",
    source = "Classic Era baseline.",
    bosses = {
      B("Razorclaw the Butcher", "Straightforward melee. Bloody Apron is a chest piece from this fight."),
      B("Baron Silverlaine", "He raises worgen after he dies if they are not already cleared. Keep the room clean."),
      B("Commander Springvale", "Holy damage and a shield. Interrupt what you can. Healer: holy attacks can spike the tank."),
      B("Wolf Master Nandos", "Kills his worgs first, or he heals from them. Then burn Nandos."),
      B("Archmage Arugal", "He blinks and casts Shadow Bolts. Spread a little, interrupt if you can, and don't stand in void zones if they appear. Cloth: Robes of Arugal.", { loot = "Robes of Arugal" }),
    },
  },
  ["wailing-caverns"] = {
    id = "wailing-caverns",
    name = "Wailing Caverns",
    source = "Classic Era baseline.",
    bosses = {
      B("Lady Anacondra", "Sleep and lightning. Dispel or wait out sleep. First of the four druids for the Naralex event."),
      B("Lord Cobrahn", "Lightning and a Druid form. Same plan as the other fanglord druids."),
      B("Lord Pythas", "Another fanglord. Same plan; get all four before Naralex."),
      B("Lord Serpentis", "Last fanglord, up on the ledge. Serpent Gloves can drop here."),
      B("Verdan the Everliving", "Huge health pool, little else. Tank and spank; healer keep a long fight in mind. Living Root can drop."),
      B("Mutanus the Devourer", "After the Naralex event. Narcolepsy / terrify can hit the group; dispel if you can, or wait it out."),
    },
  },
  ["stockade"] = {
    id = "stockade",
    name = "The Stockade",
    source = "Classic Era baseline.",
    bosses = {
      B("Targorr the Dread", "Short melee fight. Clear the room so you are not fighting extras."),
      B("Kam Deepfury", "Cleave and a short, hard-hitting fight. Healer: Bridgebreaker Bindings can drop here.", { loot = "Bridgebreaker Bindings" }),
      B("Hamhock", "Two casters together. Interrupt what you can and keep the tank in range."),
      B("Bazil Thredd", "End boss. Threat-heavy melee. Let the tank hold him; healer stay ready for sudden damage."),
    },
  },
  ["blackfathom-deeps"] = {
    id = "blackfathom-deeps",
    name = "Blackfathom Deeps",
    source = "Classic Era baseline.",
    bosses = {
      B("Ghamoo-ra", "Lots of armor and health. Be patient; don't pull extra turtles."),
      B("Lady Sarevess", "Forked lightning. Spread so it does not chain through the group."),
      B("Twilight Lord Kelris", "Sleep is the fight. Interrupt or dispel Sleep immediately or people stand still and die."),
      B("Aku'mai", "Poison and a late frenzy. Healer: dispel or heal through poison; tank, save a cooldown for the frenzy. Leech Pants can drop."),
    },
  },
  ["gnomeregan"] = {
    id = "gnomeregan",
    name = "Gnomeregan",
    source = "Classic Era baseline.",
    bosses = {
      B("Grubbis", "Comes with a trogg pack after the cave event. AoE the adds, then the boss."),
      B("Viscous Fallout", "Radiation damage over time. Healer: keep the group topped; don't linger in green pools."),
      B("Electrocutioner 6000", "Shock damage. Stay in range of the healer. Electrocutioner Lagnut can drop."),
      B("Crowd Pummeler 9-60", "Knockback. Don't stand with your back to a drop. Gnomebot Operating Boots can drop."),
      B("Mekgineer Thermaplugg", "Bomb adds and a punching attack. Kill or assign bombs; tanks keep him faced away from the group."),
    },
  },
  ["razorfen-kraul"] = {
    id = "razorfen-kraul",
    name = "Razorfen Kraul",
    source = "Classic Era baseline.",
    bosses = {
      B("Roogug", "Early boss with a pack. CC or burn extras first."),
      B("Death Speaker Jargba", "Mind Control is the danger. Line of sight or dispel it if you can; otherwise the controlled player should be pealed or sheeped.", { loot = "Death Speaker Robes" }),
      B("Overlord Ramtusk", "Heals and a pack of guards. Kill or CC the healers first."),
      B("Charlga Razorflank", "Chain Lightning and a wide room. Spread, interrupt if you can, and keep the tank in front."),
    },
  },
  ["sm-graveyard"] = {
    id = "sm-graveyard",
    name = "Scarlet Monastery: Graveyard",
    source = "Classic Era baseline.",
    bosses = {
      B("Interrogator Vishas", "A short, hard-hitting first fight. Let the tank pull; healer pre-cast."),
      B("Bloodmage Thalnos", "AoE and a fear. Stay loosely spread. Bloodmage Mantle can drop."),
    },
  },
  ["sm-library"] = {
    id = "sm-library",
    name = "Scarlet Monastery: Library",
    source = "Classic Era baseline.",
    bosses = {
      B("Houndmaster Loksey", "Hounds first, or they overwhelm the healer. CC or kill dogs, then Loksey."),
      B("Arcanist Doan", "Detonation is the wipe. When he starts the long cast, run out of the bubble, then come back in. Hypnotic Blade can drop."),
    },
  },
  ["sm-armory"] = {
    id = "sm-armory",
    name = "Scarlet Monastery: Armory",
    source = "Classic Era baseline.",
    bosses = {
      B("Herod", "Whirlwind is the fight. Everyone steps out when he spins; melee run back in after. Healer: the tank still takes hits as people move."),
    },
  },
  ["sm-cathedral"] = {
    id = "sm-cathedral",
    name = "Scarlet Monastery: Cathedral",
    source = "Classic Era baseline.",
    bosses = {
      B("Scarlet Commander Mograine", "Clear the cathedral first. When he dies, Whitemane comes in and resurrects him."),
      B("High Inquisitor Whitemane", "Burn Whitemane after she resurrects Mograine, then finish both. Sleep and a heal: interrupt the heal if you can. Whitemane's Chapeau and Triune Amulet can drop."),
    },
  },
  ["razorfen-downs"] = {
    id = "razorfen-downs",
    name = "Razorfen Downs",
    source = "Classic Era baseline.",
    bosses = {
      B("Tuten'kash", "The gong event. Don't ring it until the group is ready; waves of insects come first."),
      B("Mordresh Fire Eye", "Fire AoE. Interrupt or move out of the fire."),
      B("Amnennar the Coldbringer", "Frost and a fear. Keep the tank in front; healer dispel or heal through fear if you can. Bonefingers can drop."),
    },
  },
  ["uldaman"] = {
    id = "uldaman",
    name = "Uldaman",
    source = "Classic Era baseline.",
    bosses = {
      B("Revelosh", "First named after the entrance. Watch for patrols in the hall."),
      B("Ironaya", "A long hallway fight. Let the tank pull; healer stay back from her melee. Stoneweaver Leggings can drop."),
      B("Archaedas", "Wake him only when the group is ready. He activates add statues; kill or ignore assigned adds and stay on the boss."),
    },
  },
  ["zulfarrak"] = {
    id = "zulfarrak",
    name = "Zul'Farrak",
    source = "Classic Era baseline.",
    bosses = {
      B("Theka the Martyr", "Don't kill scarabs if the group is not ready for the hex. Straightforward otherwise."),
      B("Witch Doctor Zum'rah", "Pull from the graveyard carefully; he raises tombs. Zum'rah's Vexing Cane can drop."),
      B("Shadowpriest Sezz'ziz", "The pyramid event first: survive the waves, then the bosses. Healers stay out of avoidable damage."),
      B("Chief Ukorz Sandscalp", "Two bosses together at the end. Focus the assigned target and keep the tank up."),
    },
  },
  ["maraudon"] = {
    id = "maraudon",
    name = "Maraudon",
    source = "Classic Era baseline.",
    bosses = {
      B("Noxxion", "Splits into adds. AoE the splits, then finish him. Poison: dispel if you can."),
      B("Lord Vyletongue", "Two adds. CC or kill them first. Satyr's Lash can drop."),
      B("Celebras the Cursed", "A clean-up fight in the purple side. Straightforward once the path is clear."),
      B("Princess Theradras", "Knockback and dust. Don't stand with your back to a drop; healer watch for the knock."),
    },
  },
  ["sunken-temple"] = {
    id = "sunken-temple",
    name = "The Temple of Atal'Hakkar",
    source = "Classic Era baseline.",
    bosses = {
      B("Atal'ai Defender event", "Light the six statues in the correct order (the group should agree before starting). Wrong order means extra dragons."),
      B("Jammal'an the Prophet", "Kill or keep the pair assigned; he can hex. Healer: be ready for a sudden spike."),
      B("Shade of Eranikus", "Long dragon fight with a sleep or fear. Stay behind or to the side; don't stand in front."),
    },
  },
  ["brd"] = {
    id = "brd",
    name = "Blackrock Depths",
    source = "Classic Era baseline. This is a large instance; only the most common stops are listed.",
    bosses = {
      B("High Interrogator Gerstahn", "Near the entrance. Clear carefully; mind control is possible on some nearby casters."),
      B("Lord Incendius", "Knockback over the lava. Tank with your back to a wall, not the ledge."),
      B("Golem Lord Argelmach", "Adds and fire. Kill or CC the engineers first if they are up."),
      B("Emperor Dagran Thaurissan", "Princess Moira heals him; many groups keep her alive and control or ignore her, then stop the Emperor. Confirm the plan before the pull."),
    },
  },
  ["lbrs"] = {
    id = "lbrs",
    name = "Lower Blackrock Spire",
    source = "Classic Era baseline.",
    bosses = {
      B("Highlord Omokk", "Knockback. Don't stand near a drop."),
      B("Shadow Hunter Vosh'gajin", "Cleave and a pack. CC extras if you can."),
      B("War Master Voone", "Short, hard-hitting troll fight. Let the tank settle threat."),
      B("Overlord Wyrmthalak", "End boss with adds. Tank him away from the group; healer watch the knock. Trindlehaven Staff can drop."),
    },
  },
  ["ubrs"] = {
    id = "ubrs",
    name = "Upper Blackrock Spire",
    source = "Classic Era baseline.",
    bosses = {
      B("Pyroguard Emberseer", "Clear the room and complete the emberseer event before you start. Stay out of fire."),
      B("Rend / the stadium", "A wave event. Assign adds; don't start until the group is ready."),
      B("The Beast", "A lot of health and fire. Healer plan for a long fight."),
      B("General Drakkisath", "Adds first, then the boss. Keep the tank in front; Wildheart Vest can drop for leather wearers."),
    },
  },
  ["dire-maul"] = {
    id = "dire-maul",
    name = "Dire Maul",
    source = "Classic Era baseline. East, West, and North are different wings.",
    bosses = {
      B("Lethtendris (East)", "A caster pull with an imp. Interrupt what you can."),
      B("Alzzin the Wildshaper (East)", "He shifts forms. Stay with the tank through the changes."),
      B("Immol'thar (West)", "Kill the pylons first, then the boss. Don't start the fight early."),
      B("Prince Tortheldrin (West)", "After Immol'thar. A short, sharp melee fight."),
      B("King Gordok (North)", "A tribute run skips most bosses if you do the ogre key / tribute path. Otherwise, burn him after the last wave."),
    },
  },
  ["scholomance"] = {
    id = "scholomance",
    name = "Scholomance",
    source = "Classic Era baseline.",
    bosses = {
      B("Jandice Barov", "Illusions. Find the real one (usually slightly off-color or by nameplate) and ignore copies."),
      B("Ras Frostwhisper", "Frost and a harsh room. Interrupt what you can. Alanna's Embrace can drop."),
      B("Darkmaster Gandling", "He teleports people into side rooms. Clear a room and come back; don't leave the healer alone too long. Wildheart Cowl can drop."),
    },
  },
  ["stratholme"] = {
    id = "stratholme",
    name = "Stratholme",
    source = "Classic Era baseline. Live and undead sides are different runs.",
    bosses = {
      B("Magistrate Barthilas", "Often used as a path check. A short, hard-hitting pull."),
      B("Baroness Anastari", "Possess can hit a player. Dispel or CC the possessed person. Anastari Heirloom can drop."),
      B("Nerub'enkan / Maleki", "Undead side casters. Interrupt and don't stand in avoidable pits or ice."),
      B("Baron Rivendare", "Keep the adds or waves assigned. Healer: this is a long, spiky fight. Wildheart Kilt can drop."),
      B("Balnazzar", "Live side end. Fear and shadow; stay loosely spread. Book of the Dead can drop."),
    },
  },

  -- Forever-specific (or not yet confirmed) instances.
  ["hall-of-thanes"] = {
    id = "hall-of-thanes",
    name = "Hall of Thanes",
    tipsComing = true,
    note = "Forever dungeon under Ironforge. Boss tips are not confirmed yet. The Dwarven Tome (quest Important Heirlooms) is in this addon's loot index.",
  },
  ["ruins-of-lordaeron"] = {
    id = "ruins-of-lordaeron",
    name = "Ruins of Lordaeron",
    tipsComing = true,
    note = "Forever dungeon. Boss tips are not confirmed yet.",
  },
  ["excavation-site"] = {
    id = "excavation-site",
    name = "Excavation Site",
    tipsComing = true,
    note = "Forever dungeon in the Wetlands. Boss tips are not confirmed yet. Healer's Staff is listed as Forever loot, but the boss is not confirmed.",
  },
  ["city-of-dalaran"] = {
    id = "city-of-dalaran",
    name = "City of Dalaran",
    tipsComing = true,
    note = "Forever dungeon. Boss tips are not confirmed yet.",
  },
  ["drowned-city"] = {
    id = "drowned-city",
    name = "The Drowned City",
    tipsComing = true,
    note = "Forever dungeon. Boss tips are not confirmed yet.",
  },
  ["kroldok"] = {
    id = "kroldok",
    name = "Kroldok",
    tipsComing = true,
    note = "Forever dungeon. Boss tips are not confirmed yet.",
  },
  ["alcaz-prison"] = {
    id = "alcaz-prison",
    name = "Alcaz Prison",
    tipsComing = true,
    note = "Forever dungeon. Boss tips are not confirmed yet.",
  },
  ["blackmaw-hold"] = {
    id = "blackmaw-hold",
    name = "Blackmaw Hold",
    tipsComing = true,
    note = "Forever dungeon. Boss tips are not confirmed yet.",
  },
  ["shapers-terrace"] = {
    id = "shapers-terrace",
    name = "Shaper's Terrace",
    tipsComing = true,
    note = "Forever dungeon. Boss tips are not confirmed yet.",
  },
}
