-- Philosopher's Codex: WoW Forever Druid trainer spells
-- Levels and ranks: 60.tools /levels/druid, Forever client build 1.60.1.70888
-- (cross-checked against wowforever.one, client build 1.60.1.70532, Talents Forever export).
-- Individual trainer prices are not in the Forever client (they live on Blizzard's servers).
-- Official Forever note (Blizzard, Nov 2 2026): training every class ability from 1 to 60
-- costs about 206-207 gold. No per-rank Forever prices are shipped here.
-- Not on this trainer list (absent from 60.tools 1.60.1.70888): Faerie Fire (Feral),
-- Tiger's Fury, and talent-only ranks such as Insect Swarm and Wild Growth.
-- Recommendation tags are computed in RecommendTrainerSpell, not hard-coded per rank.

PhilosophersCodexData = PhilosophersCodexData or {}

PhilosophersCodexData.SPELL_SOURCE = {
  build = "1.60.1.70888",
  primary = "https://www.60.tools/levels/druid",
  crossCheck = "https://wowforever.one/classes/druid/spells/",
  totalGoldNote = "Blizzard Nov 2 2026: all class abilities 1-60 cost about 206-207 gold.",
}

-- n=name, r=rank or nil, l=level, s=school, new=Forever-new, note=Forever-specific note
PhilosophersCodexData.TRAINER_SPELLS = {
  { n="Wrath", r=1, l=1, s="Balance" },
  { n="Healing Touch", r=1, l=1, s="Restoration" },
  { n="Mark of the Wild", r=1, l=1, s="Restoration" },
  { n="Moonfire", r=1, l=4, s="Balance" },
  { n="Rejuvenation", r=1, l=4, s="Restoration" },
  { n="Thorns", r=1, l=6, s="Balance" },
  { n="Wrath", r=2, l=6, s="Balance" },
  { n="Entangling Roots", r=1, l=8, s="Balance" },
  { n="Healing Touch", r=2, l=8, s="Restoration" },
  { n="Nature's Grasp", r=1, l=10, s="Balance", note="Trained at 10 in Forever; this was a talent in Classic Era." },
  { n="Teleport: Moonglade", l=10, s="Balance" },
  { n="Bear Form", l=10, s="Feral Combat", note="Listed as a trainer shapeshift in Forever. The class quest may still exist; if you already know it, this is done." },
  { n="Demoralizing Roar", r=1, l=10, s="Feral Combat" },
  { n="Growl", l=10, s="Feral Combat" },
  { n="Maul", r=1, l=10, s="Feral Combat" },
  { n="Mark of the Wild", r=2, l=10, s="Restoration" },
  { n="Moonfire", r=2, l=10, s="Balance" },
  { n="Rejuvenation", r=2, l=10, s="Restoration" },
  { n="Enrage", l=12, s="Feral Combat" },
  { n="Regrowth", r=1, l=12, s="Restoration" },
  { n="Revive", r=1, l=12, s="Restoration", new=true, note="New Forever ability (not in Classic Era)." },
  { n="Bash", r=1, l=14, s="Feral Combat" },
  { n="Cure Poison", l=14, s="Restoration", note="Listed as a trainer spell in Forever (60.tools, build 1.60.1.70888). In Classic Era it was a class quest (Lessons Anew)." },
  { n="Healing Touch", r=3, l=14, s="Restoration" },
  { n="Thorns", r=2, l=14, s="Balance" },
  { n="Wrath", r=3, l=14, s="Balance" },
  { n="Aquatic Form", l=16, s="Feral Combat", note="Listed as a trainer shapeshift in Forever. The class quest may still exist; if you already know it, this is done." },
  { n="Swipe", r=1, l=16, s="Feral Combat" },
  { n="Moonfire", r=3, l=16, s="Balance" },
  { n="Rejuvenation", r=3, l=16, s="Restoration" },
  { n="Faerie Fire", r=1, l=18, s="Balance", note="In Forever, Faerie Fire works in Cat, Bear, and Dire Bear Form. Faerie Fire (Feral) is not on the Forever trainer list." },
  { n="Hibernate", r=1, l=18, s="Balance" },
  { n="Entangling Roots", r=2, l=18, s="Balance" },
  { n="Maul", r=2, l=18, s="Feral Combat" },
  { n="Nature's Grasp", r=2, l=18, s="Balance", note="Trained at 10 in Forever; this was a talent in Classic Era." },
  { n="Regrowth", r=2, l=18, s="Restoration" },
  { n="Starfire", r=1, l=20, s="Balance" },
  { n="Cat Form", l=20, s="Feral Combat", note="Listed as a trainer shapeshift in Forever. The class quest may still exist; if you already know it, this is done." },
  { n="Claw", r=1, l=20, s="Feral Combat" },
  { n="Prowl", r=1, l=20, s="Feral Combat" },
  { n="Rip", r=1, l=20, s="Feral Combat" },
  { n="Shred", r=1, l=20, s="Feral Combat" },
  { n="Rebirth", r=1, l=20, s="Restoration" },
  { n="Demoralizing Roar", r=2, l=20, s="Feral Combat" },
  { n="Healing Touch", r=4, l=20, s="Restoration" },
  { n="Mark of the Wild", r=3, l=20, s="Restoration" },
  { n="Soothe Animal", r=1, l=22, s="Feral Combat" },
  { n="Moonfire", r=4, l=22, s="Balance" },
  { n="Rejuvenation", r=4, l=22, s="Restoration" },
  { n="Wrath", r=4, l=22, s="Balance" },
  { n="Ferocious Bite", r=1, l=24, s="Feral Combat" },
  { n="Rake", r=1, l=24, s="Feral Combat" },
  { n="Remove Curse", l=24, s="Restoration" },
  { n="Regrowth", r=3, l=24, s="Restoration" },
  { n="Revive", r=2, l=24, s="Restoration", new=true, note="New Forever ability (not in Classic Era)." },
  { n="Swipe", r=2, l=24, s="Feral Combat" },
  { n="Thorns", r=3, l=24, s="Balance" },
  { n="Abolish Poison", l=26, s="Restoration" },
  { n="Healing Touch", r=5, l=26, s="Restoration" },
  { n="Maul", r=3, l=26, s="Feral Combat" },
  { n="Starfire", r=2, l=26, s="Balance" },
  { n="Challenging Roar", l=28, s="Feral Combat" },
  { n="Cower", r=1, l=28, s="Feral Combat" },
  { n="Claw", r=2, l=28, s="Feral Combat" },
  { n="Entangling Roots", r=3, l=28, s="Balance" },
  { n="Moonfire", r=5, l=28, s="Balance" },
  { n="Nature's Grasp", r=3, l=28, s="Balance", note="Trained at 10 in Forever; this was a talent in Classic Era." },
  { n="Rejuvenation", r=5, l=28, s="Restoration" },
  { n="Rip", r=2, l=28, s="Feral Combat" },
  { n="Travel Form", l=30, s="Feral Combat" },
  { n="Tranquility", r=1, l=30, s="Restoration" },
  { n="Bash", r=2, l=30, s="Feral Combat" },
  { n="Faerie Fire", r=2, l=30, s="Balance", note="In Forever, Faerie Fire works in Cat, Bear, and Dire Bear Form. Faerie Fire (Feral) is not on the Forever trainer list." },
  { n="Mark of the Wild", r=4, l=30, s="Restoration" },
  { n="Rebirth", r=2, l=30, s="Restoration" },
  { n="Regrowth", r=4, l=30, s="Restoration" },
  { n="Shred", r=2, l=30, s="Feral Combat" },
  { n="Wrath", r=5, l=30, s="Balance" },
  { n="Ravage", r=1, l=32, s="Feral Combat" },
  { n="Demoralizing Roar", r=3, l=32, s="Feral Combat" },
  { n="Ferocious Bite", r=2, l=32, s="Feral Combat" },
  { n="Healing Touch", r=6, l=32, s="Restoration" },
  { n="Maul", r=4, l=34, s="Feral Combat" },
  { n="Moonfire", r=6, l=34, s="Balance" },
  { n="Rake", r=2, l=34, s="Feral Combat" },
  { n="Rejuvenation", r=6, l=34, s="Restoration" },
  { n="Starfire", r=3, l=34, s="Balance" },
  { n="Swipe", r=3, l=34, s="Feral Combat" },
  { n="Thorns", r=4, l=34, s="Balance" },
  { n="Frenzied Regeneration", l=36, s="Feral Combat" },
  { n="Pounce", r=1, l=36, s="Feral Combat" },
  { n="Regrowth", r=5, l=36, s="Restoration" },
  { n="Revive", r=3, l=36, s="Restoration", new=true, note="New Forever ability (not in Classic Era)." },
  { n="Rip", r=3, l=36, s="Feral Combat" },
  { n="Claw", r=3, l=38, s="Feral Combat" },
  { n="Entangling Roots", r=4, l=38, s="Balance" },
  { n="Healing Touch", r=7, l=38, s="Restoration" },
  { n="Hibernate", r=2, l=38, s="Balance" },
  { n="Nature's Grasp", r=4, l=38, s="Balance", note="Trained at 10 in Forever; this was a talent in Classic Era." },
  { n="Shred", r=3, l=38, s="Feral Combat" },
  { n="Soothe Animal", r=2, l=38, s="Feral Combat" },
  { n="Wrath", r=6, l=38, s="Balance" },
  { n="Hurricane", r=1, l=40, s="Balance" },
  { n="Dire Bear Form", l=40, s="Feral Combat" },
  { n="Innervate", l=40, s="Restoration" },
  { n="Cower", r=2, l=40, s="Feral Combat" },
  { n="Ferocious Bite", r=3, l=40, s="Feral Combat" },
  { n="Mark of the Wild", r=5, l=40, s="Restoration" },
  { n="Moonfire", r=7, l=40, s="Balance" },
  { n="Prowl", r=2, l=40, s="Feral Combat" },
  { n="Rebirth", r=3, l=40, s="Restoration" },
  { n="Rejuvenation", r=7, l=40, s="Restoration" },
  { n="Tranquility", r=2, l=40, s="Restoration" },
  { n="Demoralizing Roar", r=4, l=42, s="Feral Combat" },
  { n="Faerie Fire", r=3, l=42, s="Balance", note="In Forever, Faerie Fire works in Cat, Bear, and Dire Bear Form. Faerie Fire (Feral) is not on the Forever trainer list." },
  { n="Maul", r=5, l=42, s="Feral Combat" },
  { n="Ravage", r=2, l=42, s="Feral Combat" },
  { n="Regrowth", r=6, l=42, s="Restoration" },
  { n="Starfire", r=4, l=42, s="Balance" },
  { n="Barkskin", l=44, s="Restoration" },
  { n="Healing Touch", r=8, l=44, s="Restoration" },
  { n="Rake", r=3, l=44, s="Feral Combat" },
  { n="Rip", r=4, l=44, s="Feral Combat" },
  { n="Swipe", r=4, l=44, s="Feral Combat" },
  { n="Thorns", r=5, l=44, s="Balance" },
  { n="Bash", r=3, l=46, s="Feral Combat" },
  { n="Moonfire", r=8, l=46, s="Balance" },
  { n="Pounce", r=2, l=46, s="Feral Combat" },
  { n="Rejuvenation", r=8, l=46, s="Restoration" },
  { n="Shred", r=4, l=46, s="Feral Combat" },
  { n="Wrath", r=7, l=46, s="Balance" },
  { n="Claw", r=4, l=48, s="Feral Combat" },
  { n="Entangling Roots", r=5, l=48, s="Balance" },
  { n="Ferocious Bite", r=4, l=48, s="Feral Combat" },
  { n="Nature's Grasp", r=5, l=48, s="Balance", note="Trained at 10 in Forever; this was a talent in Classic Era." },
  { n="Regrowth", r=7, l=48, s="Restoration" },
  { n="Revive", r=4, l=48, s="Restoration", new=true, note="New Forever ability (not in Classic Era)." },
  { n="Gift of the Wild", r=1, l=50, s="Restoration" },
  { n="Healing Touch", r=9, l=50, s="Restoration" },
  { n="Hurricane", r=2, l=50, s="Balance" },
  { n="Mark of the Wild", r=6, l=50, s="Restoration" },
  { n="Maul", r=6, l=50, s="Feral Combat" },
  { n="Ravage", r=3, l=50, s="Feral Combat" },
  { n="Rebirth", r=4, l=50, s="Restoration" },
  { n="Starfire", r=5, l=50, s="Balance" },
  { n="Tranquility", r=3, l=50, s="Restoration" },
  { n="Cower", r=3, l=52, s="Feral Combat" },
  { n="Demoralizing Roar", r=5, l=52, s="Feral Combat" },
  { n="Moonfire", r=9, l=52, s="Balance" },
  { n="Rejuvenation", r=9, l=52, s="Restoration" },
  { n="Rip", r=5, l=52, s="Feral Combat" },
  { n="Faerie Fire", r=4, l=54, s="Balance", note="In Forever, Faerie Fire works in Cat, Bear, and Dire Bear Form. Faerie Fire (Feral) is not on the Forever trainer list." },
  { n="Rake", r=4, l=54, s="Feral Combat" },
  { n="Regrowth", r=8, l=54, s="Restoration" },
  { n="Shred", r=5, l=54, s="Feral Combat" },
  { n="Soothe Animal", r=3, l=54, s="Feral Combat" },
  { n="Swipe", r=5, l=54, s="Feral Combat" },
  { n="Thorns", r=6, l=54, s="Balance" },
  { n="Wrath", r=8, l=54, s="Balance" },
  { n="Ferocious Bite", r=5, l=56, s="Feral Combat" },
  { n="Healing Touch", r=10, l=56, s="Restoration" },
  { n="Pounce", r=3, l=56, s="Feral Combat" },
  { n="Claw", r=5, l=58, s="Feral Combat" },
  { n="Entangling Roots", r=6, l=58, s="Balance" },
  { n="Hibernate", r=3, l=58, s="Balance" },
  { n="Maul", r=7, l=58, s="Feral Combat" },
  { n="Moonfire", r=10, l=58, s="Balance" },
  { n="Nature's Grasp", r=6, l=58, s="Balance", note="Trained at 10 in Forever; this was a talent in Classic Era." },
  { n="Ravage", r=4, l=58, s="Feral Combat" },
  { n="Rejuvenation", r=10, l=58, s="Restoration" },
  { n="Starfire", r=6, l=58, s="Balance" },
  { n="Ferocious Bite", r=6, l=60, s="Feral Combat" },
  { n="Gift of the Wild", r=2, l=60, s="Restoration" },
  { n="Healing Touch", r=11, l=60, s="Restoration" },
  { n="Hurricane", r=3, l=60, s="Balance" },
  { n="Mark of the Wild", r=7, l=60, s="Restoration" },
  { n="Prowl", r=3, l=60, s="Feral Combat" },
  { n="Rebirth", r=5, l=60, s="Restoration" },
  { n="Regrowth", r=9, l=60, s="Restoration" },
  { n="Rejuvenation", r=11, l=60, s="Restoration" },
  { n="Revive", r=5, l=60, s="Restoration", new=true, note="New Forever ability (not in Classic Era)." },
  { n="Rip", r=6, l=60, s="Feral Combat" },
  { n="Starfire", r=7, l=60, s="Balance" },
  { n="Tranquility", r=4, l=60, s="Restoration" },
}

local FERAL_SKIP = {
  Maul = true, Swipe = true, Growl = true, ["Demoralizing Roar"] = true,
  ["Challenging Roar"] = true, Enrage = true, ["Frenzied Regeneration"] = true,
  Bash = true, Claw = true, Shred = true, Rip = true, Rake = true,
  ["Ferocious Bite"] = true, Ravage = true, Pounce = true, Prowl = true, Cower = true,
}

local FERAL_FORMS = {
  ["Bear Form"] = true, ["Cat Form"] = true, ["Dire Bear Form"] = true,
}

-- Utility and group tools both roles need, including first ranks of the core kit.
local MUST_NAMES = {
  ["Mark of the Wild"] = true, ["Gift of the Wild"] = true,
  ["Teleport: Moonglade"] = true, ["Travel Form"] = true, ["Aquatic Form"] = true,
  ["Remove Curse"] = true, ["Cure Poison"] = true, ["Abolish Poison"] = true,
  Barkskin = true, Rebirth = true, Revive = true, Innervate = true,
}

local CORE_FIRST_MUST = {
  Wrath = true, Moonfire = true, Starfire = true, ["Healing Touch"] = true,
  Rejuvenation = true, Regrowth = true, ["Entangling Roots"] = true,
  ["Faerie Fire"] = true, ["Nature's Grasp"] = true, Thorns = true,
  Tranquility = true,
}

local HEAL_NAMES = {
  ["Healing Touch"] = true, Rejuvenation = true, Regrowth = true,
  Tranquility = true, Revive = true, Rebirth = true,
}

local BALANCE_NAMES = {
  Wrath = true, Moonfire = true, Starfire = true, Hurricane = true,
  Thorns = true, ["Entangling Roots"] = true, ["Faerie Fire"] = true,
  Hibernate = true, ["Nature's Grasp"] = true,
}

-- Tags follow a Balance-questing + Restoration-dungeon plan (later dual spec).
-- Sources cited in the README: Wowhead Forever Balance leveling guide, and
-- standard Classic/Forever advice to skip Feral ranks until you tank or go cat.
function PhilosophersCodexData.RecommendTrainerSpell(spell)
  if not spell or not spell.n then
    return "skip", "Unknown spell."
  end
  local name, rank = spell.n, spell.r
  if FERAL_SKIP[name] then
    return "skip", "Feral damage or threat -- skip while you quest as Balance and heal as Restoration."
  end
  if FERAL_FORMS[name] then
    return "skip", "Bear or cat form. Keep it if you already have it from a class quest; skip training unless you start tanking."
  end
  if name == "Soothe Animal" then
    return "skip", "Niche beast crowd control. Skip unless you need it for a specific quest or rare."
  end
  if MUST_NAMES[name] then
    return "must", "Core utility for both questing and dungeon healing. Train this."
  end
  if (not rank or rank == 1) and CORE_FIRST_MUST[name] then
    return "must", "First rank of a spell you will use while questing or healing. Train it."
  end
  if HEAL_NAMES[name] then
    return "heal", "Restoration rank -- train for dungeon healing (and later dual spec)."
  end
  if BALANCE_NAMES[name] then
    return "balance", "Balance rank -- train to keep your questing rotation current."
  end
  if spell.s == "Restoration" then
    return "heal", "Restoration spell -- train if you heal dungeons."
  end
  if spell.s == "Balance" then
    return "balance", "Balance spell -- train if you quest as Balance."
  end
  return "skip", "Not needed for Balance questing or Restoration healing right now."
end


PhilosophersCodexData.SPELLS = PhilosophersCodexData.SPELLS or {}
PhilosophersCodexData.SPELLS.DRUID = {
  source = PhilosophersCodexData.SPELL_SOURCE,
  list = PhilosophersCodexData.TRAINER_SPELLS,
  Recommend = PhilosophersCodexData.RecommendTrainerSpell,
}
