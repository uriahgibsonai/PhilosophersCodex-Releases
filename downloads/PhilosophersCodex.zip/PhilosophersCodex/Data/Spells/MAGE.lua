-- Philosopher's Codex: WoW Forever Mage trainer spells
-- Levels and ranks: 60.tools /levels/mage, Forever client build 1.60.1.70888
-- (cross-checked against wowhandbook.com Mage spellbook, client 1.60.1.70938).
-- Individual trainer prices are not in the Forever client.

PhilosophersCodexData = PhilosophersCodexData or {}
PhilosophersCodexData.SPELLS = PhilosophersCodexData.SPELLS or {}

local SOURCE = {
  build = "1.60.1.70888",
  primary = "https://www.60.tools/levels/mage",
  crossCheck = "https://wowhandbook.com/classes/mage/spellbook/",
  totalGoldNote = "Blizzard Nov 2 2026: all class abilities 1-60 cost about 206-207 gold.",
}

local LIST = {
  { n="Arcane Intellect", r=1, l=1, s="Arcane" },
  { n="Fireball", r=1, l=1, s="Fire" },
  { n="Chilled", l=1, s="Frost", note="Listed at level 1 on 60.tools. This is the Frost Armor chill effect in Classic; it may not be a spell you buy. Marked unverified as a trainer ability." },
  { n="Frost Armor", r=1, l=1, s="Frost" },
  { n="Conjure Water", r=1, l=4, s="Arcane" },
  { n="Frostbolt", r=1, l=4, s="Frost" },
  { n="Conjure Food", r=1, l=6, s="Arcane" },
  { n="Fire Blast", r=1, l=6, s="Fire" },
  { n="Fireball", r=2, l=6, s="Fire" },
  { n="Arcane Missiles", r=1, l=8, s="Arcane" },
  { n="Polymorph", r=1, l=8, s="Arcane" },
  { n="Frostbolt", r=2, l=8, s="Frost" },
  { n="Frost Nova", r=1, l=10, s="Frost" },
  { n="Conjure Water", r=2, l=10, s="Arcane" },
  { n="Frost Armor", r=2, l=10, s="Frost" },
  { n="Dampen Magic", r=1, l=12, s="Arcane" },
  { n="Slow Fall", l=12, s="Arcane" },
  { n="Conjure Food", r=2, l=12, s="Arcane" },
  { n="Fireball", r=3, l=12, s="Fire" },
  { n="Arcane Explosion", r=1, l=14, s="Arcane" },
  { n="Arcane Intellect", r=2, l=14, s="Arcane" },
  { n="Fire Blast", r=2, l=14, s="Fire" },
  { n="Frostbolt", r=3, l=14, s="Frost" },
  { n="Flamestrike", r=1, l=16, s="Fire" },
  { n="Arcane Missiles", r=2, l=16, s="Arcane" },
  { n="Amplify Magic", r=1, l=18, s="Arcane" },
  { n="Remove Lesser Curse", l=18, s="Arcane" },
  { n="Fireball", r=4, l=18, s="Fire" },
  { n="Blink", l=20, s="Arcane" },
  { n="Evocation", l=20, s="Arcane" },
  { n="Mana Shield", r=1, l=20, s="Arcane" },
  { n="Teleport: Ironforge", l=20, s="Arcane" },
  { n="Teleport: Orgrimmar", l=20, s="Arcane" },
  { n="Teleport: Stormwind", l=20, s="Arcane" },
  { n="Teleport: Undercity", l=20, s="Arcane" },
  { n="Fire Ward", r=1, l=20, s="Fire" },
  { n="Blizzard", r=1, l=20, s="Frost" },
  { n="Conjure Water", r=3, l=20, s="Arcane" },
  { n="Frost Armor", r=3, l=20, s="Frost" },
  { n="Frostbolt", r=4, l=20, s="Frost" },
  { n="Polymorph", r=2, l=20, s="Arcane" },
  { n="Scorch", r=1, l=22, s="Fire" },
  { n="Frost Ward", r=1, l=22, s="Frost" },
  { n="Arcane Explosion", r=2, l=22, s="Arcane" },
  { n="Conjure Food", r=3, l=22, s="Arcane" },
  { n="Fire Blast", r=3, l=22, s="Fire" },
  { n="Counterspell", l=24, s="Arcane" },
  { n="Arcane Missiles", r=3, l=24, s="Arcane" },
  { n="Dampen Magic", r=2, l=24, s="Arcane" },
  { n="Fireball", r=5, l=24, s="Fire" },
  { n="Flamestrike", r=2, l=24, s="Fire" },
  { n="Cone of Cold", r=1, l=26, s="Frost" },
  { n="Frost Nova", r=2, l=26, s="Frost" },
  { n="Frostbolt", r=5, l=26, s="Frost" },
  { n="Conjure Mana Agate", l=28, s="Arcane" },
  { n="Arcane Intellect", r=3, l=28, s="Arcane" },
  { n="Blizzard", r=2, l=28, s="Frost" },
  { n="Mana Shield", r=2, l=28, s="Arcane" },
  { n="Scorch", r=2, l=28, s="Fire" },
  { n="Teleport: Darnassus", l=30, s="Arcane" },
  { n="Teleport: Thunder Bluff", l=30, s="Arcane" },
  { n="Ice Armor", r=1, l=30, s="Frost" },
  { n="Amplify Magic", r=2, l=30, s="Arcane" },
  { n="Arcane Explosion", r=3, l=30, s="Arcane" },
  { n="Conjure Water", r=4, l=30, s="Arcane" },
  { n="Fire Blast", r=4, l=30, s="Fire" },
  { n="Fire Ward", r=2, l=30, s="Fire" },
  { n="Fireball", r=6, l=30, s="Fire" },
  { n="Arcane Missiles", r=4, l=32, s="Arcane" },
  { n="Conjure Food", r=4, l=32, s="Arcane" },
  { n="Flamestrike", r=3, l=32, s="Fire" },
  { n="Frost Ward", r=2, l=32, s="Frost" },
  { n="Frostbolt", r=6, l=32, s="Frost" },
  { n="Mage Armor", r=1, l=34, s="Arcane" },
  { n="Cone of Cold", r=2, l=34, s="Frost" },
  { n="Scorch", r=3, l=34, s="Fire" },
  { n="Blizzard", r=3, l=36, s="Frost" },
  { n="Dampen Magic", r=3, l=36, s="Arcane" },
  { n="Fireball", r=7, l=36, s="Fire" },
  { n="Mana Shield", r=3, l=36, s="Arcane" },
  { n="Conjure Mana Jade", l=38, s="Arcane" },
  { n="Arcane Explosion", r=4, l=38, s="Arcane" },
  { n="Fire Blast", r=5, l=38, s="Fire" },
  { n="Frostbolt", r=7, l=38, s="Frost" },
  { n="Portal: Ironforge", l=40, s="Arcane" },
  { n="Portal: Orgrimmar", l=40, s="Arcane" },
  { n="Portal: Stormwind", l=40, s="Arcane" },
  { n="Portal: Undercity", l=40, s="Arcane" },
  { n="Frostfire Bolt", r=1, l=40, s="Fire", new=true, note="New Forever trainer spell (60.tools, build 1.60.1.70888)." },
  { n="Arcane Missiles", r=5, l=40, s="Arcane" },
  { n="Conjure Water", r=5, l=40, s="Arcane" },
  { n="Fire Ward", r=3, l=40, s="Fire" },
  { n="Flamestrike", r=4, l=40, s="Fire" },
  { n="Frost Nova", r=3, l=40, s="Frost" },
  { n="Ice Armor", r=2, l=40, s="Frost" },
  { n="Polymorph", r=3, l=40, s="Arcane" },
  { n="Scorch", r=4, l=40, s="Fire" },
  { n="Amplify Magic", r=3, l=42, s="Arcane" },
  { n="Arcane Intellect", r=4, l=42, s="Arcane" },
  { n="Cone of Cold", r=3, l=42, s="Frost" },
  { n="Conjure Food", r=5, l=42, s="Arcane" },
  { n="Fireball", r=8, l=42, s="Fire" },
  { n="Frost Ward", r=3, l=42, s="Frost" },
  { n="Blizzard", r=4, l=44, s="Frost" },
  { n="Frostbolt", r=8, l=44, s="Frost" },
  { n="Mana Shield", r=4, l=44, s="Arcane" },
  { n="Arcane Explosion", r=5, l=46, s="Arcane" },
  { n="Fire Blast", r=6, l=46, s="Fire" },
  { n="Mage Armor", r=2, l=46, s="Arcane" },
  { n="Scorch", r=5, l=46, s="Fire" },
  { n="Conjure Mana Citrine", l=48, s="Arcane" },
  { n="Arcane Missiles", r=6, l=48, s="Arcane" },
  { n="Dampen Magic", r=4, l=48, s="Arcane" },
  { n="Fireball", r=9, l=48, s="Fire" },
  { n="Flamestrike", r=5, l=48, s="Fire" },
  { n="Portal: Darnassus", l=50, s="Arcane" },
  { n="Portal: Thunder Bluff", l=50, s="Arcane" },
  { n="Teleport: Dalaran", l=50, s="Arcane", note="Alliance-side Teleport: Dalaran is listed at 50 in Forever trainer data (60.tools / wowhandbook, build 1.60.x)." },
  { n="Cone of Cold", r=4, l=50, s="Frost" },
  { n="Conjure Water", r=6, l=50, s="Arcane" },
  { n="Fire Ward", r=4, l=50, s="Fire" },
  { n="Frostbolt", r=9, l=50, s="Frost" },
  { n="Frostfire Bolt", r=2, l=50, s="Fire", new=true, note="New Forever trainer spell (60.tools, build 1.60.1.70888)." },
  { n="Ice Armor", r=3, l=50, s="Frost" },
  { n="Blizzard", r=5, l=52, s="Frost" },
  { n="Conjure Food", r=6, l=52, s="Arcane" },
  { n="Frost Ward", r=4, l=52, s="Frost" },
  { n="Mana Shield", r=5, l=52, s="Arcane" },
  { n="Scorch", r=6, l=52, s="Fire" },
  { n="Amplify Magic", r=4, l=54, s="Arcane" },
  { n="Arcane Explosion", r=6, l=54, s="Arcane" },
  { n="Fire Blast", r=7, l=54, s="Fire" },
  { n="Fireball", r=10, l=54, s="Fire" },
  { n="Frost Nova", r=4, l=54, s="Frost" },
  { n="Arcane Brilliance", l=56, s="Arcane" },
  { n="Arcane Intellect", r=5, l=56, s="Arcane" },
  { n="Arcane Missiles", r=7, l=56, s="Arcane" },
  { n="Arcane Missiles", r=8, l=56, s="Arcane" },
  { n="Flamestrike", r=6, l=56, s="Fire" },
  { n="Frostbolt", r=10, l=56, s="Frost" },
  { n="Conjure Mana Ruby", l=58, s="Arcane" },
  { n="Cone of Cold", r=5, l=58, s="Frost" },
  { n="Mage Armor", r=3, l=58, s="Arcane" },
  { n="Scorch", r=7, l=58, s="Fire" },
  { n="Polymorph: Cow", l=60, s="Arcane", new=true, note="New Forever trainer spell at 60 (60.tools, build 1.60.1.70888)." },
  { n="Blizzard", r=6, l=60, s="Frost" },
  { n="Conjure Food", r=7, l=60, s="Arcane" },
  { n="Conjure Water", r=7, l=60, s="Arcane" },
  { n="Dampen Magic", r=5, l=60, s="Arcane" },
  { n="Fire Ward", r=5, l=60, s="Fire" },
  { n="Fireball", r=11, l=60, s="Fire" },
  { n="Fireball", r=12, l=60, s="Fire" },
  { n="Frost Ward", r=5, l=60, s="Frost" },
  { n="Frostbolt", r=11, l=60, s="Frost" },
  { n="Frostfire Bolt", r=3, l=60, s="Fire", new=true, note="New Forever trainer spell (60.tools, build 1.60.1.70888)." },
  { n="Ice Armor", r=4, l=60, s="Frost" },
  { n="Mana Shield", r=6, l=60, s="Arcane" },
  { n="Polymorph", r=4, l=60, s="Arcane" },
}

-- Frost leveling is the default Mage plan: Frostbolt, freeze tools, wand
-- finishing, and AoE (Blizzard, Arcane Explosion, Flamestrike) for packs.
-- Sources: Wowhead Forever Frost overview, wowfdb Frost 1-60 leveling guide.
local HORDE_CITY = {
  ["Teleport: Orgrimmar"] = true, ["Teleport: Undercity"] = true, ["Teleport: Thunder Bluff"] = true,
  ["Portal: Orgrimmar"] = true, ["Portal: Undercity"] = true, ["Portal: Thunder Bluff"] = true,
}
local ALLIANCE_CITY = {
  ["Teleport: Ironforge"] = true, ["Teleport: Stormwind"] = true, ["Teleport: Darnassus"] = true,
  ["Teleport: Dalaran"] = true,
  ["Portal: Ironforge"] = true, ["Portal: Stormwind"] = true, ["Portal: Darnassus"] = true,
}
local MUST = {
  ["Arcane Intellect"] = true, ["Arcane Brilliance"] = true,
  ["Conjure Water"] = true, ["Conjure Food"] = true,
  ["Frostbolt"] = true, ["Frost Armor"] = true, ["Ice Armor"] = true,
  ["Frost Nova"] = true, ["Blink"] = true, ["Evocation"] = true,
  ["Polymorph"] = true, ["Counterspell"] = true, ["Remove Lesser Curse"] = true,
  ["Slow Fall"] = true, ["Mana Shield"] = true, ["Mage Armor"] = true,
  ["Conjure Mana Agate"] = true, ["Conjure Mana Jade"] = true,
  ["Conjure Mana Citrine"] = true, ["Conjure Mana Ruby"] = true,
}
local CORE_FIRST = {
  ["Frostbolt"] = true, ["Frost Armor"] = true, ["Fireball"] = true,
  ["Conjure Water"] = true, ["Conjure Food"] = true, ["Fire Blast"] = true,
  ["Arcane Missiles"] = true, ["Frost Nova"] = true, ["Blizzard"] = true,
  ["Cone of Cold"] = true, ["Arcane Explosion"] = true, ["Flamestrike"] = true,
}
local FROST = {
  ["Frostbolt"] = true, ["Frost Armor"] = true, ["Ice Armor"] = true,
  ["Frost Nova"] = true, ["Frost Ward"] = true, ["Cone of Cold"] = true,
  ["Blizzard"] = true, ["Frostfire Bolt"] = true,
}
local AOE = {
  ["Arcane Explosion"] = true, ["Flamestrike"] = true, ["Blizzard"] = true, ["Cone of Cold"] = true,
}
local FIRE = {
  ["Fireball"] = true, ["Fire Blast"] = true, ["Scorch"] = true, ["Fire Ward"] = true, ["Flamestrike"] = true,
}

local function Recommend(spell)
  if not spell or not spell.n then
    return "skip", "Unknown spell."
  end
  local name, rank = spell.n, spell.r
  if name == "Chilled" then
    return "skip", "Listed as the Frost Armor chill effect, not a spell you typically buy."
  end
  if HORDE_CITY[name] then
    return "skip", "Horde city teleport or portal -- skip on an Alliance character."
  end
  if ALLIANCE_CITY[name] then
    return "must", "Alliance teleport or portal -- train it so you can move yourself and the guild."
  end
  if MUST[name] then
    return "must", "Core utility or the Frost leveling kit. Train this."
  end
  if (not rank or rank == 1) and CORE_FIRST[name] then
    return "must", "First rank of a spell you will use while leveling as Frost or for AoE packs."
  end
  if AOE[name] and name ~= "Fireball" then
    return "aoe", "AoE rank for grinding packs (Blizzard, Explosion, Flamestrike, Cone of Cold)."
  end
  if FROST[name] then
    return "frost", "Frost rank -- keep your leveling bolt and freeze tools current."
  end
  if FIRE[name] then
    return "fire", "Fire rank -- skip while you level as Frost unless you want a Fire off-spec or AoE."
  end
  if spell.s == "Frost" then
    return "frost", "Frost spell -- train if you level as Frost."
  end
  if spell.s == "Fire" then
    return "fire", "Fire spell -- optional while you level as Frost."
  end
  return "must", "Useful Mage utility. Train it unless a more specific tag applies."
end


PhilosophersCodexData.SPELLS.MAGE = {
  source = SOURCE,
  list = LIST,
  Recommend = Recommend,
}
