-- Philosopher's Codex: Rogue trainer spells
-- Levels and ranks: 60.tools /levels/rogue (Forever client data), checked 2026-11-19.
-- Individual trainer prices are not in the Forever client.

PhilosophersCodexData = PhilosophersCodexData or {}
PhilosophersCodexData.SPELLS = PhilosophersCodexData.SPELLS or {}

local SOURCE = {
  build = "Forever (60.tools)",
  primary = "https://www.60.tools/levels/rogue",
  totalGoldNote = "Blizzard Nov 2 2026: all class abilities 1-60 cost about 206-207 gold.",
}

local LIST = {
  { n="Eviscerate", r=1, l=1, s="Assassination" },
  { n="Sinister Strike", r=1, l=1, s="Combat" },
  { n="Stealth", r=1, l=1, s="Subtlety" },
  { n="Backstab", r=1, l=4, s="Combat" },
  { n="Pick Pocket", l=4, s="Subtlety" },
  { n="Gouge", r=1, l=6, s="Combat" },
  { n="Sinister Strike", r=2, l=6, s="Combat" },
  { n="Evasion", l=8, s="Combat" },
  { n="Eviscerate", r=2, l=8, s="Assassination" },
  { n="Slice and Dice", r=1, l=10, s="Assassination" },
  { n="Sprint", r=1, l=10, s="Combat" },
  { n="Sap", r=1, l=10, s="Subtlety" },
  { n="Kick", r=1, l=12, s="Combat" },
  { n="Backstab", r=2, l=12, s="Combat" },
  { n="Expose Armor", r=1, l=14, s="Assassination" },
  { n="Garrote", r=1, l=14, s="Assassination" },
  { n="Sinister Strike", r=3, l=14, s="Combat" },
  { n="Feint", r=1, l=16, s="Combat" },
  { n="Eviscerate", r=3, l=16, s="Assassination" },
  { n="Ambush", r=1, l=18, s="Subtlety" },
  { n="Gouge", r=2, l=18, s="Combat" },
  { n="Rupture", r=1, l=20, s="Assassination" },
  { n="Backstab", r=3, l=20, s="Combat" },
  { n="Stealth", r=2, l=20, s="Subtlety" },
  { n="Distract", l=22, s="Subtlety" },
  { n="Vanish", r=1, l=22, s="Subtlety" },
  { n="Garrote", r=2, l=22, s="Assassination" },
  { n="Sinister Strike", r=4, l=22, s="Combat" },
  { n="Eviscerate", r=4, l=24, s="Assassination" },
  { n="Cheap Shot", l=26, s="Subtlety" },
  { n="Ambush", r=2, l=26, s="Subtlety" },
  { n="Expose Armor", r=2, l=26, s="Assassination" },
  { n="Kick", r=2, l=26, s="Combat" },
  { n="Backstab", r=4, l=28, s="Combat" },
  { n="Feint", r=2, l=28, s="Combat" },
  { n="Rupture", r=2, l=28, s="Assassination" },
  { n="Sap", r=2, l=28, s="Subtlety" },
  { n="Kidney Shot", r=1, l=30, s="Assassination" },
  { n="Disarm Trap", l=30, s="Subtlety" },
  { n="Garrote", r=3, l=30, s="Assassination" },
  { n="Sinister Strike", r=5, l=30, s="Combat" },
  { n="Eviscerate", r=5, l=32, s="Assassination" },
  { n="Gouge", r=3, l=32, s="Combat" },
  { n="Blind", l=34, s="Subtlety" },
  { n="Ambush", r=3, l=34, s="Subtlety" },
  { n="Sprint", r=2, l=34, s="Combat" },
  { n="Backstab", r=5, l=36, s="Combat" },
  { n="Expose Armor", r=3, l=36, s="Assassination" },
  { n="Rupture", r=3, l=36, s="Assassination" },
  { n="Garrote", r=4, l=38, s="Assassination" },
  { n="Sinister Strike", r=6, l=38, s="Combat" },
  { n="Eviscerate", r=6, l=40, s="Assassination" },
  { n="Feint", r=3, l=40, s="Combat" },
  { n="Stealth", r=3, l=40, s="Subtlety" },
  { n="Ambush", r=4, l=42, s="Subtlety" },
  { n="Kick", r=3, l=42, s="Combat" },
  { n="Slice and Dice", r=2, l=42, s="Assassination" },
  { n="Vanish", r=2, l=42, s="Subtlety" },
  { n="Backstab", r=6, l=44, s="Combat" },
  { n="Rupture", r=4, l=44, s="Assassination" },
  { n="Expose Armor", r=4, l=46, s="Assassination" },
  { n="Garrote", r=5, l=46, s="Assassination" },
  { n="Gouge", r=4, l=46, s="Combat" },
  { n="Sinister Strike", r=7, l=46, s="Combat" },
  { n="Eviscerate", r=7, l=48, s="Assassination" },
  { n="Sap", r=3, l=48, s="Subtlety" },
  { n="Ambush", r=5, l=50, s="Subtlety" },
  { n="Kidney Shot", r=2, l=50, s="Assassination" },
  { n="Backstab", r=7, l=52, s="Combat" },
  { n="Feint", r=4, l=52, s="Combat" },
  { n="Rupture", r=5, l=52, s="Assassination" },
  { n="Garrote", r=6, l=54, s="Assassination" },
  { n="Sinister Strike", r=8, l=54, s="Combat" },
  { n="Eviscerate", r=8, l=56, s="Assassination" },
  { n="Expose Armor", r=5, l=56, s="Assassination" },
  { n="Ambush", r=6, l=58, s="Subtlety" },
  { n="Kick", r=4, l=58, s="Combat" },
  { n="Sprint", r=3, l=58, s="Combat" },
  { n="Backstab", r=8, l=60, s="Combat" },
  { n="Backstab", r=9, l=60, s="Combat" },
  { n="Eviscerate", r=9, l=60, s="Assassination" },
  { n="Feint", r=5, l=60, s="Combat" },
  { n="Gouge", r=5, l=60, s="Combat" },
  { n="Rupture", r=6, l=60, s="Assassination" },
  { n="Stealth", r=4, l=60, s="Subtlety" },
}

local MUST = { ["Eviscerate"] = true, ["Sinister Strike"] = true, ["Stealth"] = true, ["Backstab"] = true, ["Gouge"] = true, ["Evasion"] = true, ["Slice and Dice"] = true, ["Sprint"] = true, ["Sap"] = true, ["Kick"] = true, ["Garrote"] = true, ["Feint"] = true, ["Ambush"] = true, ["Rupture"] = true, ["Vanish"] = true, ["Cheap Shot"] = true, ["Kidney Shot"] = true, ["Blind"] = true, ["Expose Armor"] = true }
local TAGS = { ["Combat"] = "dps", ["Assassination"] = "dps", ["Subtlety"] = "dps" }

local function Recommend(spell)
  if MUST[spell.n] then
    return "must", "Core Rogue kit. Train it."
  end
  local tag = TAGS[spell.s] or "dps"
  return tag, spell.s .. " rank. Train it if it fits how you play."
end

PhilosophersCodexData.SPELLS.ROGUE = {
  source = SOURCE,
  list = LIST,
  Recommend = Recommend,
}
