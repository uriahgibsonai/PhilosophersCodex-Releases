-- Philosopher's Codex: Warrior trainer spells
-- Levels and ranks: 60.tools /levels/warrior (Forever client data), checked 2026-11-19.
-- Individual trainer prices are not in the Forever client.

PhilosophersCodexData = PhilosophersCodexData or {}
PhilosophersCodexData.SPELLS = PhilosophersCodexData.SPELLS or {}

local SOURCE = {
  build = "Forever (60.tools)",
  primary = "https://www.60.tools/levels/warrior",
  totalGoldNote = "Blizzard Nov 2 2026: all class abilities 1-60 cost about 206-207 gold.",
}

local LIST = {
  { n="Battle Stance", l=1, s="Arms" },
  { n="Heroic Strike", r=1, l=1, s="Arms" },
  { n="Battle Shout", r=1, l=1, s="Fury" },
  { n="Charge", r=1, l=4, s="Arms" },
  { n="Rend", r=1, l=4, s="Arms" },
  { n="Thunder Clap", r=1, l=6, s="Protection" },
  { n="Hamstring", r=1, l=8, s="Arms" },
  { n="Heroic Strike", r=2, l=8, s="Arms" },
  { n="Bloodrage", l=10, s="Fury" },
  { n="Defensive Stance", l=10, s="Protection" },
  { n="Sunder Armor", r=1, l=10, s="Protection" },
  { n="Taunt", l=10, s="Protection" },
  { n="Rend", r=2, l=10, s="Arms" },
  { n="Overpower", r=1, l=12, s="Arms" },
  { n="Shield Bash", r=1, l=12, s="Protection" },
  { n="Battle Shout", r=2, l=12, s="Fury" },
  { n="Demoralizing Shout", r=1, l=14, s="Protection" },
  { n="Revenge", r=1, l=14, s="Protection" },
  { n="Mocking Blow", r=1, l=16, s="Protection" },
  { n="Shield Block", l=16, s="Protection" },
  { n="Heroic Strike", r=3, l=16, s="Arms" },
  { n="Disarm", l=18, s="Protection" },
  { n="Thunder Clap", r=2, l=18, s="Protection" },
  { n="Retaliation", l=20, s="Arms" },
  { n="Victory Rush", l=20, s="Fury" },
  { n="Cleave", r=1, l=20, s="Fury" },
  { n="Slam", r=1, l=20, s="Fury" },
  { n="Rend", r=3, l=20, s="Arms" },
  { n="Intimidating Shout", l=22, s="Fury" },
  { n="Battle Shout", r=3, l=22, s="Fury" },
  { n="Sunder Armor", r=2, l=22, s="Protection" },
  { n="Execute", r=1, l=24, s="Fury" },
  { n="Demoralizing Shout", r=2, l=24, s="Protection" },
  { n="Heroic Strike", r=4, l=24, s="Arms" },
  { n="Revenge", r=2, l=24, s="Protection" },
  { n="Challenging Shout", l=26, s="Protection" },
  { n="Charge", r=2, l=26, s="Arms" },
  { n="Mocking Blow", r=2, l=26, s="Protection" },
  { n="Shield Wall", l=28, s="Protection" },
  { n="Overpower", r=2, l=28, s="Arms" },
  { n="Thunder Clap", r=3, l=28, s="Protection" },
  { n="Berserker Rage", l=30, s="Fury" },
  { n="Berserker Stance", l=30, s="Fury" },
  { n="Intercept", r=1, l=30, s="Fury" },
  { n="Cleave", r=2, l=30, s="Fury" },
  { n="Rend", r=4, l=30, s="Arms" },
  { n="Slam", r=2, l=30, s="Fury" },
  { n="Battle Shout", r=4, l=32, s="Fury" },
  { n="Execute", r=2, l=32, s="Fury" },
  { n="Hamstring", r=2, l=32, s="Arms" },
  { n="Heroic Strike", r=5, l=32, s="Arms" },
  { n="Shield Bash", r=2, l=32, s="Protection" },
  { n="Demoralizing Shout", r=3, l=34, s="Protection" },
  { n="Revenge", r=3, l=34, s="Protection" },
  { n="Sunder Armor", r=3, l=34, s="Protection" },
  { n="Whirlwind", l=36, s="Fury" },
  { n="Mocking Blow", r=3, l=36, s="Protection" },
  { n="Pummel", r=1, l=38, s="Fury" },
  { n="Slam", r=3, l=38, s="Fury" },
  { n="Thunder Clap", r=4, l=38, s="Protection" },
  { n="Cleave", r=3, l=40, s="Fury" },
  { n="Execute", r=3, l=40, s="Fury" },
  { n="Heroic Strike", r=6, l=40, s="Arms" },
  { n="Rend", r=5, l=40, s="Arms" },
  { n="Battle Shout", r=5, l=42, s="Fury" },
  { n="Intercept", r=2, l=42, s="Fury" },
  { n="Demoralizing Shout", r=4, l=44, s="Protection" },
  { n="Overpower", r=3, l=44, s="Arms" },
  { n="Revenge", r=4, l=44, s="Protection" },
  { n="Charge", r=3, l=46, s="Arms" },
  { n="Mocking Blow", r=4, l=46, s="Protection" },
  { n="Slam", r=4, l=46, s="Fury" },
  { n="Sunder Armor", r=4, l=46, s="Protection" },
  { n="Execute", r=4, l=48, s="Fury" },
  { n="Heroic Strike", r=7, l=48, s="Arms" },
  { n="Thunder Clap", r=5, l=48, s="Protection" },
  { n="Recklessness", l=50, s="Fury" },
  { n="Cleave", r=4, l=50, s="Fury" },
  { n="Rend", r=6, l=50, s="Arms" },
  { n="Battle Shout", r=6, l=52, s="Fury" },
  { n="Intercept", r=3, l=52, s="Fury" },
  { n="Shield Bash", r=3, l=52, s="Protection" },
  { n="Demoralizing Shout", r=5, l=54, s="Protection" },
  { n="Hamstring", r=3, l=54, s="Arms" },
  { n="Revenge", r=5, l=54, s="Protection" },
  { n="Slam", r=5, l=54, s="Fury" },
  { n="Execute", r=5, l=56, s="Fury" },
  { n="Heroic Strike", r=8, l=56, s="Arms" },
  { n="Mocking Blow", r=5, l=56, s="Protection" },
  { n="Pummel", r=2, l=58, s="Fury" },
  { n="Sunder Armor", r=5, l=58, s="Protection" },
  { n="Thunder Clap", r=6, l=58, s="Protection" },
  { n="Battle Shout", r=7, l=60, s="Fury" },
  { n="Cleave", r=5, l=60, s="Fury" },
  { n="Heroic Strike", r=9, l=60, s="Arms" },
  { n="Overpower", r=4, l=60, s="Arms" },
  { n="Rend", r=7, l=60, s="Arms" },
  { n="Revenge", r=6, l=60, s="Protection" },
}

local MUST = { ["Battle Stance"] = true, ["Heroic Strike"] = true, ["Battle Shout"] = true, ["Charge"] = true, ["Rend"] = true, ["Thunder Clap"] = true, ["Hamstring"] = true, ["Bloodrage"] = true, ["Defensive Stance"] = true, ["Sunder Armor"] = true, ["Taunt"] = true, ["Overpower"] = true, ["Shield Bash"] = true, ["Demoralizing Shout"] = true, ["Revenge"] = true, ["Victory Rush"] = true, ["Cleave"] = true, ["Execute"] = true, ["Berserker Stance"] = true, ["Intercept"] = true, ["Whirlwind"] = true, ["Pummel"] = true, ["Shield Block"] = true, ["Slam"] = true, ["Mocking Blow"] = true }
local TAGS = { ["Arms"] = "dps", ["Fury"] = "dps", ["Protection"] = "tank" }

local function Recommend(spell)
  if MUST[spell.n] then
    return "must", "Core Warrior kit. Train it."
  end
  local tag = TAGS[spell.s] or "dps"
  return tag, spell.s .. " rank. Train it if it fits how you play."
end

PhilosophersCodexData.SPELLS.WARRIOR = {
  source = SOURCE,
  list = LIST,
  Recommend = Recommend,
}
