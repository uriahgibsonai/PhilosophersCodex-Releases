-- Philosopher's Codex: WoW Forever Warlock trainer spells
-- Levels and ranks: 60.tools /levels/warlock, Forever client build 1.60.1.70888
-- (cross-checked against bindonforever and wowforevertools warlock lists).
-- Individual trainer prices are not in the Forever client.
-- Not on the 1.60.1.70888 trainer list: Unending Breath, Eye of Kilrogg,
-- Sense Demons, Detect Invisibility, Felsteed, Dreadsteed (the last two stay class quests).

PhilosophersCodexData = PhilosophersCodexData or {}
PhilosophersCodexData.SPELLS = PhilosophersCodexData.SPELLS or {}

local SOURCE = {
  build = "1.60.1.70888",
  primary = "https://www.60.tools/levels/warlock",
  crossCheck = "https://bindonforever.com/classes/warlock/leveling",
  totalGoldNote = "Blizzard Nov 2 2026: all class abilities 1-60 cost about 206-207 gold.",
}

local LIST = {
  { n="Demon Skin", r=1, l=1, s="Demonology" },
  { n="Summon Imp", l=1, s="Demonology" },
  { n="Immolate", r=1, l=1, s="Destruction" },
  { n="Shadow Bolt", r=1, l=1, s="Affliction" },
  { n="Corruption", r=1, l=4, s="Affliction" },
  { n="Curse of Weakness", r=1, l=4, s="Affliction" },
  { n="Life Tap", r=1, l=6, s="Affliction" },
  { n="Shadow Bolt", r=2, l=6, s="Affliction" },
  { n="Bane of Agony", r=1, l=8, s="Affliction" },
  { n="Fear", r=1, l=8, s="Affliction" },
  { n="Drain Soul", r=1, l=10, s="Affliction" },
  { n="Create Healthstone", r=1, l=10, s="Affliction" },
  { n="Summon Voidwalker", l=10, s="Demonology", note="Also a class quest (Alliance: Gakin the Darkbinder in Stormwind). If the trainer does not sell it, complete the quest." },
  { n="Demon Skin", r=2, l=10, s="Demonology" },
  { n="Immolate", r=2, l=10, s="Destruction" },
  { n="Health Funnel", r=1, l=12, s="Demonology" },
  { n="Curse of Weakness", r=2, l=12, s="Affliction" },
  { n="Shadow Bolt", r=3, l=12, s="Affliction" },
  { n="Curse of Recklessness", r=1, l=14, s="Affliction" },
  { n="Drain Life", r=1, l=14, s="Affliction" },
  { n="Corruption", r=2, l=14, s="Affliction" },
  { n="Life Tap", r=2, l=16, s="Affliction" },
  { n="Create Soulstone", r=1, l=18, s="Affliction" },
  { n="Searing Pain", r=1, l=18, s="Destruction" },
  { n="Bane of Agony", r=2, l=18, s="Affliction" },
  { n="Curse of the Elements", r=1, l=20, s="Affliction" },
  { n="Demon Armor", r=1, l=20, s="Demonology" },
  { n="Ritual of Summoning", l=20, s="Demonology" },
  { n="Summon Incubus", l=20, s="Demonology", new=true, note="Listed as a trainer spell at 20 in Forever (60.tools, build 1.60.1.70888), alongside Summon Succubus." },
  { n="Summon Succubus", l=20, s="Demonology" },
  { n="Rain of Fire", r=1, l=20, s="Destruction" },
  { n="Health Funnel", r=2, l=20, s="Demonology" },
  { n="Immolate", r=3, l=20, s="Destruction" },
  { n="Shadow Bolt", r=4, l=20, s="Affliction" },
  { n="Create Healthstone", r=2, l=22, s="Affliction" },
  { n="Curse of Weakness", r=3, l=22, s="Affliction" },
  { n="Drain Life", r=2, l=22, s="Affliction" },
  { n="Drain Mana", r=1, l=24, s="Affliction" },
  { n="Corruption", r=3, l=24, s="Affliction" },
  { n="Drain Soul", r=2, l=24, s="Affliction" },
  { n="Curse of Tongues", r=1, l=26, s="Affliction" },
  { n="Life Tap", r=3, l=26, s="Affliction" },
  { n="Searing Pain", r=2, l=26, s="Destruction" },
  { n="Banish", r=1, l=28, s="Affliction" },
  { n="Create Firestone", r=1, l=28, s="Affliction", note="Forever trainer data lists the first rank at 28 (it was later in Classic Era)." },
  { n="Bane of Agony", r=3, l=28, s="Affliction" },
  { n="Curse of Recklessness", r=2, l=28, s="Affliction" },
  { n="Health Funnel", r=3, l=28, s="Demonology" },
  { n="Shadow Bolt", r=5, l=28, s="Affliction" },
  { n="Subjugate Demon", r=1, l=30, s="Demonology" },
  { n="Summon Felhunter", l=30, s="Demonology", note="Also a class quest at 30 in Classic Era; Forever lists it on the trainer at 30. Complete the quest if the trainer does not sell it." },
  { n="Hellfire", r=1, l=30, s="Destruction" },
  { n="Create Soulstone", r=2, l=30, s="Affliction" },
  { n="Curse of the Elements", r=2, l=30, s="Affliction" },
  { n="Demon Armor", r=2, l=30, s="Demonology" },
  { n="Drain Life", r=3, l=30, s="Affliction" },
  { n="Immolate", r=4, l=30, s="Destruction" },
  { n="Curse of Weakness", r=4, l=32, s="Affliction" },
  { n="Fear", r=2, l=32, s="Affliction" },
  { n="Corruption", r=4, l=34, s="Affliction" },
  { n="Create Healthstone", r=3, l=34, s="Affliction" },
  { n="Drain Mana", r=2, l=34, s="Affliction" },
  { n="Rain of Fire", r=2, l=34, s="Destruction" },
  { n="Searing Pain", r=3, l=34, s="Destruction" },
  { n="Create Spellstone", r=1, l=36, s="Affliction" },
  { n="Create Firestone", r=2, l=36, s="Affliction", note="Forever trainer data lists the first rank at 28 (it was later in Classic Era)." },
  { n="Health Funnel", r=4, l=36, s="Demonology" },
  { n="Life Tap", r=4, l=36, s="Affliction" },
  { n="Shadow Bolt", r=6, l=36, s="Affliction" },
  { n="Bane of Agony", r=4, l=38, s="Affliction" },
  { n="Drain Life", r=4, l=38, s="Affliction" },
  { n="Drain Soul", r=3, l=38, s="Affliction" },
  { n="Howl of Terror", r=1, l=40, s="Affliction" },
  { n="Create Soulstone", r=3, l=40, s="Affliction" },
  { n="Curse of the Elements", r=3, l=40, s="Affliction" },
  { n="Demon Armor", r=3, l=40, s="Demonology" },
  { n="Immolate", r=5, l=40, s="Destruction" },
  { n="Death Coil", r=1, l=42, s="Affliction" },
  { n="Curse of Recklessness", r=3, l=42, s="Affliction" },
  { n="Curse of Weakness", r=5, l=42, s="Affliction" },
  { n="Hellfire", r=2, l=42, s="Destruction" },
  { n="Searing Pain", r=4, l=42, s="Destruction" },
  { n="Corruption", r=5, l=44, s="Affliction" },
  { n="Drain Mana", r=3, l=44, s="Affliction" },
  { n="Health Funnel", r=5, l=44, s="Demonology" },
  { n="Shadow Bolt", r=7, l=44, s="Affliction" },
  { n="Subjugate Demon", r=2, l=44, s="Demonology" },
  { n="Create Firestone", r=3, l=46, s="Affliction", note="Forever trainer data lists the first rank at 28 (it was later in Classic Era)." },
  { n="Create Healthstone", r=4, l=46, s="Affliction" },
  { n="Drain Life", r=5, l=46, s="Affliction" },
  { n="Life Tap", r=5, l=46, s="Affliction" },
  { n="Rain of Fire", r=3, l=46, s="Destruction" },
  { n="Soul Fire", r=1, l=48, s="Destruction" },
  { n="Bane of Agony", r=5, l=48, s="Affliction" },
  { n="Banish", r=2, l=48, s="Affliction" },
  { n="Create Spellstone", r=2, l=48, s="Affliction" },
  { n="Inferno", l=50, s="Demonology" },
  { n="Create Soulstone", r=4, l=50, s="Affliction" },
  { n="Curse of the Elements", r=4, l=50, s="Affliction" },
  { n="Curse of Tongues", r=2, l=50, s="Affliction" },
  { n="Death Coil", r=2, l=50, s="Affliction" },
  { n="Demon Armor", r=4, l=50, s="Demonology" },
  { n="Immolate", r=6, l=50, s="Destruction" },
  { n="Searing Pain", r=5, l=50, s="Destruction" },
  { n="Curse of Weakness", r=6, l=52, s="Affliction" },
  { n="Drain Soul", r=4, l=52, s="Affliction" },
  { n="Health Funnel", r=6, l=52, s="Demonology" },
  { n="Shadow Bolt", r=8, l=52, s="Affliction" },
  { n="Corruption", r=6, l=54, s="Affliction" },
  { n="Drain Life", r=6, l=54, s="Affliction" },
  { n="Drain Mana", r=4, l=54, s="Affliction" },
  { n="Hellfire", r=3, l=54, s="Destruction" },
  { n="Howl of Terror", r=2, l=54, s="Affliction" },
  { n="Create Firestone", r=4, l=56, s="Affliction", note="Forever trainer data lists the first rank at 28 (it was later in Classic Era)." },
  { n="Curse of Recklessness", r=4, l=56, s="Affliction" },
  { n="Fear", r=3, l=56, s="Affliction" },
  { n="Life Tap", r=6, l=56, s="Affliction" },
  { n="Soul Fire", r=2, l=56, s="Destruction" },
  { n="Bane of Agony", r=6, l=58, s="Affliction" },
  { n="Create Healthstone", r=5, l=58, s="Affliction" },
  { n="Death Coil", r=3, l=58, s="Affliction" },
  { n="Rain of Fire", r=4, l=58, s="Destruction" },
  { n="Searing Pain", r=6, l=58, s="Destruction" },
  { n="Subjugate Demon", r=3, l=58, s="Demonology" },
  { n="Bane of Doom", l=60, s="Affliction" },
  { n="Portal of Summoning", l=60, s="Demonology", new=true, note="New Forever trainer spell at 60 (60.tools, build 1.60.1.70888)." },
  { n="Ritual of Doom", l=60, s="Demonology", note="Listed as a trainer spell at 60; it was a class quest in Classic Era. Confirm in-game how you learn it." },
  { n="Corruption", r=7, l=60, s="Affliction" },
  { n="Create Soulstone", r=5, l=60, s="Affliction" },
  { n="Create Spellstone", r=3, l=60, s="Affliction" },
  { n="Demon Armor", r=5, l=60, s="Demonology" },
  { n="Health Funnel", r=7, l=60, s="Demonology" },
  { n="Immolate", r=7, l=60, s="Destruction" },
  { n="Immolate", r=8, l=60, s="Destruction" },
  { n="Shadow Bolt", r=9, l=60, s="Affliction" },
  { n="Shadow Bolt", r=10, l=60, s="Affliction" },
}

-- Affliction + demon pets is the default Warlock leveling plan: DoTs,
-- Drain Life, Life Tap, and a tank or damage pet. Destruction ranks are
-- optional while you level this way.
-- Sources: Wowhead Forever Affliction level-20/30 overviews, wowfdb Affliction 1-60.
local MUST = {
  ["Shadow Bolt"] = true, ["Corruption"] = true, ["Bane of Agony"] = true,
  ["Life Tap"] = true, ["Fear"] = true, ["Drain Soul"] = true,
  ["Drain Life"] = true, ["Create Healthstone"] = true, ["Create Soulstone"] = true,
  ["Demon Skin"] = true, ["Demon Armor"] = true,
  ["Summon Imp"] = true, ["Summon Voidwalker"] = true,
  ["Summon Succubus"] = true, ["Summon Incubus"] = true, ["Summon Felhunter"] = true,
  ["Ritual of Summoning"] = true, ["Curse of the Elements"] = true,
  ["Health Funnel"] = true, ["Howl of Terror"] = true,
}
local CORE_FIRST = {
  ["Shadow Bolt"] = true, ["Immolate"] = true, ["Corruption"] = true,
  ["Life Tap"] = true, ["Bane of Agony"] = true, ["Fear"] = true,
  ["Drain Life"] = true, ["Rain of Fire"] = true,
}
local AFF = {
  ["Corruption"] = true, ["Bane of Agony"] = true, ["Drain Life"] = true,
  ["Drain Soul"] = true, ["Drain Mana"] = true, ["Life Tap"] = true,
  ["Curse of Weakness"] = true, ["Curse of Recklessness"] = true,
  ["Curse of the Elements"] = true, ["Curse of Tongues"] = true,
  ["Fear"] = true, ["Howl of Terror"] = true, ["Death Coil"] = true,
  ["Banish"] = true, ["Bane of Doom"] = true, ["Create Healthstone"] = true,
  ["Create Soulstone"] = true,
}
local DEMO = {
  ["Demon Skin"] = true, ["Demon Armor"] = true, ["Health Funnel"] = true,
  ["Subjugate Demon"] = true, ["Ritual of Summoning"] = true,
  ["Portal of Summoning"] = true, ["Inferno"] = true, ["Ritual of Doom"] = true,
  ["Create Firestone"] = true, ["Create Spellstone"] = true,
}
local DEST = {
  ["Immolate"] = true, ["Searing Pain"] = true, ["Rain of Fire"] = true,
  ["Hellfire"] = true, ["Soul Fire"] = true,
}

local function Recommend(spell)
  if not spell or not spell.n then
    return "skip", "Unknown spell."
  end
  local name, rank = spell.n, spell.r
  if MUST[name] then
    return "must", "Core affliction leveling or pet tool. Train this."
  end
  if (not rank or rank == 1) and CORE_FIRST[name] then
    return "must", "First rank of a spell you will use while leveling with DoTs and a pet."
  end
  if name == "Hellfire" then
    return "dest", "Hellfire is dangerous self-AoE. Train later if you want Destruction or a packed pull tool."
  end
  if AFF[name] then
    return "affliction", "Affliction rank -- keep your DoTs and drains current."
  end
  if DEMO[name] then
    return "demo", "Demonology or stone rank -- useful for pet management and stones."
  end
  if DEST[name] then
    return "dest", "Destruction rank -- optional while you level as Affliction."
  end
  if spell.s == "Affliction" then
    return "affliction", "Affliction spell -- train if you level with DoTs."
  end
  if spell.s == "Demonology" then
    return "demo", "Demonology spell -- train for pets and utility."
  end
  return "dest", "Optional Destruction or utility spell."
end


PhilosophersCodexData.SPELLS.WARLOCK = {
  source = SOURCE,
  list = LIST,
  Recommend = Recommend,
}
