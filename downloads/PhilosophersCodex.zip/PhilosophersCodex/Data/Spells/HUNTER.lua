-- Philosopher's Codex: Hunter trainer spells
-- Levels and ranks: 60.tools /levels/hunter (Forever client data), checked 2026-11-19.
-- Individual trainer prices are not in the Forever client.

PhilosophersCodexData = PhilosophersCodexData or {}
PhilosophersCodexData.SPELLS = PhilosophersCodexData.SPELLS or {}

local SOURCE = {
  build = "Forever (60.tools)",
  primary = "https://www.60.tools/levels/hunter",
  totalGoldNote = "Blizzard Nov 2 2026: all class abilities 1-60 cost about 206-207 gold.",
}

local LIST = {
  { n="Auto Shot", l=1, s="Marksmanship" },
  { n="Raptor Strike", r=1, l=1, s="Survival" },
  { n="Track Beasts", l=1, s="Survival" },
  { n="Aspect of the Monkey", l=4, s="Beast Mastery" },
  { n="Serpent Sting", r=1, l=4, s="Marksmanship" },
  { n="Arcane Shot", r=1, l=6, s="Marksmanship" },
  { n="Hunter's Mark", r=1, l=6, s="Marksmanship" },
  { n="Concussive Shot", l=8, s="Marksmanship" },
  { n="Raptor Strike", r=2, l=8, s="Survival" },
  { n="Aspect of the Hawk", r=1, l=10, s="Beast Mastery" },
  { n="Revive Pet", l=10, s="Beast Mastery" },
  { n="Track Humanoids", l=10, s="Survival" },
  { n="Serpent Sting", r=2, l=10, s="Marksmanship" },
  { n="Mend Pet", r=1, l=12, s="Beast Mastery" },
  { n="Distracting Shot", r=1, l=12, s="Marksmanship" },
  { n="Wing Clip", r=1, l=12, s="Survival" },
  { n="Arcane Shot", r=2, l=12, s="Marksmanship" },
  { n="Eyes of the Beast", l=14, s="Beast Mastery" },
  { n="Immolation Trap", r=1, l=16, s="Survival" },
  { n="Mongoose Bite", r=1, l=16, s="Survival" },
  { n="Raptor Strike", r=3, l=16, s="Survival" },
  { n="Multi-Shot", l=18, s="Marksmanship" },
  { n="Track Undead", l=18, s="Survival" },
  { n="Aspect of the Hawk", r=2, l=18, s="Beast Mastery" },
  { n="Serpent Sting", r=3, l=18, s="Marksmanship" },
  { n="Aspect of the Cheetah", l=20, s="Beast Mastery" },
  { n="Aimed Shot", r=1, l=20, s="Marksmanship" },
  { n="Disengage", r=1, l=20, s="Survival" },
  { n="Freezing Trap", r=1, l=20, s="Survival" },
  { n="Arcane Shot", r=3, l=20, s="Marksmanship" },
  { n="Distracting Shot", r=2, l=20, s="Marksmanship" },
  { n="Mend Pet", r=2, l=20, s="Beast Mastery" },
  { n="Scorpid Sting", l=22, s="Marksmanship" },
  { n="Hunter's Mark", r=2, l=22, s="Marksmanship" },
  { n="Track Hidden", l=24, s="Survival" },
  { n="Raptor Strike", r=4, l=24, s="Survival" },
  { n="Rapid Fire", l=26, s="Marksmanship" },
  { n="Track Elementals", l=26, s="Survival" },
  { n="Immolation Trap", r=2, l=26, s="Survival" },
  { n="Serpent Sting", r=4, l=26, s="Marksmanship" },
  { n="Frost Trap", l=28, s="Survival" },
  { n="Aimed Shot", r=2, l=28, s="Marksmanship" },
  { n="Arcane Shot", r=4, l=28, s="Marksmanship" },
  { n="Aspect of the Hawk", r=3, l=28, s="Beast Mastery" },
  { n="Mend Pet", r=3, l=28, s="Beast Mastery" },
  { n="Feign Death", l=30, s="Survival" },
  { n="Lacerate", r=1, l=30, s="Survival" },
  { n="Distracting Shot", r=3, l=30, s="Marksmanship" },
  { n="Mongoose Bite", r=2, l=30, s="Survival" },
  { n="Flare", l=32, s="Marksmanship" },
  { n="Track Demons", l=32, s="Survival" },
  { n="Raptor Strike", r=5, l=32, s="Survival" },
  { n="Explosive Trap", r=1, l=34, s="Survival" },
  { n="Disengage", r=2, l=34, s="Survival" },
  { n="Serpent Sting", r=5, l=34, s="Marksmanship" },
  { n="Viper Sting", r=1, l=36, s="Marksmanship" },
  { n="Aimed Shot", r=3, l=36, s="Marksmanship" },
  { n="Arcane Shot", r=5, l=36, s="Marksmanship" },
  { n="Immolation Trap", r=3, l=36, s="Survival" },
  { n="Mend Pet", r=4, l=36, s="Beast Mastery" },
  { n="Aspect of the Hawk", r=4, l=38, s="Beast Mastery" },
  { n="Wing Clip", r=2, l=38, s="Survival" },
  { n="Aspect of the Pack", l=40, s="Beast Mastery" },
  { n="Volley", r=1, l=40, s="Marksmanship" },
  { n="Track Giants", l=40, s="Survival" },
  { n="Distracting Shot", r=4, l=40, s="Marksmanship" },
  { n="Freezing Trap", r=2, l=40, s="Survival" },
  { n="Hunter's Mark", r=3, l=40, s="Marksmanship" },
  { n="Lacerate", r=2, l=40, s="Survival" },
  { n="Raptor Strike", r=6, l=40, s="Survival" },
  { n="Serpent Sting", r=6, l=42, s="Marksmanship" },
  { n="Aimed Shot", r=4, l=44, s="Marksmanship" },
  { n="Arcane Shot", r=6, l=44, s="Marksmanship" },
  { n="Explosive Trap", r=2, l=44, s="Survival" },
  { n="Mend Pet", r=5, l=44, s="Beast Mastery" },
  { n="Mongoose Bite", r=3, l=44, s="Survival" },
  { n="Aspect of the Wild", r=1, l=46, s="Beast Mastery" },
  { n="Immolation Trap", r=4, l=46, s="Survival" },
  { n="Viper Sting", r=2, l=46, s="Marksmanship" },
  { n="Aspect of the Hawk", r=5, l=48, s="Beast Mastery" },
  { n="Disengage", r=3, l=48, s="Survival" },
  { n="Raptor Strike", r=7, l=48, s="Survival" },
  { n="Track Dragonkin", l=50, s="Survival" },
  { n="Distracting Shot", r=5, l=50, s="Marksmanship" },
  { n="Lacerate", r=3, l=50, s="Survival" },
  { n="Serpent Sting", r=7, l=50, s="Marksmanship" },
  { n="Volley", r=2, l=50, s="Marksmanship" },
  { n="Aimed Shot", r=5, l=52, s="Marksmanship" },
  { n="Arcane Shot", r=7, l=52, s="Marksmanship" },
  { n="Mend Pet", r=6, l=52, s="Beast Mastery" },
  { n="Explosive Trap", r=3, l=54, s="Survival" },
  { n="Aspect of the Wild", r=2, l=56, s="Beast Mastery" },
  { n="Immolation Trap", r=5, l=56, s="Survival" },
  { n="Raptor Strike", r=8, l=56, s="Survival" },
  { n="Viper Sting", r=3, l=56, s="Marksmanship" },
  { n="Aspect of the Hawk", r=6, l=58, s="Beast Mastery" },
  { n="Hunter's Mark", r=4, l=58, s="Marksmanship" },
  { n="Mongoose Bite", r=4, l=58, s="Survival" },
  { n="Serpent Sting", r=8, l=58, s="Marksmanship" },
  { n="Volley", r=3, l=58, s="Marksmanship" },
  { n="Tranquilizing Shot", l=60, s="Marksmanship" },
  { n="Aimed Shot", r=6, l=60, s="Marksmanship" },
  { n="Arcane Shot", r=8, l=60, s="Marksmanship" },
  { n="Aspect of the Hawk", r=7, l=60, s="Beast Mastery" },
  { n="Distracting Shot", r=6, l=60, s="Marksmanship" },
  { n="Freezing Trap", r=3, l=60, s="Survival" },
  { n="Lacerate", r=4, l=60, s="Survival" },
  { n="Mend Pet", r=7, l=60, s="Beast Mastery" },
  { n="Serpent Sting", r=9, l=60, s="Marksmanship" },
  { n="Wing Clip", r=3, l=60, s="Survival" },
}

local MUST = {
  ["Auto Shot"] = true, ["Raptor Strike"] = true, ["Serpent Sting"] = true, ["Arcane Shot"] = true,
  ["Hunter's Mark"] = true, ["Concussive Shot"] = true, ["Aspect of the Hawk"] = true, ["Aspect of the Monkey"] = true,
  ["Aspect of the Cheetah"] = true, ["Mend Pet"] = true, ["Wing Clip"] = true, ["Disengage"] = true,
  ["Feign Death"] = true, ["Freezing Trap"] = true, ["Multi-Shot"] = true, ["Rapid Fire"] = true, ["Aimed Shot"] = true,
  ["Tame Beast"] = true, ["Call Pet"] = true, ["Dismiss Pet"] = true, ["Feed Pet"] = true, ["Revive Pet"] = true,
  ["Track Beasts"] = true, ["Track Humanoids"] = true, ["Volley"] = true, ["Aspect of the Pack"] = true,
}
local PET = { ["Tame Beast"] = true, ["Call Pet"] = true, ["Dismiss Pet"] = true, ["Feed Pet"] = true, ["Revive Pet"] = true }
local SKIP = { ["Aspect of the Wild"] = true, ["Track Dragonkin"] = true, ["Track Giants"] = true, ["Tranquilizing Shot"] = false }

local function Recommend(spell)
  local name, rank = spell.n, spell.r
  if PET[name] then
    return "must", "Pet tool. Train it."
  end
  if MUST[name] then
    return "must", "Core Hunter kit. Train it."
  end
  if SKIP[name] then
    return "skip", "Situational. Pick it up when you need it."
  end
  if spell.s == "Survival" and (name:find("Track") or name:find("Trap")) then
    return "surv", "Trap or tracking utility."
  end
  if spell.s == "Beast Mastery" then
    return "bm", "Pet or aspect rank."
  end
  return "mm", "Shot or sting rank. Keep it current."
end

PhilosophersCodexData.SPELLS.HUNTER = {
  source = SOURCE,
  list = LIST,
  Recommend = Recommend,
}
