-- Philosopher's Codex profession tracks for WoW Forever.
-- Tailoring 1-300 follows the common Classic Era skill-up path (Wowhead Classic
-- and era guides) and is labeled as a baseline except where a Forever trainer
-- is already confirmed. First Aid, Cooking, Fishing, Enchanting, and gathering
-- are rank-and-basics tracks on that same baseline. Unconfirmed trainers,
-- gold costs, and Forever-only recipes are left blank.

PhilosophersCodexData = PhilosophersCodexData or {}

local function M(id, name, count)
  return { id = id, name = name, count = count }
end

-- Classic item IDs (cloth, thread, dyes) are unchanged in Forever lists so far.
local LINEN, WOOL, SILK, MAGEWEAVE, RUNE = 2589, 2592, 4306, 4338, 14047
local BOLT_L, BOLT_W, BOLT_S, BOLT_M, BOLT_R = 2996, 2997, 4305, 4339, 14048
local COARSE, FINE, SILKEN, HEAVY, RUNE_TH = 2320, 2321, 4291, 8343, 14341
local BLUE, RED, BLEACH = 6260, 2604, 2324

PhilosophersCodexData.PROFESSIONS = {
  tailoring = {
    id = "tailoring",
    name = "Tailoring",
    icon = "Interface\\Icons\\Trade_Tailoring",
    source = "Classic Era baseline (Wowhead Classic tailoring 1-300), except Journeyman in Ironforge.",
    efficiencyConfirmed = true,
    save = {
      "Don't turn every Bolt of Linen Cloth into early cloaks or robes; bags from 45-70 are more efficient and useful, and you still need bolts for the 70-75 capes.",
      "Don't start Bolt of Woolen Cloth until you train Journeyman at 75 with Jormund Stonebrow in Ironforge.",
      "Don't start Bolt of Silk Cloth until you train Expert (Classic: Georgio Bolero in Stormwind).",
      "Keep bolts you make. They feed the next recipes, so crafting them first is cheaper than buying finished cloth later.",
      "Don't spend Mageweave or Runecloth on late bags or hats until you have enough bolts for the written range; those crafts are best when they are still orange.",
    },
    ranks = {
      { name = "Apprentice", skill = 1, cap = 75 },
      {
        name = "Journeyman",
        skill = 50,
        cap = 150,
        trainAt = 75,
        trainer = "Jormund Stonebrow",
        zone = "Ironforge",
        note = "The Great Forge. Confirmed for Forever (Alliance).",
        confirmed = true,
      },
      {
        name = "Expert",
        skill = 125,
        cap = 225,
        trainAt = 125,
        trainer = "Georgio Bolero",
        zone = "Stormwind City",
        note = "Mage Quarter. Classic Era baseline; not yet confirmed for Forever.",
        source = "classic",
      },
      {
        name = "Artisan",
        skill = 200,
        cap = 300,
        trainAt = 200,
        trainer = "Timothy Worthington",
        zone = "Theramore Isle",
        note = "Classic Era baseline; not yet confirmed for Forever. Character level 35 was required in Classic.",
        source = "classic",
      },
    },
    steps = {
      { from = 1, to = 45, recipe = "Bolt of Linen Cloth", skillReq = 1, mats = { M(LINEN, "Linen Cloth", 2) }, orange = 25, yellow = 37, green = 50, note = "Keep extra bolts for bags and capes.", why = "Cheapest early skill-up: 2 linen per point, and the bolts feed Linen Bags and capes.", feeds = "Save extra bolts for Linen Bags (45-70) and Reinforced Linen Capes (70-75)." },
      { from = 45, to = 70, recipe = "Linen Bag", skillReq = 45, mats = { M(BOLT_L, "Bolt of Linen Cloth", 3), M(COARSE, "Coarse Thread", 3) }, orange = 70, yellow = 87, green = 105, why = "Stays orange to 70, uses the bolts you already made, and the bags sell or are useful.", feeds = "Leave a few bolts for Reinforced Linen Cape at 70-75." },
      { from = 70, to = 75, recipe = "Reinforced Linen Cape", skillReq = 60, mats = { M(BOLT_L, "Bolt of Linen Cloth", 2), M(COARSE, "Coarse Thread", 3) }, orange = 75, yellow = 92, green = 110, why = "The usual Classic finish for Apprentice: cheaper than another bag and gets you to Journeyman." },
      { from = 75, to = 100, recipe = "Bolt of Woolen Cloth", skillReq = 75, mats = { M(WOOL, "Wool Cloth", 3) }, orange = 90, yellow = 97, green = 105, note = "Requires Journeyman. Train with Jormund Stonebrow in Ironforge at 75.", why = "Make bolts first so Simple Kilts and wool shoulders are cheaper later.", feeds = "Save bolts for Simple Kilt (100-110) and Double-stitched Woolen Shoulders (110-125).", save = "Do not start this until Journeyman is trained at 75." },
      { from = 100, to = 110, recipe = "Simple Kilt", skillReq = 75, mats = { M(BOLT_W, "Bolt of Woolen Cloth", 4), M(FINE, "Fine Thread", 1) }, orange = 110, yellow = 127, green = 145, why = "Orange to 110 and a standard, low-waste use of wool bolts." },
      { from = 110, to = 125, recipe = "Double-stitched Woolen Shoulders", skillReq = 110, mats = { M(BOLT_W, "Bolt of Woolen Cloth", 3), M(FINE, "Fine Thread", 2) }, orange = 125, yellow = 142, green = 160, why = "Stays orange to Expert range and uses leftover wool bolts." },
      { from = 125, to = 145, recipe = "Bolt of Silk Cloth", skillReq = 125, mats = { M(SILK, "Silk Cloth", 4) }, orange = 135, yellow = 140, green = 145, note = "Requires Expert (Classic: Georgio Bolero in Stormwind).", why = "Bolts first, then hoods and shirts. Cheaper than buying silk bolts later.", feeds = "Save bolts for Azure Silk Hood, Silk Headband, Formal White Shirt, and Crimson Silk crafts.", save = "Do not start silk bolts until Expert is trained." },
      { from = 145, to = 160, recipe = "Azure Silk Hood", skillReq = 145, mats = { M(BOLT_S, "Bolt of Silk Cloth", 2), M(BLUE, "Blue Dye", 2), M(FINE, "Fine Thread", 1) }, orange = 155, yellow = 160, green = 165, why = "One of the cheaper silk skill-ups: 2 bolts and vendor dye." },
      { from = 160, to = 170, recipe = "Silk Headband", skillReq = 160, mats = { M(BOLT_S, "Bolt of Silk Cloth", 3), M(FINE, "Fine Thread", 2) }, orange = 170, yellow = 187, green = 205, why = "Orange to 170 and uses bolts you already made." },
      { from = 170, to = 175, recipe = "Formal White Shirt", skillReq = 170, mats = { M(BOLT_S, "Bolt of Silk Cloth", 3), M(BLEACH, "Bleach", 2), M(FINE, "Fine Thread", 1) }, orange = 175, yellow = 192, green = 210, why = "A short, cheap finish to 175 so you can start Mageweave bolts." },
      { from = 175, to = 185, recipe = "Bolt of Mageweave", skillReq = 175, mats = { M(MAGEWEAVE, "Mageweave Cloth", 4) }, orange = 180, yellow = 182, green = 185, why = "Make a stock of bolts now; later Black Mageweave crafts consume them.", feeds = "Save bolts for Black Mageweave Gloves and Headband (215-250)." },
      { from = 185, to = 205, recipe = "Crimson Silk Vest", skillReq = 165, mats = { M(BOLT_S, "Bolt of Silk Cloth", 4), M(RED, "Red Dye", 2), M(FINE, "Fine Thread", 2) }, orange = 205, yellow = 220, green = 235, why = "Uses leftover silk bolts instead of spending Mageweave early. Orange to 205." },
      { from = 205, to = 215, recipe = "Crimson Silk Pantaloons", skillReq = 195, mats = { M(BOLT_S, "Bolt of Silk Cloth", 4), M(RED, "Red Dye", 2), M(SILKEN, "Silken Thread", 2) }, orange = 215, yellow = 230, green = 245, note = "Requires Artisan in the Classic path.", why = "Finish leftover silk while Artisan is trained, then switch to Mageweave." },
      { from = 215, to = 230, recipe = "Black Mageweave Gloves", skillReq = 215, mats = { M(BOLT_M, "Bolt of Mageweave", 2), M(HEAVY, "Heavy Silken Thread", 2) }, orange = 230, yellow = 245, green = 260, why = "Only 2 bolts per craft, so this is the efficient Mageweave start." },
      { from = 230, to = 250, recipe = "Black Mageweave Headband", skillReq = 230, mats = { M(BOLT_M, "Bolt of Mageweave", 3), M(HEAVY, "Heavy Silken Thread", 2) }, orange = 250, yellow = 265, green = 280, why = "Stays orange to 250. Do not skip ahead to runecloth bags yet." },
      { from = 250, to = 260, recipe = "Bolt of Runecloth", skillReq = 250, mats = { M(RUNE, "Runecloth", 4) }, orange = 255, yellow = 257, green = 260, why = "Build bolts first; belts and hats eat several each.", feeds = "Save bolts for Runecloth Belt (260-280) and Runecloth Headband or Bags (280-300)." },
      { from = 260, to = 280, recipe = "Runecloth Belt", skillReq = 255, mats = { M(BOLT_R, "Bolt of Runecloth", 3), M(RUNE_TH, "Rune Thread", 1) }, orange = 275, yellow = 280, green = 285, why = "Orange most of the way to 280 and cheaper than jumping to hats early." },
      { from = 280, to = 300, recipe = "Runecloth Headband", skillReq = 295, mats = { M(BOLT_R, "Bolt of Runecloth", 4), M(RUNE_TH, "Rune Thread", 1) }, orange = 300, yellow = 315, green = 330, note = "If Runecloth Headband is not learned yet, Runecloth Bags or Boots are the usual Classic substitutes. Confirm the Forever trainer list.", why = "The usual Classic finish. Bags are a useful substitute if the headband is not on the trainer yet.", save = "Do not start this until 280, when it is still orange." },
    },
  },

  firstaid = {
    id = "firstaid",
    name = "First Aid",
    icon = "Interface\\Icons\\Spell_Holy_SealOfSacrifice",
    source = "Classic Era baseline.",
    efficiencyConfirmed = true,
    save = {
      "Switch to the Heavy bandage as soon as it is orange. Light bandages become a waste of cloth after that.",
      "Train the next First Aid rank on time; you cannot craft the next bandage until the rank is learned.",
    },
    ranks = {
      { name = "Apprentice", skill = 1, cap = 75 },
      { name = "Journeyman", skill = 50, cap = 150, trainAt = 75, note = "Capital-city First Aid trainers in Classic. Forever trainers not yet confirmed." },
      { name = "Expert", skill = 125, cap = 225, trainAt = 150, note = "Classic used a vendor book (Expert First Aid). Forever source unconfirmed." },
      { name = "Artisan", skill = 200, cap = 300, trainAt = 225, trainer = "Doctor Gustaf VanHowzen", zone = "Dustwallow Marsh", note = "Theramore in Classic. Forever source unconfirmed.", source = "classic" },
    },
    steps = {
      { from = 1, to = 40, recipe = "Linen Bandage", skillReq = 1, mats = { M(LINEN, "Linen Cloth", 1) }, orange = 30, yellow = 45, green = 60 },
      { from = 40, to = 80, recipe = "Heavy Linen Bandage", skillReq = 40, mats = { M(LINEN, "Linen Cloth", 2) }, orange = 50, yellow = 75, green = 100 },
      { from = 80, to = 115, recipe = "Wool Bandage", skillReq = 80, mats = { M(WOOL, "Wool Cloth", 1) }, orange = 80, yellow = 115, green = 150 },
      { from = 115, to = 150, recipe = "Heavy Wool Bandage", skillReq = 115, mats = { M(WOOL, "Wool Cloth", 2) }, orange = 125, yellow = 150, green = 175 },
      { from = 150, to = 180, recipe = "Silk Bandage", skillReq = 150, mats = { M(SILK, "Silk Cloth", 1) }, orange = 150, yellow = 180, green = 210 },
      { from = 180, to = 210, recipe = "Heavy Silk Bandage", skillReq = 180, mats = { M(SILK, "Silk Cloth", 2) }, orange = 180, yellow = 210, green = 240 },
      { from = 210, to = 240, recipe = "Mageweave Bandage", skillReq = 210, mats = { M(MAGEWEAVE, "Mageweave Cloth", 1) }, orange = 210, yellow = 240, green = 270 },
      { from = 240, to = 260, recipe = "Heavy Mageweave Bandage", skillReq = 240, mats = { M(MAGEWEAVE, "Mageweave Cloth", 2) }, orange = 240, yellow = 260, green = 280 },
      { from = 260, to = 290, recipe = "Runecloth Bandage", skillReq = 260, mats = { M(RUNE, "Runecloth", 1) }, orange = 260, yellow = 290, green = 320 },
      { from = 290, to = 300, recipe = "Heavy Runecloth Bandage", skillReq = 290, mats = { M(RUNE, "Runecloth", 2) }, orange = 290, yellow = 320, green = 350 },
    },
  },

  cooking = {
    id = "cooking",
    name = "Cooking",
    icon = "Interface\\Icons\\INV_Misc_Food_15",
    source = "Classic Era baseline. Recipes vary by zone; these are common skill-up staples.",
    ranks = {
      { name = "Apprentice", skill = 1, cap = 75 },
      { name = "Journeyman", skill = 50, cap = 150, trainAt = 75, note = "Capital-city cooking trainers in Classic. Forever trainers not yet confirmed." },
      { name = "Expert", skill = 125, cap = 225, trainAt = 125, note = "Classic used the Expert Cookbook. Forever source unconfirmed." },
      { name = "Artisan", skill = 200, cap = 300, trainAt = 225, note = "Classic Artisan was a quest (Dirge Quikcleave, Gadgetzan). Forever source unconfirmed.", source = "classic" },
    },
    steps = {
      { from = 1, to = 40, recipe = "Spice Bread or Brilliant Smallfish", skillReq = 1, mats = {}, note = "Any apprentice recipe. Exact Forever trainer recipes are unconfirmed." },
      { from = 40, to = 80, recipe = "Smoked Bear Meat or zone meat/fish", skillReq = 40, mats = {}, note = "Use whatever meat or fish your current zone supplies." },
      { from = 80, to = 130, recipe = "Curiously Tasty Omelet / soothefish staples", skillReq = 80, mats = {}, note = "Classic mid-tier recipes. Leave unconfirmed for Forever." },
      { from = 130, to = 175, recipe = "Zone mid-level cooking", skillReq = 130, mats = {}, note = "Recipe list for Forever is not written here yet." },
      { from = 175, to = 225, recipe = "Tender Wolf Steak or similar", skillReq = 175, mats = {}, note = "Classic Era staple. Confirm Forever recipes before buying mats." },
      { from = 225, to = 275, recipe = "Poached / grilled high-level fish or meat", skillReq = 225, mats = {}, note = "Requires Artisan in Classic. Forever path unconfirmed." },
      { from = 275, to = 300, recipe = "Endgame cooking recipes", skillReq = 275, mats = {}, note = "Left blank until Forever recipes are confirmed." },
    },
  },

  fishing = {
    id = "fishing",
    name = "Fishing",
    icon = "Interface\\Icons\\Trade_Fishing",
    source = "Classic Era baseline. No crafts; skill up by fishing in appropriate-level waters.",
    ranks = {
      { name = "Apprentice", skill = 1, cap = 75 },
      { name = "Journeyman", skill = 50, cap = 150, trainAt = 75, note = "Capital-city fishing trainers in Classic. Forever trainers not yet confirmed." },
      { name = "Expert", skill = 125, cap = 225, trainAt = 125, note = "Classic used the Expert Fishing book (Old Man Heming, Booty Bay). Forever source unconfirmed." },
      { name = "Artisan", skill = 200, cap = 300, trainAt = 225, note = "Classic Artisan was a quest (Nat Pagle). Forever source unconfirmed.", source = "classic" },
    },
    steps = {
      { from = 1, to = 75, recipe = "Fish in starting zones and Elwynn or Dun Morogh", skillReq = 1, mats = {}, note = "Stay in low-level waters until Journeyman." },
      { from = 75, to = 150, recipe = "Fish in mid zones (Redridge, Wetlands, Barrens)", skillReq = 75, mats = {}, note = "Move up as fish get away less often." },
      { from = 150, to = 225, recipe = "Fish in mid-to-high zones", skillReq = 150, mats = {}, note = "Requires Expert in Classic." },
      { from = 225, to = 300, recipe = "Fish in late-game waters", skillReq = 225, mats = {}, note = "Requires Artisan in Classic. Forever trainers unconfirmed." },
    },
  },

  enchanting = {
    id = "enchanting",
    name = "Enchanting",
    icon = "Interface\\Icons\\Trade_Engraving",
    source = "Classic Era baseline (Wowhead Classic enchanting 1-100). Forever recipes may differ.",
    matSources = {
      [10940] = "Disenchant green armor and weapons (item level 5-20), or AH",
      [10938] = "Disenchant green weapons (item level 5-20), or AH",
      [6217] = "Enchanting supplier (vendor)",
    },
    save = {
      "Disenchant every green you don't need instead of selling it: dust is the whole 1-75 path.",
      "Lesser Magic Essence comes mostly from green weapons; keep a few for the rod and 75-85.",
    },
    ranks = {
      { name = "Apprentice", skill = 1, cap = 75 },
      { name = "Journeyman", skill = 50, cap = 150, trainAt = 75, note = "Ironforge and Stormwind have Enchanting trainers in Classic. Forever trainers not yet confirmed." },
      { name = "Expert", skill = 125, cap = 225, trainAt = 125, note = "Classic Expert trainer was typically in a capital or outland-adjacent city later; Forever source unconfirmed." },
      { name = "Artisan", skill = 200, cap = 300, trainAt = 200, note = "Classic Artisan trainer locations vary by era. Forever source unconfirmed.", source = "classic" },
    },
    steps = {
      { from = 1, to = 2, recipe = "Runed Copper Rod", skillReq = 1, mats = { M(6217, "Copper Rod", 1), M(10940, "Strange Dust", 1), M(10938, "Lesser Magic Essence", 1) }, note = "Buy the Copper Rod from an enchanting supplier. Keep the Runed Copper Rod in your bags: early enchants need it." },
      { from = 2, to = 75, recipe = "Enchant Bracer - Minor Health", skillReq = 1, mats = { M(10940, "Strange Dust", 1) }, note = "1 Strange Dust per enchant. Cast it on any bracers, even your own." },
      { from = 75, to = 85, recipe = "Enchant Bracer - Minor Deflection", skillReq = 60, mats = { M(10938, "Lesser Magic Essence", 1), M(10940, "Strange Dust", 1) }, note = "Needs Journeyman (train at 75)." },
      { from = 85, to = 100, recipe = "Enchant Bracer - Minor Stamina", skillReq = 80, mats = { M(10940, "Strange Dust", 3) }, note = "Classic Era baseline path." },
      { from = 100, to = 150, recipe = "Journeyman disenchants and mid enchants", skillReq = 100, mats = {}, note = "Recipe path past 100 is unconfirmed for Forever." },
      { from = 150, to = 225, recipe = "Expert enchants", skillReq = 150, mats = {}, note = "Left blank until Forever recipes are confirmed." },
      { from = 225, to = 300, recipe = "Artisan enchants", skillReq = 225, mats = {}, note = "Left blank until Forever recipes are confirmed." },
    },
  },

  herbalism = {
    id = "herbalism",
    name = "Herbalism",
    icon = "Interface\\Icons\\Trade_Herbalism",
    source = "Classic Era node skill bands.",
    ranks = {
      { name = "Apprentice", skill = 1, cap = 75 },
      { name = "Journeyman", skill = 50, cap = 150, trainAt = 75, note = "Capital-city Herbalism trainers in Classic. Forever trainers not yet confirmed." },
      { name = "Expert", skill = 125, cap = 225, trainAt = 125, note = "Classic Era baseline." },
      { name = "Artisan", skill = 200, cap = 300, trainAt = 200, note = "Classic Era baseline. Forever trainers unconfirmed." },
    },
    steps = {
      { from = 1, to = 70, recipe = "Peacebloom, Silverleaf, Earthroot", skillReq = 1, mats = {}, note = "Starting zones and Elwynn, Dun Morogh, Teldrassil." },
      { from = 70, to = 115, recipe = "Mageroyal, Briarthorn, Stranglekelp", skillReq = 70, mats = {}, note = "Hills, coasts, and mid starting zones." },
      { from = 115, to = 170, recipe = "Bruiseweed, Wild Steelbloom, Kingsblood, Liferoot", skillReq = 115, mats = {}, note = "Classic node bands." },
      { from = 170, to = 250, recipe = "Fadeleaf, Goldthorn, Khadgar's Whisker, Purple Lotus", skillReq = 170, mats = {}, note = "Classic node bands." },
      { from = 250, to = 300, recipe = "Sungrass, Gromsblood, Golden Sansam, Mountain Silversage, Plaguebloom", skillReq = 250, mats = {}, note = "Classic endgame herbs. Forever node skill may match; unconfirmed." },
    },
  },

  mining = {
    id = "mining",
    name = "Mining",
    icon = "Interface\\Icons\\Trade_Mining",
    source = "Classic Era vein skill bands.",
    ranks = {
      { name = "Apprentice", skill = 1, cap = 75 },
      { name = "Journeyman", skill = 50, cap = 150, trainAt = 75, note = "Capital-city Mining trainers in Classic. Forever trainers not yet confirmed." },
      { name = "Expert", skill = 125, cap = 225, trainAt = 125, note = "Classic Era baseline." },
      { name = "Artisan", skill = 200, cap = 300, trainAt = 200, note = "Classic Era baseline. Forever trainers unconfirmed." },
    },
    steps = {
      { from = 1, to = 65, recipe = "Copper veins", skillReq = 1, mats = {}, note = "Starting zones and early mid zones." },
      { from = 65, to = 125, recipe = "Tin, silver, and incidental copper", skillReq = 65, mats = {}, note = "Requires Journeyman soon after 75." },
      { from = 125, to = 175, recipe = "Iron and gold", skillReq = 125, mats = {}, note = "Requires Expert in Classic." },
      { from = 175, to = 245, recipe = "Mithril and truesilver", skillReq = 175, mats = {}, note = "Classic vein bands." },
      { from = 245, to = 300, recipe = "Thorium", skillReq = 245, mats = {}, note = "Classic endgame veins. Forever unconfirmed." },
    },
  },

  skinning = {
    id = "skinning",
    name = "Skinning",
    icon = "Interface\\Icons\\INV_Misc_Pelt_Wolf_01",
    source = "Classic Era baseline: you can skin mobs around your skill (about 5 skill per level of mob, with orange/yellow/green bands).",
    ranks = {
      { name = "Apprentice", skill = 1, cap = 75 },
      { name = "Journeyman", skill = 50, cap = 150, trainAt = 75, note = "Capital-city Skinning trainers in Classic. Forever trainers not yet confirmed." },
      { name = "Expert", skill = 125, cap = 225, trainAt = 125, note = "Classic Era baseline." },
      { name = "Artisan", skill = 200, cap = 300, trainAt = 200, note = "Classic Era baseline. Forever trainers unconfirmed." },
    },
    steps = {
      { from = 1, to = 75, recipe = "Skin beasts near your level in starting zones", skillReq = 1, mats = {} },
      { from = 75, to = 150, recipe = "Skin mid-level beasts", skillReq = 75, mats = {}, note = "Train Journeyman at 75." },
      { from = 150, to = 225, recipe = "Skin higher-level beasts", skillReq = 150, mats = {}, note = "Train Expert at 125-150." },
      { from = 225, to = 300, recipe = "Skin late-game beasts", skillReq = 225, mats = {}, note = "Train Artisan at 200-225." },
    },
  },
}

PhilosophersCodexData.PROFESSION_ALIASES = {
  ["tailoring"] = "tailoring",
  ["first aid"] = "firstaid",
  ["firstaid"] = "firstaid",
  ["cooking"] = "cooking",
  ["fishing"] = "fishing",
  ["enchanting"] = "enchanting",
  ["herbalism"] = "herbalism",
  ["mining"] = "mining",
  ["skinning"] = "skinning",
}
