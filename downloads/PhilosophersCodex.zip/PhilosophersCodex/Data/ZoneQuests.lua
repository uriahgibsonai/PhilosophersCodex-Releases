-- Philosopher's Codex Alliance zone quests, levels 1-30.
-- Chains use previous / next quest IDs so the Path tab can show a
-- parent (the chain starter) with follow-ups as children.
-- IDs, givers, and coordinates follow Classic / Questie Forever data
-- for the original Alliance quests. Forever-only quests are omitted
-- unless they were already catalogued elsewhere in this addon.
-- A quest is Alliance unless faction is set. Race or class, when
-- present, further limits who can pick it up.

PhilosophersCodexData = PhilosophersCodexData or {}

local function Q(id, name, level, minLevel, giver, where, map, x, y, extra)
  local t = {
    questID = id,
    name = name,
    level = level,
    minLevel = minLevel,
    giver = giver,
    where = where,
    uiMapID = map,
    x = x,
    y = y,
    faction = "Alliance",
  }
  if type(extra) == "table" then
    for k, v in pairs(extra) do
      t[k] = v
    end
  end
  return t
end

local function Chain(id, name, quests)
  quests = quests or {}
  for i = 1, #quests do
    local q = quests[i]
    if q.prev == nil and i > 1 then
      q.prev = quests[i - 1].questID
    end
    if q.next == nil and i < #quests then
      q.next = quests[i + 1].questID
    end
  end
  return { id = id, name = name, quests = quests }
end

PhilosophersCodexData.ZONE_QUEST_ALIASES = {
  ["Coldridge Valley"] = "Dun Morogh",
  ["Anvilmar"] = "Dun Morogh",
  ["Shadowglen"] = "Teldrassil",
  ["Northshire Valley"] = "Elwynn Forest",
  ["Northshire Abbey"] = "Elwynn Forest",
  ["Goldshire"] = "Elwynn Forest",
  ["Sentinel Hill"] = "Westfall",
  ["Thelsamar"] = "Loch Modan",
  ["Lakeshire"] = "Redridge Mountains",
  ["Darkshire"] = "Duskwood",
  ["Menethil Harbor"] = "Wetlands",
  ["Astranaar"] = "Ashenvale",
  ["Auberdine"] = "Darkshore",
  ["Dolanaar"] = "Teldrassil",
  ["Kharanos"] = "Dun Morogh",
  ["Southshore"] = "Hillsbrad Foothills",
  ["Stonetalon Peak"] = "Stonetalon Mountains",
}

PhilosophersCodexData.ZONE_QUESTS = {
  ['Elwynn Forest'] = {
    uiMapID = 1429,
    faction = "Alliance",
    minLevel = 1,
    maxLevel = 10,
    note = 'Northshire through Goldshire and Eastvale. Human start; other Alliance races can still pick up Goldshire quests while passing through.',
    chains = {
      Chain('northshire-threat', 'A Threat Within', {
        Q(783, 'A Threat Within', 1, 1, 'Deputy Willem', 'Northshire Abbey', 1429, 48.17, 42.95, nil),
        Q(7, 'Kobold Camp Cleanup', 1, 1, 'Marshal McBride', 'Northshire Abbey', 1429, 48.92, 41.61, nil),
        Q(15, 'Investigate Echo Ridge', 2, 1, 'Marshal McBride', 'Northshire Abbey', 1429, 48.92, 41.61, nil),
        Q(21, 'Skirmish at Echo Ridge', 3, 1, 'Marshal McBride', 'Northshire Abbey', 1429, 48.92, 41.61, nil),
        Q(54, 'Report to Goldshire', 4, 1, 'Marshal McBride', 'Northshire Abbey', 1429, 48.92, 41.61, nil),
      }),
      Chain('northshire-wolves', 'Wolves Across the Border', {
        Q(5261, 'Eagan Peltskinner', 1, 1, 'Deputy Willem', 'Northshire Abbey', 1429, 48.17, 42.95, nil),
        Q(33, 'Wolves Across the Border', 2, 1, 'Eagan Peltskinner', 'Northshire Valley', 1429, 48.94, 40.16, nil),
      }),
      Chain('northshire-defias', 'Brotherhood of Thieves', {
        Q(18, 'Brotherhood of Thieves', 3, 1, 'Deputy Willem', 'Northshire Abbey', 1429, 48.17, 42.95, nil),
        Q(6, 'Bounty on Garrick Padfoot', 4, 2, 'Deputy Willem', 'Northshire Abbey', 1429, 48.17, 42.95, nil),
      }),
      Chain('rest-and-relaxation', 'Rest and Relaxation', {
        Q(2158, 'Rest and Relaxation', 5, 1, 'Falkhaan Isenstrider', 'Road from Northshire to Goldshire', 1429, 45.56, 47.74, nil),
      }),
      Chain('fargodeep', 'The Fargodeep Mine', {
        Q(62, 'The Fargodeep Mine', 7, 4, 'Marshal Dughan', 'Goldshire', 1429, 42.11, 65.93, nil),
        Q(76, 'The Jasperlode Mine', 8, 4, 'Marshal Dughan', 'Goldshire', 1429, 42.11, 65.93, nil),
        Q(239, 'Westbrook Garrison Needs Help!', 9, 6, 'Marshal Dughan', 'Goldshire', 1429, 42.11, 65.93, nil),
        Q(11, 'Riverpaw Gnoll Bounty', 10, 6, 'Deputy Rainer', 'Westbrook Garrison', 1429, 24.23, 74.45, nil),
      }),
      Chain('fishy-peril', 'A Fishy Peril', {
        Q(40, 'A Fishy Peril', 7, 7, 'Remy Two Times', 'Goldshire', 1429, 42.14, 67.26, nil),
        Q(35, 'Further Concerns', 7, 7, 'Marshal Dughan', 'Goldshire', 1429, 42.11, 65.93, nil),
        Q(37, 'Find the Lost Guards', 8, 7, 'Guard Thomas', 'Eastvale road', 1429, 73.97, 72.18, nil),
        Q(45, 'Discover Rolf\'s Fate', 8, 7, 'A half-eaten body', 'Near Crystal Lake', 1429, 72.65, 60.33, nil),
        Q(71, 'Report to Thomas', 8, 7, 'Rolf\'s corpse', 'Crystal Lake', 1429, 79.8, 55.5, nil),
        Q(39, 'Deliver Thomas\' Report', 8, 7, 'Guard Thomas', 'Eastvale road', 1429, 73.97, 72.18, nil),
        Q(59, 'Cloth and Leather Armor', 10, 7, 'Marshal Dughan', 'Goldshire', 1429, 42.11, 65.93, nil),
      }),
      Chain('kobold-candles', 'Kobold Candles', {
        Q(60, 'Kobold Candles', 7, 3, 'William Pestle', 'Goldshire inn', 1429, 43.32, 65.7, nil),
        Q(61, 'Shipment to Stormwind', 7, 3, 'William Pestle', 'Goldshire inn', 1429, 43.32, 65.7, nil),
      }),
      Chain('gold-dust', 'Gold Dust Exchange', {
        Q(47, 'Gold Dust Exchange', 7, 4, 'Remy Two Times', 'Goldshire', 1429, 42.14, 67.26, nil),
      }),
      Chain('lost-necklace', 'Lost Necklace', {
        Q(85, 'Lost Necklace', 6, 5, 'Auntie Bernice Stonefield', 'The Stonefield Farm', 1429, 34.49, 84.25, nil),
        Q(86, 'Pie for Billy', 6, 5, 'Billy Maclure', 'The Maclure Vineyards', 1429, 43.13, 85.72, nil),
        Q(84, 'Back to Billy', 6, 5, 'Auntie Bernice Stonefield', 'The Stonefield Farm', 1429, 34.49, 84.25, nil),
        Q(87, 'Goldtooth', 8, 5, 'Billy Maclure', 'The Maclure Vineyards', 1429, 43.13, 85.72, nil),
      }),
      Chain('young-lovers', 'Young Lovers', {
        Q(106, 'Young Lovers', 6, 5, 'Maybell Maclure', 'The Maclure Vineyards', 1429, 43.15, 89.62, nil),
        Q(111, 'Speak with Gramma', 6, 5, 'Tommy Joe Stonefield', 'The Stonefield Farm', 1429, 29.84, 85.97, nil),
        Q(107, 'Note to William', 6, 5, 'Gramma Stonefield', 'The Stonefield Farm', 1429, 34.94, 83.86, nil),
        Q(112, 'Collecting Kelp', 7, 5, 'William Pestle', 'Goldshire inn', 1429, 43.32, 65.7, nil),
        Q(114, 'The Escape', 7, 5, 'William Pestle', 'Goldshire inn', 1429, 43.32, 65.7, nil),
      }),
      Chain('protect-frontier', 'Protect the Frontier', {
        Q(52, 'Protect the Frontier', 7, 6, 'Guard Thomas', 'Eastvale road', 1429, 73.97, 72.18, nil),
        Q(5545, 'A Bundle of Trouble', 9, 5, 'Supervisor Raelen', 'Eastvale Logging Camp', 1429, 81.38, 66.11, nil),
        Q(83, 'Red Linen Goods', 9, 4, 'Sara Timberlain', 'Eastvale Logging Camp', 1429, 79.46, 68.79, nil),
        Q(88, 'Princess Must Die!', 9, 6, 'Ma Stonefield', 'The Stonefield Farm', 1429, 34.66, 84.48, nil),
        Q(176, 'Wanted: Hogger', 11, 5, 'Wanted Poster', 'Goldshire', 1429, 42.11, 65.93, nil),
        Q(46, 'Bounty on Murlocs', 10, 7, 'Guard Thomas', 'Eastvale road', 1429, 73.97, 72.18, nil),
      }),
      Chain('the-collector', 'The Collector', {
        Q(123, 'The Collector', 8, 7, 'Gold Pickup Schedule (item)', 'Riverpaw gnolls in Elwynn', 1429, 42.11, 65.93, nil),
        Q(147, 'Manhunt', 10, 7, 'Marshal Dughan', 'Goldshire', 1429, 42.11, 65.93, nil),
      }),
      Chain('report-gryan', 'Report to Gryan Stoutmantle', {
        Q(109, 'Report to Gryan Stoutmantle', 10, 9, 'Guard Thomas', 'Eastvale road', 1429, 73.97, 72.18, nil),
      }),
    },
  },
  ['Dun Morogh'] = {
    uiMapID = 1426,
    faction = "Alliance",
    minLevel = 1,
    maxLevel = 12,
    note = 'Coldridge Valley and Kharanos. Gnome and Dwarf start.',
    chains = {
      Chain('coldridge-outfitters', 'Dwarven Outfitters', {
        Q(179, 'Dwarven Outfitters', 1, 1, 'Sten Stoutarm', 'Coldridge Valley', 1426, 29.93, 71.2, nil),
      }),
      Chain('coldridge-mail', 'Coldridge Valley Mail Delivery', {
        Q(233, 'Coldridge Valley Mail Delivery', 2, 1, 'Sten Stoutarm', 'Coldridge Valley', 1426, 29.93, 71.2, nil),
        Q(234, 'Coldridge Valley Mail Delivery', 3, 1, 'Talin Keeneye', 'Coldridge Valley', 1426, 22.6, 71.43, nil),
        Q(182, 'The Troll Cave', 4, 1, 'Grelin Whitebeard', 'Coldridge Valley', 1426, 25.08, 75.71, nil),
        Q(218, 'The Stolen Journal', 5, 1, 'Grelin Whitebeard', 'Coldridge Valley', 1426, 25.08, 75.71, nil),
        Q(282, 'Senir\'s Observations', 5, 1, 'Grelin Whitebeard', 'Coldridge Valley', 1426, 25.08, 75.71, nil),
        Q(420, 'Senir\'s Observations', 5, 1, 'Mountaineer Thalos', 'Coldridge pass', 1426, 33.48, 71.84, nil),
      }),
      Chain('boar-hunter', 'The Boar Hunter', {
        Q(183, 'The Boar Hunter', 3, 1, 'Talin Keeneye', 'Coldridge Valley', 1426, 22.6, 71.43, nil),
      }),
      Chain('new-threat', 'A New Threat', {
        Q(170, 'A New Threat', 2, 1, 'Balir Frosthammer', 'Coldridge Valley', 1426, 29.71, 71.25, nil),
      }),
      Chain('mornbrew', 'Scalding Mornbrew Delivery', {
        Q(3364, 'Scalding Mornbrew Delivery', 4, 4, 'Nori Pridedrift', 'Coldridge Valley', 1426, 25.02, 75.88, nil),
        Q(3365, 'Bring Back the Mug', 5, 4, 'Durnan Furcutter', 'Anvilmar', 1426, 28.77, 66.37, nil),
      }),
      Chain('refugee', 'A Refugee\'s Quandary', {
        Q(3361, 'A Refugee\'s Quandary', 3, 1, 'Felix Whindlebolt', 'Anvilmar', 1426, 28.55, 67.87, nil),
      }),
      Chain('supplies-tannok', 'Supplies to Tannok', {
        Q(2160, 'Supplies to Tannok', 5, 1, 'Hands Springsprocket', 'Coldridge pass', 1426, 33.85, 72.18, nil),
      }),
      Chain('beer-ribs', 'Beer Basted Boar Ribs', {
        Q(384, 'Beer Basted Boar Ribs', 7, 5, 'Ragnar Thunderbrew', 'Kharanos', 1426, 46.83, 52.36, nil),
      }),
      Chain('stocking-jetsteam', 'Stocking Jetsteam', {
        Q(317, 'Stocking Jetsteam', 6, 2, 'Pilot Bellowfiz', 'Steelgrill\'s Depot', 1426, 49.43, 48.41, nil),
        Q(318, 'Evershine', 7, 2, 'Pilot Bellowfiz', 'Steelgrill\'s Depot', 1426, 49.43, 48.41, nil),
        Q(319, 'A Favor for Evershine', 8, 2, 'Rejold Barleybrew', 'Brewnall Village', 1426, 30.2, 45.73, nil),
        Q(320, 'Return to Bellowfiz', 8, 2, 'Rejold Barleybrew', 'Brewnall Village', 1426, 30.2, 45.73, nil),
        Q(413, 'Shimmer Stout', 9, 8, 'Rejold Barleybrew', 'Brewnall Village', 1426, 30.2, 45.73, nil),
        Q(414, 'Stout to Kadrell', 9, 8, 'Mountaineer Barleybrew', 'Dun Morogh to Loch pass', 1426, 86.28, 48.81, nil),
      }),
      Chain('frostmane-hold', 'Frostmane Hold', {
        Q(287, 'Frostmane Hold', 9, 7, 'Senir Whitebeard', 'Kharanos', 1426, 46.73, 53.83, nil),
        Q(291, 'The Reports', 10, 7, 'Senir Whitebeard', 'Kharanos', 1426, 46.73, 53.83, nil),
      }),
      Chain('recombobulation', 'Operation Recombobulation', {
        Q(412, 'Operation Recombobulation', 10, 7, 'Razzle Sprysprocket', 'Kharanos', 1426, 45.85, 49.37, nil),
      }),
      Chain('bitter-rivals', 'Bitter Rivals', {
        Q(310, 'Bitter Rivals', 6, 2, 'Marleth Barleybrew', 'Thunderbrew Distillery, Kharanos', 1426, 47.67, 52.33, nil),
        Q(311, 'Return to Marleth', 7, 2, 'Unguarded Thunder Ale Barrel', 'Thunderbrew Distillery cellar', 1426, 47.7, 52.7, nil),
      }),
      Chain('perfect-stout', 'The Perfect Stout', {
        Q(315, 'The Perfect Stout', 9, 5, 'Rejold Barleybrew', 'Brewnall Village', 1426, 30.2, 45.73, nil),
      }),
      Chain('tools-steelgrill', 'Tools for Steelgrill', {
        Q(400, 'Tools for Steelgrill', 5, 2, 'Tharek Blackstone', 'Kharanos', 1426, 46.02, 51.71, nil),
      }),
      Chain('ammo-rumbleshot', 'Ammo for Rumbleshot', {
        Q(5541, 'Ammo for Rumbleshot', 6, 5, 'Loslor Rudge', 'Steelgrill\'s Depot', 1426, 50.08, 49.42, nil),
      }),
      Chain('trogg-quarry', 'Those Blasted Troggs!', {
        Q(432, 'Those Blasted Troggs!', 9, 5, 'Foreman Stonebrow', 'Gol\'Bolar Quarry', 1426, 69.08, 56.33, nil),
        Q(433, 'The Public Servant', 11, 6, 'Senator Mehr Stonehallow', 'Gol\'Bolar Quarry', 1426, 68.67, 55.97, nil),
      }),
      Chain('lost-pilot', 'The Lost Pilot', {
        Q(419, 'The Lost Pilot', 10, 8, 'Pilot Hammerfoot', 'North Gate Outpost', 1426, 83.89, 39.19, nil),
        Q(417, 'A Pilot\'s Revenge', 11, 8, 'A Dwarven Corpse', 'Helm\'s Bed Lake area', 1426, 79.67, 36.17, nil),
      }),
    },
  },
  ['Teldrassil'] = {
    uiMapID = 1438,
    faction = "Alliance",
    minLevel = 1,
    maxLevel = 10,
    note = 'Shadowglen, Dolanaar, and the Crown of the Earth chain. Night Elf start.',
    chains = {
      Chain('balance-of-nature', 'The Balance of Nature', {
        Q(456, 'The Balance of Nature', 2, 1, 'Conservator Ilthalaine', 'Shadowglen', 1438, 58.69, 44.27, nil),
        Q(457, 'The Balance of Nature', 3, 1, 'Conservator Ilthalaine', 'Shadowglen', 1438, 58.69, 44.27, nil),
      }),
      Chain('woodland-protector', 'The Woodland Protector', {
        Q(458, 'The Woodland Protector', 1, 1, 'Conservator Ilthalaine', 'Shadowglen', 1438, 58.69, 44.27, nil),
        Q(459, 'The Woodland Protector', 3, 1, 'Tarindrella', 'Shadowglen', 1438, 57.83, 45.2, nil),
      }),
      Chain('webwood', 'Webwood Venom and Crown of the Earth', {
        Q(916, 'Webwood Venom', 3, 1, 'Gilshalan Windwalker', 'Aldrassil', 1438, 57.81, 41.65, nil),
        Q(917, 'Webwood Egg', 5, 1, 'Gilshalan Windwalker', 'Aldrassil', 1438, 57.81, 41.65, nil),
        Q(920, 'Tenaron\'s Summons', 5, 1, 'Gilshalan Windwalker', 'Aldrassil', 1438, 57.81, 41.65, nil),
        Q(921, 'Crown of the Earth', 5, 1, 'Tenaron Stormgrip', 'Aldrassil treetop', 1438, 59.06, 39.45, nil),
        Q(928, 'Crown of the Earth', 5, 1, 'Tenaron Stormgrip', 'Aldrassil treetop', 1438, 59.06, 39.45, nil),
        Q(929, 'Crown of the Earth', 5, 1, 'Corithras Moonrage', 'Dolanaar', 1438, 56.15, 61.71, nil),
        Q(933, 'Crown of the Earth', 9, 1, 'Corithras Moonrage', 'Dolanaar', 1438, 56.15, 61.71, nil),
        Q(7383, 'Crown of the Earth', 10, 1, 'Corithras Moonrage', 'Dolanaar', 1438, 56.15, 61.71, nil),
        Q(935, 'Crown of the Earth', 10, 1, 'Corithras Moonrage', 'Dolanaar', 1438, 56.15, 61.71, nil),
      }),
      Chain('good-friend', 'A Good Friend', {
        Q(4495, 'A Good Friend', 4, 2, 'Dirania Silvershine', 'Shadowglen', 1438, 60.9, 41.96, nil),
        Q(3519, 'A Friend in Need', 4, 2, 'Iverron', 'Shadowglen cave', 1438, 54.6, 32.99, nil),
        Q(3521, 'Iverron\'s Antidote', 4, 2, 'Dirania Silvershine', 'Shadowglen', 1438, 60.9, 41.96, nil),
        Q(3522, 'Iverron\'s Antidote', 4, 2, 'Dirania Silvershine', 'Shadowglen', 1438, 60.9, 41.96, nil),
      }),
      Chain('zenn', 'Zenn\'s Bidding', {
        Q(488, 'Zenn\'s Bidding', 5, 4, 'Zenn Foulhoof', 'East of Dolanaar', 1438, 60.45, 56.15, nil),
        Q(489, 'Seek Redemption!', 7, 4, 'Syral Bladeleaf', 'Dolanaar', 1438, 56.08, 57.73, nil),
      }),
      Chain('dolanaar-delivery', 'Dolanaar Delivery', {
        Q(2159, 'Dolanaar Delivery', 5, 1, 'Porthannius', 'Road from Shadowglen', 1438, 61.16, 47.64, nil),
      }),
      Chain('troubling-breeze', 'A Troubling Breeze', {
        Q(475, 'A Troubling Breeze', 6, 4, 'Athridas Bearmantle', 'Dolanaar', 1438, 55.95, 57.28, nil),
        Q(476, 'Gnarlpine Corruption', 6, 4, 'Gaerolas Talvethren', 'Starbreeze Village', 1438, 66.26, 58.52, nil),
        Q(483, 'The Relics of Wakening', 8, 4, 'Athridas Bearmantle', 'Dolanaar', 1438, 55.95, 57.28, nil),
        Q(486, 'Ursal the Mauler', 11, 4, 'Athridas Bearmantle', 'Dolanaar', 1438, 55.95, 57.28, nil),
      }),
      Chain('road-darnassus', 'The Road to Darnassus', {
        Q(487, 'The Road to Darnassus', 8, 5, 'Moon Priestess Amara', 'Road west of Dolanaar', 1438, 49.94, 53.54, nil),
      }),
      Chain('twisted-hatred', 'Twisted Hatred', {
        Q(932, 'Twisted Hatred', 7, 4, 'Tallonkai Swiftroot', 'Dolanaar', 1438, 55.57, 56.95, nil),
      }),
      Chain('dreamcatcher', 'The Emerald Dreamcatcher', {
        Q(2438, 'The Emerald Dreamcatcher', 6, 1, 'Tallonkai Swiftroot', 'Dolanaar', 1438, 55.57, 56.95, nil),
        Q(2459, 'Ferocitas the Dream Eater', 8, 1, 'Tallonkai Swiftroot', 'Dolanaar', 1438, 55.57, 56.95, nil),
      }),
      Chain('denalan', 'Denalan\'s Earth', {
        Q(997, 'Denalan\'s Earth', 7, 4, 'Syral Bladeleaf', 'Dolanaar', 1438, 56.08, 57.73, nil),
        Q(918, 'Timberling Seeds', 7, 4, 'Denalan', 'Lake Al\'Ameth', 1438, 60.9, 68.49, nil),
        Q(919, 'Timberling Sprouts', 7, 4, 'Denalan', 'Lake Al\'Ameth', 1438, 60.9, 68.49, nil),
        Q(922, 'Rellian Greenspyre', 8, 4, 'Denalan', 'Lake Al\'Ameth', 1438, 60.9, 68.49, nil),
        Q(923, 'Tumors', 9, 4, 'Rellian Greenspyre', 'Cenarion Enclave, Darnassus', 1457, 38.32, 21.61, nil),
        Q(2498, 'Return to Denalan', 9, 4, 'Rellian Greenspyre', 'Darnassus', 1457, 38.32, 21.61, nil),
        Q(2499, 'Oakenscowl', 9, 4, 'Denalan', 'Lake Al\'Ameth', 1438, 60.9, 68.49, nil),
      }),
      Chain('mist', 'Mist', {
        Q(938, 'Mist', 10, 7, 'Mist', 'Path to the Oracle Glade', 1438, 31.54, 31.61, nil),
      }),
      Chain('nessa', 'Nessa Shadowsong', {
        Q(6344, 'Nessa Shadowsong', 10, 10, 'Nyoma', 'Dolanaar', 1438, 56.25, 59.43, nil),
        Q(6341, 'The Bounty of Teldrassil', 10, 10, 'Nessa Shadowsong', 'Rut\'theran Village', 1438, 56.25, 92.44, nil),
        Q(6342, 'Flight to Auberdine', 10, 10, 'Vesprystus', 'Rut\'theran Village', 1438, 58.4, 94.02, nil),
        Q(6343, 'Return to Nessa', 10, 10, 'Laird', 'Auberdine', 1439, 36.77, 44.29, nil),
      }),
    },
  },
  ['Darkshore'] = {
    uiMapID = 1439,
    faction = "Alliance",
    minLevel = 10,
    maxLevel = 20,
    note = 'Auberdine is the hub. Beached sea creature quests are turned in to Gwennyth Bly\'Leggonde.',
    chains = {
      Chain('washed-ashore', 'Washed Ashore', {
        Q(3524, 'Washed Ashore', 12, 11, 'Gwennyth Bly\'Leggonde', 'Auberdine dock', 1439, 36.62, 45.59, nil),
        Q(4681, 'Washed Ashore', 13, 11, 'Gwennyth Bly\'Leggonde', 'Auberdine dock', 1439, 36.62, 45.59, nil),
      }),
      Chain('buzzbox', 'Buzzbox', {
        Q(983, 'Buzzbox 827', 10, 7, 'Wizbang Cranktoggle', 'Auberdine', 1439, 36.98, 44.14, nil),
        Q(1001, 'Buzzbox 411', 12, 10, 'Buzzbox 827', 'South of Auberdine', 1439, 36.66, 46.26, nil),
        Q(1002, 'Buzzbox 323', 14, 10, 'Buzzbox 411', 'North coast of Darkshore', 1439, 41.98, 28.64, nil),
        Q(1003, 'Buzzbox 525', 16, 10, 'Buzzbox 323', 'Cliffspring River', 1439, 51.28, 24.58, nil),
      }),
      Chain('plagued-lands', 'Plagued Lands', {
        Q(2118, 'Plagued Lands', 11, 10, 'Tharnariun Treetender', 'Auberdine', 1439, 38.84, 43.42, nil),
        Q(2138, 'Cleansing of the Infected', 14, 10, 'Tharnariun Treetender', 'Auberdine', 1439, 38.84, 43.42, nil),
        Q(2139, 'Tharnariun\'s Hope', 16, 10, 'Tharnariun Treetender', 'Auberdine', 1439, 38.84, 43.42, nil),
      }),
      Chain('how-big-threat', 'How Big a Threat?', {
        Q(984, 'How Big a Threat?', 12, 10, 'Terenthis', 'Auberdine', 1439, 39.37, 43.48, nil),
        Q(985, 'How Big a Threat?', 14, 10, 'Terenthis', 'Auberdine', 1439, 39.37, 43.48, nil),
        Q(986, 'A Lost Master', 16, 10, 'Terenthis', 'Auberdine', 1439, 39.37, 43.48, nil),
        Q(993, 'A Lost Master', 20, 10, 'Terenthis', 'Auberdine', 1439, 39.37, 43.48, nil),
        Q(994, 'Escape Through Force', 20, 10, 'Volcor', 'Cave south of Auberdine', 1439, 45.0, 85.4, nil),
      }),
      Chain('thundris', 'Thundris Windweaver', {
        Q(4761, 'Thundris Windweaver', 11, 9, 'Barithras Moonshade', 'Auberdine', 1439, 37.32, 43.64, nil),
        Q(4762, 'The Cliffspring River', 15, 11, 'Thundris Windweaver', 'Auberdine', 1439, 37.4, 40.13, nil),
        Q(4763, 'The Blackwood Corrupted', 18, 15, 'Thundris Windweaver', 'Auberdine', 1439, 37.4, 40.13, nil),
      }),
      Chain('red-crystal', 'The Red Crystal', {
        Q(4811, 'The Red Crystal', 12, 12, 'Sentinel Glynda Nal\'Shea', 'Auberdine', 1439, 37.71, 43.39, nil),
        Q(4812, 'As Water Cascades', 14, 12, 'Sentinel Glynda Nal\'Shea', 'Auberdine', 1439, 37.71, 43.39, nil),
        Q(4813, 'The Fragments Within', 14, 12, 'Mysterious Red Crystal', 'Mountains east of Auberdine', 1439, 47.29, 48.69, nil),
      }),
      Chain('cave-mushrooms', 'Cave Mushrooms', {
        Q(947, 'Cave Mushrooms', 14, 12, 'Barithras Moonshade', 'Auberdine', 1439, 37.32, 43.64, nil),
        Q(948, 'Onu', 17, 12, 'Barithras Moonshade', 'Auberdine', 1439, 37.32, 43.64, nil),
        Q(944, 'The Master\'s Glaive', 17, 12, 'Onu', 'Grove of the Ancients', 1439, 43.55, 76.29, nil),
        Q(949, 'The Twilight Camp', 17, 12, 'The Master\'s Glaive (scrying)', 'The Master\'s Glaive', 1439, 38.54, 86.05, nil),
        Q(950, 'Return to Onu', 17, 12, 'Twilight Tome', 'The Master\'s Glaive', 1439, 38.54, 86.05, nil),
      }),
      Chain('prospector', 'The Absent Minded Prospector', {
        Q(729, 'The Absent Minded Prospector', 16, 15, 'Prospector Remtravel', 'On the southwest ruins', 1439, 35.74, 83.7, nil),
        Q(731, 'The Absent Minded Prospector', 20, 15, 'Prospector Remtravel', 'On the southwest ruins', 1439, 35.74, 83.7, nil),
        Q(741, 'The Absent Minded Prospector', 20, 15, 'Archaeologist Hollee', 'Auberdine', 1439, 37.44, 41.84, nil),
        Q(942, 'The Absent Minded Prospector', 20, 15, 'Chief Archaeologist Greywhisker', 'Darnassus', 1457, 31.25, 84.5, nil),
        Q(943, 'The Absent Minded Prospector', 24, 15, 'Archaeologist Flagonguard', 'Menethil Harbor', 1437, 10.84, 60.36, nil),
      }),
      Chain('easy-strider', 'Easy Strider Flesh', {
        Q(2178, 'Easy Strider Flesh', 12, 9, 'Alanndarian Nightsong', 'Auberdine', 1439, 37.69, 40.65, nil),
      }),
      Chain('fruit-of-the-sea', 'Fruit of the Sea', {
        Q(1138, 'Fruit of the Sea', 17, 15, 'Gubber Blump', 'Auberdine dock', 1439, 36.1, 44.93, nil),
      }),
      Chain('gyromast', 'Gyromast\'s Retrieval', {
        Q(2098, 'Gyromast\'s Retrieval', 14, 12, 'Gelkak Gyromast', 'North of Auberdine, coast', 1439, 56.66, 13.5, nil),
        Q(2078, 'Gyromast\'s Revenge', 18, 12, 'Gelkak Gyromast', 'North of Auberdine, coast', 1439, 56.66, 13.5, nil),
      }),
      Chain('wanted-murkdeep', 'WANTED: Murkdeep!', {
        Q(4740, 'WANTED: Murkdeep!', 18, 15, 'Wanted Poster', 'Auberdine', 1439, 37.22, 44.23, nil),
      }),
      Chain('for-love-eternal', 'For Love Eternal', {
        Q(963, 'For Love Eternal', 16, 11, 'Cerellean Whiteclaw', 'Auberdine', 1439, 35.74, 43.71, nil),
      }),
      Chain('tower-althalaxx', 'The Tower of Althalaxx', {
        Q(965, 'The Tower of Althalaxx', 18, 13, 'Sentinel Elissa Starbreeze', 'Auberdine', 1439, 39.04, 43.56, nil),
        Q(966, 'The Tower of Althalaxx', 18, 13, 'Balthule Shadowstrike', 'Tower of Althalaxx', 1439, 54.97, 24.89, nil),
        Q(967, 'The Tower of Althalaxx', 18, 13, 'Balthule Shadowstrike', 'Tower of Althalaxx', 1439, 54.97, 24.89, nil),
      }),
      Chain('onward-ashenvale', 'Onward to Ashenvale', {
        Q(10752, 'Onward to Ashenvale', 19, 18, 'Thundris Windweaver', 'Auberdine', 1439, 37.4, 40.13, nil),
      }),
      Chain('beached', 'Beached Sea Creatures', {
        Q(4723, 'Beached Sea Creature', 13, 11, 'Beached Sea Creature', 'South of Auberdine', 1439, 42.0, 31.6, nil),
        Q(4722, 'Beached Sea Turtle', 13, 12, 'Beached Sea Turtle', 'South of Auberdine', 1439, 37.1, 62.2, nil),
        Q(4725, 'Beached Sea Turtle', 15, 12, 'Beached Sea Turtle', 'North of Auberdine', 1439, 44.2, 20.6, nil),
        Q(4727, 'Beached Sea Turtle', 16, 12, 'Beached Sea Turtle', 'Mist\'s Edge', 1439, 53.1, 18.1, nil),
        Q(4728, 'Beached Sea Creature', 14, 12, 'Beached Sea Creature', 'Mist\'s Edge', 1439, 53.4, 20.0, nil),
        Q(4730, 'Beached Sea Creature', 16, 13, 'Beached Sea Creature', 'North Darkshore', 1439, 51.2, 9.1, nil),
        Q(4731, 'Beached Sea Turtle', 19, 13, 'Beached Sea Turtle', 'North Darkshore', 1439, 52.8, 11.1, nil),
        Q(4732, 'Beached Sea Turtle', 19, 13, 'Beached Sea Turtle', 'North Darkshore', 1439, 53.0, 18.8, nil),
        Q(4733, 'Beached Sea Creature', 19, 13, 'Beached Sea Creature', 'North Darkshore', 1439, 52.9, 2.9, nil),
      }),
    },
  },
  ['Westfall'] = {
    uiMapID = 1436,
    faction = "Alliance",
    minLevel = 9,
    maxLevel = 18,
    note = 'Sentinel Hill is the hub. The Defias chain is the main story and ends inside the Deadmines.',
    chains = {
      Chain('furlbrow', 'The Forgotten Heirloom', {
        Q(64, 'The Forgotten Heirloom', 12, 9, 'Farmer Furlbrow', 'Jangolode / Furlbrow farm', 1436, 60.0, 19.37, nil),
        Q(151, 'Poor Old Blanchy', 14, 9, 'Verna Furlbrow', 'Furlbrow farm', 1436, 59.99, 19.42, nil),
        Q(36, 'Westfall Stew', 10, 9, 'Verna Furlbrow', 'Furlbrow farm', 1436, 59.99, 19.42, nil),
        Q(38, 'Westfall Stew', 13, 9, 'Salma Saldean', 'Saldean\'s Farm', 1436, 56.42, 30.52, nil),
        Q(22, 'Goretusk Liver Pie', 12, 9, 'Salma Saldean', 'Saldean\'s Farm', 1436, 56.42, 30.52, nil),
        Q(9, 'The Killing Fields', 12, 8, 'Farmer Saldean', 'Saldean\'s Farm', 1436, 56.04, 31.23, nil),
      }),
      Chain('peoples-militia', 'The People\'s Militia', {
        Q(12, 'The People\'s Militia', 12, 9, 'Gryan Stoutmantle', 'Sentinel Hill', 1436, 56.33, 47.52, nil),
        Q(13, 'The People\'s Militia', 14, 9, 'Gryan Stoutmantle', 'Sentinel Hill', 1436, 56.33, 47.52, nil),
        Q(14, 'The People\'s Militia', 17, 9, 'Gryan Stoutmantle', 'Sentinel Hill', 1436, 56.33, 47.52, nil),
      }),
      Chain('defias', 'The Defias Brotherhood', {
        Q(65, 'The Defias Brotherhood', 18, 14, 'Gryan Stoutmantle', 'Sentinel Hill', 1436, 56.33, 47.52, nil),
        Q(132, 'The Defias Brotherhood', 18, 14, 'Wiley the Black', 'Lakeshire inn, Redridge', 1433, 26.48, 45.34, nil),
        Q(135, 'The Defias Brotherhood', 18, 14, 'Gryan Stoutmantle', 'Sentinel Hill', 1436, 56.33, 47.52, nil),
        Q(141, 'The Defias Brotherhood', 18, 14, 'Master Mathias Shaw', 'SI:7, Stormwind Old Town', 1453, 75.78, 59.84, nil),
        Q(142, 'The Defias Brotherhood', 18, 14, 'Gryan Stoutmantle', 'Sentinel Hill', 1436, 56.33, 47.52, nil),
        Q(155, 'The Defias Traitor', 18, 14, 'The Defias Traitor', 'Sentinel Hill', 1436, 55.68, 47.5, nil),
        Q(166, 'The Defias Brotherhood', 22, 14, 'Gryan Stoutmantle', 'Sentinel Hill', 1436, 56.33, 47.52, nil),
      }),
      Chain('red-leather', 'Red Leather Bandanas', {
        Q(153, 'Red Leather Bandanas', 15, 10, 'Scout Galiaan', 'Sentinel Hill', 1436, 53.99, 53.0, nil),
        Q(214, 'Red Silk Bandanas', 17, 14, 'Scout Riell', 'Sentinel Hill tower', 1436, 56.67, 47.35, { prev = 155 }),
      }),
      Chain('patrolling', 'Patrolling Westfall', {
        Q(102, 'Patrolling Westfall', 14, 8, 'Captain Danuvin', 'Sentinel Hill', 1436, 56.42, 47.62, nil),
      }),
      Chain('coast', 'The Coast isn\'t Clear', {
        Q(152, 'The Coast isn\'t Clear', 15, 10, 'Captain Grayson', 'Westfall lighthouse', 1436, 30.02, 86.02, nil),
        Q(104, 'The Coastal Menace', 19, 15, 'Captain Grayson', 'Westfall lighthouse', 1436, 30.02, 86.02, nil),
        Q(103, 'Keeper of the Flame', 16, 10, 'Captain Grayson', 'Westfall lighthouse', 1436, 30.02, 86.02, nil),
      }),
    },
  },
  ['Loch Modan'] = {
    uiMapID = 1432,
    faction = "Alliance",
    minLevel = 10,
    maxLevel = 20,
    note = 'Thelsamar is the hub. Hall of Thanes under Ironforge is the natural first dungeon on the Gnome path.',
    chains = {
      Chain('kings-lands', 'In Defense of the King\'s Lands', {
        Q(224, 'In Defense of the King\'s Lands', 12, 10, 'Mountaineer Cobbleflint', 'Valley of Kings', 1432, 22.07, 73.13, nil),
        Q(237, 'In Defense of the King\'s Lands', 15, 10, 'Mountaineer Gravelgaw', 'Valley of Kings', 1432, 23.53, 76.4, nil),
        Q(263, 'In Defense of the King\'s Lands', 15, 10, 'Mountaineer Wallbang', 'Valley of Kings', 1432, 23.47, 74.49, nil),
        Q(217, 'In Defense of the King\'s Lands', 17, 10, 'Captain Rugelfuss', 'Valley of Kings', 1432, 23.23, 73.68, nil),
      }),
      Chain('stormpike', 'Mountaineer Stormpike\'s Task', {
        Q(1339, 'Mountaineer Stormpike\'s Task', 15, 9, 'Mountaineer Kadrell', 'Thelsamar', 1432, 34.83, 47.14, nil),
        Q(1338, 'Stormpike\'s Order', 14, 9, 'Mountaineer Stormpike', 'Algaz Station', 1432, 24.76, 18.4, nil),
        Q(307, 'Filthy Paws', 15, 9, 'Mountaineer Stormpike', 'Algaz Station', 1432, 24.76, 18.4, nil),
      }),
      Chain('rat-catching', 'Rat Catching', {
        Q(416, 'Rat Catching', 15, 10, 'Mountaineer Kadrell', 'Thelsamar', 1432, 34.83, 47.14, nil),
        Q(418, 'Thelsamar Blood Sausages', 12, 7, 'Vidra Hearthstove', 'Thelsamar inn', 1432, 34.83, 49.28, nil),
      }),
      Chain('hunter-boast', 'A Hunter\'s Boast', {
        Q(257, 'A Hunter\'s Boast', 12, 11, 'Daryl the Youngling', 'Farstrider Lodge', 1432, 83.47, 65.4, nil),
        Q(258, 'A Hunter\'s Challenge', 15, 11, 'Daryl the Youngling', 'Farstrider Lodge', 1432, 83.47, 65.4, nil),
        Q(271, 'Vyrin\'s Revenge', 15, 15, 'Vyrin Swiftwind', 'Farstrider Lodge', 1432, 81.76, 64.15, nil),
        Q(531, 'Vyrin\'s Revenge', 15, 15, 'Daryl the Youngling', 'Farstrider Lodge', 1432, 83.47, 65.4, nil),
      }),
      Chain('crocolisk', 'Crocolisk Hunting', {
        Q(385, 'Crocolisk Hunting', 15, 10, 'Marek Ironheart', 'Farstrider Lodge', 1432, 81.76, 61.66, nil),
      }),
      Chain('dark-threat', 'A Dark Threat Looms', {
        Q(250, 'A Dark Threat Looms', 16, 12, 'Chief Engineer Hinderweir VII', 'Stonewrought Dam', 1432, 46.05, 13.62, nil),
        Q(199, 'A Dark Threat Looms', 16, 16, 'Suspicious Barrel', 'East of the dam', 1432, 56.07, 13.24, nil),
        Q(161, 'A Dark Threat Looms', 16, 16, 'Chief Engineer Hinderweir VII', 'Stonewrought Dam', 1432, 46.05, 13.62, nil),
        Q(274, 'A Dark Threat Looms', 18, 16, 'Ashlan Stonesmirk', 'Dun Modr, Wetlands', 1437, 49.92, 18.23, nil),
        Q(278, 'A Dark Threat Looms', 18, 16, 'Chief Engineer Hinderweir VII', 'Stonewrought Dam', 1432, 46.05, 13.62, nil),
        Q(280, 'A Dark Threat Looms', 18, 16, 'Chief Engineer Hinderweir VII', 'Stonewrought Dam', 1432, 46.05, 13.62, nil),
        Q(283, 'A Dark Threat Looms', 20, 16, 'Explosives (disarm)', 'East of the dam', 1432, 50.6, 14.3, nil),
      }),
      Chain('ironband', 'Ironband\'s Excavation', {
        Q(436, 'Ironband\'s Excavation', 15, 13, 'Jern Hornhelm', 'Thelsamar', 1432, 37.24, 47.39, nil),
        Q(297, 'Gathering Idols', 18, 13, 'Magmar Felhew', 'Ironband\'s Excavation', 1432, 64.89, 66.66, nil),
        Q(298, 'Excavation Progress Report', 15, 13, 'Prospector Ironband', 'Ironband\'s Excavation', 1432, 65.93, 65.62, nil),
        Q(301, 'Report to Ironforge', 15, 13, 'Jern Hornhelm', 'Thelsamar', 1432, 37.24, 47.39, nil),
        Q(302, 'Powder to Ironband', 15, 13, 'Prospector Stormpike', 'The Library, Ironforge', 1455, 74.64, 11.74, nil),
      }),
      Chain('mercenaries', 'Mercenaries', {
        Q(255, 'Mercenaries', 19, 15, 'Magistrate Bluntnose', 'Thelsamar', 1432, 34.69, 44.54, nil),
        Q(256, 'WANTED: Chok\'sul', 22, 17, 'Wanted Poster', 'Thelsamar', 1432, 37.23, 46.44, nil),
      }),
    },
  },
  ['Redridge Mountains'] = {
    uiMapID = 1433,
    faction = "Alliance",
    minLevel = 15,
    maxLevel = 25,
    note = 'Lakeshire is the hub. Several breadcrumb and Defias steps also pass through here.',
    chains = {
      Chain('encroaching-gnolls', 'Encroaching Gnolls', {
        Q(244, 'Encroaching Gnolls', 16, 11, 'Guard Parker', 'Three Corners', 1433, 15.27, 71.45, nil),
        Q(246, 'Assessing the Threat', 19, 11, 'Deputy Feldon', 'Lakeshire', 1433, 30.73, 59.99, nil),
      }),
      Chain('blackrock-menace', 'The Blackrock Menace', {
        Q(20, 'Blackrock Menace', 21, 18, 'Marshal Marris', 'Lakeshire', 1433, 33.5, 48.97, nil),
        Q(19, 'Tharil\'zun', 25, 18, 'Marshal Marris', 'Lakeshire', 1433, 33.5, 48.97, nil),
        Q(115, 'Shadow Magic', 23, 18, 'Marshal Marris', 'Lakeshire', 1433, 33.5, 48.97, nil),
        Q(169, 'Wanted: Gath\'Ilzogg', 26, 15, 'Wanted Poster', 'Lakeshire town hall', 1433, 29.62, 46.23, nil),
      }),
      Chain('verner', 'The Price of Shoes', {
        Q(118, 'The Price of Shoes', 16, 14, 'Verner Osgood', 'Lakeshire', 1433, 30.98, 47.27, nil),
        Q(119, 'Return to Verner', 16, 14, 'Smith Argus', 'Goldshire', 1429, 41.71, 65.55, nil),
        Q(122, 'Underbelly Scales', 18, 14, 'Verner Osgood', 'Lakeshire', 1433, 30.98, 47.27, nil),
        Q(124, 'A Baying of Gnolls', 20, 15, 'Verner Osgood', 'Lakeshire', 1433, 30.98, 47.27, nil),
        Q(126, 'Howling in the Hills', 21, 15, 'Verner Osgood', 'Lakeshire', 1433, 30.98, 47.27, nil),
      }),
      Chain('everstill', 'The Lost Tools', {
        Q(125, 'The Lost Tools', 16, 15, 'Foreman Oslow', 'Lakeshire bridge', 1433, 32.14, 48.64, nil),
        Q(89, 'The Everstill Bridge', 20, 15, 'Foreman Oslow', 'Lakeshire bridge', 1433, 32.14, 48.64, nil),
      }),
      Chain('free-lunch', 'A Free Lunch', {
        Q(129, 'A Free Lunch', 15, 12, 'Darcy', 'Lakeshire inn', 1433, 26.75, 44.34, nil),
        Q(130, 'Visit the Herbalist', 15, 12, 'Guard Parker', 'Three Corners', 1433, 15.27, 71.45, nil),
        Q(131, 'Delivering Daffodils', 15, 12, 'Martie Jainrose', 'Lakeshire', 1433, 21.86, 46.33, nil),
      }),
      Chain('redridge-goulash', 'Redridge Goulash', {
        Q(92, 'Redridge Goulash', 18, 15, 'Chef Breanna', 'Lakeshire', 1433, 22.68, 43.84, nil),
        Q(34, 'An Unwelcome Guest', 18, 18, 'Martie Jainrose', 'Lakeshire', 1433, 21.86, 46.33, nil),
      }),
      Chain('dry-times', 'Dry Times', {
        Q(116, 'Dry Times', 18, 12, 'Barkeep Daniels', 'Lakeshire inn', 1433, 26.48, 43.7, nil),
      }),
      Chain('murloc-poachers', 'Murloc Poachers', {
        Q(150, 'Murloc Poachers', 20, 20, 'Dockmaster Baren', 'Lakeshire docks', 1433, 27.35, 47.38, nil),
        Q(127, 'Selling Fish', 21, 16, 'Dockmaster Baren', 'Lakeshire docks', 1433, 27.35, 47.38, nil),
      }),
      Chain('solomon-law', 'Solomon\'s Law', {
        Q(91, 'Solomon\'s Law', 23, 17, 'Bailiff Conacher', 'Lakeshire town hall', 1433, 29.72, 44.27, nil),
        Q(180, 'Wanted: Lieutenant Fangore', 23, 15, 'Wanted Poster', 'Lakeshire town hall', 1433, 29.62, 46.23, nil),
      }),
      Chain('blackrock-bounty', 'Blackrock Bounty', {
        Q(128, 'Blackrock Bounty', 25, 20, 'Guard Howe', 'Lakeshire', 1433, 31.54, 57.86, nil),
      }),
      Chain('missing-in-action', 'Missing In Action', {
        Q(219, 'Missing In Action', 25, 19, 'Corporal Keeshan', 'Render\'s Rock cave', 1433, 28.4, 12.6, nil),
      }),
    },
  },
  ['Duskwood'] = {
    uiMapID = 1431,
    faction = "Alliance",
    minLevel = 18,
    maxLevel = 30,
    note = 'Darkshire is the hub. Several long chains travel to Elwynn, Westfall, and Wetlands.',
    chains = {
      Chain('stalvan', 'The Legend of Stalvan', {
        Q(66, 'The Legend of Stalvan', 28, 22, 'Clerk Daltry', 'Darkshire town hall', 1431, 72.6, 46.85, nil),
        Q(67, 'The Legend of Stalvan', 28, 22, 'Clerk Daltry', 'Darkshire town hall', 1431, 72.6, 46.85, nil),
        Q(68, 'The Legend of Stalvan', 28, 22, 'Old Footlocker', 'Moonbrook schoolhouse, Westfall', 1436, 41.51, 66.72, nil),
        Q(69, 'The Legend of Stalvan', 28, 22, 'Clerk Daltry', 'Darkshire town hall', 1431, 72.6, 46.85, nil),
        Q(70, 'The Legend of Stalvan', 28, 22, 'Innkeeper Farley', 'Lion\'s Pride Inn, Goldshire', 1429, 43.77, 65.81, nil),
        Q(72, 'The Legend of Stalvan', 28, 22, 'A sealed chest', 'Lion\'s Pride Inn upstairs', 1429, 44.22, 65.78, nil),
        Q(74, 'The Legend of Stalvan', 28, 22, 'Clerk Daltry', 'Darkshire town hall', 1431, 72.6, 46.85, nil),
        Q(75, 'The Legend of Stalvan', 28, 22, 'Marshal Haggard', 'Eastvale Logging Camp', 1429, 84.61, 69.37, nil),
        Q(78, 'The Legend of Stalvan', 28, 22, 'Marshal Haggard', 'Eastvale Logging Camp', 1429, 84.61, 69.37, nil),
        Q(79, 'The Legend of Stalvan', 28, 22, 'Tavernkeep Smitts', 'Darkshire inn', 1431, 73.78, 44.49, nil),
        Q(80, 'The Legend of Stalvan', 28, 22, 'Tavernkeep Smitts', 'Darkshire inn', 1431, 73.78, 44.49, nil),
        Q(97, 'The Legend of Stalvan', 28, 22, 'Clerk Daltry', 'Darkshire town hall', 1431, 72.6, 46.85, nil),
        Q(98, 'The Legend of Stalvan', 32, 22, 'Commander Althea Ebonlocke', 'Darkshire town hall', 1431, 73.59, 46.89, nil),
      }),
      Chain('sven-morbent', 'Sven\'s Camp and Morbent Fel', {
        Q(164, 'Deliveries to Sven', 23, 17, 'Elaine Carevin', 'Darkshire', 1431, 75.33, 48.07, nil),
        Q(95, 'Sven\'s Revenge', 25, 20, 'Sven Yorgen', 'The Hushed Bank', 1431, 7.79, 34.15, nil),
        Q(230, 'Sven\'s Camp', 25, 20, 'A mound of loose dirt', 'The Dawning Wood, Westfall border', 1436, 49.86, 77.7, nil),
        Q(262, 'The Shadowy Figure', 25, 20, 'Sven Yorgen', 'The Hushed Bank', 1431, 7.79, 34.15, nil),
        Q(265, 'The Shadowy Search Continues', 25, 20, 'Madame Eva', 'Darkshire', 1431, 75.81, 45.3, nil),
        Q(266, 'Inquire at the Inn', 25, 20, 'Clerk Daltry', 'Darkshire town hall', 1431, 72.6, 46.85, nil),
        Q(453, 'Finding the Shadowy Figure', 25, 20, 'Tavernkeep Smitts', 'Darkshire inn', 1431, 73.78, 44.49, nil),
        Q(268, 'Return to Sven', 25, 20, 'Jitters', 'Raven Hill', 1431, 18.37, 56.36, nil),
        Q(323, 'Proving Your Worth', 25, 20, 'Sven Yorgen', 'The Hushed Bank', 1431, 7.79, 34.15, nil),
        Q(269, 'Seeking Wisdom', 29, 20, 'Sven Yorgen', 'The Hushed Bank', 1431, 7.79, 34.15, nil),
        Q(270, 'The Doomed Fleet', 29, 20, 'Bishop Farthing', 'Stormwind Cathedral', 1453, 39.11, 27.87, nil),
        Q(321, 'Lightforge Iron', 29, 20, 'Glorin Steelbrow', 'Menethil Harbor inn', 1437, 10.61, 60.77, nil),
        Q(55, 'Morbent Fel', 32, 20, 'Sven Yorgen', 'The Hushed Bank', 1431, 7.79, 34.15, nil),
      }),
      Chain('night-watch', 'The Night Watch', {
        Q(56, 'The Night Watch', 24, 18, 'Commander Althea Ebonlocke', 'Darkshire town hall', 1431, 73.59, 46.89, nil),
        Q(57, 'The Night Watch', 26, 18, 'Commander Althea Ebonlocke', 'Darkshire town hall', 1431, 73.59, 46.89, nil),
        Q(58, 'The Night Watch', 30, 18, 'Commander Althea Ebonlocke', 'Darkshire town hall', 1431, 73.59, 46.89, nil),
      }),
      Chain('worgen', 'Worgen in the Woods', {
        Q(173, 'Worgen in the Woods', 28, 23, 'Calor', 'Darkshire', 1431, 75.73, 47.56, nil),
        Q(221, 'Worgen in the Woods', 29, 23, 'Calor', 'Darkshire', 1431, 75.73, 47.56, nil),
        Q(222, 'Worgen in the Woods', 31, 23, 'Calor', 'Darkshire', 1431, 75.73, 47.56, nil),
        Q(223, 'Worgen in the Woods', 31, 23, 'Calor', 'Darkshire', 1431, 75.73, 47.56, nil),
      }),
      Chain('look-to-stars', 'Look To The Stars', {
        Q(174, 'Look To The Stars', 25, 20, 'Viktori Prism\'Antras', 'Darkshire', 1431, 79.8, 48.02, nil),
        Q(175, 'Look To The Stars', 25, 20, 'Viktori Prism\'Antras', 'Darkshire', 1431, 79.8, 48.02, nil),
        Q(177, 'Look To The Stars', 25, 20, 'Blind Mary', 'Tranquil Gardens Cemetery road', 1431, 81.99, 59.09, nil),
        Q(181, 'Look To The Stars', 30, 20, 'Viktori Prism\'Antras', 'Darkshire', 1431, 79.8, 48.02, nil),
      }),
      Chain('eight-legged', 'Eight-Legged Menaces', {
        Q(245, 'Eight-Legged Menaces', 21, 17, 'Watcher Dodds', 'Road west of Darkshire', 1431, 45.12, 67.02, nil),
        Q(93, 'Dusky Crab Cakes', 20, 17, 'Chef Grual', 'Darkshire inn', 1431, 73.88, 43.45, nil),
        Q(5, 'Jitters\' Growling Gut', 20, 17, 'Jitters', 'Raven Hill', 1431, 18.37, 56.36, nil),
        Q(240, 'Return to Jitters', 20, 17, 'Chef Grual', 'Darkshire inn', 1431, 73.88, 43.45, nil),
      }),
      Chain('hermit', 'The Hermit', {
        Q(165, 'The Hermit', 21, 17, 'Elaine Carevin', 'Darkshire', 1431, 75.33, 48.07, nil),
        Q(148, 'Supplies from Darkshire', 24, 20, 'Abercrombie', 'Raven Hill', 1431, 28.11, 31.47, nil),
        Q(149, 'Ghost Hair Thread', 24, 20, 'Madame Eva', 'Darkshire', 1431, 75.81, 45.3, nil),
        Q(154, 'Return the Comb', 24, 20, 'Blind Mary', 'Tranquil Gardens Cemetery road', 1431, 81.99, 59.09, nil),
        Q(157, 'Deliver the Thread', 24, 20, 'Madame Eva', 'Darkshire', 1431, 75.81, 45.3, nil),
        Q(158, 'Zombie Juice', 24, 20, 'Abercrombie', 'Raven Hill', 1431, 28.11, 31.47, nil),
        Q(156, 'Gather Rot Blossoms', 24, 20, 'Tavernkeep Smitts', 'Darkshire inn', 1431, 73.78, 44.49, nil),
        Q(159, 'Juice Delivery', 24, 20, 'Tavernkeep Smitts', 'Darkshire inn', 1431, 73.78, 44.49, nil),
        Q(133, 'Ghoulish Effigy', 24, 20, 'Abercrombie', 'Raven Hill', 1431, 28.11, 31.47, nil),
        Q(134, 'Ogre Thieves', 24, 20, 'Abercrombie', 'Raven Hill', 1431, 28.11, 31.47, nil),
        Q(160, 'Note to the Mayor', 30, 20, 'Abercrombie', 'Raven Hill', 1431, 28.11, 31.47, nil),
        Q(251, 'Translate Abercrombie\'s Note', 30, 20, 'Lord Ello Ebonlocke', 'Darkshire town hall', 1431, 71.93, 46.43, nil),
        Q(401, 'Wait for Sirra to Finish', 30, 20, 'Sirra Von\'Indi', 'Darkshire town hall', 1431, 72.64, 47.62, nil),
        Q(252, 'Translation to Ello', 30, 20, 'Sirra Von\'Indi', 'Darkshire town hall', 1431, 72.64, 47.62, nil),
        Q(253, 'Bride of the Embalmer', 30, 20, 'Lord Ello Ebonlocke', 'Darkshire town hall', 1431, 71.93, 46.43, nil),
      }),
    },
  },
  ['Wetlands'] = {
    uiMapID = 1437,
    faction = "Alliance",
    minLevel = 20,
    maxLevel = 30,
    note = 'Menethil Harbor is the hub. Excavation Site, a Forever dungeon, sits above Whelgar\'s Excavation.',
    chains = {
      Chain('claws-deep', 'Claws from the Deep', {
        Q(279, 'Claws from the Deep', 22, 20, 'Karl Boran', 'Menethil Harbor docks', 1437, 8.31, 58.54, nil),
        Q(281, 'Reclaiming Goods', 22, 20, 'Karl Boran', 'Menethil Harbor docks', 1437, 8.31, 58.54, nil),
        Q(284, 'The Search Continues', 22, 20, 'Damaged Crate', 'Murloc camps, west coast', 1437, 13.51, 41.39, nil),
        Q(285, 'Search More Hovels', 22, 20, 'Sealed Barrel', 'Murloc camps, west coast', 1437, 13.61, 38.21, nil),
        Q(286, 'Return the Statuette', 22, 20, 'Half-buried Barrel', 'Murloc camps, west coast', 1437, 13.89, 34.81, nil),
      }),
      Chain('greenwarden', 'The Greenwarden', {
        Q(463, 'The Greenwarden', 21, 20, 'First Mate Fitzsimmons', 'Menethil Harbor inn', 1437, 10.89, 59.67, nil),
        Q(276, 'Tramping Paws', 21, 20, 'Rethiel the Greenwarden', 'East of Menethil', 1437, 56.37, 40.48, nil),
        Q(277, 'Fire Taboo', 23, 20, 'Rethiel the Greenwarden', 'East of Menethil', 1437, 56.37, 40.48, nil),
        Q(275, 'Blisters on The Land', 26, 20, 'Rethiel the Greenwarden', 'East of Menethil', 1437, 56.37, 40.48, nil),
      }),
      Chain('ormer', 'Ormer\'s Revenge', {
        Q(294, 'Ormer\'s Revenge', 24, 22, 'Ormer Ironbraid', 'Whelgar\'s Excavation', 1437, 38.08, 51.15, nil),
        Q(295, 'Ormer\'s Revenge', 27, 22, 'Ormer Ironbraid', 'Whelgar\'s Excavation', 1437, 38.08, 51.15, nil),
        Q(296, 'Ormer\'s Revenge', 29, 22, 'Ormer Ironbraid', 'Whelgar\'s Excavation', 1437, 38.08, 51.15, nil),
        Q(299, 'Uncovering the Past', 28, 25, 'Prospector Whelgar', 'Whelgar\'s Excavation cave', 1437, 38.91, 52.34, nil),
      }),
      Chain('dark-iron-war', 'The Dark Iron War', {
        Q(303, 'The Dark Iron War', 30, 25, 'Motley Garmason', 'Dun Modr', 1437, 49.67, 18.23, nil),
        Q(304, 'A Grim Task', 32, 26, 'Longbraid the Grim', 'Dun Modr', 1437, 49.8, 18.27, nil),
      }),
      Chain('nekrosh', 'War Banners', {
        Q(464, 'War Banners', 26, 23, 'Captain Stoutfist', 'Menethil Keep', 1437, 9.86, 57.49, nil),
        Q(465, 'Nek\'rosh\'s Gambit', 26, 23, 'Captain Stoutfist', 'Menethil Keep', 1437, 9.86, 57.49, nil),
        Q(474, 'Defeat Nek\'rosh', 26, 23, 'Dragonmaw catapult', 'Angerfang Encampment', 1437, 47.45, 46.88, nil),
      }),
      Chain('third-fleet', 'The Third Fleet', {
        Q(288, 'The Third Fleet', 27, 22, 'First Mate Fitzsimmons', 'Menethil Harbor inn', 1437, 10.89, 59.67, nil),
        Q(289, 'The Cursed Crew', 29, 22, 'First Mate Fitzsimmons', 'Menethil Harbor inn', 1437, 10.89, 59.67, nil),
        Q(290, 'Lifting the Curse', 30, 22, 'First Mate Fitzsimmons', 'Menethil Harbor inn', 1437, 10.89, 59.67, nil),
        Q(292, 'The Eye of Paleth', 30, 22, 'Intrepid\'s Locked Strongbox', 'The Intrepid wreck', 1437, 14.1, 26.4, nil),
        Q(293, 'Cleansing the Eye', 30, 22, 'Glorin Steelbrow', 'Menethil Harbor inn', 1437, 10.61, 60.77, nil),
      }),
      Chain('digging-ooze', 'Digging Through the Ooze', {
        Q(470, 'Digging Through the Ooze', 24, 19, 'Sida', 'Menethil Harbor', 1437, 11.8, 57.99, nil),
      }),
      Chain('young-crocolisks', 'Young Crocolisk Skins', {
        Q(484, 'Young Crocolisk Skins', 22, 15, 'James Halloran', 'Menethil Harbor', 1437, 8.55, 55.74, nil),
        Q(471, 'Apprentice\'s Duties', 26, 18, 'James Halloran', 'Menethil Harbor', 1437, 8.55, 55.74, nil),
      }),
      Chain('thandol', 'The Thandol Span', {
        Q(631, 'The Thandol Span', 31, 28, 'Rhag Garmason', 'Dun Modr', 1437, 49.91, 18.23, nil),
        Q(632, 'The Thandol Span', 31, 28, 'Ebenezer Rustlocke\'s Corpse', 'Thandol Span', 1437, 51.28, 8.0, nil),
        Q(633, 'The Thandol Span', 31, 28, 'Rhag Garmason', 'Dun Modr', 1437, 49.91, 18.23, nil),
        Q(634, 'Plea To The Alliance', 31, 28, 'Rhag Garmason', 'Dun Modr', 1437, 49.91, 18.23, nil),
      }),
      Chain('fall-dun-modr', 'Fall of Dun Modr', {
        Q(472, 'Fall of Dun Modr', 25, 22, 'Longbraid the Grim', 'Dun Modr', 1437, 49.8, 18.27, nil),
      }),
    },
  },
  ['Ashenvale'] = {
    uiMapID = 1440,
    faction = "Alliance",
    minLevel = 18,
    maxLevel = 30,
    note = 'Astranaar is the hub. Blackfathom Deeps sits on the northwest coast.',
    chains = {
      Chain('bathrans-hair', 'Bathran\'s Hair', {
        Q(1010, 'Bathran\'s Hair', 20, 18, 'Orendil Broadleaf', 'Maestra\'s Post', 1440, 26.44, 38.59, nil),
        Q(1020, 'Orendil\'s Cure', 20, 18, 'Orendil Broadleaf', 'Maestra\'s Post', 1440, 26.44, 38.59, nil),
      }),
      Chain('raene', 'Raene\'s Cleansing', {
        Q(991, 'Raene\'s Cleansing', 19, 18, 'Raene Wolfrunner', 'Astranaar', 1440, 36.62, 49.58, nil),
        Q(1023, 'Raene\'s Cleansing', 21, 18, 'Teronis\' Corpse', 'Lake Falathim', 1440, 20.31, 42.34, nil),
        Q(1024, 'Raene\'s Cleansing', 21, 18, 'Raene Wolfrunner', 'Astranaar', 1440, 36.62, 49.58, nil),
        Q(1026, 'Raene\'s Cleansing', 21, 18, 'Shael\'dryn', 'Moonwell, Fallen Sky Lake path', 1440, 53.54, 46.21, nil),
        Q(1027, 'Raene\'s Cleansing', 28, 18, 'Shael\'dryn', 'Moonwell, Fallen Sky Lake path', 1440, 53.54, 46.21, nil),
        Q(1028, 'Raene\'s Cleansing', 28, 18, 'Shael\'dryn', 'Moonwell, Fallen Sky Lake path', 1440, 53.54, 46.21, nil),
        Q(1055, 'Raene\'s Cleansing', 28, 18, 'Hidden shrine', 'Talondeep path area', 1440, 54.41, 35.39, nil),
        Q(1029, 'Raene\'s Cleansing', 28, 18, 'Shael\'dryn', 'Moonwell, Fallen Sky Lake path', 1440, 53.54, 46.21, nil),
        Q(1030, 'Raene\'s Cleansing', 28, 18, 'Raene Wolfrunner', 'Astranaar', 1440, 36.62, 49.58, nil),
        Q(1045, 'Raene\'s Cleansing', 30, 18, 'Krolg', 'South of Mystral Lake', 1440, 50.85, 75.07, nil),
        Q(1046, 'Raene\'s Cleansing', 30, 18, 'Krolg', 'South of Mystral Lake', 1440, 50.85, 75.07, nil),
      }),
      Chain('zoram-strand', 'The Zoram Strand', {
        Q(1008, 'The Zoram Strand', 19, 14, 'Shindrell Swiftfire', 'Astranaar', 1440, 34.67, 48.84, nil),
        Q(1007, 'The Ancient Statuette', 20, 17, 'Talen', 'Zoram Strand', 1440, 14.79, 31.29, nil),
        Q(1009, 'Ruuzel', 25, 20, 'Talen', 'Zoram Strand', 1440, 14.79, 31.29, nil),
      }),
      Chain('elune', 'Fallen Sky Lake', {
        Q(1033, 'Elune\'s Tear', 22, 17, 'Pelturas Whitemoon', 'Astranaar', 1440, 37.36, 51.79, nil),
        Q(1034, 'The Ruins of Stardust', 23, 20, 'Pelturas Whitemoon', 'Astranaar', 1440, 37.36, 51.79, nil),
        Q(1035, 'Fallen Sky Lake', 30, 20, 'Pelturas Whitemoon', 'Astranaar', 1440, 37.36, 51.79, nil),
      }),
      Chain('vile-satyr', 'Vile Satyr! Dryads in Danger!', {
        Q(1021, 'Vile Satyr! Dryads in Danger!', 28, 24, 'Illiyana', 'Forest Song, eastern Ashenvale', 1440, 87.07, 43.48, nil),
        Q(1031, 'The Branch of Cenarius', 32, 26, 'Anilia', 'Xavian', 1440, 78.32, 44.85, nil),
      }),
      Chain('howling-vale', 'The Howling Vale', {
        Q(1022, 'The Howling Vale', 30, 21, 'Sentinel Melyria Frostshadow', 'Shrine of Aessina', 1440, 22.24, 52.98, nil),
        Q(1037, 'Velinde Starsong', 30, 25, 'Sentinel Melyria Frostshadow', 'Shrine of Aessina', 1440, 22.24, 52.98, nil),
      }),
      Chain('aggressive-defense', 'An Aggressive Defense', {
        Q(1025, 'An Aggressive Defense', 24, 18, 'Raene Wolfrunner', 'Astranaar', 1440, 36.62, 49.58, nil),
        Q(1054, 'Culling the Threat', 24, 18, 'Raene Wolfrunner', 'Astranaar', 1440, 36.62, 49.58, nil),
      }),
      Chain('elemental-bracers', 'Elemental Bracers', {
        Q(1016, 'Elemental Bracers', 24, 20, 'Sentinel Velene Starstrike', 'Silverwind Refuge', 1440, 49.81, 67.21, nil),
      }),
      Chain('pridewings', 'Pridewings of Stonetalon', {
        Q(1134, 'Pridewings of Stonetalon', 21, 18, 'Shindrell Swiftfire', 'Astranaar', 1440, 34.67, 48.84, nil),
      }),
      Chain('kayneth', 'Kayneth Stillwind', {
        Q(4581, 'Kayneth Stillwind', 29, 24, 'Shindrell Swiftfire', 'Astranaar', 1440, 34.67, 48.84, nil),
        Q(1011, 'Forsaken Diseases', 29, 24, 'Kayneth Stillwind', 'Forest Song', 1440, 85.24, 44.71, nil),
      }),
      Chain('journey-stonetalon', 'Journey to Stonetalon Peak', {
        Q(1056, 'Journey to Stonetalon Peak', 18, 18, 'Faldreas Goeth\'Shael', 'Astranaar', 1440, 35.76, 49.1, nil),
        Q(1070, 'On Guard in Stonetalon', 21, 17, 'Sentinel Thenysil', 'Astranaar', 1440, 34.89, 49.72, nil),
      }),
    },
  },
  ['Stonetalon Mountains'] = {
    uiMapID = 1442,
    faction = "Alliance",
    minLevel = 17,
    maxLevel = 27,
    note = 'Windshear Crag and Stonetalon Peak are the Alliance hubs. Several steps travel to Ironforge, Stormwind, and Ratchet.',
    chains = {
      Chain('onguard', 'On Guard in Stonetalon', {
        Q(1085, 'On Guard in Stonetalon', 21, 17, 'Kaela Shadowspear', 'Windshear Crag / web path', 1442, 59.06, 62.58, nil),
        Q(1071, 'A Gnome\'s Respite', 21, 17, 'Gaxim Rustfizzle', 'Windshear Crag hideout', 1442, 59.52, 67.15, nil),
        Q(1072, 'An Old Colleague', 21, 17, 'Gaxim Rustfizzle', 'Windshear Crag hideout', 1442, 59.52, 67.15, nil),
        Q(1073, 'Ineptitude + Chemicals = Fun', 21, 17, 'Lomac Gearstrip', 'Tinker Town, Ironforge', 1455, 72.08, 51.89, nil),
        Q(1074, 'Ineptitude + Chemicals = Fun', 21, 17, 'Lomac Gearstrip', 'Tinker Town, Ironforge', 1455, 72.08, 51.89, nil),
        Q(1075, 'A Scroll from Mauren', 21, 17, 'Gaxim Rustfizzle', 'Windshear Crag hideout', 1442, 59.52, 67.15, nil),
        Q(1076, 'Devils in Westfall', 21, 17, 'Collin Mauren', 'Mage Quarter, Stormwind', 1453, 43.08, 80.3, nil),
        Q(1077, 'Special Delivery for Gaxim', 21, 17, 'Collin Mauren', 'Mage Quarter, Stormwind', 1453, 43.08, 80.3, nil),
        Q(1078, 'Retrieval for Mauren', 21, 17, 'Collin Mauren', 'Mage Quarter, Stormwind', 1453, 43.08, 80.3, nil),
        Q(1079, 'Covert Ops - Alpha', 22, 17, 'Gaxim Rustfizzle', 'Windshear Crag hideout', 1442, 59.52, 67.15, nil),
        Q(1080, 'Covert Ops - Beta', 22, 17, 'Gaxim Rustfizzle', 'Windshear Crag hideout', 1442, 59.52, 67.15, nil),
        Q(1081, 'Reception from Tyrande', 22, 17, 'Kaela Shadowspear', 'Windshear Crag / web path', 1442, 59.06, 62.58, nil),
      }),
      Chain('super-reaper', 'Super Reaper 6000', {
        Q(1093, 'Super Reaper 6000', 21, 16, 'Ziz Fizziks', 'Windshear Crag', 1442, 58.99, 62.6, nil),
        Q(1094, 'Further Instructions', 21, 16, 'Ziz Fizziks', 'Windshear Crag', 1442, 58.99, 62.6, nil),
        Q(1095, 'Further Instructions', 21, 16, 'Sputtervalve', 'Ratchet, The Barrens', 1413, 62.98, 37.22, nil),
        Q(1096, 'Gerenzo Wrenchwhistle', 21, 16, 'Ziz Fizziks', 'Windshear Crag', 1442, 58.99, 62.6, nil),
      }),
      Chain('charred-vale', 'Reclaiming the Charred Vale', {
        Q(1057, 'Reclaiming the Charred Vale', 27, 20, 'Keeper Albagorm', 'Stonetalon Peak', 1442, 37.11, 8.1, nil),
        Q(1059, 'Reclaiming the Charred Vale', 27, 20, 'Keeper Albagorm', 'Stonetalon Peak', 1442, 37.11, 8.1, nil),
      }),
    },
  },
  ['Hillsbrad Foothills'] = {
    uiMapID = 1424,
    faction = "Alliance",
    minLevel = 20,
    maxLevel = 30,
    note = 'Southshore is the Alliance hub. Horde Elixir chain rows are included only so faction filters can be tested and will not show for Alliance players.',
    chains = {
      Chain('down-the-coast', 'Down the Coast', {
        Q(536, 'Down the Coast', 26, 25, 'Lieutenant Farren Orinelle', 'Southshore', 1424, 51.46, 58.38, nil),
        Q(559, 'Farren\'s Proof', 30, 25, 'Lieutenant Farren Orinelle', 'Southshore', 1424, 51.46, 58.38, nil),
        Q(560, 'Farren\'s Proof', 32, 25, 'Lieutenant Farren Orinelle', 'Southshore', 1424, 51.46, 58.38, nil),
        Q(561, 'Farren\'s Proof', 32, 25, 'Marshal Redpath', 'Southshore', 1424, 49.48, 58.73, nil),
        Q(562, 'Stormwind Ho!', 32, 25, 'Lieutenant Farren Orinelle', 'Southshore', 1424, 51.46, 58.38, nil),
      }),
      Chain('costly-menace', 'Costly Menace', {
        Q(564, 'Costly Menace', 28, 24, 'Darren Malvew', 'Southshore stables', 1424, 52.42, 56.02, nil),
        Q(555, 'Soothing Turtle Bisque', 31, 28, 'Chef Jessen', 'Southshore inn', 1424, 51.89, 58.68, nil),
      }),
      Chain('crushridge', 'Crushridge Bounty', {
        Q(500, 'Crushridge Bounty', 36, 30, 'Marshal Redpath', 'Southshore', 1424, 49.48, 58.73, nil),
        Q(504, 'Crushridge Warmongers', 40, 30, 'Marshal Redpath', 'Southshore', 1424, 49.48, 58.73, nil),
      }),
      Chain('syndicate', 'Syndicate Assassins', {
        Q(505, 'Syndicate Assassins', 33, 26, 'Magistrate Henry Maleb', 'Southshore town hall', 1424, 48.14, 59.11, nil),
        Q(533, 'Infiltration', 34, 26, 'Magistrate Henry Maleb', 'Southshore town hall', 1424, 48.14, 59.11, nil),
        Q(512, 'Noble Deaths', 34, 26, 'Magistrate Henry Maleb', 'Southshore town hall', 1424, 48.14, 59.11, nil),
      }),
      Chain('elixir', 'Elixir of Agony', {
        Q(496, 'Elixir of Suffering', 22, 19, 'Apothecary Lydon', 'Should not show: Horde, Tarren Mill', 1424, 61.44, 19.06, { faction = 'Horde' }),
        Q(501, 'Elixir of Pain', 24, 21, 'Apothecary Lydon', 'Tarren Mill', 1424, 61.44, 19.06, { faction = 'Horde' }),
        Q(509, 'Elixir of Agony', 28, 24, 'Apothecary Lydon', 'Tarren Mill', 1424, 61.44, 19.06, { faction = 'Horde' }),
      }),
      Chain('preserving-knowledge', 'Preserving Knowledge', {
        Q(538, 'Southshore', 38, 27, 'Loremaster Dibbs', 'Southshore', 1424, 50.57, 57.09, nil),
        Q(540, 'Preserving Knowledge', 38, 27, 'Loremaster Dibbs', 'Southshore', 1424, 50.57, 57.09, nil),
        Q(551, 'The Ensorcelled Parchment', 30, 27, 'Worn Parchment (item)', 'Dalaran ruins, Alterac', 1416, 18.0, 78.0, nil),
        Q(554, 'Stormpike\'s Deciphering', 30, 27, 'Loremaster Dibbs', 'Southshore', 1424, 50.57, 57.09, nil),
      }),
      Chain('hints-plague', 'Hints of a New Plague?', {
        Q(659, 'Hints of a New Plague?', 33, 30, 'Phin Odelic', 'Southshore inn', 1424, 50.34, 58.86, nil),
        Q(658, 'Hints of a New Plague?', 36, 30, 'Quae', 'Go\'Shek Farm, Arathi', 1417, 60.18, 53.85, nil),
        Q(657, 'Hints of a New Plague?', 37, 30, 'Quae', 'Go\'Shek Farm, Arathi', 1417, 60.18, 53.85, nil),
        Q(660, 'Hints of a New Plague?', 37, 30, 'Quae', 'Go\'Shek Farm, Arathi', 1417, 60.18, 53.85, nil),
        Q(661, 'Hints of a New Plague?', 37, 30, 'Phin Odelic', 'Southshore inn', 1424, 50.34, 58.86, nil),
      }),
    },
  },
}

-- Canonical zone names the Path tab should have quest lists for.
PhilosophersCodexData.ZONE_QUEST_EXPECTED = {
  'Elwynn Forest',
  'Dun Morogh',
  'Teldrassil',
  'Darkshore',
  'Westfall',
  'Loch Modan',
  'Redridge Mountains',
  'Duskwood',
  'Wetlands',
  'Ashenvale',
  'Stonetalon Mountains',
  'Hillsbrad Foothills',
}

