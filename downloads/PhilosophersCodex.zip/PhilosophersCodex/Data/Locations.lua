-- Philosopher's Codex map data for WoW Forever (Interface 16001).
-- uiMapIDs and entrance coordinates come from QuestieDB Forever
-- support/Forever/Zones/areaIdToUiMapId.lua and Zones/dungeons.lua
-- (https://github.com/Questie/QuestieDB). Flight-master and trainer
-- coordinates come from data/Forever/foreverNpcDB.lua.
-- Entrances are included only where Questie lists them.

PhilosophersCodexData = PhilosophersCodexData or {}

local LOC = {
  -- AreaID -> uiMapID for Forever (Classic-style 14xx continent maps).
  uiMapByArea = {
    [1] = 1426,    -- Dun Morogh
    [3] = 1418,    -- Badlands
    [4] = 1419,    -- Blasted Lands
    [8] = 1435,    -- Swamp of Sorrows
    [10] = 1431,   -- Duskwood
    [11] = 1437,   -- Wetlands
    [12] = 1429,   -- Elwynn Forest
    [15] = 1445,   -- Dustwallow Marsh
    [16] = 1447,   -- Azshara
    [17] = 1413,   -- The Barrens
    [28] = 1422,   -- Western Plaguelands
    [33] = 1434,   -- Stranglethorn Vale
    [36] = 1416,   -- Alterac Mountains
    [38] = 1432,   -- Loch Modan
    [40] = 1436,   -- Westfall
    [44] = 1433,   -- Redridge Mountains
    [45] = 1417,   -- Arathi Highlands
    [46] = 1428,   -- Burning Steppes
    [47] = 1425,   -- The Hinterlands
    [51] = 1427,   -- Searing Gorge
    [85] = 1420,   -- Tirisfal Glades
    [130] = 1421,  -- Silverpine Forest
    [139] = 1423,  -- Eastern Plaguelands
    [141] = 1438,  -- Teldrassil
    [148] = 1439,  -- Darkshore
    [215] = 1412,  -- Mulgore
    [267] = 1424,  -- Hillsbrad Foothills
    [331] = 1440,  -- Ashenvale
    [357] = 1444,  -- Feralas
    [361] = 1448,  -- Felwood
    [400] = 1441,  -- Thousand Needles
    [405] = 1443,  -- Desolace
    [406] = 1442,  -- Stonetalon Mountains
    [440] = 1446,  -- Tanaris
    [490] = 1449,  -- Un'Goro Crater
    [493] = 1450,  -- Moonglade
    [618] = 1452,  -- Winterspring
    [1377] = 1451, -- Silithus
    [1497] = 1458, -- Undercity
    [1519] = 1453, -- Stormwind City
    [1537] = 1455, -- Ironforge
    [1637] = 1454, -- Orgrimmar
    [1657] = 1457, -- Darnassus
    [16591] = 2548, -- Riverglades
    [16985] = 1449, -- The Shaper's Terrace (shown on Un'Goro)
  },
}

-- Dungeon entrance pins. x/y are zone percentages on the parent overworld map.
-- Only dungeons Questie Forever publishes an entrance for.
LOC.entrances = {
  ["deadmines"]          = { uiMapID = 1436, x = 42.5,  y = 71.7,  title = "The Deadmines entrance", zone = "Westfall" },
  ["shadowfang-keep"]    = { uiMapID = 1421, x = 44.8,  y = 67.8,  title = "Shadowfang Keep entrance", zone = "Silverpine Forest" },
  ["hall-of-thanes"]     = { uiMapID = 1455, x = 27.63, y = 47.83, title = "The Hall of Thanes entrance", zone = "Ironforge" },
  ["wailing-caverns"]    = { uiMapID = 1413, x = 46.0,  y = 36.5,  title = "Wailing Caverns entrance", zone = "The Barrens" },
  ["ruins-of-lordaeron"] = { uiMapID = 1458, x = 72.48, y = 11.33, title = "Ruins of Lordaeron entrance", zone = "Undercity" },
  ["stockade"]           = { uiMapID = 1453, x = 52.41, y = 70.01, title = "The Stockade entrance", zone = "Stormwind City" },
  ["excavation-site"]    = { uiMapID = 1437, x = 47.79, y = 56.16, title = "Excavation Site entrance", zone = "Wetlands" },
  ["blackfathom-deeps"]  = { uiMapID = 1440, x = 14.5,  y = 14.2,  title = "Blackfathom Deeps entrance", zone = "Ashenvale" },
  ["city-of-dalaran"]    = { uiMapID = 1416, x = 8.46,  y = 59.21, title = "City of Dalaran entrance", zone = "Alterac Mountains" },
  ["sm-graveyard"]       = { uiMapID = 1420, x = 82.6,  y = 33.8,  title = "Scarlet Monastery entrance", zone = "Tirisfal Glades" },
  ["sm-library"]         = { uiMapID = 1420, x = 82.6,  y = 33.8,  title = "Scarlet Monastery entrance", zone = "Tirisfal Glades" },
  ["sm-armory"]          = { uiMapID = 1420, x = 82.6,  y = 33.8,  title = "Scarlet Monastery entrance", zone = "Tirisfal Glades" },
  ["sm-cathedral"]       = { uiMapID = 1420, x = 82.6,  y = 33.8,  title = "Scarlet Monastery entrance", zone = "Tirisfal Glades" },
  ["gnomeregan"]         = { uiMapID = 1426, x = 24.3,  y = 39.8,  title = "Gnomeregan entrance", zone = "Dun Morogh" },
  ["razorfen-kraul"]     = { uiMapID = 1413, x = 42.9,  y = 90.2,  title = "Razorfen Kraul entrance", zone = "The Barrens" },
  ["razorfen-downs"]     = { uiMapID = 1413, x = 49.0,  y = 93.9,  title = "Razorfen Downs entrance", zone = "The Barrens" },
  ["uldaman"]            = { uiMapID = 1418, x = 44.6,  y = 12.1,  title = "Uldaman entrance", zone = "Badlands" },
  ["zulfarrak"]          = { uiMapID = 1446, x = 38.7,  y = 20.1,  title = "Zul'Farrak entrance", zone = "Tanaris" },
  ["maraudon"]           = { uiMapID = 1443, x = 29.1,  y = 62.5,  title = "Maraudon entrance", zone = "Desolace" },
  ["sunken-temple"]      = { uiMapID = 1435, x = 69.9,  y = 53.5,  title = "The Temple of Atal'Hakkar entrance", zone = "Swamp of Sorrows" },
  -- Blackrock Mountain: Searing Gorge and Burning Steppes sides, both in Questie.
  ["brd"]                = { uiMapID = 1427, x = 34.8,  y = 85.3,  title = "Blackrock Depths (Searing Gorge approach)", zone = "Searing Gorge" },
  ["lbrs"]               = { uiMapID = 1427, x = 34.8,  y = 85.3,  title = "Blackrock Spire (Searing Gorge approach)", zone = "Searing Gorge" },
  ["ubrs"]               = { uiMapID = 1427, x = 34.8,  y = 85.3,  title = "Blackrock Spire (Searing Gorge approach)", zone = "Searing Gorge" },
  ["dire-maul"]          = { uiMapID = 1444, x = 59.2,  y = 45.1,  title = "Dire Maul entrance", zone = "Feralas" },
  ["scholomance"]        = { uiMapID = 1422, x = 69.7,  y = 73.2,  title = "Scholomance entrance", zone = "Western Plaguelands" },
  ["stratholme"]         = { uiMapID = 1423, x = 26.52, y = 10.36, title = "Stratholme (main gate)", zone = "Eastern Plaguelands" },
}

-- No Questie Forever entrance row exists yet for: The Drowned City,
-- Krol'dok Stronghold, Alcaz Prison, Blackmaw Hold, or Shaper's Terrace.

-- Zone pins: a verified flight master or town NPC, not a guessed zone center.
LOC.zones = {
  ["Stormwind City"]        = { uiMapID = 1453, x = 70.95, y = 72.51, title = "Dungar Longdrink (Stormwind)" },
  ["Ironforge"]             = { uiMapID = 1455, x = 55.50, y = 47.74, title = "Gryth Thurden (Ironforge)" },
  ["Darnassus"]             = { uiMapID = 1457, x = 35.37, y = 8.40,  title = "Mathrengyl Bearwalker (Darnassus)" },
  ["Elwynn Forest"]         = { uiMapID = 1429, x = 70.95, y = 72.51, title = "Stormwind (from Elwynn)", note = "Uses the Stormwind flight master." },
  ["Westfall"]              = { uiMapID = 1436, x = 56.55, y = 52.64, title = "Thor (Sentinel Hill)" },
  ["Redridge Mountains"]    = { uiMapID = 1433, x = 25.50, y = 59.41, title = "Ariena Stormfeather (Lakeshire)" },
  ["Duskwood"]              = { uiMapID = 1431, x = 77.49, y = 44.29, title = "Felicia Maline (Darkshire)" },
  ["Wetlands"]              = { uiMapID = 1437, x = 9.49,  y = 59.69, title = "Shellei Brondir (Menethil Harbor)" },
  ["Loch Modan"]            = { uiMapID = 1432, x = 33.94, y = 50.95, title = "Thorgrum Borrelson (Thelsamar)" },
  ["Dun Morogh"]            = { uiMapID = 1426, x = 45.89, y = 49.39, title = "Ozzie Togglevolt (Kharanos)" },
  ["Darkshore"]             = { uiMapID = 1439, x = 36.34, y = 45.58, title = "Caylais Moonfeather (Auberdine)" },
  ["Teldrassil"]            = { uiMapID = 1438, x = 58.40, y = 94.02, title = "Vesprystus (Rut'theran Village)" },
  ["Ashenvale"]             = { uiMapID = 1440, x = 34.41, y = 47.99, title = "Daelyshia (Astranaar)" },
  ["Hillsbrad Foothills"]   = { uiMapID = 1424, x = 49.34, y = 52.27, title = "Darla Harris (Southshore)" },
  ["Alterac Mountains"]     = { uiMapID = 1416, x = 8.46,  y = 59.21, title = "City of Dalaran entrance (Alterac)" },
  ["Arathi Highlands"]      = { uiMapID = 1417, x = 45.73, y = 46.10, title = "Cedrik Prose (Refuge Pointe)" },
  ["Stranglethorn Vale"]    = { uiMapID = 1434, x = 27.53, y = 77.79, title = "Gyll (Booty Bay)" },
  ["The Barrens"]           = { uiMapID = 1413, x = 62.37, y = 37.62, title = "Mebok Mizzyrix (Ratchet)" },
  ["Tirisfal Glades"]       = { uiMapID = 1420, x = 82.6,  y = 33.8,  title = "Scarlet Monastery entrance" },
  ["Silverpine Forest"]     = { uiMapID = 1421, x = 44.8,  y = 67.8,  title = "Shadowfang Keep entrance" },
  ["Desolace"]              = { uiMapID = 1443, x = 64.66, y = 10.54, title = "Baritanas Skyriver (Nijel's Point)" },
  ["Dustwallow Marsh"]      = { uiMapID = 1445, x = 67.48, y = 51.30, title = "Baldruc (Theramore)" },
  ["Tanaris"]               = { uiMapID = 1446, x = 51.01, y = 29.34, title = "Bera Stonehammer (Gadgetzan)" },
  ["Thousand Needles"]      = { uiMapID = 1441, x = 78.14, y = 77.12, title = "Wizzle Brassbolts (Mirage Raceway)" },
  ["Feralas"]               = { uiMapID = 1444, x = 89.50, y = 45.85, title = "Thyssiana (Thalanaar)" },
  ["Badlands"]              = { uiMapID = 1418, x = 53.42, y = 43.39, title = "Prospector Ryedol (Badlands)" },
  ["Swamp of Sorrows"]      = { uiMapID = 1435, x = 69.9,  y = 53.5,  title = "The Temple of Atal'Hakkar entrance" },
  ["Searing Gorge"]         = { uiMapID = 1427, x = 37.94, y = 30.86, title = "Lanie Reed (Thorium Point)" },
  ["Burning Steppes"]       = { uiMapID = 1428, x = 84.33, y = 68.33, title = "Borgus Stoutarm (Morgan's Vigil)" },
  ["Western Plaguelands"]   = { uiMapID = 1422, x = 42.92, y = 85.06, title = "Bibilfaz Featherwhistle (Chillwind Camp)" },
  ["Eastern Plaguelands"]   = { uiMapID = 1423, x = 71.81, y = 49.60, title = "Khaelyn Steelwing (Light's Hope Chapel)" },
  ["The Hinterlands"]       = { uiMapID = 1425, x = 11.07, y = 46.15, title = "Guthrum Thunderfist (Aerie Peak)" },
  ["Stonetalon Mountains"]  = { uiMapID = 1442, x = 36.44, y = 7.18,  title = "Teloren (Stonetalon Peak)" },
  ["Blasted Lands"]         = { uiMapID = 1419, x = 65.54, y = 24.34, title = "Alexandra Constantine (Nethergarde Keep)" },
  ["Riverglades"]           = { uiMapID = 2548, x = 66.75, y = 81.10, title = "Ashe Amberhall (Riverglades)" },
  ["Moonglade"]             = { uiMapID = 1450, x = 48.10, y = 67.34, title = "Sindrayl (Moonglade)" },
}

LOC.trainers = {
  ["jartsam"] = {
    uiMapID = 1457, x = 38.69, y = 15.84,
    title = "Jartsam, Nightsaber Riding Instructor",
    zone = "Darnassus",
    npcId = 4753,
  },
  ["mathrengyl"] = {
    uiMapID = 1457, x = 35.37, y = 8.40,
    title = "Mathrengyl Bearwalker, Druid Trainer",
    zone = "Darnassus",
    npcId = 4217,
  },
}

-- 1.23.0: leveling ranges for zone picks, cities (never the zone pick),
-- and how to reach each zone as Alliance. Classic-style routes; Forever
-- may differ in places, so the Path pane says to report anything wrong.
LOC.cities = {
  ["Stormwind City"] = true, ["Ironforge"] = true, ["Darnassus"] = true,
  ["The Exodar"] = true, ["Orgrimmar"] = true, ["Undercity"] = true,
  ["Thunder Bluff"] = true, ["Silvermoon City"] = true, ["Dalaran"] = true,
}

LOC.zoneLevels = {
  ["Elwynn Forest"] = { 1, 10 }, ["Dun Morogh"] = { 1, 10 }, ["Coldridge Valley"] = { 1, 6 },
  ["Teldrassil"] = { 1, 11 }, ["Shadowglen"] = { 1, 6 }, ["Tirisfal Glades"] = { 1, 10 },
  ["Westfall"] = { 10, 20 }, ["Loch Modan"] = { 10, 20 }, ["Darkshore"] = { 10, 20 },
  ["Silverpine Forest"] = { 10, 20 }, ["The Barrens"] = { 10, 25 },
  ["Redridge Mountains"] = { 15, 25 }, ["Stonetalon Mountains"] = { 15, 27 },
  ["Duskwood"] = { 18, 30 }, ["Ashenvale"] = { 18, 30 }, ["Wetlands"] = { 20, 30 },
  ["Hillsbrad Foothills"] = { 20, 30 }, ["Thousand Needles"] = { 25, 35 },
  ["Alterac Mountains"] = { 30, 40 }, ["Arathi Highlands"] = { 30, 40 },
  ["Desolace"] = { 30, 40 }, ["Stranglethorn Vale"] = { 30, 45 },
  ["Dustwallow Marsh"] = { 35, 45 }, ["Badlands"] = { 35, 45 }, ["Swamp of Sorrows"] = { 35, 45 },
  ["Feralas"] = { 40, 50 }, ["The Hinterlands"] = { 40, 50 }, ["Tanaris"] = { 40, 50 },
  ["Searing Gorge"] = { 43, 50 }, ["Azshara"] = { 45, 55 }, ["Blasted Lands"] = { 45, 55 },
  ["Un'Goro Crater"] = { 48, 55 }, ["Felwood"] = { 48, 55 }, ["Burning Steppes"] = { 50, 58 },
  ["Western Plaguelands"] = { 51, 58 }, ["Eastern Plaguelands"] = { 53, 60 },
  ["Winterspring"] = { 55, 60 }, ["Silithus"] = { 55, 60 },
}

-- Zones on Kalimdor, so routes can start from the right side of the sea.
LOC.kalimdor = {
  ["Teldrassil"] = true, ["Shadowglen"] = true, ["Darnassus"] = true, ["Darkshore"] = true,
  ["Ashenvale"] = true, ["The Barrens"] = true, ["Stonetalon Mountains"] = true,
  ["Desolace"] = true, ["Dustwallow Marsh"] = true, ["Thousand Needles"] = true,
  ["Feralas"] = true, ["Tanaris"] = true, ["Un'Goro Crater"] = true, ["Azshara"] = true,
  ["Felwood"] = true, ["Winterspring"] = true, ["Silithus"] = true, ["Moonglade"] = true,
  ["Durotar"] = true, ["Mulgore"] = true, ["Orgrimmar"] = true, ["Thunder Bluff"] = true,
  ["Rut'theran Village"] = true,
}

-- Steps to reach a zone. east = from Stormwind / Ironforge, kal = from
-- Darnassus / Darkshore. A missing side is filled in with the boat.
LOC.travel = {
  ["Stormwind City"] = { east = { "You're in the right city; the route below is inside Stormwind." } },
  ["Elwynn Forest"] = { east = { "Leave Stormwind through the main gate." } },
  ["Westfall"] = { east = { "Fly to Sentinel Hill, or ride west from Goldshire across the bridge." } },
  ["Redridge Mountains"] = { east = { "Fly to Lakeshire, or ride east through Elwynn past Eastvale." } },
  ["Duskwood"] = { east = { "Fly to Darkshire, or ride south from Goldshire on the road." } },
  ["Ironforge"] = { east = { "Take the Deeprun Tram in Stormwind's Dwarven District." } },
  ["Dun Morogh"] = { east = { "Take the Deeprun Tram to Ironforge and leave by the front gate." } },
  ["Coldridge Valley"] = { east = { "Take the tram to Ironforge, then ride west through Dun Morogh." } },
  ["Loch Modan"] = { east = { "Take the tram to Ironforge.", "Fly to Thelsamar, or ride east out of Dun Morogh through the North Gate tunnel." } },
  ["Wetlands"] = { east = { "Fly to Menethil Harbor, or ride north from Loch Modan through the Dun Algaz tunnel." } },
  ["Arathi Highlands"] = { east = { "Fly to Refuge Pointe, or ride north from the Wetlands over Thandol Span." } },
  ["Hillsbrad Foothills"] = { east = { "Fly to Southshore, or cross Thandol Span from the Wetlands and ride west through Arathi." } },
  ["Alterac Mountains"] = { east = { "Get to Southshore in Hillsbrad.", "Ride north up into the mountains." } },
  ["Silverpine Forest"] = { east = { "Get to Hillsbrad Foothills (fly to Southshore).", "Ride west through the pass into Silverpine. Horde land: watch for guards." } },
  ["Tirisfal Glades"] = { east = { "Get to Silverpine Forest.", "Ride north past the Sepulcher into Tirisfal. Horde land: avoid Brill." } },
  ["Undercity"] = { east = { "Get to Tirisfal Glades.", "The ruined city is east of Brill. Horde city: stay out of the guards' sight." } },
  ["Western Plaguelands"] = { east = { "Fly to Chillwind Camp, or ride north from Hillsbrad past the Alterac foothills." } },
  ["Eastern Plaguelands"] = { east = { "Fly to Light's Hope Chapel, or ride east from Western Plaguelands." } },
  ["The Hinterlands"] = { east = { "Fly to Aerie Peak, or ride east from Hillsbrad." } },
  ["Stranglethorn Vale"] = { east = { "Fly to Rebel Camp or Booty Bay, or ride south from Duskwood." } },
  ["Badlands"] = { east = { "Get to Loch Modan.", "Ride out the southeast gate into the Badlands." } },
  ["Searing Gorge"] = { east = { "Fly to Thorium Point, or ride in through the Badlands gate." } },
  ["Burning Steppes"] = { east = { "Fly to Morgan's Vigil, or ride north out of Redridge." } },
  ["Blasted Lands"] = { east = { "Fly to Nethergarde Keep, or ride south from Duskwood through Deadwind Pass and the Swamp." } },
  ["Swamp of Sorrows"] = { east = { "Fly to Nethergarde Keep in the Blasted Lands.", "Ride north into the Swamp of Sorrows." } },
  ["Teldrassil"] = { kal = { "Take the boat from Auberdine to Rut'theran Village, then the portal up." } },
  ["Darnassus"] = { kal = { "Take the boat from Auberdine to Rut'theran Village, then the portal up to Darnassus." } },
  ["Darkshore"] = { kal = { "Take the boat from Rut'theran Village to Auberdine." } },
  ["Ashenvale"] = { kal = { "Get to Auberdine in Darkshore.", "Fly to Astranaar, or ride south down the road into Ashenvale." } },
  ["Stonetalon Mountains"] = { kal = { "Get to Ashenvale.", "Fly to Stonetalon Peak, or ride southwest out of Ashenvale." } },
  ["The Barrens"] = { kal = { "Get to Ashenvale.", "Ride east and south through Mor'shan into the Barrens. Horde land." } },
  ["Dustwallow Marsh"] = { east = { "Fly to Menethil Harbor.", "Take the boat to Theramore." }, kal = { "Fly to Theramore if you have it, or go through the Barrens east to Dustwallow." } },
  ["Desolace"] = { kal = { "Fly to Nijel's Point, or ride south from Stonetalon Mountains." } },
  ["Thousand Needles"] = { kal = { "Get to the Barrens.", "Ride south through the Great Lift into Thousand Needles." } },
  ["Feralas"] = { kal = { "Fly to Thalanaar or Feathermoon Stronghold, or ride south from Desolace." } },
  ["Tanaris"] = { kal = { "Fly to Gadgetzan, or ride south from Dustwallow Marsh." } },
  ["Un'Goro Crater"] = { kal = { "Get to Tanaris.", "Ride west from Gadgetzan and down the ramp into the crater." } },
  ["Azshara"] = { kal = { "Fly to Talrendis Point, or ride east out of Ashenvale." } },
  ["Felwood"] = { kal = { "Fly to Talonbranch Glade, or ride north out of Ashenvale." } },
  ["Winterspring"] = { kal = { "Fly to Everlook, or ride north through Felwood's Timbermaw Hold." } },
  ["Moonglade"] = { kal = { "Druids: cast Teleport: Moonglade. Everyone else: through Timbermaw Hold in Felwood." } },
  ["Silithus"] = { kal = { "Fly to Cenarion Hold, or ride south out of Un'Goro Crater." } },
}

-- Extra lines for getting from a dungeon's zone pin to the door.
LOC.entranceHints = {
  ["deadmines"] = "In southern Westfall, enter the mine at the back of Moonbrook.",
  ["stockade"] = "Inside Stormwind, the prison in the canals between Old Town and the Cathedral district.",
  ["hall-of-thanes"] = "Inside Ironforge on the west side.",
  ["wailing-caverns"] = "Southwest of the Crossroads, the cave in the big oasis.",
  ["shadowfang-keep"] = "The castle on the hill above Pyrewood Village.",
  ["ruins-of-lordaeron"] = "In the ruined city above Undercity.",
  ["excavation-site"] = "Above Whelgar's Excavation in the central Wetlands.",
  ["blackfathom-deeps"] = "Zoram Strand on the far west coast; swim down into the temple ruins.",
  ["city-of-dalaran"] = "Western Alterac Mountains, by the dome of Dalaran.",
  ["sm-graveyard"] = "Northeast Tirisfal; the Monastery has four wing doors in its courtyard.",
  ["sm-library"] = "Northeast Tirisfal; the Monastery has four wing doors in its courtyard.",
  ["sm-armory"] = "Northeast Tirisfal; the Monastery has four wing doors in its courtyard.",
  ["sm-cathedral"] = "Northeast Tirisfal; the Monastery has four wing doors in its courtyard.",
  ["gnomeregan"] = "West Dun Morogh, the gnome city entrance past the Airfields.",
  ["razorfen-kraul"] = "Far south Barrens, the thorny mound.",
  ["razorfen-downs"] = "Far south Barrens, just east of Razorfen Kraul.",
  ["uldaman"] = "North Badlands, the cave by the Hall of the Crafters.",
  ["zulfarrak"] = "Northwest Tanaris, the troll city in the desert.",
  ["maraudon"] = "Southwest Desolace, the centaur caves.",
  ["sunken-temple"] = "In the Pool of Tears, east Swamp of Sorrows; swim down.",
  ["brd"] = "Inside Blackrock Mountain, take the chain down.",
  ["lbrs"] = "Inside Blackrock Mountain, take the chain up.",
  ["ubrs"] = "Inside Blackrock Mountain, take the chain up.",
  ["dire-maul"] = "Central Feralas, the ruined elven city.",
  ["scholomance"] = "On Caer Darrow island in the lake.",
  ["stratholme"] = "The main gate in far north Eastern Plaguelands.",
}

PhilosophersCodexData.LOCATIONS = LOC
