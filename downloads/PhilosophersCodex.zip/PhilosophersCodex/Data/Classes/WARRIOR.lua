-- Philosopher's Codex class module: Warrior
-- 1.25.0: Arms leveling with Protection for tanking. Spells from 60.tools Forever data; class notes are a
-- Classic Era baseline where Forever details aren't confirmed.

PhilosophersCodexData = PhilosophersCodexData or {}
PhilosophersCodexData.CLASSES = PhilosophersCodexData.CLASSES or {}

PhilosophersCodexData.CLASSES.WARRIOR = {
  classFile = "WARRIOR",
  title = "Warrior Leveling & Gearing",
  supported = true,
  icons = {
    class = "Interface\\Icons\\Ability_Warrior_DefensiveStance",
    forms = "Interface\\Icons\\Ability_Warrior_OffensiveStance",
    talents = "Interface\\Icons\\Ability_Warrior_SavageBlow",
    trainer = "Interface\\Icons\\INV_Misc_Book_09",
    mounts = "Interface\\Icons\\Ability_Mount_RidingHorse",
    gear = "Interface\\Icons\\INV_Chest_Plate06",
    professions = "Interface\\Icons\\Trade_Alchemy",
    zones = "Interface\\Icons\\INV_Misc_Map_01",
    dungeons = "Interface\\Icons\\INV_Misc_ShadowEgg",
    goals = "Interface\\Icons\\Ability_Warrior_OffensiveStance",
    spells = "Interface\\Icons\\Ability_Warrior_BattleShout",
  },
  allowedRoles = { "tank", "dps" },
  defaultRole = "dps",
  defaultProfile = "arms",
  trainerWaypoint = nil,
  factionNote = "Level as Arms: Charge in, Rend, Heroic Strike with extra rage, Overpower when the target dodges, and Execute low targets. Forever gives Victory Rush at 20 for free healing after kills. Defensive Stance at 10 to tank dungeons. Eat after most fights; downtime is the warrior tax.",
  gearPriorities = {
    "Arms/Fury: strength, then crit, hit, agility, stamina. A big two-hander matters most.",
    "Protection: stamina, armor, defense, strength. One-hander and shield.",
    "Mail until 40, then plate. Every melee weapon type, plus bows, guns and crossbows for pulling."
  },
  allowedArmor = { [0] = true, [1] = true, [2] = true, [3] = true, [4] = true, [6] = true },
  allowedWeapons = { [0] = true, [1] = true, [2] = true, [3] = true, [4] = true, [5] = true, [6] = true, [7] = true, [8] = true, [13] = true, [15] = true, [16] = true, [18] = true },
  allowWands = false,
  allowShields = true,
  allowRelics = false,
  allowRanged = true,
  dualWieldAt = 20,
  armorAt = { [4] = 40 },
  recLabels = {
    must = "Must train",
    dps = "Train for damage",
    tank = "Train for tanking",
    skip = "Skip for now",
  },
  profiles = {
    { id = "arms", name = "Arms", labels = { "dps" }, weights = { strength = 10, agility = 5, attackpower = 5, meleedps = 10, crit = 6, hit = 7, stamina = 3, intellect = 0, armor = 0.02 } },
    { id = "prot", name = "Protection", labels = { "tank" }, weights = { stamina = 10, armor = 0.12, strength = 4, agility = 4, hit = 3, meleedps = 2, attackpower = 1 } },
    { id = "both", name = "Both", labels = { "dps", "tank" }, compare = { "arms", "prot" } },
  },
  goalGroups = {
    { key = "goals-trainer", title = "Trainer spells by level", kind = "trainer", default = false },
    { key = "goals-forms", title = "Class milestones", ids = { "charge-4", "defensive-10", "victory-rush-20", "berserker-30" }, defaultLevel = { 1, 40 } },
    { key = "goals-zones", title = "Leveling zones by level", kind = "zones", default = false },
    { key = "goals-dungeons", title = "Dungeon goals by level", kind = "dungeons", default = false },
    { key = "goals-mounts", title = "Mounts, riding & gold", ids = { "riding", "first-mount" }, defaultLevel = { 38, 45 } },
    { key = "goals-gear", title = "Gear & stat priorities", kind = "gear", default = false },
  },
  gear = {
    { id = "smites-mighty-hammer-warrior", name = "Smite's Mighty Hammer", itemID = 7230, source = "The Deadmines", boss = "Mr. Smite", slot = "Two-Hand" },
  },
  milestones = {
    { id = "charge-4", name = "Charge", level = 4, spellName = "Charge", note = "Rush to the target and gain rage. Your opener." },
    { id = "defensive-10", name = "Defensive Stance", level = 10, spellName = "Defensive Stance", note = "Your tanking stance. Taunt and Sunder Armor come with it." },
    { id = "victory-rush-20", name = "Victory Rush", level = 20, spellName = "Victory Rush", note = "After a kill, a free hit that heals you. Use it every fight." },
    { id = "berserker-30", name = "Berserker Stance", level = 30, spellName = "Berserker Stance", note = "Your third stance, with Intercept and Berserker Rage." },
    { id = "riding", name = "Apprentice Riding", level = 40, note = "Train riding at 40. Level is detected; training is manual." },
    { id = "first-mount", name = "First mount", level = 40, note = "Buy your first mount at 40. Manual check." },
    { id = "dual-spec", name = "Dual spec (50 gold)", level = 40, note = "Buy from your class trainer at 40. Manual check." },
  },
}
