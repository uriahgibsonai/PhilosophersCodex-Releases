-- Philosopher's Codex class module: Priest
-- 1.25.0: Shadow leveling with Holy for dungeons. Spells from 60.tools Forever data; class notes are a
-- Classic Era baseline where Forever details aren't confirmed.

PhilosophersCodexData = PhilosophersCodexData or {}
PhilosophersCodexData.CLASSES = PhilosophersCodexData.CLASSES or {}

PhilosophersCodexData.CLASSES.PRIEST = {
  classFile = "PRIEST",
  title = "Priest Leveling & Gearing",
  supported = true,
  icons = {
    class = "Interface\\Icons\\Spell_Holy_PowerWordShield",
    forms = "Interface\\Icons\\Spell_Holy_InnerFire",
    talents = "Interface\\Icons\\Spell_Shadow_ShadowWordPain",
    trainer = "Interface\\Icons\\INV_Misc_Book_09",
    mounts = "Interface\\Icons\\Ability_Mount_RidingHorse",
    gear = "Interface\\Icons\\INV_Chest_Cloth_17",
    professions = "Interface\\Icons\\Trade_Alchemy",
    zones = "Interface\\Icons\\INV_Misc_Map_01",
    dungeons = "Interface\\Icons\\INV_Misc_ShadowEgg",
    goals = "Interface\\Icons\\Spell_Holy_InnerFire",
    spells = "Interface\\Icons\\Spell_Holy_FlashHeal",
  },
  allowedRoles = { "healer", "dps" },
  defaultRole = "healer",
  defaultProfile = "heal",
  trainerWaypoint = nil,
  factionNote = "Level as Shadow: Shadow Word: Pain, Mind Blast, then wand the mob down while Power Word: Shield soaks the hits. Psychic Scream if a second mob joins. Heal dungeons with Renew, Flash Heal and Heal. Forever adds Starshards, Hex and Touch of Weakness, and Desperate Prayer at 10.",
  gearPriorities = {
    "Holy: healing power, intellect, spirit, mana per 5, stamina.",
    "Shadow: spell damage, intellect, spirit, stamina. A good wand is a big early upgrade.",
    "Cloth only. Staves, maces, daggers, wands and off-hand items."
  },
  allowedArmor = { [0] = true, [1] = true },
  allowedWeapons = { [4] = true, [10] = true, [15] = true, [19] = true },
  allowWands = true,
  allowShields = false,
  allowRelics = false,
  recLabels = {
    must = "Must train",
    heal = "Train for healing",
    shadow = "Train for Shadow",
    dps = "Train it",
    skip = "Skip for now",
  },
  profiles = {
    { id = "heal", name = "Healing", labels = { "heal" }, weights = { healing = 10, spellpower = 8, intellect = 5, mp5 = 5, spirit = 3, crit = 2, stamina = 1, armor = 0.02 } },
    { id = "shadow", name = "Shadow", labels = { "shadow" }, weights = { spelldamage = 10, spellpower = 10, intellect = 5, crit = 4, spirit = 3, stamina = 2, mp5 = 1, wanddps = 6 } },
    { id = "both", name = "Both", labels = { "heal", "shadow" }, compare = { "heal", "shadow" } },
  },
  goalGroups = {
    { key = "goals-trainer", title = "Trainer spells by level", kind = "trainer", default = false },
    { key = "goals-forms", title = "Class milestones", ids = { "shield-6", "starshards-10", "flash-heal-20", "fear-ward-20", "mind-control-30" }, defaultLevel = { 1, 40 } },
    { key = "goals-zones", title = "Leveling zones by level", kind = "zones", default = false },
    { key = "goals-dungeons", title = "Dungeon goals by level", kind = "dungeons", default = false },
    { key = "goals-mounts", title = "Mounts, riding & gold", ids = { "riding", "first-mount" }, defaultLevel = { 38, 45 } },
    { key = "goals-gear", title = "Gear & stat priorities", kind = "gear", default = false },
  },
  gear = {
    { id = "robes-of-arugal-priest", name = "Robes of Arugal", itemID = 6324, source = "Shadowfang Keep", boss = "Archmage Arugal", slot = "Chest" },
  },
  milestones = {
    { id = "shield-6", name = "Power Word: Shield", level = 6, spellName = "Power Word: Shield", note = "Your best leveling tool. Shield first, then fight." },
    { id = "starshards-10", name = "Starshards", level = 10, spellName = "Starshards", note = "Forever gives every Priest the old racial spells at 10." },
    { id = "flash-heal-20", name = "Flash Heal", level = 20, spellName = "Flash Heal", note = "Your fast heal for dungeons." },
    { id = "fear-ward-20", name = "Fear Ward", level = 20, spellName = "Fear Ward", note = "Put it on the tank for fear-heavy bosses." },
    { id = "mind-control-30", name = "Mind Control", level = 30, spellName = "Mind Control", note = "Take over a humanoid for a while. Great crowd control in some dungeons." },
    { id = "riding", name = "Apprentice Riding", level = 40, note = "Train riding at 40. Level is detected; training is manual." },
    { id = "first-mount", name = "First mount", level = 40, note = "Buy your first mount at 40. Manual check." },
    { id = "dual-spec", name = "Dual spec (50 gold)", level = 40, note = "Buy from your class trainer at 40. Manual check." },
  },
}
