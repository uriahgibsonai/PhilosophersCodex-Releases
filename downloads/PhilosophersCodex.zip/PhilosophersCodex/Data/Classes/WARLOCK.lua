-- Philosopher's Codex class module: Warlock
-- Affliction / Demonology leveling with pet guidance, Alliance Gnome path.

PhilosophersCodexData = PhilosophersCodexData or {}
PhilosophersCodexData.CLASSES = PhilosophersCodexData.CLASSES or {}

PhilosophersCodexData.CLASSES.WARLOCK = {
  classFile = "WARLOCK",
  title = "Warlock Leveling & Gearing",
  supported = true,
  icons = {
    class = "Interface\\Icons\\Spell_Shadow_ShadowBolt",
    forms = "Interface\\Icons\\Spell_Shadow_SummonImp",
    talents = "Interface\\Icons\\Spell_Shadow_Metamorphosis",
    trainer = "Interface\\Icons\\INV_Misc_Book_09",
    mounts = "Interface\\Icons\\Ability_Mount_Dreadsteed",
    gear = "Interface\\Icons\\INV_Chest_Cloth_09",
    professions = "Interface\\Icons\\Trade_Tailoring",
    zones = "Interface\\Icons\\INV_Misc_Map_01",
    dungeons = "Interface\\Icons\\INV_Misc_ShadowEgg",
    goals = "Interface\\Icons\\Spell_Shadow_ShadowBolt",
    spells = "Interface\\Icons\\Spell_Shadow_ShadowBolt",
  },
  allowedRoles = { "dps" },
  defaultRole = "dps",
  defaultProfile = "affliction",
  trainerWaypoint = nil, -- no verified Forever trainer pin yet (Ironforge / Stormwind)
  factionNote = "Alliance Gnome route. Level as Affliction with a demon: Corruption and Bane of Agony, Life Tap for mana, Drain Life as it comes online, and a wand to finish. The Voidwalker holds questing mobs from 10; many guides switch to the Succubus at 20 for faster kills.",
  gearPriorities = {
    "Affliction leveling: spell damage or spell power first, then stamina, intellect, and spirit (Life Tap benefits from spirit in Forever guides).",
    "A wand or a staff with spell power is the usual weapon. Wand DPS is scored on the wand slot.",
    "Cloth only. Daggers, staves, one-hand swords, wands, and held-in-off-hand items are usable. No shields, leather, or mail.",
    "If a named caster piece is not on the gear list, the upgrade scorer still compares it to what you are wearing.",
  },
  allowedArmor = { [0] = true, [1] = true },
  allowedWeapons = { [7] = true, [10] = true, [15] = true, [19] = true }, -- 1H sword, staff, dagger, wand
  allowWands = true,
  allowShields = false,
  allowRelics = false,
  recLabels = {
    must = "Must train",
    affliction = "Train for Affliction",
    demo = "Train for Demonology",
    dest = "Train for Destruction",
    skip = "Skip for now",
  },
  profiles = {
    { id = "affliction", name = "Affliction", labels = { "affliction", "demo" }, weights = {
      spelldamage = 10, spellpower = 10, stamina = 4, intellect = 4, spirit = 3, crit = 3, mp5 = 0, wanddps = 5, healing = 0, armor = 0,
    }},
    { id = "dest", name = "Destruction", labels = { "dest" }, weights = {
      spelldamage = 10, spellpower = 10, crit = 5, intellect = 4, stamina = 3, spirit = 2, wanddps = 5, healing = 0, armor = 0,
    }},
    { id = "both", name = "Both", labels = { "affliction", "demo", "dest" }, compare = { "affliction", "dest" } },
  },
  goalGroups = {
    { key = "goals-trainer", title = "Trainer spells by level", kind = "trainer", default = false },
    { key = "goals-forms", title = "Pets & class quests", ids = { "summon-imp", "voidwalker", "succubus", "felhunter", "felsteed", "inferno", "dreadsteed" }, defaultLevel = { 1, 60 } },
    { key = "goals-talents", title = "Talents & spec milestones", ids = { "improved-corruption", "ritual-of-summoning", "dual-spec", "dest-offspec" }, defaultLevel = { 10, 40 } },
    { key = "goals-zones", title = "Leveling zones by level", kind = "zones", default = false },
    { key = "goals-dungeons", title = "Dungeon goals by level", kind = "dungeons", default = false },
    { key = "goals-professions", title = "Professions", ids = { "cloth-crafting", "secondaries" }, default = false },
    { key = "goals-mounts", title = "Mounts, riding & gold", ids = { "felsteed", "riding", "dreadsteed" }, defaultLevel = { 38, 60 } },
    { key = "goals-gear", title = "Gear & stat priorities", kind = "gear", default = false },
  },

  gear = {
    { id = "robes-of-arugal", name = "Robes of Arugal", itemID = 6324, source = "Shadowfang Keep", boss = "Archmage Arugal", slot = "Chest" },
    { id = "dwarven-tome", name = "Dwarven Tome", itemID = 279898, source = "Hall of Thanes quest: Important Heirlooms", slot = "Held In Off-hand" },
    { id = "civinad-robes", name = "Civinad Robes", itemID = 9623, source = "Gnomeregan quest: The Grand Betrayal", slot = "Chest" },
    { id = "death-speaker-robes", name = "Death Speaker Robes", itemID = 6682, source = "Razorfen Kraul", boss = "Death Speaker Jargba", slot = "Chest" },
    { id = "embalmed-shroud", name = "Embalmed Shroud", itemID = 7691, source = "Scarlet Monastery: Graveyard", boss = "Fallen Champion", slot = "Head" },
    { id = "bloodmage-mantle", name = "Bloodmage Mantle", itemID = 7684, source = "Scarlet Monastery: Graveyard", boss = "Bloodmage Thalnos", slot = "Shoulder" },
    { id = "hypnotic-blade", name = "Hypnotic Blade", itemID = 7714, source = "Scarlet Monastery: Library", boss = "Arcanist Doan", slot = "Main Hand" },
    { id = "whitemanes-chapeau", name = "Whitemane's Chapeau", itemID = 7720, source = "Scarlet Monastery: Cathedral", boss = "High Inquisitor Whitemane", slot = "Head" },
    { id = "triune-amulet", name = "Triune Amulet", itemID = 7722, source = "Scarlet Monastery: Cathedral", boss = "High Inquisitor Whitemane", slot = "Neck" },
    { id = "doomsayers-robe", name = "Doomsayer's Robe", itemID = 4746, source = "Uldaman quest: Solution to Doom", slot = "Chest" },
    { id = "zumrahs-vexing-cane", name = "Zum'rah's Vexing Cane", itemID = 18082, source = "Zul'Farrak", boss = "Witch Doctor Zum'rah", slot = "Two-Hand Staff" },
    { id = "omnicast-boots", name = "Omnicast Boots", itemID = 11822, source = "Blackrock Depths", boss = "Golem Lord Argelmach", slot = "Feet" },
    { id = "spritecaster-cape", name = "Spritecaster Cape", itemID = 11623, source = "Blackrock Depths", boss = "Houndmaster Grebmar", slot = "Back" },
    { id = "chief-architects-monocle", name = "Chief Architect's Monocle", itemID = 11839, source = "Blackrock Depths", boss = "Fineous Darkvire", slot = "Head" },
    { id = "banthok-sash", name = "Ban'thok Sash", itemID = 11662, source = "Blackrock Depths", boss = "Ok'thor the Breaker", slot = "Waist" },
    { id = "hands-exalted-herald", name = "Hands of the Exalted Herald", itemID = 12554, source = "Blackrock Depths", boss = "Princess Moira Bronzebeard", slot = "Hands" },
    { id = "briarwood-reed", name = "Briarwood Reed", itemID = 12930, source = "Upper Blackrock Spire", boss = "Jed Runewatcher", slot = "Trinket" },
    { id = "alannas-embrace", name = "Alanna's Embrace", itemID = 13314, source = "Scholomance", boss = "Ras Frostwhisper", slot = "Chest" },
    { id = "book-of-the-dead", name = "Book of the Dead", itemID = 13353, source = "Stratholme", boss = "Balnazzar", slot = "Held In Off-hand" },
    { id = "tome-of-knowledge", name = "Tome of Knowledge", itemID = 13385, source = "Stratholme", boss = "Archivist Galford", slot = "Held In Off-hand" },
  },

  milestones = {
    { id = "summon-imp", name = "Summon Imp", level = 1, spellName = "Summon Imp", note = "Learned at 1. Alliance Gnomes start this with the Anvilmar quest Beginnings in classic-style starts; Forever still lists the spell as a trainer ability at 1." },
    { id = "voidwalker", name = "Summon Voidwalker", level = 10, spellName = "Summon Voidwalker", note = "Trainer lists it at 10. The Alliance class quest is Gakin the Darkbinder in Stormwind (wowfdb). Complete the quest if the trainer does not sell it. Your first tank pet." },
    { id = "improved-corruption", name = "Improved Corruption (Affliction)", level = 10, note = "Affliction leveling guides put early points into Improved Corruption so the DoT becomes instant. Manual unless the talent effect is obvious in-game." },
    { id = "ritual-of-summoning", name = "Ritual of Summoning", level = 20, spellName = "Ritual of Summoning", note = "Trained at 20. Bring the guild to you." },
    { id = "succubus", name = "Summon Succubus (or Incubus)", level = 20, spellName = "Summon Succubus", note = "Both Summon Succubus and Summon Incubus are on the Forever trainer list at 20. Classic had a Seduction class quest; if the trainer does not sell them, look for that quest. Many leveling guides switch to the Succubus here for faster kills." },
    { id = "felhunter", name = "Summon Felhunter", level = 30, spellName = "Summon Felhunter", note = "Listed at 30 on the Forever trainer list. Classic required a class quest; complete it if the trainer does not sell the spell." },
    { id = "felsteed", name = "Felsteed", level = 40, spellName = "Summon Felsteed", note = "Not on the 1.60.1.70888 trainer list. In Classic this is the level 40 class mount quest. Treat it as a class quest until a Forever trainer sale is verified." },
    { id = "riding", name = "Apprentice Riding", level = 40, note = "You still need riding skill at 40 to use a mount, even with Felsteed. Manual check." },
    { id = "inferno", name = "Inferno", level = 50, spellName = "Inferno", note = "Trained at 50. Summons an infernal; a reagent is typically required. Confirm the reagent in-game." },
    { id = "dreadsteed", name = "Dreadsteed", level = 60, spellName = "Summon Dreadsteed", note = "Not on the 1.60.1.70888 trainer list. In Classic this is the level 60 epic mount quest chain. Treat it as a class quest until verified for Forever." },
    { id = "dual-spec", name = "Dual spec (50 gold)", level = 40, note = "Buy from your class trainer at 40 for 50 gold (same Forever price as other classes). A common split is Affliction for questing and a Destruction set for burst. Level is detected; the purchase is manual." },
    { id = "dest-offspec", name = "Destruction off-spec (optional)", level = 40, note = "Affliction (Corruption, Drain Life, and a pet) is the default leveling path in this guide. Destruction is a fine alternative later. Classic Era talent-tree details can differ in Forever; treat this as a baseline and confirm in-game." },
    { id = "cloth-crafting", name = "Tailoring or Enchanting (optional)", level = 1, note = "Cloth classes often take Tailoring, sometimes paired with Enchanting, so they can make bags and disenchant greens. This is the Classic Era baseline; confirm Forever trainers in Ironforge or Stormwind. Exact gold costs are not listed here." },
    { id = "secondaries", name = "First Aid, Cooking, and Fishing", level = 1, note = "These secondary professions are free to pick up and useful while you quest. Exact trainer locations and costs were not verified for Forever here; Ironforge and Stormwind both have trainers." },
  },
}
