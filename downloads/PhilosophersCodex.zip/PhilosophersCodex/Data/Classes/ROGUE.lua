-- Philosopher's Codex class module: Rogue
-- 1.25.0: Combat leveling. Spells from 60.tools Forever data; class notes are a
-- Classic Era baseline where Forever details aren't confirmed.

PhilosophersCodexData = PhilosophersCodexData or {}
PhilosophersCodexData.CLASSES = PhilosophersCodexData.CLASSES or {}

PhilosophersCodexData.CLASSES.ROGUE = {
  classFile = "ROGUE",
  title = "Rogue Leveling & Gearing",
  supported = true,
  icons = {
    class = "Interface\\Icons\\Ability_Stealth",
    forms = "Interface\\Icons\\Ability_Rogue_Sprint",
    talents = "Interface\\Icons\\Ability_BackStab",
    trainer = "Interface\\Icons\\INV_Misc_Book_09",
    mounts = "Interface\\Icons\\Ability_Mount_RidingHorse",
    gear = "Interface\\Icons\\INV_Chest_Leather_09",
    professions = "Interface\\Icons\\Trade_Alchemy",
    zones = "Interface\\Icons\\INV_Misc_Map_01",
    dungeons = "Interface\\Icons\\INV_Misc_ShadowEgg",
    goals = "Interface\\Icons\\Ability_Rogue_Sprint",
    spells = "Interface\\Icons\\Spell_Shadow_RitualOfSacrifice",
  },
  allowedRoles = { "dps" },
  defaultRole = "dps",
  defaultProfile = "combat",
  trainerWaypoint = nil,
  factionNote = "Level as Combat with two fast one-handers: Sinister Strike to build combo points, Slice and Dice, then Eviscerate to finish. Open from Stealth with Cheap Shot or Ambush. Evasion and Sprint get you out of bad pulls, Vanish at 22. Keep poisons on once you learn them.",
  gearPriorities = {
    "Agility first, then attack power, hit, crit, stamina.",
    "A slow main-hand for Sinister Strike, a fast off-hand. Daggers for Backstab builds.",
    "Leather only. Daggers, swords, maces, fist weapons, plus bows, guns, crossbows or thrown."
  },
  allowedArmor = { [0] = true, [1] = true, [2] = true },
  allowedWeapons = { [2] = true, [3] = true, [4] = true, [7] = true, [13] = true, [15] = true, [16] = true, [18] = true },
  allowWands = false,
  allowShields = false,
  allowRelics = false,
  allowRanged = true,
  dualWieldAt = 1,
  recLabels = {
    must = "Must train",
    dps = "Train it",
    skip = "Skip for now",
  },
  profiles = {
    { id = "combat", name = "Combat", labels = { "dps" }, weights = { agility = 10, strength = 4, attackpower = 5, meleedps = 9, crit = 6, hit = 8, stamina = 3, armor = 0.02 } },
  },
  goalGroups = {
    { key = "goals-trainer", title = "Trainer spells by level", kind = "trainer", default = false },
    { key = "goals-forms", title = "Class milestones", ids = { "slice-dice-10", "vanish-22", "kidney-shot-30", "blind-34" }, defaultLevel = { 1, 40 } },
    { key = "goals-zones", title = "Leveling zones by level", kind = "zones", default = false },
    { key = "goals-dungeons", title = "Dungeon goals by level", kind = "dungeons", default = false },
    { key = "goals-mounts", title = "Mounts, riding & gold", ids = { "riding", "first-mount" }, defaultLevel = { 38, 45 } },
    { key = "goals-gear", title = "Gear & stat priorities", kind = "gear", default = false },
  },
  gear = {
    { id = "corsairs-overshirt-rogue", name = "Corsair's Overshirt", itemID = 5202, source = "The Deadmines", boss = "Edwin VanCleef", slot = "Chest" },
  },
  milestones = {
    { id = "slice-dice-10", name = "Slice and Dice", level = 10, spellName = "Slice and Dice", note = "Faster attacks. Keep it up on longer fights." },
    { id = "vanish-22", name = "Vanish", level = 22, spellName = "Vanish", note = "Drop out of combat into stealth. Your escape." },
    { id = "kidney-shot-30", name = "Kidney Shot", level = 30, spellName = "Kidney Shot", note = "A finisher stun. Great for interrupting casters." },
    { id = "blind-34", name = "Blind", level = 34, spellName = "Blind", note = "Takes one enemy out of the fight for a while. Needs a reagent." },
    { id = "riding", name = "Apprentice Riding", level = 40, note = "Train riding at 40. Level is detected; training is manual." },
    { id = "first-mount", name = "First mount", level = 40, note = "Buy your first mount at 40. Manual check." },
    { id = "dual-spec", name = "Dual spec (50 gold)", level = 40, note = "Buy from your class trainer at 40. Manual check." },
  },
}
