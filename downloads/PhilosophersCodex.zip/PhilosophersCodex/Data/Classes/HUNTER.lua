-- Philosopher's Codex class module: Hunter
-- 1.24.0: Beast Mastery leveling (default), Alliance. Classic Era baseline;
-- Forever-specific changes are not confirmed yet.

PhilosophersCodexData = PhilosophersCodexData or {}
PhilosophersCodexData.CLASSES = PhilosophersCodexData.CLASSES or {}

PhilosophersCodexData.CLASSES.HUNTER = {
  classFile = "HUNTER",
  title = "Hunter Leveling & Gearing",
  supported = true,
  icons = {
    class = "Interface\\Icons\\INV_Weapon_Bow_07",
    forms = "Interface\\Icons\\Ability_Hunter_BeastTaming",
    talents = "Interface\\Icons\\Ability_Hunter_BeastWithin",
    trainer = "Interface\\Icons\\INV_Misc_Book_09",
    mounts = "Interface\\Icons\\Ability_Mount_RidingHorse",
    gear = "Interface\\Icons\\INV_Chest_Chain_15",
    professions = "Interface\\Icons\\Trade_Engineering",
    zones = "Interface\\Icons\\INV_Misc_Map_01",
    dungeons = "Interface\\Icons\\INV_Misc_ShadowEgg",
    goals = "Interface\\Icons\\Ability_Hunter_BeastTaming",
    spells = "Interface\\Icons\\Ability_Marksmanship",
  },
  allowedRoles = { "dps" },
  defaultRole = "dps",
  defaultProfile = "bm",
  trainerWaypoint = nil,
  factionNote = "Level as Beast Mastery: send the pet in, let it build threat, then Serpent Sting and Arcane Shot from range. Keep Aspect of the Hawk up while you fight and Cheetah while you travel. Get your first pet at 10 (Revive Pet trains then), and keep its food in your bags. Aimed Shot at 20 is a big opener. Buy arrows or bullets every trip to town.",
  gearPriorities = {
    "Agility first, then attack power, stamina, crit, and intellect (for mana).",
    "Your ranged weapon is your biggest upgrade: bows, guns and crossbows are scored by damage per second.",
    "Leather until 40, then mail. Two-handers or two one-handers for stats; you rarely melee.",
    "Keep a stack of the best ammo your level allows, and a quiver or ammo pouch.",
  },
  allowedArmor = { [0] = true, [1] = true, [2] = true, [3] = true },
  allowedWeapons = { [0] = true, [1] = true, [2] = true, [3] = true, [6] = true, [7] = true, [8] = true, [10] = true, [13] = true, [15] = true, [16] = true, [18] = true },
  allowWands = false,
  allowRanged = true,
  dualWieldAt = 20,
  mailAt = 40,
  allowShields = false,
  allowRelics = false,
  recLabels = {
    must = "Must train",
    bm = "Train for pet & aspects",
    mm = "Train for shots",
    surv = "Train for traps & tracking",
    skip = "Skip for now",
  },
  profiles = {
    { id = "bm", name = "Beast Mastery", labels = { "bm", "mm" }, weights = {
      agility = 10, attackpower = 5, rangeddps = 8, crit = 6, hit = 6, stamina = 3, intellect = 2, spirit = 0, strength = 0, armor = 0.02,
    }},
    { id = "mm", name = "Marksmanship", labels = { "mm", "surv" }, weights = {
      agility = 10, attackpower = 5, rangeddps = 10, crit = 7, hit = 7, stamina = 2, intellect = 2, spirit = 0, strength = 0, armor = 0.02,
    }},
    { id = "both", name = "Both", labels = { "bm", "mm", "surv" }, compare = { "bm", "mm" } },
  },
  goalGroups = {
    { key = "goals-trainer", title = "Trainer spells by level", kind = "trainer", default = false },
    { key = "goals-forms", title = "Pet & class quests", ids = { "taming-quest", "aspect-cheetah", "feign-death", "aspect-pack" }, defaultLevel = { 10, 40 } },
    { key = "goals-talents", title = "Talents & spec milestones", ids = { "bm-talents-10", "dual-spec" }, defaultLevel = { 10, 40 } },
    { key = "goals-zones", title = "Leveling zones by level", kind = "zones", default = false },
    { key = "goals-dungeons", title = "Dungeon goals by level", kind = "dungeons", default = false },
    { key = "goals-mounts", title = "Mounts, riding & gold", ids = { "riding", "first-mount" }, defaultLevel = { 38, 45 } },
    { key = "goals-gear", title = "Gear & stat priorities", kind = "gear", default = false },
  },
  gear = {
    { id = "corsairs-overshirt-hunter", name = "Corsair's Overshirt", itemID = 5202, source = "The Deadmines", boss = "Edwin VanCleef", slot = "Chest" },
  },
  milestones = {
    { id = "taming-quest", name = "First pet", level = 10, spellName = "Revive Pet", note = "At 10 ask your class trainer about taming. In Classic this was a quest; the steps may differ in Forever." },
    { id = "bm-talents-10", name = "Start the Beast Mastery line", level = 10, note = "Pet and aspect talents first make leveling safest. Manual check." },
    { id = "aspect-cheetah", name = "Aspect of the Cheetah", level = 20, spellName = "Aspect of the Cheetah", note = "Run speed until your mount. Turn it off before a fight: you get dazed when hit." },
    { id = "feign-death", name = "Feign Death", level = 30, spellName = "Feign Death", note = "Drops threat and gets you out of bad pulls." },
    { id = "aspect-pack", name = "Aspect of the Pack", level = 40, spellName = "Aspect of the Pack", note = "Group run speed. Same daze rule as Cheetah." },
    { id = "riding", name = "Apprentice Riding", level = 40, note = "Train riding at 40. Level is detected; training is manual." },
    { id = "first-mount", name = "First mount", level = 40, note = "Buy your first mount at 40. Manual check." },
    { id = "dual-spec", name = "Dual spec (50 gold)", level = 40, note = "Buy from your class trainer at 40. Manual check." },
  },
}
