-- Philosopher's Codex class module: Paladin
-- 1.25.0: Retribution leveling with Holy and Protection options. Spells from 60.tools Forever data; class notes are a
-- Classic Era baseline where Forever details aren't confirmed.

PhilosophersCodexData = PhilosophersCodexData or {}
PhilosophersCodexData.CLASSES = PhilosophersCodexData.CLASSES or {}

PhilosophersCodexData.CLASSES.PALADIN = {
  classFile = "PALADIN",
  title = "Paladin Leveling & Gearing",
  supported = true,
  icons = {
    class = "Interface\\Icons\\Spell_Holy_HolyBolt",
    forms = "Interface\\Icons\\Spell_Holy_DevotionAura",
    talents = "Interface\\Icons\\Spell_Holy_AuraOfLight",
    trainer = "Interface\\Icons\\INV_Misc_Book_09",
    mounts = "Interface\\Icons\\Ability_Mount_RidingHorse",
    gear = "Interface\\Icons\\INV_Chest_Plate01",
    professions = "Interface\\Icons\\Trade_Alchemy",
    zones = "Interface\\Icons\\INV_Misc_Map_01",
    dungeons = "Interface\\Icons\\INV_Misc_ShadowEgg",
    goals = "Interface\\Icons\\Spell_Holy_DevotionAura",
    spells = "Interface\\Icons\\Spell_Holy_SealOfMight",
  },
  allowedRoles = { "tank", "healer", "dps" },
  defaultRole = "dps",
  defaultProfile = "ret",
  trainerWaypoint = nil,
  factionNote = "Level as Retribution: a slow two-hander, a Seal up, Judgement on pull, Holy Strike on cooldown, Blessing of Might and Devotion or Retribution Aura. Heal yourself between fights. Consecration and Exorcism at 20; Forever adds Voice of Truth and Holy Strike.",
  gearPriorities = {
    "Retribution: strength, then crit, stamina, agility and intellect. A slow two-hander matters most.",
    "Holy: healing power, intellect, mana per 5, stamina.",
    "Protection: stamina, armor, strength. Shield and one-hander.",
    "Mail until 40, then plate. Two-handed swords, axes and maces, one-handers and shields."
  },
  allowedArmor = { [0] = true, [1] = true, [2] = true, [3] = true, [4] = true, [6] = true },
  allowedWeapons = { [0] = true, [1] = true, [4] = true, [5] = true, [6] = true, [7] = true, [8] = true },
  allowWands = false,
  allowShields = true,
  allowRelics = true,
  armorAt = { [4] = 40 },
  recLabels = {
    must = "Must train",
    ret = "Train for Retribution",
    heal = "Train for healing",
    prot = "Train for tanking",
    skip = "Skip for now",
  },
  profiles = {
    { id = "ret", name = "Retribution", labels = { "ret" }, weights = { strength = 10, agility = 5, attackpower = 5, meleedps = 10, crit = 6, hit = 7, stamina = 3, intellect = 0, armor = 0.02 } },
    { id = "heal", name = "Holy", labels = { "heal" }, weights = { healing = 10, spellpower = 8, intellect = 5, mp5 = 5, spirit = 3, crit = 2, stamina = 1, armor = 0.02 } },
    { id = "prot", name = "Protection", labels = { "prot" }, weights = { stamina = 10, armor = 0.12, strength = 4, agility = 4, hit = 3, meleedps = 2, attackpower = 1 } },
    { id = "both", name = "Ret + Holy", labels = { "ret", "heal" }, compare = { "ret", "heal" } },
  },
  goalGroups = {
    { key = "goals-trainer", title = "Trainer spells by level", kind = "trainer", default = false },
    { key = "goals-forms", title = "Class milestones", ids = { "judgement-4", "lay-on-hands-10", "consecration-20", "divine-shield-34" }, defaultLevel = { 1, 40 } },
    { key = "goals-zones", title = "Leveling zones by level", kind = "zones", default = false },
    { key = "goals-dungeons", title = "Dungeon goals by level", kind = "dungeons", default = false },
    { key = "goals-mounts", title = "Mounts, riding & gold", ids = { "riding", "first-mount" }, defaultLevel = { 38, 45 } },
    { key = "goals-gear", title = "Gear & stat priorities", kind = "gear", default = false },
  },
  gear = {
    { id = "smites-mighty-hammer-paladin", name = "Smite's Mighty Hammer", itemID = 7230, source = "The Deadmines", boss = "Mr. Smite", slot = "Two-Hand" },
  },
  milestones = {
    { id = "judgement-4", name = "Judgement", level = 4, spellName = "Judgement", note = "Unleash your Seal on the target. Use it on every pull." },
    { id = "lay-on-hands-10", name = "Lay on Hands", level = 10, spellName = "Lay on Hands", note = "Full heal on a long cooldown. Save it for emergencies." },
    { id = "consecration-20", name = "Consecration", level = 20, spellName = "Consecration", note = "Holy damage on the ground around you. Great for packs." },
    { id = "divine-shield-34", name = "Divine Shield", level = 34, spellName = "Divine Shield", note = "You take no damage for a short time. Your escape button." },
    { id = "riding", name = "Apprentice Riding", level = 40, note = "Train riding at 40. Level is detected; training is manual." },
    { id = "first-mount", name = "First mount", level = 40, note = "Buy your first mount at 40. Manual check." },
    { id = "dual-spec", name = "Dual spec (50 gold)", level = 40, note = "Buy from your class trainer at 40. Manual check." },
  },
}
