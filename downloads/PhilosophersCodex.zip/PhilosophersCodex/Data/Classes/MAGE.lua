-- Philosopher's Codex class module: Mage
-- Frost leveling (default) with AoE grinding notes, Alliance Gnome path.

PhilosophersCodexData = PhilosophersCodexData or {}
PhilosophersCodexData.CLASSES = PhilosophersCodexData.CLASSES or {}

PhilosophersCodexData.CLASSES.MAGE = {
  classFile = "MAGE",
  title = "Mage Leveling & Gearing",
  supported = true,
  icons = {
    class = "Interface\\Icons\\Spell_Frost_FrostBolt02",
    forms = "Interface\\Icons\\Spell_Arcane_TeleportStormWind",
    talents = "Interface\\Icons\\Spell_Holy_MagicalSentry",
    trainer = "Interface\\Icons\\INV_Misc_Book_09",
    mounts = "Interface\\Icons\\Ability_Mount_RidingHorse",
    gear = "Interface\\Icons\\INV_Chest_Cloth_21",
    professions = "Interface\\Icons\\Trade_Tailoring",
    zones = "Interface\\Icons\\INV_Misc_Map_01",
    dungeons = "Interface\\Icons\\INV_Misc_ShadowEgg",
    goals = "Interface\\Icons\\Spell_Holy_MagicalSentry",
    spells = "Interface\\Icons\\Spell_Frost_FrostBolt02",
  },
  allowedRoles = { "dps" },
  defaultRole = "dps",
  defaultProfile = "frost",
  trainerWaypoint = nil, -- no verified Forever trainer pin yet (Ironforge / Stormwind)
  factionNote = "Alliance Gnome route. Level as Frost: Frostbolt to pull, Frost Nova and Blink when something reaches you, and a wand to finish mobs and save mana. You will drink often; Conjure Food and Water every rank. AoE packs with Arcane Explosion, Flamestrike, and Blizzard once you have them.",
  gearPriorities = {
    "Frost leveling: spell damage or spell power first, then intellect, spell crit, stamina, and spirit (you drink a lot).",
    "Buy a wand around level 5 (Lesser Magic Wand from an enchanter or the auction house) and finish mobs with it. Wand DPS is scored on the wand slot.",
    "Cloth only. Staves, daggers, one-hand swords, wands, and held-in-off-hand items are usable. No shields, leather, or mail.",
    "If a named caster piece is not on the gear list, the upgrade scorer still compares it to what you are wearing.",
  },
  allowedArmor = { [0] = true, [1] = true }, -- misc holdable, cloth
  allowedWeapons = { [7] = true, [10] = true, [15] = true, [19] = true }, -- 1H sword, staff, dagger, wand
  allowWands = true,
  allowShields = false,
  allowRelics = false,
  recLabels = {
    must = "Must train",
    frost = "Train for Frost",
    fire = "Train for Fire",
    aoe = "Train for AoE",
    skip = "Skip for now",
  },
  profiles = {
    { id = "frost", name = "Frost", labels = { "frost", "aoe" }, weights = {
      spelldamage = 10, spellpower = 10, intellect = 5, crit = 4, stamina = 2, spirit = 3, mp5 = 1, wanddps = 6, healing = 0, armor = 0,
    }},
    { id = "fire", name = "Fire", labels = { "fire", "aoe" }, weights = {
      spelldamage = 10, spellpower = 10, intellect = 5, crit = 5, stamina = 2, spirit = 2, mp5 = 1, wanddps = 5, healing = 0, armor = 0,
    }},
    { id = "both", name = "Both", labels = { "frost", "fire", "aoe" }, compare = { "frost", "fire" } },
  },
  goalGroups = {
    { key = "goals-trainer", title = "Trainer spells by level", kind = "trainer", default = false },
    { key = "goals-forms", title = "Class tools & teleports", ids = { "conjure-water", "conjure-food", "polymorph", "blink-evocation", "teleports-20", "mage-armor", "portals-40", "arcane-brilliance" }, defaultLevel = { 1, 56 } },
    { key = "goals-talents", title = "Talents & spec milestones", ids = { "frost-talents-10", "ice-lance-talent", "dual-spec", "fire-offspec" }, defaultLevel = { 10, 40 } },
    { key = "goals-zones", title = "Leveling zones by level", kind = "zones", default = false },
    { key = "goals-dungeons", title = "Dungeon goals by level", kind = "dungeons", default = false },
    { key = "goals-professions", title = "Professions", ids = { "tailoring-75", "tailoring-enchanting", "secondaries" }, default = false },
    { key = "goals-mounts", title = "Mounts, riding & gold", ids = { "riding", "first-mount" }, defaultLevel = { 38, 45 } },
    { key = "goals-gear", title = "Gear & stat priorities", kind = "gear", default = false },
  },

  gear = {
    { id = "robes-of-arugal", name = "Robes of Arugal", itemID = 6324, source = "Shadowfang Keep", boss = "Archmage Arugal", slot = "Chest" },
    { id = "dwarven-tome", name = "Dwarven Tome", itemID = 279898, source = "Hall of Thanes quest: Important Heirlooms", slot = "Held In Off-hand" },
    { id = "civinad-robes", name = "Civinad Robes", itemID = 9623, source = "Gnomeregan quest: The Grand Betrayal", slot = "Chest" },
    { id = "death-speaker-robes", name = "Death Speaker Robes", itemID = 6682, source = "Razorfen Kraul", boss = "Death Speaker Jargba", slot = "Chest" },
    { id = "embalmed-shroud", name = "Embalmed Shroud", itemID = 7691, source = "Scarlet Monastery: Graveyard", boss = "Fallen Champion", slot = "Head" },
    { id = "bloodmage-mantle", name = "Bloodmage Mantle", itemID = 7684, source = "Scarlet Monastery: Graveyard", boss = "Bloodmage Thalnos", slot = "Shoulder" },
    { id = "hypnotic-blade", name = "Hypnotic Blade", itemID = 7714, source = "Scarlet Monastery: Library", boss = "Arcanist Doan", slot = "Main Hand" },
    { id = "scorns-icy-choker", name = "Scorn's Icy Choker", itemID = 23169, source = "Scarlet Monastery: Graveyard", boss = "Scorn", slot = "Neck" },
    { id = "whitemanes-chapeau", name = "Whitemane's Chapeau", itemID = 7720, source = "Scarlet Monastery: Cathedral", boss = "High Inquisitor Whitemane", slot = "Head" },
    { id = "triune-amulet", name = "Triune Amulet", itemID = 7722, source = "Scarlet Monastery: Cathedral", boss = "High Inquisitor Whitemane", slot = "Neck" },
    { id = "doomsayers-robe", name = "Doomsayer's Robe", itemID = 4746, source = "Uldaman quest: Solution to Doom", slot = "Chest" },
    { id = "zumrahs-vexing-cane", name = "Zum'rah's Vexing Cane", itemID = 18082, source = "Zul'Farrak", boss = "Witch Doctor Zum'rah", slot = "Two-Hand Staff" },
    { id = "omnicast-boots", name = "Omnicast Boots", itemID = 11822, source = "Blackrock Depths", boss = "Golem Lord Argelmach", slot = "Feet" },
    { id = "spritecaster-cape", name = "Spritecaster Cape", itemID = 11623, source = "Blackrock Depths", boss = "Houndmaster Grebmar", slot = "Back" },
    { id = "chief-architects-monocle", name = "Chief Architect's Monocle", itemID = 11839, source = "Blackrock Depths", boss = "Fineous Darkvire", slot = "Head" },
    { id = "banthok-sash", name = "Ban'thok Sash", itemID = 11662, source = "Blackrock Depths", boss = "Ok'thor the Breaker", slot = "Waist" },
    { id = "hands-exalted-herald", name = "Hands of the Exalted Herald", itemID = 12554, source = "Blackrock Depths", boss = "Princess Moira Bronzebeard", slot = "Hands" },
    { id = "briarwood-reed", name = "Briarwood Reed", itemID = 12930, source = "Upper Blackrock Spire", boss = "Jed Runewatcher", slot = "Trinket" },
    { id = "alannas-embrace", name = "Alanna's Embrace", itemID = 13314, source = "Scholomance", boss = "Ras Frostwhisper", slot = "Chest" },
    { id = "book-of-the-dead", name = "Book of the Dead", itemID = 13353, source = "Stratholme", boss = "Balnazzar", slot = "Held In Off-hand" },
    { id = "tome-of-knowledge", name = "Tome of Knowledge", itemID = 13385, source = "Stratholme", boss = "Archivist Galford", slot = "Held In Off-hand" },
    { id = "arcane-runed-bracers", name = "Arcane Runed Bracers", itemID = 4744, source = "Quest: WANTED: Marez Cowl", slot = "Wrist" },
  },

  milestones = {
    { id = "conjure-water", name = "Conjure Water", level = 4, spellName = "Conjure Water", note = "Trained at 4. Keep every rank current; Frost drinks more than most classes." },
    { id = "conjure-food", name = "Conjure Food", level = 6, spellName = "Conjure Food", note = "Trained at 6. Keep every rank current." },
    { id = "polymorph", name = "Polymorph", level = 8, spellName = "Polymorph", note = "Trained at 8 in Forever (60.tools). Classic had a later sheep quest in some eras; Forever lists it as a trainer spell." },
    { id = "frost-talents-10", name = "Start the Frost talent line", level = 10, note = "First talent point at 10 (or earlier with the Legacy Talented perk). Frost leveling guides open with hit/precision and the Frostbolt line. Manual check." },
    { id = "blink-evocation", name = "Blink and Evocation", level = 20, spellName = "Blink", note = "Both trained at 20, with Mana Shield and Blizzard. Evocation is your mana battery." },
    { id = "teleports-20", name = "Alliance teleports", level = 20, note = "Teleport: Ironforge and Teleport: Stormwind at 20, Darnassus at 30, Dalaran at 50 (Alliance-side in Forever trainer data). Skip Horde city teleports." },
    { id = "ice-lance-talent", name = "Ice Lance (Frost talent)", level = 20, note = "Ice Lance is not on the 1.60.1.70888 trainer list; Frost leveling guides treat it as a talent (around the first full Frost tier). Manual unless the spell is detected." },
    { id = "mage-armor", name = "Mage Armor", level = 34, spellName = "Mage Armor", note = "Trained at 34. A mana-friendly armor option alongside Ice Armor." },
    { id = "riding", name = "Apprentice Riding", level = 40, note = "Train riding at 40. Gnome mount vendors are in Ironforge; exact trainer gold was not verified here. Level is detected; training is manual." },
    { id = "first-mount", name = "First mount", level = 40, note = "Buy or claim your first 60% mount at 40. Manual check." },
    { id = "portals-40", name = "Alliance portals", level = 40, note = "Portal: Ironforge and Portal: Stormwind at 40, Darnassus at 50. Skip Horde city portals." },
    { id = "arcane-brilliance", name = "Arcane Brilliance", level = 56, spellName = "Arcane Brilliance", note = "Trained at 56. Group version of Arcane Intellect." },
    { id = "dual-spec", name = "Dual spec (50 gold)", level = 40, note = "Buy from your class trainer at 40 for 50 gold (same Forever price as other classes). A common split is Frost for questing and a Fire or AoE set for packs. Level is detected; the purchase is manual." },
    { id = "fire-offspec", name = "Fire off-spec (optional)", level = 40, note = "Frost is the default leveling path in this guide. Fire is a fine dungeon or later-level alternative; keep Fireball and Fire Blast ranks if you plan to respec. Classic Era talent-tree details can differ in Forever; treat this as a baseline and confirm in-game." },
    { id = "tailoring-75", name = "Journeyman Tailoring (skill 75+)", level = 1, note = "Train Journeyman Tailoring from Jormund Stonebrow in Ironforge once you are past 75 skill. Bags and your own cloth gear are the reason to keep this up while you level. Trainer gold is left blank; confirm the cost in-game." },
    { id = "tailoring-enchanting", name = "Enchanting pairing (optional)", level = 1, note = "Cloth classes often pair Tailoring with Enchanting so greens can be disenchanted. This is the Classic Era baseline; confirm Forever trainers in Ironforge or Stormwind. Exact gold costs are not listed here." },
    { id = "secondaries", name = "First Aid, Cooking, and Fishing", level = 1, note = "These secondary professions are free to pick up and useful while you quest. Exact trainer locations and costs were not verified for Forever here; Ironforge and Stormwind both have trainers." },
  },
}
