-- Philosopher's Codex class module: Shaman
-- 1.24.0: Enhancement leveling (default) with Restoration for dungeons.
-- Classic Era baseline; Forever-specific changes are not confirmed yet.

PhilosophersCodexData = PhilosophersCodexData or {}
PhilosophersCodexData.CLASSES = PhilosophersCodexData.CLASSES or {}

PhilosophersCodexData.CLASSES.SHAMAN = {
  classFile = "SHAMAN",
  title = "Shaman Leveling & Gearing",
  supported = true,
  icons = {
    class = "Interface\\Icons\\Spell_Nature_BloodLust",
    forms = "Interface\\Icons\\Spell_Nature_SpiritWolf",
    talents = "Interface\\Icons\\Spell_Nature_LightningShield",
    trainer = "Interface\\Icons\\INV_Misc_Book_09",
    mounts = "Interface\\Icons\\Ability_Mount_RidingHorse",
    gear = "Interface\\Icons\\INV_Chest_Chain_05",
    professions = "Interface\\Icons\\Trade_Alchemy",
    zones = "Interface\\Icons\\INV_Misc_Map_01",
    dungeons = "Interface\\Icons\\INV_Misc_ShadowEgg",
    goals = "Interface\\Icons\\Spell_Nature_StoneSkinTotem",
    spells = "Interface\\Icons\\Spell_Nature_Lightning",
  },
  allowedRoles = { "dps", "healer" },
  defaultRole = "dps",
  defaultProfile = "enh",
  trainerWaypoint = nil,
  factionNote = "Level as Enhancement: a slow two-hander, Lightning Shield up, Earth Shock to interrupt and finish, Flame Shock on tougher mobs, and Stoneskin or Strength of Earth down on bigger fights. Windfury Weapon at 30 is the big leveling jump. From 20, Call of the Elements drops a set of totems at once and Totemic Recall picks them back up. Heal yourself between pulls.",
  gearPriorities = {
    "Enhancement: strength and agility first, then stamina, crit, intellect. A slow two-hander's damage matters most.",
    "Restoration (dungeon healing): healing power, intellect, mana per 5, spirit, stamina.",
    "Leather and shields until 40, then mail. Two-handed axes and maces, staves, one-hand axes, maces and daggers.",
  },
  allowedArmor = { [0] = true, [1] = true, [2] = true, [3] = true, [6] = true },
  allowedWeapons = { [0] = true, [1] = true, [4] = true, [5] = true, [10] = true, [13] = true, [15] = true },
  allowWands = false,
  mailAt = 40,
  allowShields = true,
  allowRelics = true,
  recLabels = {
    must = "Must train",
    enh = "Train for Enhancement",
    ele = "Train for Elemental",
    resto = "Train for healing",
    skip = "Skip for now",
  },
  profiles = {
    { id = "enh", name = "Enhancement", labels = { "enh" }, weights = {
      strength = 8, agility = 6, attackpower = 4, meleedps = 9, crit = 6, hit = 6, stamina = 3, intellect = 2, spirit = 0, armor = 0.03,
    }},
    { id = "heal", name = "Healing", labels = { "resto" }, weights = {
      healing = 10, spellpower = 8, intellect = 5, mp5 = 5, spirit = 2, crit = 2, stamina = 1, armor = 0.02,
    }},
    { id = "ele", name = "Elemental", labels = { "ele" }, weights = {
      spelldamage = 10, spellpower = 10, intellect = 5, crit = 5, mp5 = 3, stamina = 2, spirit = 1,
    }},
    { id = "both", name = "Enh + heal", labels = { "enh", "resto" }, compare = { "enh", "heal" } },
  },
  goalGroups = {
    { key = "goals-trainer", title = "Trainer spells by level", kind = "trainer", default = false },
    { key = "goals-forms", title = "Totems & class tools", ids = { "earth-totem", "fire-totem", "ghost-wolf", "call-elements", "windfury-weapon" }, defaultLevel = { 4, 30 } },
    { key = "goals-talents", title = "Talents & spec milestones", ids = { "enh-talents-10", "dual-spec" }, defaultLevel = { 10, 40 } },
    { key = "goals-zones", title = "Leveling zones by level", kind = "zones", default = false },
    { key = "goals-dungeons", title = "Dungeon goals by level", kind = "dungeons", default = false },
    { key = "goals-mounts", title = "Mounts, riding & gold", ids = { "riding", "first-mount" }, defaultLevel = { 38, 45 } },
    { key = "goals-gear", title = "Gear & stat priorities", kind = "gear", default = false },
  },
  gear = {
    { id = "smite-mighty-hammer", name = "Smite's Mighty Hammer", itemID = 7230, source = "The Deadmines", boss = "Mr. Smite", slot = "Two-Hand" },
    { id = "corsairs-overshirt-shaman", name = "Corsair's Overshirt", itemID = 5202, source = "The Deadmines quest", slot = "Chest" },
    { id = "bloody-apron-shaman", name = "Bloody Apron", itemID = 6226, source = "Shadowfang Keep", boss = "Razorclaw the Butcher", slot = "Chest" },
    { id = "commanders-crest-shaman", name = "Commander's Crest", itemID = 6320, source = "Shadowfang Keep", boss = "Commander Springvale", slot = "Shield" },
  },
  milestones = {
    { id = "earth-totem", name = "First earth totem", level = 4, spellName = "Stoneskin Totem", note = "Stoneskin Totem at 4. In Classic a totem quest came first; check your trainer in Forever." },
    { id = "fire-totem", name = "First fire totem", level = 10, spellName = "Searing Totem", note = "Searing Totem at 10. Drop it on tougher fights for free damage." },
    { id = "enh-talents-10", name = "Start the Enhancement line", level = 10, note = "Enhancement talents first for leveling. Manual check." },
    { id = "ghost-wolf", name = "Ghost Wolf", level = 20, spellName = "Ghost Wolf", note = "Run speed until your mount." },
    { id = "call-elements", name = "Call of the Elements", level = 20, spellName = "Call of the Elements", note = "Drops a set of totems in one cast. Totemic Recall at 20 picks them back up." },
    { id = "windfury-weapon", name = "Windfury Weapon", level = 30, spellName = "Windfury Weapon", note = "Your weapon buff for Enhancement from 30. Keep it up all the time." },
    { id = "riding", name = "Apprentice Riding", level = 40, note = "Train riding at 40. Level is detected; training is manual." },
    { id = "first-mount", name = "First mount", level = 40, note = "Buy your first mount at 40. Manual check." },
    { id = "dual-spec", name = "Dual spec (50 gold)", level = 40, note = "Buy from your class trainer at 40. Enhancement for questing and Restoration for dungeons is a common split." },
  },
}
