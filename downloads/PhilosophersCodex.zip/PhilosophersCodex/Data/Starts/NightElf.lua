-- Alliance Night Elf starting path, levels 1-20, then the shared route takes over.
-- Zones follow the usual Teldrassil / Darkshore climb. Forever early dungeons
-- that are a trip from Kalimdor are listed as optional, not required.

PhilosophersCodexData = PhilosophersCodexData or {}
PhilosophersCodexData.STARTS = PhilosophersCodexData.STARTS or {}

PhilosophersCodexData.STARTS.NightElf = {
  raceFile = "NightElf",
  title = "Night Elf start",
  note = "Shadowglen and Teldrassil, then Darkshore from Auberdine. The shared Alliance route (Redridge, Duskwood, Wetlands) starts at 21.",
  brackets = {
    {
      id = "1-10",
      heading = "Levels 1-10  ·  Teldrassil",
      min = 1,
      max = 10,
      alert = "Time to start in Shadowglen, then Dolanaar and Teldrassil, before the boat from Darnassus to Darkshore.",
      zones = {
        "Shadowglen",
        "Teldrassil",
        "Darnassus",
      },
      zoneHint = "Quest through Shadowglen, then Dolanaar. At 10, take the boat from Darnassus to Auberdine.",
      dungeons = {},
    },
    {
      id = "10-20",
      heading = "Levels 10-20  ·  Darkshore",
      min = 10,
      max = 20,
      alert = "Time to move to Darkshore. Work the Auberdine quests toward 20, then head east toward the shared Alliance route.",
      zones = {
        "Darkshore",
        "Darnassus",
        "Teldrassil",
      },
      zoneHint = "Auberdine is the hub. Ruins of Lordaeron (11-24) and Hall of Thanes (13-22) are Forever Alliance dungeons if you want an early dungeon trip to the Eastern Kingdoms; they are optional from here.",
      dungeons = {
        {
          id = "ruins-of-lordaeron",
          name = "Ruins of Lordaeron",
          range = "11-24",
          aliases = { "Ruins of Lordaeron", "The Ruins of Lordaeron" },
          note = "Optional early Forever dungeon in the Eastern Kingdoms. A trip from Darkshore; not required for this start.",
        },
        {
          id = "wailing-caverns",
          name = "Wailing Caverns",
          range = "15-24",
          aliases = { "Wailing Caverns" },
          note = "Optional Kalimdor dungeon if you want a group. The Barrens is a longer run from Darkshore.",
        },
        {
          id = "deadmines",
          name = "The Deadmines",
          range = "17-26",
          aliases = { "The Deadmines", "Deadmines", "Deadmine" },
          note = "Optional Eastern Kingdoms dungeon around 17. Westfall is a boat trip from Darkshore.",
        },
      },
    },
  },
}
