-- Alliance Gnome starting path, levels 1-20, then the shared route takes over.
-- Coldridge / Dun Morogh / Loch Modan, with Hall of Thanes under Ironforge,
-- then Westfall or Redridge. Sources: wow-forever.gg gnome guide, wowfdb
-- class leveling "Where" notes for Gnome.

PhilosophersCodexData = PhilosophersCodexData or {}
PhilosophersCodexData.STARTS = PhilosophersCodexData.STARTS or {}

PhilosophersCodexData.STARTS.Gnome = {
  raceFile = "Gnome",
  title = "Gnome start",
  note = "Coldridge Valley, then Kharanos in Dun Morogh, Loch Modan with Hall of Thanes, then Westfall or Redridge before the shared Alliance route at 21.",
  brackets = {
    {
      id = "1-6",
      heading = "Levels 1-6  ·  Coldridge Valley",
      min = 1,
      max = 6,
      alert = "Time to start in Coldridge Valley (Anvilmar), then walk out to Kharanos in Dun Morogh.",
      zones = {
        "Coldridge Valley",
        "Dun Morogh",
      },
      zoneHint = "Quest through Coldridge Valley and Anvilmar until you are sent to Kharanos.",
      dungeons = {},
    },
    {
      id = "6-12",
      heading = "Levels 6-12  ·  Dun Morogh",
      min = 6,
      max = 12,
      alert = "Time to quest in Dun Morogh from Kharanos. Ironforge is next door when you need a trainer or the tram.",
      zones = {
        "Dun Morogh",
        "Ironforge",
        "Coldridge Valley",
      },
      zoneHint = "Kharanos is the hub. Visit Ironforge for trainers and the Deeprun Tram toward Stormwind when you are ready to go east.",
      dungeons = {},
    },
    {
      id = "10-20",
      heading = "Levels 10-20  ·  Loch Modan and the west",
      min = 10,
      max = 20,
      alert = "Time to move through Loch Modan, including Hall of Thanes under Ironforge, then Westfall or Redridge toward 20.",
      zones = {
        "Loch Modan",
        "Dun Morogh",
        "Ironforge",
        "Westfall",
        "Elwynn Forest",
        "Redridge Mountains",
        "Stormwind City",
      },
      zoneHint = "Loch Modan (Thelsamar) from about 10, with Hall of Thanes at 13-16 under Ironforge. Then Westfall (Deadmines around 17) or start Redridge, which feeds the shared 21-25 route.",
      dungeons = {
        {
          id = "hall-of-thanes",
          name = "Hall of Thanes",
          range = "13-22",
          aliases = { "Hall of Thanes", "The Hall of Thanes" },
          note = "Forever dungeon under Ironforge. Natural first dungeon on the Gnome path around 13-16.",
        },
        {
          id = "deadmines",
          name = "The Deadmines",
          range = "17-26",
          aliases = { "The Deadmines", "Deadmines", "Deadmine" },
          note = "Westfall. A natural Gnome follow-up after Loch Modan.",
        },
        {
          id = "shadowfang-keep",
          name = "Shadowfang Keep",
          range = "20-30",
          aliases = { "Shadowfang Keep" },
          note = "Optional Silverpine dungeon once you can travel to the Eastern Kingdoms north.",
        },
      },
    },
  },
}
