-- Philosopher's Codex: level-aware gear recommendations.
-- Soon = required level <= player + 3, from a dungeon or zone that is
-- in range now, usable by this class, and an upgrade when we can score it.
-- Later = the next window only (up to player + 10). Far-future pieces
-- such as Stratholme at 17 or 45 stay hidden.

local PC = PhilosophersCodex
PC.GEAR_SOON_WINDOW = 3
PC.GEAR_LATER_WINDOW = 10

local dungeonRangeCache

local function Lower(s)
  if type(s) ~= "string" then
    return ""
  end
  return string.lower(s)
end

local function VisitDungeon(cache, d)
  if type(d) ~= "table" or not d.id then
    return
  end
  local minL, maxL
  if PC.ParseLevelRange then
    minL, maxL = PC:ParseLevelRange(d.range)
  end
  local prev = cache[d.id]
  if prev then
    if minL and (not prev.min or minL < prev.min) then
      prev.min = minL
    end
    if maxL and (not prev.max or maxL > prev.max) then
      prev.max = maxL
    end
    return
  end
  cache[d.id] = {
    id = d.id,
    name = d.name,
    min = minL,
    max = maxL,
    aliases = d.aliases,
  }
end

local function VisitBrackets(cache, brackets)
  if type(brackets) ~= "table" then
    return
  end
  for i = 1, #brackets do
    local dungeons = brackets[i] and brackets[i].dungeons
    if type(dungeons) == "table" then
      for j = 1, #dungeons do
        VisitDungeon(cache, dungeons[j])
      end
    end
  end
end

function PC:GetDungeonRangeTable()
  if dungeonRangeCache then
    return dungeonRangeCache
  end
  local cache = {}
  if PhilosophersCodexData and PhilosophersCodexData.ROUTE then
    VisitBrackets(cache, PhilosophersCodexData.ROUTE.brackets)
  end
  if PhilosophersCodexData and PhilosophersCodexData.STARTS then
    for _, start in pairs(PhilosophersCodexData.STARTS) do
      if type(start) == "table" then
        VisitBrackets(cache, start.brackets)
      end
    end
  end
  dungeonRangeCache = cache
  return cache
end

function PC:GetDungeonLevelRange(dungeonId)
  if not dungeonId then
    return nil, nil
  end
  local row = self:GetDungeonRangeTable()[dungeonId]
  if not row then
    return nil, nil
  end
  return row.min, row.max
end

function PC:ResolveDungeonId(item)
  if not item then
    return nil
  end
  if item.dungeon and item.dungeon ~= "" then
    return item.dungeon
  end
  local cache = self:GetDungeonRangeTable()
  if cache[item.dungeon] then
    return item.dungeon
  end
  local hay = Lower((item.dungeonName or "") .. " " .. (item.source or "") .. " " .. (item.quest or ""))
  if hay == " " or hay == "  " then
    return nil
  end
  for id, row in pairs(cache) do
    if row.name and hay:find(Lower(row.name), 1, true) then
      return id
    end
    local aliases = row.aliases or {}
    for i = 1, #aliases do
      if hay:find(Lower(aliases[i]), 1, true) then
        return id
      end
    end
  end
  return nil
end

function PC:GetItemRequiredLevel(item)
  if not item then
    return nil
  end
  local req = tonumber(item.reqLevel) or tonumber(item.minLevel)
  if req and req > 0 then
    return req
  end
  if item.itemID and self.FindLootByItemID then
    local loot = self:FindLootByItemID(item.itemID)
    if loot then
      req = tonumber(loot.reqLevel) or tonumber(loot.minLevel)
      if req and req > 0 then
        return req
      end
    end
  end
  if item.itemID and GetItemInfo then
    local ok, _, _, _, _, minLevel = pcall(GetItemInfo, item.itemID)
    if ok then
      minLevel = tonumber(minLevel)
      if minLevel and minLevel > 0 then
        return minLevel
      end
    end
  end
  local dungeonId = self:ResolveDungeonId(item)
  if dungeonId then
    local minL = self:GetDungeonLevelRange(dungeonId)
    if minL then
      return minL
    end
  end
  return nil
end

function PC:GetGearHorizon(item, level)
  level = tonumber(level) or self:PlayerLevel() or 1
  local soonW = self.GEAR_SOON_WINDOW or 3
  local laterW = self.GEAR_LATER_WINDOW or 10
  local req = self:GetItemRequiredLevel(item) or 0
  local dungeonId = self:ResolveDungeonId(item)
  local dMin = dungeonId and self:GetDungeonLevelRange(dungeonId) or nil

  -- A far-future dungeon hides the item even if a required level is missing
  -- or slightly low (Anastari Heirloom is 55, but Stratholme is a 58 dungeon).
  if dMin and dMin > level + laterW then
    return "hidden", req, dMin
  end
  if req > level + laterW then
    return "hidden", req, dMin
  end

  local soonByReq = req <= level + soonW
  local soonByDungeon = (not dMin) or (dMin <= level + soonW)
  if soonByReq and soonByDungeon then
    return "soon", req, dMin
  end
  local laterByReq = req <= level + laterW
  local laterByDungeon = (not dMin) or (dMin <= level + laterW)
  if laterByReq and laterByDungeon then
    return "later", req, dMin
  end
  return "hidden", req, dMin
end

local function ItemFactionOk(item, faction)
  local f = item and item.faction
  if not f or f == "" or Lower(f) == "both" or Lower(f) == "neutral" then
    return true
  end
  if not faction then
    return true
  end
  return Lower(f) == Lower(faction)
end

local function PlayerFaction()
  if UnitFactionGroup then
    local ok, name = pcall(UnitFactionGroup, "player")
    if ok and type(name) == "string" and name ~= "" then
      return name
    end
  end
  return "Alliance"
end

local function SlotKey(item)
  local slot = item and item.slot
  if PC.ClassifyGearSlot then
    local cat, sub = PC:ClassifyGearSlot(slot)
    return cat, sub or slot or "Other"
  end
  return "other", slot or "Other"
end

local function WhereText(item, dungeonId)
  if item and item.origin == "quest" and item.quest and item.questZone then
    return "Quest: " .. item.quest .. " — " .. item.questZone
  end
  if item and item.origin == "quest" and item.quest and item.quest ~= "" then
    return "Quest: " .. item.quest
  end
  local parts = {}
  if item.boss and item.boss ~= "" then
    parts[#parts + 1] = item.boss
  end
  if item.quest and item.quest ~= "" then
    parts[#parts + 1] = item.quest
  end
  local place = item.dungeonName or item.source
  if place and place ~= "" then
    parts[#parts + 1] = place
  elseif dungeonId then
    parts[#parts + 1] = dungeonId
  end
  if #parts == 0 then
    return nil
  end
  return table.concat(parts, "  ·  ")
end

local function ScoreUpgrade(self, item)
  if not item or not item.itemID or not self.EvaluateUpgrade then
    return nil, nil, nil
  end
  local ok, result = pcall(self.EvaluateUpgrade, self, item.itemID)
  if not ok or type(result) ~= "table" then
    return nil, nil, nil
  end
  if result.cantUse or result.ignored then
    return result, nil, false
  end
  local cmp = result.primary
  if not cmp and result.primaryId then
    cmp = result[result.primaryId]
  end
  if type(cmp) ~= "table" then
    return result, nil, nil
  end
  if cmp.blocked then
    return result, nil, false
  end
  local delta = (cmp.newScore or 0) - (cmp.oldScore or 0)
  return result, delta, cmp.upgrade and true or false
end


local INVTYPE_FROM_INV = {
  [1] = "INVTYPE_HEAD",
  [2] = "INVTYPE_NECK",
  [3] = "INVTYPE_SHOULDER",
  [5] = "INVTYPE_CHEST",
  [6] = "INVTYPE_WAIST",
  [7] = "INVTYPE_LEGS",
  [8] = "INVTYPE_FEET",
  [9] = "INVTYPE_WRIST",
  [10] = "INVTYPE_HAND",
  [11] = "INVTYPE_FINGER",
  [12] = "INVTYPE_TRINKET",
  [13] = "INVTYPE_WEAPON",
  [14] = "INVTYPE_SHIELD",
  [15] = "INVTYPE_RANGED",
  [16] = "INVTYPE_CLOAK",
  [17] = "INVTYPE_2HWEAPON",
  [20] = "INVTYPE_ROBE",
  [21] = "INVTYPE_WEAPONMAINHAND",
  [22] = "INVTYPE_WEAPONOFFHAND",
  [23] = "INVTYPE_HOLDABLE",
  [25] = "INVTYPE_THROWN",
  [26] = "INVTYPE_RANGEDRIGHT",
}

function PC:GetQuestItem(itemID)
  itemID = tonumber(itemID)
  if not itemID then
    return nil
  end
  local catalog = PhilosophersCodexData and PhilosophersCodexData.QUEST_ITEMS
  if type(catalog) == "table" then
    return catalog[itemID]
  end
  return nil
end

function PC:GetQuestRewards(questID)
  questID = tonumber(questID)
  if not questID then
    return nil
  end
  local rewards = PhilosophersCodexData and PhilosophersCodexData.QUEST_REWARDS
  if type(rewards) == "table" then
    return rewards[questID]
  end
  return nil
end

function PC:CatalogEquipLoc(item)
  if not item then
    return nil
  end
  if item.inv and INVTYPE_FROM_INV[item.inv] then
    return INVTYPE_FROM_INV[item.inv]
  end
  return nil
end

function PC:ClassCanEquipCatalog(item, classFile)
  if not item then
    return false
  end
  classFile = classFile or (self.GetClassFile and self:GetClassFile())
  local data = self.GetClassData and self:GetClassData(classFile) or nil
  local sc = tonumber(item.sc)
  local cls = tonumber(item.c)
  local inv = tonumber(item.inv)
  -- Jewelry, cloaks, and holdables are usable by every class we support.
  if inv == 2 or inv == 11 or inv == 12 or inv == 16 or inv == 23 then
    return true
  end
  if cls == 4 and (sc == 6 or inv == 14) then
    return data and data.allowShields and true or false
  end
  if cls == 2 and sc == 19 then
    return data and data.allowWands and true or false
  end
  if cls == 2 and (inv == 15 or inv == 25 or inv == 26) and sc ~= 19 then
    local weapons = data and data.allowedWeapons
    if weapons then
      return weapons[sc] and true or false
    end
    return false
  end
  if cls == 4 then
    local armor = data and data.allowedArmor
    if not armor then
      -- Unknown class: allow cloth and jewelry only.
      return sc == 1 or sc == 0 or sc == -6
    end
    if sc == -6 or sc == 0 then
      return true
    end
    return armor[sc] and true or false
  end
  if cls == 2 then
    local weapons = data and data.allowedWeapons
    if not weapons then
      return true
    end
    return weapons[sc] and true or false
  end
  return false
end

local function CatalogStatScore(item, role, classFile)
  if not item then
    return 0
  end
  role = role or "dps"
  local int = item.intellect or 0
  local spi = item.spirit or 0
  local sta = item.stamina or 0
  local agi = item.agility or 0
  local str = item.strength or 0
  local sp = item.spellDamage or item.spellpower or 0
  local heal = item.spellHealing or 0
  local armor = item.armor or 0
  local dps = item.meleeDps or 0
  local ap = item.attackPower or 0
  local quality = item.q or 1
  local score = quality * 2
  if role == "healer" then
    score = score + heal * 10 + sp * 2 + int * 4 + spi * 3 + sta * 1
  elseif classFile == "MAGE" or classFile == "WARLOCK" or role == "dps" and (classFile == "PRIEST") then
    score = score + sp * 10 + int * 5 + spi * 2 + sta * 1
  elseif role == "tank" then
    score = score + sta * 5 + armor * 0.08 + agi * 2 + str * 2 + ap
  else
    -- leather/melee dps (feral / generic)
    if classFile == "DRUID" then
      -- Balance-ish default if the upgrade profile is caster; otherwise feral-ish.
      local profile = PC.GetUpgradeProfile and PC:GetUpgradeProfile() or nil
      if profile == "heal" then
        score = score + heal * 10 + sp * 2 + int * 4 + spi * 3
      elseif profile == "balance" then
        score = score + sp * 10 + int * 5 + spi * 2
      else
        score = score + agi * 5 + str * 3 + ap * 2 + dps * 3 + sta * 1
      end
    else
      score = score + sp * 8 + int * 4 + spi * 2 + agi * 3 + str * 2
    end
  end
  return score
end

function PC:PickBestQuestReward(itemIDs, classFile, role)
  classFile = classFile or (self.GetClassFile and self:GetClassFile())
  role = role or (self.GetSocialRole and self:GetSocialRole()) or "dps"
  local best, bestScore, usable = nil, -1e9, {}
  for i = 1, #(itemIDs or {}) do
    local id = tonumber(itemIDs[i])
    local item = id and self:GetQuestItem(id)
    if item and self:ClassCanEquipCatalog(item, classFile) then
      local rec = { itemID = id, catalog = item }
      local score = CatalogStatScore(item, role, classFile)
      -- Prefer a live upgrade score when the client has item stats cached.
      if self.EvaluateUpgrade then
        local ok, ev = pcall(self.EvaluateUpgrade, self, id)
        if ok and type(ev) == "table" and ev.primary and ev.primary.newScore then
          score = score + (ev.primary.newScore or 0) * 0.25
          if ev.cantUse then
            rec = nil
          end
        end
      end
      if rec then
        rec.score = score
        usable[#usable + 1] = rec
        if score > bestScore then
          bestScore = score
          best = rec
        end
      end
    end
  end
  return best, usable
end

function PC:CollectGearCandidates(level)
  level = tonumber(level) or (self.PlayerLevel and self:PlayerLevel()) or 1
  local list = {}
  local seen = {}
  local function add(item, origin)
    if type(item) ~= "table" then
      return
    end
    local key
    if item.itemID then
      key = "id:" .. tostring(item.itemID)
    elseif item.id then
      key = "key:" .. tostring(item.id)
    elseif item.name then
      key = "name:" .. Lower(item.name)
    else
      return
    end
    if seen[key] then
      -- Prefer a class-guide row (has a tracker id) over a raw loot row.
      if origin == "class" and seen[key].origin ~= "class" then
        item.origin = origin
        list[seen[key].index] = item
        seen[key] = { index = seen[key].index, origin = origin }
      end
      return
    end
    item.origin = origin
    list[#list + 1] = item
    seen[key] = { index = #list, origin = origin }
  end

  local data = self.GetClassData and self:GetClassData() or nil
  if data and type(data.gear) == "table" then
    for i = 1, #data.gear do
      add(data.gear[i], "class")
    end
  end
  local loot = self.GetLootTable and self:GetLootTable() or nil
  if type(loot) == "table" then
    for i = 1, #loot do
      local it = loot[i]
      if type(it) == "table" then
        add({
          id = it.tracker or (it.itemID and ("loot-" .. tostring(it.itemID))) or it.name,
          name = it.name,
          itemID = it.itemID,
          reqLevel = it.reqLevel,
          source = it.dungeonName or it.quest,
          dungeon = it.dungeon,
          dungeonName = it.dungeonName,
          boss = it.boss,
          quest = it.quest,
          slot = it.slot,
          note = it.note,
          faction = it.faction,
        }, "loot")
      end
    end
  end

  -- Alliance 1-30 quest rewards (fixed and the best choice pick).
  local rewards = PhilosophersCodexData and PhilosophersCodexData.QUEST_REWARDS
  if type(rewards) == "table" then
    local classFile = self.GetClassFile and self:GetClassFile() or nil
    local role = self.GetSocialRole and self:GetSocialRole() or nil
    for questID, pack in pairs(rewards) do
      local quest = self.FindZoneQuest and self:FindZoneQuest(questID) or nil
      if not quest then
        quest = { questID = questID }
      end
      -- Hide turned-in quests. Gray / ineligible quests stay out of Soon.
      local status
      if self.GetZoneQuestStatus then
        status = self:GetZoneQuestStatus(quest, level)
      elseif self.IsQuestFlaggedComplete or self.IsQuestFlaggedCompleteAny then
        local doneFn = self.IsQuestFlaggedCompleteAny or self.IsQuestFlaggedComplete
        if doneFn(self, questID) then
          status = "complete"
        end
      end
      if status ~= "complete" and status ~= "ineligible" then
        local hideGray = (not self.IsHideGrayQuests) or self:IsHideGrayQuests()
        if status == "gray" and hideGray then
          -- Still allowed in Later if the required level is in that window;
          -- Collect keeps it and GetRecommendedGear applies the horizon.
        end
        local fixed = pack.items or {}
        local choice = pack.choice or {}
        local best, usable
        if #choice > 0 then
          best, usable = self:PickBestQuestReward(choice, classFile, role)
        end
        local function addQuestItem(itemID, isChoice, isBest)
          local catalog = self:GetQuestItem(itemID)
          if not catalog then
            return
          end
          if not self:ClassCanEquipCatalog(catalog, classFile) then
            return
          end
          local qname = quest.name or ("Quest " .. tostring(questID))
          local zone = quest.zone or quest.where or ""
          local source = "Quest: " .. qname
          if zone ~= "" then
            source = source .. " — " .. zone
          end
          local req = tonumber(catalog.r) or 0
          if req <= 0 then
            req = tonumber(quest.minLevel) or tonumber(quest.level) or 1
          end
          -- Use the quest level as a floor so Northshire whites don't
          -- linger in a level-17 Soon list just because reqLevel is 0.
          local qLevel = tonumber(quest.level) or tonumber(quest.minLevel) or req
          if qLevel > req then
            req = qLevel
          end
          local note = isChoice and (isBest and "Best pick for your class and role" or "Choice reward") or nil
          add({
            id = "quest-" .. tostring(questID) .. "-" .. tostring(itemID),
            name = catalog.n,
            itemID = itemID,
            reqLevel = req,
            source = source,
            quest = qname,
            questZone = zone,
            questID = questID,
            slot = catalog.s,
            note = note,
            faction = quest.faction or "Alliance",
            catalog = catalog,
            waypoint = self.GetQuestWaypoint and self:GetQuestWaypoint(quest) or nil,
            isChoice = isChoice and true or false,
            bestPick = isBest and true or false,
            questLevel = qLevel,
            questStatus = status,
          }, "quest")
        end
        for i = 1, #fixed do
          addQuestItem(fixed[i], false, false)
        end
        if best then
          addQuestItem(best.itemID, true, true)
        elseif usable then
          for i = 1, #usable do
            addQuestItem(usable[i].itemID, true, false)
          end
        end
      end
    end
  end
  return list
end

local function SortRecs(a, b)
  local sa, sb = a.score or -1e9, b.score or -1e9
  if sa ~= sb then
    return sa > sb
  end
  local ra, rb = a.reqLevel or 0, b.reqLevel or 0
  if ra ~= rb then
    return ra < rb
  end
  local na, nb = a.name or "", b.name or ""
  return na < nb
end

function PC:GetRecommendedGear(level)
  level = tonumber(level) or self:PlayerLevel() or 1
  local faction = PlayerFaction()
  local soon, later = {}, {}
  local candidates = self:CollectGearCandidates(level)
  for i = 1, #candidates do
    local item = candidates[i]
    if ItemFactionOk(item, faction) then
      local ev, delta, isUpgrade = ScoreUpgrade(self, item)
      local usable = true
      if ev and ev.cantUse then
        usable = false
      end
      if usable then
        local horizon, req, dMin = self:GetGearHorizon(item, level)
        if horizon == "soon" or horizon == "later" then
          -- In the soon list, skip pieces we can score and already know
          -- are worse than what is equipped. Unscored items still appear
          -- so the player has something to look for.
          local include = true
          if horizon == "soon" and ev and isUpgrade == false and delta ~= nil and delta <= 0 then
            include = false
          end
          -- Low-level (gray) quest rewards stay out of Soon, even if the
          -- item's required level is 0 or the quest is still "locked" on
          -- a prereq. Use the quest level as well as the status flag.
          if horizon == "soon" and item.origin == "quest" then
            local hideGray = (not self.IsHideGrayQuests) or self:IsHideGrayQuests()
            local gray = item.questStatus == "gray"
            if not gray and self.IsGrayQuest then
              gray = self:IsGrayQuest({ level = item.questLevel or item.reqLevel }, level)
            elseif not gray then
              local qLevel = tonumber(item.questLevel) or tonumber(item.reqLevel) or 0
              gray = qLevel > 0 and (level - qLevel) >= 6
            end
            if hideGray and gray then
              include = false
            end
          end
          if include then
            local cat, sub = SlotKey(item)
            local dungeonId = self:ResolveDungeonId(item)
            local rec = {
              id = item.id,
              name = item.name,
              itemID = item.itemID,
              slot = item.slot,
              category = cat,
              subslot = sub,
              source = item.source or item.dungeonName or item.quest,
              boss = item.boss,
              quest = item.quest,
              questZone = item.questZone,
              questID = item.questID,
              note = item.note,
              dungeon = dungeonId,
              dungeonMin = dMin,
              reqLevel = req,
              where = WhereText(item, dungeonId),
              waypoint = item.waypoint,
              horizon = horizon,
              score = delta,
              upgrade = isUpgrade and true or false,
              bestPick = item.bestPick and true or false,
              tooHigh = ev and ev.tooHigh or (req and req > level) or false,
              origin = item.origin,
            }
            if horizon == "soon" then
              soon[#soon + 1] = rec
            else
              later[#later + 1] = rec
            end
          end
        end
      end
    end
  end
  table.sort(soon, SortRecs)
  table.sort(later, SortRecs)
  return { soon = soon, later = later, level = level }
end

function PC:RecommendedHasItem(list, pred)
  if type(list) ~= "table" then
    return false
  end
  for i = 1, #list do
    if pred(list[i]) then
      return true
    end
  end
  return false
end

function PC:IsFarFutureGear(item)
  if not item then
    return false
  end
  local hay = Lower((item.dungeon or "") .. " " .. (item.dungeonName or "") .. " " .. (item.source or "") .. " " .. (item.name or ""))
  if hay:find("stratholme", 1, true) then
    return true
  end
  if item.dungeon == "stratholme" or item.dungeon == "scholomance" or item.dungeon == "ubrs" then
    return true
  end
  return false
end
