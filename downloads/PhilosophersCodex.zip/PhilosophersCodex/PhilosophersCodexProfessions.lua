-- Philosopher's Codex professions: detection, skill-up plan, and mat counts.

local PC = PhilosophersCodex

local function Lower(s)
  if type(s) ~= "string" then
    return ""
  end
  return string.lower(s)
end

function PC:GetProfessionData(idOrName)
  local packs = PhilosophersCodexData and PhilosophersCodexData.PROFESSIONS
  if not packs then
    return nil
  end
  if type(idOrName) ~= "string" or idOrName == "" then
    return nil
  end
  local aliases = PhilosophersCodexData.PROFESSION_ALIASES or {}
  local key = aliases[Lower(idOrName)] or Lower(idOrName)
  key = string.gsub(key, "%s+", "")
  if packs[key] then
    return packs[key], key
  end
  for id, pack in pairs(packs) do
    if type(pack) == "table" and Lower(pack.name) == Lower(idOrName) then
      return pack, id
    end
  end
  return nil
end

local function SkillLineInfo(index)
  if GetSkillLineInfo then
    local ok, name, header, expanded, rank, _, _, maxRank = pcall(GetSkillLineInfo, index)
    if ok then
      return name, header, rank, maxRank
    end
  end
  return nil
end

local function ProfessionInfo(index)
  if not index or not GetProfessionInfo then
    return nil
  end
  local ok, name, icon, skill, maxSkill = pcall(GetProfessionInfo, index)
  if not ok or not name then
    return nil
  end
  return { name = name, icon = icon, skill = skill or 0, maxSkill = maxSkill or 0 }
end

-- Detect learned professions. Retail-style GetProfessions is tried first,
-- then Classic GetNumSkillLines / GetSkillLineInfo. Returns a list of
-- { name, skill, maxSkill, icon, pack, id }.
function PC:GetPlayerProfessions()
  local list = {}
  local seen = {}

  local function add(name, skill, maxSkill, icon)
    if type(name) ~= "string" or name == "" then
      return
    end
    local pack, id = self:GetProfessionData(name)
    local key = id or Lower(name)
    if seen[key] then
      return
    end
    seen[key] = true
    list[#list + 1] = {
      name = (pack and pack.name) or name,
      skill = tonumber(skill) or 0,
      maxSkill = tonumber(maxSkill) or 0,
      icon = icon or (pack and pack.icon) or (self.ClassIcon and self:ClassIcon("professions")),
      pack = pack,
      id = id,
    }
  end

  local usedAPI = false
  if GetProfessions then
    local ok, a, b, arch, fish, cook, firstAid = pcall(GetProfessions)
    if ok then
      usedAPI = true
      local indexes = { a, b, arch, fish, cook, firstAid }
      for i = 1, #indexes do
        local rec = ProfessionInfo(indexes[i])
        if rec then
          add(rec.name, rec.skill, rec.maxSkill, rec.icon)
        end
      end
    end
  end

  if (not usedAPI or #list == 0) and GetNumSkillLines and GetSkillLineInfo then
    local ok, n = pcall(GetNumSkillLines)
    if ok and type(n) == "number" then
      usedAPI = true
      for i = 1, n do
        local name, header, rank, maxRank = SkillLineInfo(i)
        if name and not header then
          if self:GetProfessionData(name) then
            add(name, rank, maxRank)
          end
        end
      end
    end
  end

  if not usedAPI and self.LogMissing then
    self:LogMissing("professions", "api", "No profession API (GetProfessions or GetSkillLineInfo) was available.")
  end

  table.sort(list, function(a, b)
    return a.name < b.name
  end)
  return list
end

function PC:HasProfessionAPI()
  return (GetProfessions and true) or (GetNumSkillLines and GetSkillLineInfo and true) or false
end

function PC:ProfessionColor(skill, step)
  if not step or not skill then
    return "gray"
  end
  if step.orange and skill < step.orange then
    return "orange"
  end
  if step.yellow and skill < step.yellow then
    return "yellow"
  end
  if step.green and skill < step.green then
    return "green"
  end
  return "gray"
end

function PC:GetProfessionStep(pack, skill)
  if not pack or type(pack.steps) ~= "table" then
    return nil
  end
  skill = tonumber(skill) or 0
  local last
  for i = 1, #pack.steps do
    local step = pack.steps[i]
    last = step
    if skill < (step.to or 0) then
      return step, i
    end
  end
  return last, pack.steps and #pack.steps
end

function PC:GetNextProfessionRank(pack, skill, maxSkill)
  if not pack or type(pack.ranks) ~= "table" then
    return nil, false
  end
  skill = tonumber(skill) or 0
  maxSkill = tonumber(maxSkill) or 0
  local upcoming
  for i = 1, #pack.ranks do
    local rank = pack.ranks[i]
    local trainAt = rank.trainAt
    if trainAt then
      local cap = rank.cap or 300
      local already = maxSkill > 0 and maxSkill >= cap
      if not already and skill >= trainAt then
        return rank, true
      end
      if not already and skill < trainAt and not upcoming then
        upcoming = rank
      end
    end
  end
  return upcoming, false
end

function PC:CountProfessionMat(item, includeBank)
  if not item then
    return 0
  end
  if item.id and self.GetItemCount then
    return self:GetItemCount(item.id, includeBank ~= false) or 0
  end
  if item.name and self.PlayerHasItemByName then
    -- Name lookup only confirms presence, not a count.
    return 0
  end
  return 0
end

-- Builds a plan for one detected (or named) profession.
function PC:GetProfessionPlan(rec)
  if type(rec) == "string" then
    local pack, id = self:GetProfessionData(rec)
    rec = { name = pack and pack.name or rec, skill = 0, maxSkill = 0, pack = pack, id = id }
  end
  if type(rec) ~= "table" then
    return nil
  end
  local pack = rec.pack or (self:GetProfessionData(rec.id or rec.name))
  local skill = tonumber(rec.skill) or 0
  local maxSkill = tonumber(rec.maxSkill) or 0
  local step = pack and self:GetProfessionStep(pack, skill) or nil
  local rank, needTrain = nil, false
  if pack then
    rank, needTrain = self:GetNextProfessionRank(pack, skill, maxSkill)
  end
  local crafts, mats, missing = 0, {}, {}

  local milestone = (step and step.to) or skill
  if rank and rank.trainAt and rank.trainAt > skill and (not step or rank.trainAt <= (step.to or 999)) then
    milestone = math.min(milestone, rank.trainAt)
  end
  local remaining = milestone - skill
  if remaining < 0 then
    remaining = 0
  end
  if step and remaining > 0 and type(step.mats) == "table" and #step.mats > 0 then
    crafts = remaining
    for i = 1, #step.mats do
      local m = step.mats[i]
      local per = m.count or 1
      local need = per * crafts
      local have = self:CountProfessionMat(m, true)
      local row = {
        id = m.id,
        name = m.name,
        perCraft = per,
        need = need,
        have = have,
        short = have < need,
      }
      mats[#mats + 1] = row
      if row.short then
        missing[#missing + 1] = row
      end
    end
  end

  local color = self:ProfessionColor(skill, step)
  return {
    rec = rec,
    pack = pack,
    skill = skill,
    maxSkill = maxSkill,
    step = step,
    rank = rank,
    needTrain = needTrain,
    crafts = crafts,
    remaining = remaining,
    milestone = milestone,
    mats = mats,
    missing = missing,
    color = color,
  }
end

function PC:IsProfessionChecked(id)
  local db = self:GetDB()
  if not db or type(db.profChecks) ~= "table" then
    return false
  end
  return db.profChecks[id] and true or false
end

function PC:SetProfessionChecked(id, on)
  local db = self:GetDB()
  if not db then
    return
  end
  if type(db.profChecks) ~= "table" then
    db.profChecks = {}
  end
  if on then
    db.profChecks[id] = true
  else
    db.profChecks[id] = nil
  end
  if self.Refresh then
    self:Refresh()
  end
end

function PC:ProfessionCheckId(profId, kind, key)
  return tostring(profId or "prof") .. ":" .. tostring(kind or "x") .. ":" .. tostring(key or "")
end

function PC:FormatMatLine(row)
  if not row then
    return ""
  end
  local have = tostring(row.have or 0)
  local need = tostring(row.need or 0)
  local name = row.name or "item"
  if row.short then
    return "Need " .. tostring((row.need or 0) - (row.have or 0)) .. " more " .. name .. "  ·  " .. have .. "/" .. need
  end
  return "Have " .. have .. "/" .. need .. " " .. name
end

function PC:ProfessionStepSummary(plan)
  if not plan then
    return "No profession plan."
  end
  if not plan.pack then
    return "No written guide for this profession yet."
  end
  if plan.needTrain and plan.rank then
    local r = plan.rank
    local where = r.trainer and (r.trainer .. (r.zone and (" in " .. r.zone) or "")) or (r.zone or "your trainer")
    return "Train " .. (r.name or "the next rank") .. " with " .. where .. " at skill " .. tostring(r.trainAt or "?") .. "."
  end
  if plan.skill >= 300 or (plan.step and plan.skill >= (plan.step.to or 300) and plan.step.to == 300) then
    return "This profession is at cap."
  end
  if not plan.step then
    return "No next recipe is written for this skill."
  end
  local color = plan.color or "gray"
  local line = "Craft " .. (plan.step.recipe or "the next recipe") .. "  ·  " .. color .. " at " .. tostring(plan.skill)
  if plan.crafts and plan.crafts > 0 then
    line = line .. "  ·  about " .. tostring(plan.crafts) .. " to skill " .. tostring(plan.milestone)
  end
  return line
end

function PC:ProfessionColorRGB(color)
  if color == "orange" then
    return { r = 1.00, g = 0.50, b = 0.10 }
  end
  if color == "yellow" then
    return { r = 1.00, g = 0.82, b = 0.00 }
  end
  if color == "green" then
    return { r = 0.12, g = 1.00, b = 0.00 }
  end
  return { r = 0.62, g = 0.62, b = 0.62 }
end

function PC:ProfessionRankLabel(pack, skill, maxSkill)
  if not pack or type(pack.ranks) ~= "table" then
    return nil
  end
  skill = tonumber(skill) or 0
  maxSkill = tonumber(maxSkill) or 0
  local current
  for i = 1, #pack.ranks do
    local r = pack.ranks[i]
    local startAt = r.skill or r.trainAt or 0
    if skill >= startAt or (maxSkill > 0 and r.cap and maxSkill >= r.cap and skill >= (r.trainAt or startAt)) then
      current = r.name
    end
  end
  if not current and pack.ranks[1] then
    current = pack.ranks[1].name
  end
  return current
end

function PC:GetMatSource(item, pack)
  if type(item) == "table" and type(item.source) == "string" and item.source ~= "" then
    return item.source
  end
  if pack and type(pack.matSources) == "table" and type(item) == "table" and item.id and pack.matSources[item.id] then
    return pack.matSources[item.id]
  end
  local name = Lower(type(item) == "table" and item.name or item)
  if name == "" then
    return "AH or loot"
  end
  if name:find("thread", 1, true) or name:find("dye", 1, true) or name:find("bleach", 1, true)
      or name:find("salt", 1, true) or name:find("vendor", 1, true) or name:find("sharpening", 1, true)
      or name:find("weightstone", 1, true) or name:find("flux", 1, true) then
    return "Vendor"
  end
  if name:find("bolt of", 1, true) then
    return "Craft (previous step)"
  end
  if name:find("ore", 1, true) or name:find("stone", 1, true) or name:find("bar", 1, true)
      or name:find("ingot", 1, true) then
    return "Gather (mining) or AH"
  end
  if name:find("leaf", 1, true) or name:find("bloom", 1, true) or name:find("root", 1, true)
      or name:find("herb", 1, true) or name:find("lotus", 1, true) or name:find("grass", 1, true)
      or name:find("kelp", 1, true) or name:find("mushroom", 1, true) then
    return "Gather (herbalism) or AH"
  end
  if name:find("hide", 1, true) or name:find("scale", 1, true) or name:find("leather", 1, true)
      or name:find("hide", 1, true) or name:find("skin", 1, true) then
    return "Gather (skinning) or AH"
  end
  if name:find("cloth", 1, true) then
    return "Loot (humanoids) or AH"
  end
  return "AH or loot"
end

function PC:FormatMatLine(row)
  if not row then
    return ""
  end
  local have = tostring(row.have or 0)
  local need = tostring(row.need or 0)
  local name = row.name or "item"
  local source = self:GetMatSource(row)
  local line
  if row.short then
    line = "Need " .. tostring((row.need or 0) - (row.have or 0)) .. " more " .. name .. "  ·  " .. have .. "/" .. need
  else
    line = "Have " .. have .. "/" .. need .. " " .. name
  end
  if source and source ~= "" then
    line = line .. "  ·  " .. source
  end
  return line
end

function PC:GetAllProfessionPacks()
  local packs = PhilosophersCodexData and PhilosophersCodexData.PROFESSIONS
  local list = {}
  if type(packs) ~= "table" then
    return list
  end
  for id, pack in pairs(packs) do
    if type(pack) == "table" and type(pack.name) == "string" then
      list[#list + 1] = pack
      pack.id = pack.id or id
    end
  end
  table.sort(list, function(a, b)
    return (a.name or "") < (b.name or "")
  end)
  return list
end

function PC:GetUnlearnedProfessions()
  local learned = {}
  local have = self:GetPlayerProfessions() or {}
  for i = 1, #have do
    local rec = have[i]
    if rec.id then
      learned[rec.id] = true
    end
    if rec.name then
      learned[Lower(rec.name)] = true
    end
  end
  local list = {}
  local packs = self:GetAllProfessionPacks()
  for i = 1, #packs do
    local pack = packs[i]
    local id = pack.id or Lower(pack.name)
    if not learned[id] and not learned[Lower(pack.name or "")] then
      list[#list + 1] = {
        name = pack.name,
        id = id,
        pack = pack,
        icon = pack.icon,
        skill = 0,
        maxSkill = 0,
        unlearned = true,
      }
    end
  end
  return list
end

function PC:ProfessionLandingStatus(rec)
  local plan = self:GetProfessionPlan(rec)
  if not plan then
    return "No plan yet.", nil, plan
  end
  local mid
  if plan.needTrain and plan.rank then
    mid = "Train " .. (plan.rank.name or "the next rank")
    if plan.rank.trainer then
      mid = mid .. "  ·  " .. plan.rank.trainer
    end
  elseif plan.milestone and plan.skill and plan.milestone > plan.skill then
    mid = "Next milestone: skill " .. tostring(plan.milestone)
  elseif plan.skill and plan.skill >= 300 then
    mid = "At cap"
  end
  return self:ProfessionStepSummary(plan), mid, plan
end


-- How many crafts remain until a color or the planned switch point.
function PC:ProfessionCraftsUntil(skill, target)
  skill = tonumber(skill) or 0
  target = tonumber(target)
  if not target then
    return nil
  end
  local n = target - skill
  if n < 0 then
    n = 0
  end
  return n
end

-- One-line "craft this next" summary for a profession plan.
function PC:GetCraftNextSummary(plan)
  if not plan or not plan.step then
    return self:ProfessionStepSummary(plan)
  end
  local skill = plan.skill or 0
  local step = plan.step
  local color = plan.color or self:ProfessionColor(skill, step)
  local parts = { "skill " .. tostring(skill) }
  if step.to then
    parts[#parts + 1] = "switch at " .. tostring(step.to)
  end
  if step.yellow and skill < step.yellow then
    parts[#parts + 1] = "yellow at " .. tostring(step.yellow)
  elseif step.green and skill < step.green then
    parts[#parts + 1] = "green at " .. tostring(step.green)
  elseif color and color ~= "" then
    parts[#parts + 1] = color
  end
  return table.concat(parts, "  ·  ")
end

-- Efficient "Craft next" plan for the profession detail page.
-- Uses written skill ranges (orange/yellow/green and switch points). Tailoring
-- is a full Classic Era baseline (Wowhead Classic 1-300) with feed-forward
-- bolt notes; other professions use the same shape where a path is confirmed.
function PC:GetCraftEfficiencyPlan(rec)
  local plan = self:GetProfessionPlan(rec)
  if not plan then
    return nil
  end
  local pack = plan.pack
  local skill = plan.skill or 0
  local out = {
    rec = plan.rec or rec,
    pack = pack,
    skill = skill,
    maxSkill = plan.maxSkill or 0,
    source = pack and pack.source or nil,
    confirmed = pack and (pack.efficiencyConfirmed or pack.id == "tailoring" or (pack.name and string.lower(pack.name) == "tailoring")) or false,
    current = nil,
    upcoming = {},
    save = {},
    needTrain = plan.needTrain,
    rank = plan.rank,
  }
  if pack and type(pack.save) == "table" then
    for i = 1, #pack.save do
      out.save[#out.save + 1] = pack.save[i]
    end
  end
  if not pack or type(pack.steps) ~= "table" then
    out.note = "No written efficiency path for this profession yet."
    return out
  end

  local step, index = self:GetProfessionStep(pack, skill)
  if not step then
    out.note = "No next recipe is written for this skill."
    return out
  end

  local nextStep = pack.steps[index + 1]
  local color = self:ProfessionColor(skill, step)
  local untilYellow = self:ProfessionCraftsUntil(skill, step.yellow)
  local untilGreen = self:ProfessionCraftsUntil(skill, step.green)
  local untilSwitch = self:ProfessionCraftsUntil(skill, step.to or step.switchAt)
  local switchAt = step.switchAt or step.to
  local switchTo = nextStep and nextStep.recipe or nil
  local why = step.why or step.note
  if not why or why == "" then
    if color == "orange" then
      why = "This is orange, so each craft is a guaranteed skill-up."
    elseif color == "yellow" then
      why = "This is yellow. Keep crafting until the switch point, then move on so you waste fewer mats."
    elseif color == "green" then
      why = "This is green. Switch as soon as the next recipe is available."
    end
  end
  local mats = plan.mats or {}
  -- Cheapness is a simple per-craft material count; labeled as a guide, not a price.
  local matCost = 0
  for i = 1, #mats do
    matCost = matCost + (mats[i].perCraft or mats[i].count or 0)
  end
  local headline = "Craft " .. (step.recipe or "the next recipe")
  local lines = {}
  if untilSwitch and untilSwitch > 0 then
    lines[#lines + 1] = "About " .. tostring(untilSwitch) .. " to skill " .. tostring(switchAt or step.to)
  end
  if untilYellow and untilYellow > 0 and (not untilSwitch or untilYellow < untilSwitch) then
    lines[#lines + 1] = "Turns yellow in about " .. tostring(untilYellow) .. " crafts"
  elseif color == "yellow" then
    lines[#lines + 1] = "Already yellow"
  elseif color == "green" then
    lines[#lines + 1] = "Already green"
  elseif color == "orange" then
    lines[#lines + 1] = "Orange now (guaranteed skill-ups)"
  end
  if untilGreen and untilGreen > 0 and color ~= "green" then
    lines[#lines + 1] = "Turns green in about " .. tostring(untilGreen)
  end
  if switchTo and switchAt then
    lines[#lines + 1] = "Switch to " .. switchTo .. " at " .. tostring(switchAt)
  end
  if step.feeds then
    lines[#lines + 1] = step.feeds
  end
  out.current = {
    recipe = step.recipe,
    from = step.from,
    to = step.to,
    color = color,
    untilYellow = untilYellow,
    untilGreen = untilGreen,
    untilSwitch = untilSwitch,
    switchAt = switchAt,
    switchTo = switchTo,
    why = why,
    feeds = step.feeds,
    crafts = untilSwitch or plan.crafts,
    mats = mats,
    matCost = matCost,
    headline = headline,
    detail = table.concat(lines, "  ·  "),
    step = step,
    index = index,
  }
  -- Upcoming ranges (next 3 written steps).
  local last = index or 1
  for i = last + 1, math.min(#pack.steps, last + 3) do
    local s = pack.steps[i]
    local row = {
      recipe = s.recipe,
      from = s.from,
      to = s.to,
      why = s.why or s.note,
      feeds = s.feeds,
    }
    local range = ""
    if s.from and s.to then
      range = tostring(s.from) .. "–" .. tostring(s.to)
    end
    row.title = (range ~= "" and (range .. "  ·  ") or "") .. (s.recipe or "Next recipe")
    row.detail = s.why or s.note or s.feeds
    out.upcoming[#out.upcoming + 1] = row
  end
  -- Save-for-later notes whose skill window still applies.
  if pack and type(pack.save) == "table" then
    -- already copied
  end
  if step.save then
    -- Per-step reminders first.
    local extra = {}
    extra[#extra + 1] = step.save
    for i = 1, #out.save do
      extra[#extra + 1] = out.save[i]
    end
    out.save = extra
  end
  return out
end

-- 1.23.0: everything between your skill and the next tier (the next trainer
-- rank), as crafts to make, a shopping list, and the trainer visit.
function PC:GetProfessionTierPlan(rec)
  local plan = self:GetProfessionPlan(rec)
  if not plan or not plan.pack then
    return nil
  end
  local pack, skill, maxSkill = plan.pack, plan.skill or 0, plan.maxSkill or 0
  local out = { pack = pack, skill = skill, maxSkill = maxSkill, crafts = {}, shopping = {}, tips = {}, source = pack.source }
  local nextRank, trainNow
  for i = 1, #(pack.ranks or {}) do
    local r = pack.ranks[i]
    if r.trainAt then
      local already = maxSkill > 0 and maxSkill >= (r.cap or 300)
      if not already then
        if skill >= r.trainAt then
          trainNow = trainNow or r
        elseif not nextRank then
          nextRank = r
        end
      end
    end
  end
  local target = nextRank and nextRank.trainAt or ((maxSkill > skill) and maxSkill) or 300
  if trainNow and maxSkill > 0 and skill >= maxSkill then
    -- Capped: the next tier starts after training.
    target = math.min(trainNow.cap or 300, nextRank and nextRank.trainAt or 300)
  end
  out.target, out.nextRank, out.trainNow = target, nextRank, trainNow
  local totals, order = {}, {}
  for i = 1, #(pack.steps or {}) do
    local st = pack.steps[i]
    local lo = math.max(skill, st.from or 0)
    local hi = math.min(target, st.to or 0)
    if hi > lo then
      local n = hi - lo
      local mats = {}
      for j = 1, #(st.mats or {}) do
        local m = st.mats[j]
        mats[#mats + 1] = { id = m.id, name = m.name, per = m.count or 1 }
        local key = m.id or m.name
        if not totals[key] then
          totals[key] = { id = m.id, name = m.name, need = 0 }
          order[#order + 1] = key
        end
        totals[key].need = totals[key].need + (m.count or 1) * n
      end
      out.crafts[#out.crafts + 1] = { recipe = st.recipe, from = lo, to = hi, count = n, mats = mats, note = st.note, gather = (#(st.mats or {}) == 0) }
    end
  end
  for i = 1, #order do
    local t = totals[order[i]]
    t.have = self:CountProfessionMat(t, true)
    t.short = t.have < t.need
    t.source = self:GetMatSource(t, pack)
    out.shopping[#out.shopping + 1] = t
  end
  for i = 1, #(pack.save or {}) do
    out.tips[#out.tips + 1] = pack.save[i]
  end
  return out
end
