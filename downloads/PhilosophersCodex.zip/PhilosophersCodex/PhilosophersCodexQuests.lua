-- Philosopher's Codex: zone quest lists, chain trees, and quest-log status.
-- Bundled Alliance 1-30 data is used first. When Questie Forever is loaded,
-- its QuestieDB is read (guarded) to fill missing coordinates or names.

local PC = PhilosophersCodex

PC.QUEST_LEVEL_SLACK = 2 -- pick up a quest whose min level is at most +2
PC.QUEST_GRAY_GAP = 6    -- gray when the quest level is this far below the player

local questieUnavailableLogged = false
local coverageLogged = false
local cache

local function Lower(s)
  if type(s) ~= "string" then
    return ""
  end
  return string.lower(s)
end

local function CopyQuest(q)
  local t = {}
  for k, v in pairs(q) do
    t[k] = v
  end
  return t
end

function PC:InvalidateQuestCache()
  cache = nil
end

function PC:CanonicalZoneName(name)
  if type(name) ~= "string" or name == "" then
    return nil
  end
  local data = PhilosophersCodexData
  local zones = data and data.ZONE_QUESTS
  if type(zones) == "table" and zones[name] then
    return name
  end
  local aliases = data and data.ZONE_QUEST_ALIASES
  if type(aliases) == "table" and aliases[name] then
    return aliases[name]
  end
  local needle = Lower(name)
  if type(aliases) == "table" then
    for k, v in pairs(aliases) do
      if Lower(k) == needle then
        return v
      end
    end
  end
  if type(zones) == "table" then
    for k in pairs(zones) do
      if Lower(k) == needle then
        return k
      end
    end
  end
  return name
end

function PC:GetZoneQuestData(zoneName)
  local canon = self:CanonicalZoneName(zoneName)
  local zones = PhilosophersCodexData and PhilosophersCodexData.ZONE_QUESTS
  if type(zones) ~= "table" or not canon then
    return nil, canon
  end
  return zones[canon], canon
end

-- ---------------------------------------------------------------------------
-- Questie Forever, when the addon is present. Every call is pcall'd.
-- ---------------------------------------------------------------------------

function PC:GetQuestieDB()
  if type(QuestieDB) == "table" then
    return QuestieDB
  end
  if type(QuestieLoader) == "table" and type(QuestieLoader.ImportModule) == "function" then
    local ok, db = pcall(QuestieLoader.ImportModule, QuestieLoader, "QuestieDB")
    if ok and type(db) == "table" then
      return db
    end
  end
  if type(Questie) == "table" and type(Questie.db) == "table" and type(Questie.db.char) == "table" then
    -- Not the quest database itself; ignore.
  end
  return nil
end

function PC:HasQuestieDB()
  return self:GetQuestieDB() ~= nil
end

function PC:LookupQuestieQuest(questID)
  questID = tonumber(questID)
  if not questID then
    return nil
  end
  local db = self:GetQuestieDB()
  if not db then
    return nil
  end
  if type(db.GetQuest) == "function" then
    local ok, q = pcall(db.GetQuest, db, questID)
    if ok and type(q) == "table" then
      return q
    end
  end
  if type(db.QueryQuest) == "function" then
    local ok, q = pcall(db.QueryQuest, db, questID)
    if ok and type(q) == "table" then
      return q
    end
  end
  if type(db.QueryQuestSingle) == "function" then
    local function field(key)
      local ok, v = pcall(db.QueryQuestSingle, db, questID, key)
      if ok then
        return v
      end
      return nil
    end
    local name = field("name")
    if name then
      return {
        name = name,
        requiredLevel = field("requiredLevel"),
        questLevel = field("questLevel"),
        preQuestSingle = field("preQuestSingle"),
        preQuestGroup = field("preQuestGroup"),
        nextQuestInChain = field("nextQuestInChain"),
        childQuests = field("childQuests"),
        requiredRaces = field("requiredRaces"),
        requiredClasses = field("requiredClasses"),
        startedBy = field("startedBy"),
        zoneOrSort = field("zoneOrSort"),
      }
    end
  end
  return nil
end

-- ---------------------------------------------------------------------------
-- Quest log / completion. Complements IsQuestFlaggedComplete / IsQuestInLog.
-- ---------------------------------------------------------------------------

function PC:IsQuestFlaggedCompleteAny(questID)
  questID = tonumber(questID)
  if not questID then
    return false
  end
  if self.IsQuestFlaggedComplete and self:IsQuestFlaggedComplete(questID) then
    return true
  end
  if GetQuestsCompleted then
    local ok, completed = pcall(GetQuestsCompleted)
    if ok and type(completed) == "table" and completed[questID] then
      return true
    end
  end
  return false
end

function PC:IsQuestInLogAny(questID, questName)
  questID = tonumber(questID)
  if questID and C_QuestLog and C_QuestLog.GetLogIndexForQuestID then
    local ok, index = pcall(C_QuestLog.GetLogIndexForQuestID, questID)
    if ok and index and tonumber(index) and tonumber(index) > 0 then
      return true
    end
  end
  if self.IsQuestInLog then
    return self:IsQuestInLog(questID, questName)
  end
  return false
end

-- ---------------------------------------------------------------------------
-- Availability filters
-- ---------------------------------------------------------------------------

function PC:PlayerFactionName()
  if UnitFactionGroup then
    local ok, name = pcall(UnitFactionGroup, "player")
    if ok and type(name) == "string" and name ~= "" then
      return name
    end
  end
  return "Alliance"
end

local ALLIANCE_RACE_BITS = 1 + 4 + 8 + 64 -- Human, Dwarf, Night Elf, Gnome
local HORDE_RACE_BITS = 2 + 16 + 32 + 128 -- Orc, Undead, Tauren, Troll
local RACE_BITS = {
  Human = 1, Orc = 2, Dwarf = 4, NightElf = 8, Scourge = 16, Undead = 16,
  Tauren = 32, Gnome = 64, Troll = 128,
}
local CLASS_BITS = {
  WARRIOR = 1, PALADIN = 2, HUNTER = 4, ROGUE = 8, PRIEST = 16,
  SHAMAN = 64, MAGE = 128, WARLOCK = 256, DRUID = 1024,
}

local function BitOn(mask, bit)
  mask = tonumber(mask)
  bit = tonumber(bit)
  if not mask or not bit then
    return false
  end
  -- Lua 5.1 has no native bitwise ops; emulate AND.
  local a, b = mask, bit
  if a < 0 then
    a = 0
  end
  local result = 0
  local n = 1
  while a > 0 and b > 0 do
    local abit = a % 2
    local bbit = b % 2
    if abit == 1 and bbit == 1 then
      result = result + n
    end
    a = math.floor(a / 2)
    b = math.floor(b / 2)
    n = n * 2
  end
  return result ~= 0
end

function PC:QuestFactionOk(quest, faction)
  if not quest then
    return false
  end
  faction = faction or self:PlayerFactionName()
  local f = quest.faction
  if type(f) == "string" and f ~= "" and Lower(f) ~= "both" and Lower(f) ~= "neutral" then
    return Lower(f) == Lower(faction)
  end
  local mask = tonumber(quest.requiredRaces)
  if mask and mask > 0 then
    if Lower(faction) == "alliance" then
      return BitOn(mask, ALLIANCE_RACE_BITS) or BitOn(mask, 1) or BitOn(mask, 4) or BitOn(mask, 8) or BitOn(mask, 64)
    end
    if Lower(faction) == "horde" then
      return BitOn(mask, HORDE_RACE_BITS) or BitOn(mask, 2) or BitOn(mask, 16) or BitOn(mask, 32) or BitOn(mask, 128)
    end
  end
  return true
end

function PC:QuestRaceClassOk(quest)
  if not quest then
    return false
  end
  local race = self.GetRaceFile and self:GetRaceFile() or nil
  local classFile = self.GetClassFile and self:GetClassFile() or nil
  if quest.race then
    local ok = false
    if type(quest.race) == "string" then
      ok = Lower(quest.race) == Lower(race or "")
    elseif type(quest.race) == "table" then
      for i = 1, #quest.race do
        if Lower(quest.race[i]) == Lower(race or "") then
          ok = true
          break
        end
      end
    end
    if not ok then
      return false
    end
  end
  if quest.class then
    local ok = false
    if type(quest.class) == "string" then
      ok = Lower(quest.class) == Lower(classFile or "")
    elseif type(quest.class) == "table" then
      for i = 1, #quest.class do
        if Lower(quest.class[i]) == Lower(classFile or "") then
          ok = true
          break
        end
      end
    end
    if not ok then
      return false
    end
  end
  local raceMask = tonumber(quest.requiredRaces)
  if raceMask and raceMask > 0 and race and RACE_BITS[race] then
    if not BitOn(raceMask, RACE_BITS[race]) then
      return false
    end
  end
  local classMask = tonumber(quest.requiredClasses)
  if classMask and classMask > 0 and classFile and CLASS_BITS[classFile] then
    if not BitOn(classMask, CLASS_BITS[classFile]) then
      return false
    end
  end
  return true
end

function PC:QuestPrereqsMet(quest)
  if not quest then
    return false
  end
  local function done(id)
    return self:IsQuestFlaggedCompleteAny(id)
  end
  if quest.prev then
    if type(quest.prev) == "table" then
      for i = 1, #quest.prev do
        if not done(quest.prev[i]) then
          return false
        end
      end
    elseif not done(quest.prev) then
      return false
    end
  end
  if quest.pre then
    if type(quest.pre) == "table" then
      for i = 1, #quest.pre do
        if not done(quest.pre[i]) then
          return false
        end
      end
    elseif not done(quest.pre) then
      return false
    end
  end
  if type(quest.preQuestSingle) == "table" then
    -- Any one of the listed prereqs is enough.
    if #quest.preQuestSingle > 0 then
      local any = false
      for i = 1, #quest.preQuestSingle do
        if done(quest.preQuestSingle[i]) then
          any = true
          break
        end
      end
      if not any then
        return false
      end
    end
  end
  if type(quest.preQuestGroup) == "table" then
    for i = 1, #quest.preQuestGroup do
      if not done(quest.preQuestGroup[i]) then
        return false
      end
    end
  end
  return true
end

function PC:IsGrayQuest(quest, level)
  if not quest then
    return false
  end
  level = tonumber(level) or self:PlayerLevel() or 1
  local qLevel = tonumber(quest.level) or tonumber(quest.minLevel) or level
  local gap = self.QUEST_GRAY_GAP or 6
  return (level - qLevel) >= gap
end

function PC:IsHideGrayQuests()
  local db = self.GetDB and self:GetDB() or nil
  if not db then
    return true
  end
  return db.hideGrayQuests ~= false
end

function PC:SetHideGrayQuests(hide)
  local db = self.GetDB and self:GetDB() or nil
  if db then
    db.hideGrayQuests = hide and true or false
  end
  self:InvalidateQuestCache()
  if self.Refresh then
    self:Refresh()
  end
end

function PC:QuestMeetsLevel(quest, level)
  if not quest then
    return false
  end
  level = tonumber(level) or self:PlayerLevel() or 1
  local minL = tonumber(quest.minLevel) or 1
  local slack = self.QUEST_LEVEL_SLACK or 2
  return minL <= level + slack
end

function PC:GetZoneQuestStatus(quest, level)
  if not quest then
    return "ineligible"
  end
  level = tonumber(level) or self:PlayerLevel() or 1
  if not self:QuestFactionOk(quest) or not self:QuestRaceClassOk(quest) then
    return "ineligible"
  end
  if self:IsQuestFlaggedCompleteAny(quest.questID) then
    return "complete"
  end
  if self:IsQuestInLogAny(quest.questID, quest.name) then
    return "log"
  end
  if not self:QuestMeetsLevel(quest, level) then
    return "locked"
  end
  if not self:QuestPrereqsMet(quest) then
    return "locked"
  end
  if self:IsGrayQuest(quest, level) then
    return "gray"
  end
  return "available"
end

-- ---------------------------------------------------------------------------
-- Tree building
-- ---------------------------------------------------------------------------

function PC:GetZoneQuestChains(zoneName)
  local data = self:GetZoneQuestData(zoneName)
  if not data or type(data.chains) ~= "table" then
    return {}, data
  end
  local chains = {}
  for i = 1, #data.chains do
    local c = data.chains[i]
    if type(c) == "table" and type(c.quests) == "table" then
      local quests = {}
      for j = 1, #c.quests do
        local q = c.quests[j]
        if type(q) == "table" then
          local copy = CopyQuest(q)
          -- Enrich from Questie when a name or pin is missing.
          if (not copy.x or not copy.giver) and copy.questID then
            local qe = self:LookupQuestieQuest(copy.questID)
            if type(qe) == "table" then
              if (not copy.name or copy.name == "") and qe.name then
                copy.name = qe.name
              end
              if not copy.minLevel and qe.requiredLevel then
                copy.minLevel = qe.requiredLevel
              end
              if not copy.level and qe.questLevel then
                copy.level = qe.questLevel
              end
              if not copy.next and qe.nextQuestInChain then
                copy.next = qe.nextQuestInChain
              end
            end
          end
          quests[#quests + 1] = copy
        end
      end
      chains[#chains + 1] = {
        id = c.id or ("chain-" .. tostring(i)),
        name = c.name or (quests[1] and quests[1].name) or "Quest chain",
        quests = quests,
      }
    end
  end
  return chains, data
end

function PC:GetZoneQuestTrees(zoneName, level)
  level = tonumber(level) or self:PlayerLevel() or 1
  local key = tostring(self:CanonicalZoneName(zoneName) or "") .. ":" .. tostring(level) .. ":" .. tostring(self:IsHideGrayQuests())
  -- Status depends on the quest log, so the cache is only for one build
  -- pass; events clear it.
  if cache and cache.key == key and cache.trees then
    return cache.trees, cache.summary
  end
  local chains = self:GetZoneQuestChains(zoneName)
  local hideGray = self:IsHideGrayQuests()
  local trees = {}
  local summary = { available = 0, log = 0, done = 0, total = 0, gray = 0 }
  for i = 1, #chains do
    local chain = chains[i]
    local parentQ = chain.quests[1]
    local children = {}
    local visibleChildren = {}
    local doneCount, total = 0, #chain.quests
    local anyVisible = false
    local statuses = {}
    for j = 1, #chain.quests do
      local q = chain.quests[j]
      local st = self:GetZoneQuestStatus(q, level)
      statuses[j] = st
      if st == "complete" then
        doneCount = doneCount + 1
        summary.done = summary.done + 1
      elseif st == "log" then
        summary.log = summary.log + 1
      elseif st == "available" then
        summary.available = summary.available + 1
      elseif st == "gray" then
        summary.gray = summary.gray + 1
      end
      summary.total = summary.total + 1
      q._status = st
      if j > 1 then
        children[#children + 1] = q
      end
    end
    local function visibleStatus(st)
      if st == "complete" then
        return false
      end
      if st == "ineligible" or st == "locked" then
        return false
      end
      if st == "gray" and hideGray then
        return false
      end
      return st == "available" or st == "log" or (st == "gray" and not hideGray)
    end
    for j = 2, #chain.quests do
      if visibleStatus(statuses[j]) then
        visibleChildren[#visibleChildren + 1] = chain.quests[j]
        anyVisible = true
      end
    end
    local parentVisible = parentQ and visibleStatus(statuses[1])
    local allDone = total > 0 and doneCount == total
    if parentVisible or anyVisible then
      trees[#trees + 1] = {
        id = chain.id,
        name = chain.name,
        parent = parentQ,
        parentStatus = statuses[1],
        children = visibleChildren,
        allChildren = children,
        done = doneCount,
        total = total,
        allDone = allDone,
        parentVisible = parentVisible,
      }
    elseif allDone then
      trees[#trees + 1] = {
        id = chain.id,
        name = chain.name,
        parent = parentQ,
        parentStatus = "complete",
        children = {},
        allChildren = children,
        done = doneCount,
        total = total,
        allDone = true,
        parentVisible = false,
        hiddenDone = true,
      }
    end
  end
  cache = { key = key, trees = trees, summary = summary }
  return trees, summary
end

function PC:GetZoneQuestSummary(zoneName, level)
  local _, summary = self:GetZoneQuestTrees(zoneName, level)
  return summary or { available = 0, log = 0, done = 0, total = 0, gray = 0 }
end

function PC:GetPathZoneSelection()
  local db = self.GetDB and self:GetDB() or nil
  if db and type(db.pathZone) == "string" and db.pathZone ~= "" then
    return self:CanonicalZoneName(db.pathZone) or db.pathZone
  end
  local current = self.GetCurrentZoneName and self:GetCurrentZoneName() or nil
  if current then
    local canon = self:CanonicalZoneName(current)
    if self:GetZoneQuestData(canon or current) then
      return canon or current
    end
  end
  local rec = self.GetRecommendedZone and self:GetRecommendedZone() or nil
  if rec and rec.name then
    return self:CanonicalZoneName(rec.name) or rec.name
  end
  if current then
    return self:CanonicalZoneName(current) or current
  end
  return nil
end

function PC:SetPathZoneSelection(zoneName)
  local db = self.GetDB and self:GetDB() or nil
  if db then
    db.pathZone = zoneName
  end
  if self.Refresh then
    self:Refresh()
  end
end

function PC:PathZoneDefaultOpen(zoneName)
  -- Zones start collapsed so leaving the tab and coming back is tidy.
  -- "You are here" still highlights the current zone; tap to expand it.
  return false
end

function PC:IsPathZoneExpanded(zoneName)
  local key = "path-quests:" .. tostring(self:CanonicalZoneName(zoneName) or zoneName or "")
  local defaultOn = self:PathZoneDefaultOpen(zoneName)
  if self.IsExpanded then
    return self:IsExpanded(key, defaultOn)
  end
  return defaultOn
end

function PC:TogglePathZoneQuests(zoneName)
  local key = "path-quests:" .. tostring(self:CanonicalZoneName(zoneName) or zoneName or "")
  local was = self:IsPathZoneExpanded(zoneName)
  local defaultOn = self:PathZoneDefaultOpen(zoneName)
  local db = self.GetDB and self:GetDB() or nil
  if db and not was then
    db.pathZone = self:CanonicalZoneName(zoneName) or zoneName
  end
  if self.ToggleExpanded then
    self:ToggleExpanded(key, defaultOn)
  end
end

function PC:OnZoneQuestEvent(event, arg1, arg2)
  self:InvalidateQuestCache()
  if event == "QUEST_ACCEPTED" or event == "QUEST_TURNED_IN" or event == "QUEST_REMOVED" or event == "QUEST_LOG_UPDATE" then
    if self.Refresh then
      -- The core event handler already throttles QUEST_LOG_UPDATE; this
      -- is a cheap invalidate so the next refresh sees fresh status.
    end
  end
end

-- Faction-home zones the other faction never quests in; not "missing" data.
local FACTION_HOME_ZONES = {
  Alliance = {
    ["Tirisfal Glades"] = true, ["Durotar"] = true, ["Mulgore"] = true, ["The Barrens"] = true,
    ["Silverpine Forest"] = true, ["Orgrimmar"] = true, ["Thunder Bluff"] = true, ["Undercity"] = true,
  },
  Horde = {
    ["Elwynn Forest"] = true, ["Dun Morogh"] = true, ["Teldrassil"] = true, ["Westfall"] = true,
    ["Loch Modan"] = true, ["Darkshore"] = true, ["Stormwind City"] = true, ["Ironforge"] = true, ["Darnassus"] = true,
  },
}

local function SkipForFaction(name)
  if not UnitFactionGroup then
    return false
  end
  local ok, faction = pcall(UnitFactionGroup, "player")
  local set = ok and FACTION_HOME_ZONES[faction or ""]
  return set and name and set[name] and true or false
end

function PC:AuditZoneQuestCoverage()
  if coverageLogged then
    return
  end
  coverageLogged = true
  local expected = PhilosophersCodexData and PhilosophersCodexData.ZONE_QUEST_EXPECTED
  if type(expected) ~= "table" then
    return
  end
  local hasQuestie = self:HasQuestieDB()
  if not hasQuestie and not questieUnavailableLogged then
    questieUnavailableLogged = true
  end
  for i = 1, #expected do
    local name = expected[i]
    local data = self:GetZoneQuestData(name)
    local count = 0
    if data and type(data.chains) == "table" then
      for c = 1, #data.chains do
        local quests = data.chains[c] and data.chains[c].quests
        if type(quests) == "table" then
          count = count + #quests
        end
      end
    end
    if count == 0 and not SkipForFaction(name) then
      local msg = "No bundled quests for " .. tostring(name)
      if not hasQuestie then
        msg = msg .. " (Questie Forever is not loaded)"
      end
      if self.LogMissing then
        self:LogMissing("zone-quests", name, msg)
      end
    end
  end
  -- Also flag path-list zones outside the bundled 1-30 set.
  local data = self.GetClassData and self:GetClassData() or nil
  if data and type(data.brackets) == "table" then
    local seen = {}
    for i = 1, #data.brackets do
      local zones = data.brackets[i].zones or {}
      for z = 1, #zones do
        local name = zones[z]
        local canon = self:CanonicalZoneName(name) or name
        if not seen[canon] then
          seen[canon] = true
          local zdata, _ = self:GetZoneQuestData(canon)
          local count = 0
          if zdata and type(zdata.chains) == "table" then
            for c = 1, #zdata.chains do
              local quests = zdata.chains[c] and zdata.chains[c].quests
              if type(quests) == "table" then
                count = count + #quests
              end
            end
          end
          if count == 0 and not SkipForFaction(canon) then
            if self.LogMissing then
              self:LogMissing("zone-quests", canon, "Path zone has no quest list yet: " .. tostring(canon))
            end
          end
        end
      end
    end
  end
end

local zoneQuestIndex

local function BuildZoneQuestIndex()
  local index = {}
  local zones = PhilosophersCodexData and PhilosophersCodexData.ZONE_QUESTS
  if type(zones) ~= "table" then
    return index
  end
  for zoneName, data in pairs(zones) do
    local chains = data and data.chains
    if type(chains) == "table" then
      for i = 1, #chains do
        local quests = chains[i] and chains[i].quests
        if type(quests) == "table" then
          for j = 1, #quests do
            local q = quests[j]
            local id = q and tonumber(q.questID)
            if id and not index[id] then
              if not q.zone then
                q.zone = zoneName
              end
              index[id] = q
            end
          end
        end
      end
    end
  end
  return index
end

function PC:FindZoneQuest(questID)
  questID = tonumber(questID)
  if not questID then
    return nil
  end
  if not zoneQuestIndex then
    zoneQuestIndex = BuildZoneQuestIndex()
  end
  return zoneQuestIndex[questID]
end

function PC:GetQuestWaypoint(quest)
  if not quest then
    return nil
  end
  if quest.uiMapID and quest.x and quest.y then
    return {
      uiMapID = quest.uiMapID,
      x = quest.x,
      y = quest.y,
      title = quest.name or quest.giver or "Quest",
    }
  end
  return nil
end
