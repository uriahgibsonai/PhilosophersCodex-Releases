-- Philosopher's Codex: smart upgrade alerts. Weights, usable armor, and
-- weapons come from the active class module. All item APIs are guarded.

local PC = PhilosophersCodex

local DEFAULT_WEIGHTS = {
  heal = {
    healing = 10,
    spellpower = 8,
    spelldamage = 1,
    intellect = 4,
    spirit = 3,
    mp5 = 4,
    crit = 3,
    stamina = 1,
    armor = 0.05,
  },
  balance = {
    healing = 0,
    spellpower = 10,
    spelldamage = 10,
    intellect = 5,
    spirit = 2,
    mp5 = 1,
    crit = 4,
    stamina = 1,
    armor = 0,
  },
}

-- Inventory type -> equipment slot ids (1-based, classic/mainline layout).
local EQUIP_SLOTS = {
  INVTYPE_HEAD = { 1 },
  INVTYPE_NECK = { 2 },
  INVTYPE_SHOULDER = { 3 },
  INVTYPE_BODY = { 4 },
  INVTYPE_CHEST = { 5 },
  INVTYPE_ROBE = { 5 },
  INVTYPE_WAIST = { 6 },
  INVTYPE_LEGS = { 7 },
  INVTYPE_FEET = { 8 },
  INVTYPE_WRIST = { 9 },
  INVTYPE_HAND = { 10 },
  INVTYPE_FINGER = { 11, 12 },
  INVTYPE_TRINKET = { 13, 14 },
  INVTYPE_CLOAK = { 15 },
  INVTYPE_WEAPON = { 16 },
  INVTYPE_2HWEAPON = { 16 },
  INVTYPE_WEAPONMAINHAND = { 16 },
  INVTYPE_WEAPONOFFHAND = { 17 },
  INVTYPE_HOLDABLE = { 17 },
  INVTYPE_SHIELD = { 17 },
  INVTYPE_RANGED = { 18 },
  INVTYPE_RANGEDRIGHT = { 18 },
  INVTYPE_RELIC = { 18 },
}

-- Weapon class 2 subclasses a druid can use; armor class 4, cloth/leather only.
local ALLOWED_WEAPON = {
  [4] = true,  -- 1H mace
  [5] = true,  -- 2H mace
  [6] = true,  -- polearm
  [10] = true, -- staff
  [13] = true, -- fist
  [15] = true, -- dagger
}
local ALLOWED_ARMOR = {
  [0] = true, -- misc / held-in-off-hand
  [1] = true, -- cloth
  [2] = true, -- leather
}

local bagSnapshot = nil
local alerted = {}
local scanTip
local scanning = false
local statCache = {}
local STAT_CACHE_MAX = 64

local function Now()
  if GetTime then
    return GetTime()
  end
  return (time and time()) or 0
end

local function ItemIDFromLink(link)
  if type(link) ~= "string" then
    return nil
  end
  return tonumber(string.match(link, "item:(%d+)"))
end

local function GetInfo(idOrLink)
  if not idOrLink then
    return nil
  end
  local ok, name, link, rarity, level, minLevel, itype, subtype, stack, equipLoc, icon, _, classID, subID
  if GetItemInfo then
    ok, name, link, rarity, level, minLevel, itype, subtype, stack, equipLoc, icon, _, classID, subID = pcall(GetItemInfo, idOrLink)
    if ok and name then
      return {
        name = name,
        link = link,
        rarity = rarity,
        itemLevel = level,
        minLevel = minLevel,
        type = itype,
        subType = subtype,
        equipLoc = equipLoc,
        icon = icon,
        classID = classID,
        subClassID = subID,
        itemID = ItemIDFromLink(link) or tonumber(idOrLink),
      }
    end
  end
  if GetItemInfoInstant then
    local ok2, itemID, itype2, subtype2, loc, icon2, cid, sid = pcall(GetItemInfoInstant, idOrLink)
    if ok2 and itemID then
      return {
        name = nil,
        link = type(idOrLink) == "string" and idOrLink or nil,
        minLevel = nil,
        type = itype2,
        subType = subtype2,
        equipLoc = loc,
        icon = icon2,
        classID = cid,
        subClassID = sid,
        itemID = itemID,
      }
    end
  end
  if C_Item and C_Item.GetItemInfoInstant then
    local ok3, itemID, itype3, subtype3, loc, icon3, cid, sid = pcall(C_Item.GetItemInfoInstant, idOrLink)
    if ok3 and itemID then
      return {
        equipLoc = loc,
        icon = icon3,
        classID = cid,
        subClassID = sid,
        itemID = itemID,
        type = itype3,
        subType = subtype3,
      }
    end
  end
  return nil
end

local function AddStat(stats, key, value)
  value = tonumber(value) or 0
  if value == 0 or not key then
    return
  end
  stats[key] = (stats[key] or 0) + value
end

local function IngestStatKey(stats, rawKey, value)
  value = tonumber(value) or 0
  if value == 0 or rawKey == nil then
    return
  end
  local k = string.upper(tostring(rawKey))
  k = string.gsub(k, "^ITEM_MOD_", "")
  k = string.gsub(k, "_SHORT$", "")
  k = string.gsub(k, "_NAME$", "")
  k = string.gsub(k, " ", "_")
  -- 1.24.0: physical stats for Hunter, Shaman and other melee or ranged classes.
  if string.find(k, "ATTACK_POWER", 1, true) or k == "AP" then
    AddStat(stats, "attackpower", value)
    return
  elseif string.find(k, "AGILITY", 1, true) or k == "AGI" then
    AddStat(stats, "agility", value)
    return
  elseif string.find(k, "STRENGTH", 1, true) or k == "STR" then
    AddStat(stats, "strength", value)
    return
  elseif k == "HIT_RATING" or k == "HIT" or k == "HIT_MELEE_RATING" then
    AddStat(stats, "hit", value)
    return
  end
  if string.find(k, "HEALING", 1, true) or k == "SPELL_HEALING_DONE" or k == "SPELLHEALINGDONE" then
    AddStat(stats, "healing", value)
  elseif string.find(k, "SPELL_POWER", 1, true) or k == "SPELLPOWER" or k == "SPELL_PWR" then
    AddStat(stats, "spellpower", value)
  elseif string.find(k, "SPELL_DAMAGE", 1, true) or string.find(k, "SPELL_DMG", 1, true) or k == "SPELLDAMAGE" then
    AddStat(stats, "spelldamage", value)
  elseif string.find(k, "INTELLECT", 1, true) or k == "INT" then
    AddStat(stats, "intellect", value)
  elseif string.find(k, "SPIRIT", 1, true) then
    AddStat(stats, "spirit", value)
  elseif string.find(k, "STAMINA", 1, true) then
    AddStat(stats, "stamina", value)
  elseif string.find(k, "CRIT", 1, true) then
    AddStat(stats, "crit", value)
  elseif string.find(k, "MANA_REGEN", 1, true) or string.find(k, "POWER_REGEN", 1, true) or k == "MP5" then
    AddStat(stats, "mp5", value)
  elseif k == "ARMOR" or k == "RESISTANCE0" or k == "RESISTANCE0_NAME" then
    AddStat(stats, "armor", value)
  elseif string.find(k, "DAMAGE_PER_SECOND", 1, true) or k == "DPS" or k == "WEAPON_DPS" then
    AddStat(stats, "dps", value)
  end
end

local function IngestStatsTable(stats, tbl)
  if type(tbl) ~= "table" then
    return
  end
  for k, v in pairs(tbl) do
    IngestStatKey(stats, k, v)
  end
end

local function ParseTooltipText(stats, text)
  if type(text) ~= "string" or text == "" then
    return
  end
  local n
  n = string.match(text, "[Ii]ncreases healing done by spells and effects by up to (%d+)")
  if n then AddStat(stats, "healing", n) end
  n = string.match(text, "[Ii]ncreases healing done by up to (%d+)")
  if n then AddStat(stats, "healing", n) end
  n = string.match(text, "%+(%d+) Healing Spells")
  if n then AddStat(stats, "healing", n) end
  n = string.match(text, "[Ii]ncreases damage and healing done by magical spells and effects by up to (%d+)")
  if n then
    AddStat(stats, "spellpower", n)
  end
  n = string.match(text, "[Ii]ncreases damage done by magical spells and effects by up to (%d+)")
  if n then AddStat(stats, "spelldamage", n) end
  n = string.match(text, "[Rr]estores (%d+) mana per 5")
  if n then AddStat(stats, "mp5", n) end
  n = string.match(text, "[Rr]estores (%d+) mana every 5")
  if n then AddStat(stats, "mp5", n) end
  n = string.match(text, "%+(%d+) Intellect")
  if n then AddStat(stats, "intellect", n) end
  n = string.match(text, "%+(%d+) Spirit")
  if n then AddStat(stats, "spirit", n) end
  n = string.match(text, "%+(%d+) Stamina")
  if n then AddStat(stats, "stamina", n) end
  n = string.match(text, "%+(%d+) Agility")
  if n then AddStat(stats, "agility", n) end
  n = string.match(text, "%+(%d+) Strength")
  if n then AddStat(stats, "strength", n) end
  n = string.match(text, "%+(%d+) Attack Power") or string.match(text, "[Ii]ncreases attack power by (%d+)") or string.match(text, "%+(%d+) [Rr]anged Attack Power")
  if n then AddStat(stats, "attackpower", n) end
  n = string.match(text, "[Ii]mproves your chance to hit by (%d+)%%")
  if n then AddStat(stats, "hit", n) end
  n = string.match(text, "(%d+%.?%d*)%s*[Dd]amage per second")
  if n then AddStat(stats, "dps", n) end
  local dmin, dmax = string.match(text, "(%d+)%s*%-%s*(%d+)%s+[Dd]amage")
  local speed = string.match(text, "[Ss]peed%s*(%d+%.?%d*)")
  if dmin and dmax and speed and tonumber(speed) and tonumber(speed) > 0 then
    local dps = ((tonumber(dmin) + tonumber(dmax)) / 2) / tonumber(speed)
    if not stats.dps or stats.dps == 0 then
      AddStat(stats, "dps", dps)
    end
  end
end

function PC:IsScanTooltip(tooltip)
  if not tooltip then
    return true
  end
  if scanning then
    return true
  end
  if scanTip and tooltip == scanTip then
    return true
  end
  local name
  if tooltip.GetName then
    local ok, got = pcall(tooltip.GetName, tooltip)
    if ok then
      name = got
    end
  end
  return name == "PhilosophersCodexScanTip"
end

local function EnsureScanTip()
  if scanTip and scanTip.SetHyperlink then
    return scanTip
  end
  if not CreateFrame then
    return nil
  end
  -- Dedicated hidden tip only. Never fall back to GameTooltip — SetHyperlink
  -- on the live tooltip re-enters TooltipDataProcessor / OnTooltipSetItem.
  local ok, tip = pcall(CreateFrame, "GameTooltip", "PhilosophersCodexScanTip", nil, "GameTooltipTemplate")
  if not ok or not tip then
    ok, tip = pcall(CreateFrame, "GameTooltip", "PhilosophersCodexScanTip", nil)
  end
  if not ok or not tip then
    return nil
  end
  local name
  if tip.GetName then
    local okName, got = pcall(tip.GetName, tip)
    if okName then
      name = got
    end
  end
  if tip == GameTooltip or tip == ItemRefTooltip or name == "GameTooltip" or name == "ItemRefTooltip" then
    return nil
  end
  scanTip = tip
  PC.scanTip = tip
  local owner = WorldFrame or UIParent
  if tip.SetOwner and owner then
    pcall(tip.SetOwner, tip, owner, "ANCHOR_NONE")
  end
  return tip
end

local EnsureScanLines

local function ScanItemTooltip(idOrLink, stats)
  local tip = EnsureScanTip()
  if not tip or tip == GameTooltip then
    return
  end
  scanning = true
  local function finish()
    scanning = false
  end
  pcall(function()
  if tip.SetOwner then
    pcall(tip.SetOwner, tip, WorldFrame or UIParent, "ANCHOR_NONE")
  end
  if tip.ClearLines then
    pcall(tip.ClearLines, tip)
  end
  local set = false
  if type(idOrLink) == "string" and tip.SetHyperlink then
    local ok = pcall(tip.SetHyperlink, tip, idOrLink)
    set = ok
  end
  if not set and tip.SetItemByID then
    local id = tonumber(idOrLink) or ItemIDFromLink(idOrLink)
    if id then
      local ok = pcall(tip.SetItemByID, tip, id)
      set = ok
    end
  end
  if not set then
    return
  end
  if EnsureScanLines then
    EnsureScanLines()
  end
  local n = 0
  if tip.NumLines then
    local ok, count = pcall(tip.NumLines, tip)
    if ok and type(count) == "number" then
      n = count
    end
  end
  if n > 40 then
    n = 40
  end
  for i = 1, n do
    local fs = rawget(_G, "PhilosophersCodexScanTipTextLeft" .. i)
    if fs and fs.GetText then
      local ok, text = pcall(fs.GetText, fs)
      if ok then
        ParseTooltipText(stats, text)
      end
    end
  end
  if tip.Hide then
    pcall(tip.Hide, tip)
  end
  end)
  finish()
end

local function CacheKey(idOrLink)
  if type(idOrLink) == "string" and idOrLink ~= "" then
    return idOrLink
  end
  if type(idOrLink) == "number" then
    return "item:" .. tostring(idOrLink)
  end
  return nil
end

local function CollectStats(idOrLink)
  local key = CacheKey(idOrLink)
  if key and statCache[key] then
    return statCache[key]
  end
  local stats = {}
  local raw
  if C_Item and C_Item.GetItemStats then
    local ok, result = pcall(C_Item.GetItemStats, idOrLink)
    if ok then
      raw = result
    end
  end
  if not raw and GetItemStats then
    local ok, result = pcall(GetItemStats, idOrLink)
    if ok then
      raw = result
    end
  end
  IngestStatsTable(stats, raw)
  ScanItemTooltip(idOrLink, stats)
  local infoAfter = GetInfo(idOrLink)
  if infoAfter and (infoAfter.equipLoc == "INVTYPE_RANGEDRIGHT" or infoAfter.equipLoc == "INVTYPE_RANGED" or infoAfter.subClassID == 19) then
    if stats.dps and stats.dps > 0 then
      stats.wanddps = stats.dps
      if infoAfter.subClassID ~= 19 then
        stats.rangeddps = stats.dps
      end
    end
  elseif infoAfter and stats.dps and stats.dps > 0 then
    stats.meleedps = stats.dps
  end
  if key then
    statCache[key] = stats
    local n = 0
    for _ in pairs(statCache) do
      n = n + 1
    end
    if n > STAT_CACHE_MAX then
      statCache = { [key] = stats }
    end
  end
  return stats
end

local function GetWeights(profile)
  local db = PC:GetDB()
  local custom = db and db.upgradeWeights and db.upgradeWeights[profile]
  if type(custom) == "table" then
    return custom
  end
  if PC.GetProfileDef then
    local def = PC:GetProfileDef(profile)
    if def and type(def.weights) == "table" then
      return def.weights
    end
  end
  return DEFAULT_WEIGHTS[profile] or DEFAULT_WEIGHTS.heal or DEFAULT_WEIGHTS.balance or {}
end

local function Score(stats, profile)
  local w = GetWeights(profile)
  local s = 0
  for key, weight in pairs(w) do
    s = s + (stats[key] or 0) * (weight or 0)
  end
  return s
end

local function DeltaParts(newStats, oldStats, profile)
  local w = GetWeights(profile)
  local keys = { "healing", "spellpower", "spelldamage", "intellect", "spirit", "mp5", "crit", "stamina", "wanddps", "agility", "strength", "attackpower", "hit", "rangeddps", "meleedps" }
  local parts = {}
  for i = 1, #keys do
    local key = keys[i]
    if (w[key] or 0) > 0 then
      local d = (newStats[key] or 0) - (oldStats[key] or 0)
      if d > 0 then
        local label = key
        if key == "healing" then label = "healing" end
        if key == "spellpower" then label = "sp" end
        if key == "spelldamage" then label = "spd" end
        if key == "intellect" then label = "int" end
        if key == "spirit" then label = "spi" end
        if key == "stamina" then label = "sta" end
        if key == "agility" then label = "agi" end
        if key == "strength" then label = "str" end
        if key == "attackpower" then label = "ap" end
        if key == "rangeddps" then label = "ranged dps" end
        if key == "meleedps" then label = "weapon dps" end
        parts[#parts + 1] = "+" .. tostring(math.floor(d + 0.5)) .. " " .. label
      end
    end
  end
  return parts
end

local function Percent(newScore, oldScore)
  if not oldScore or oldScore <= 0 then
    if newScore > 0 then
      return 100
    end
    return 0
  end
  return math.floor(((newScore - oldScore) / oldScore) * 100 + 0.5)
end

local function ClassRules()
  return PC.GetClassData and PC:GetClassData() or nil
end

local function DruidCanUse(info)
  if not info then
    return false, "unknown item"
  end
  local data = ClassRules()
  local loc = info.equipLoc
  local allowShields = data and data.allowShields
  local allowWands = data and data.allowWands
  local allowRelics = data and data.allowRelics
  local armor = (data and data.allowedArmor) or ALLOWED_ARMOR
  local weapons = (data and data.allowedWeapons) or ALLOWED_WEAPON
  local strict = data and data.supported and (data.allowedArmor or data.allowedWeapons)
  if loc == "INVTYPE_SHIELD" or (info.classID == 4 and info.subClassID == 6) then
    if not allowShields then
      return false, "this class cannot use shields"
    end
  end
  local plevel = (PC.PlayerLevel and PC:PlayerLevel()) or 1
  if loc == "INVTYPE_WEAPONOFFHAND" and info.classID == 2 then
    if not (data and data.dualWieldAt and plevel >= data.dualWieldAt) then
      return false, (data and data.dualWieldAt) and ("dual wield comes at level " .. data.dualWieldAt) or "this class cannot dual wield"
    end
  end
  if loc == "INVTYPE_RELIC" and not allowRelics then
    return false, "this class cannot use relics"
  end
  -- 1.24.0: wands and bows/guns/crossbows are told apart, so Hunters can
  -- use ranged weapons without casters getting bows.
  local rangedLoc = (loc == "INVTYPE_RANGED" or loc == "INVTYPE_RANGEDRIGHT" or loc == "INVTYPE_THROWN")
  local isWand = (info.classID == 2 and info.subClassID == 19) or (rangedLoc and info.subClassID == nil and allowWands and not (data and data.allowRanged))
  if isWand then
    if not allowWands then
      return false, "this class cannot use a wand"
    end
  elseif rangedLoc then
    if not (data and data.allowRanged) then
      return false, "not a usable ranged weapon for this class"
    end
  end
  if info.classID == 4 and info.subClassID == 3 and data and data.mailAt and plevel < data.mailAt then
    return false, "mail comes at level " .. data.mailAt
  end
  local gate = data and data.armorAt and info.classID == 4 and data.armorAt[info.subClassID]
  if gate and plevel < gate then
    return false, ((info.subClassID == 4) and "plate" or "this armor") .. " comes at level " .. gate
  end
  if strict then
    if info.classID == 4 then
      if info.subClassID == 6 and not allowShields then
        return false, "this class cannot use shields"
      end
      if info.subClassID and armor and not armor[info.subClassID] then
        return false, "armor type this class cannot wear"
      end
    elseif info.classID == 2 and not isWand then
      if info.subClassID and weapons and not weapons[info.subClassID] then
        return false, "weapon this class cannot use"
      end
    end
  end
  -- If class IDs are missing, fall back to equip loc only (jewelry, cloaks, etc.).
  if loc == "" or loc == nil then
    return false, "not equippable"
  end
  if IsEquippableItem then
    local ok, usable = pcall(IsEquippableItem, info.link or info.itemID)
    if ok and usable == false then
      return false, "not equippable"
    end
  end
  if C_Item and C_Item.IsEquippableItem then
    local ok, usable = pcall(C_Item.IsEquippableItem, info.link or info.itemID)
    if ok and usable == false then
      return false, "not equippable"
    end
  end
  return true
end

local function EquippedLink(slot)
  if GetInventoryItemLink then
    local ok, link = pcall(GetInventoryItemLink, "player", slot)
    if ok then
      return link
    end
  end
  return nil
end

-- Balance and Healing profiles score staff/mace stats (healing, spell power,
-- intellect, etc.) only. Weapon DPS is intentionally omitted unless a Feral
-- profile is added later.
local WEAPON_KIND = {
  INVTYPE_2HWEAPON = "2h",
  INVTYPE_WEAPON = "mh",
  INVTYPE_WEAPONMAINHAND = "mh",
  INVTYPE_WEAPONOFFHAND = "oh",
  INVTYPE_HOLDABLE = "oh",
}

local function BagSlotCount(bag)
  if C_Container and C_Container.GetContainerNumSlots then
    return C_Container.GetContainerNumSlots(bag) or 0
  end
  if GetContainerNumSlots then
    return GetContainerNumSlots(bag) or 0
  end
  return 0
end

local function BagItemLink(bag, slot)
  if C_Container and C_Container.GetContainerItemLink then
    return C_Container.GetContainerItemLink(bag, slot)
  end
  if GetContainerItemLink then
    return GetContainerItemLink(bag, slot)
  end
  return nil
end

local function LinkStats(link)
  if not link then
    return {}, 0, nil
  end
  local st = CollectStats(link)
  return st, nil, GetInfo(link)
end

local function SetupFromSlots()
  local mhLink = EquippedLink(16)
  local ohLink = EquippedLink(17)
  local mhInfo = mhLink and GetInfo(mhLink) or nil
  local ohInfo = ohLink and GetInfo(ohLink) or nil
  local mhStats = mhLink and CollectStats(mhLink) or {}
  local ohStats = ohLink and CollectStats(ohLink) or {}
  local kind = "empty"
  if mhInfo and WEAPON_KIND[mhInfo.equipLoc] == "2h" then
    kind = "2h"
  elseif mhLink and ohLink then
    kind = "mh_oh"
  elseif mhLink then
    kind = "mh"
  elseif ohLink then
    kind = "oh"
  end
  return {
    kind = kind,
    mhLink = mhLink,
    ohLink = ohLink,
    mhInfo = mhInfo,
    ohInfo = ohInfo,
    mhStats = mhStats,
    ohStats = ohStats,
  }
end

function PC:GetWeaponSetup()
  return SetupFromSlots()
end

local function BestBagWeapon(kind, profile, excludeID)
  local bestScore, bestLink, bestInfo, bestStats
  for bag = 0, 4 do
    local slots = BagSlotCount(bag)
    for slot = 1, slots do
      local link = BagItemLink(bag, slot)
      if link then
        local info = GetInfo(link)
        if info and WEAPON_KIND[info.equipLoc] == kind and info.itemID ~= excludeID then
          local ok = DruidCanUse(info)
          if ok then
            local st = CollectStats(link)
            local sc = Score(st, profile)
            if bestScore == nil or sc > bestScore then
              bestScore = sc
              bestLink = link
              bestInfo = info
              bestStats = st
            end
          end
        end
      end
    end
  end
  return bestInfo, bestLink, bestStats, bestScore
end

local function ShortWeaponName(info, fallback)
  if info and info.name and info.name ~= "" then
    return info.name
  end
  if info and info.subType and info.subType ~= "" then
    return string.lower(info.subType)
  end
  return fallback or "weapon"
end

local function Result(profile, newScore, oldScore, newStats, oldStats, opts)
  opts = opts or {}
  local pct = Percent(newScore, oldScore)
  local blocked = opts.blocked and true or false
  local upgrade = (not blocked) and newScore > (oldScore or 0) + 0.01
  return {
    profile = profile,
    newScore = newScore,
    oldScore = oldScore or 0,
    pct = pct,
    upgrade = upgrade,
    blocked = blocked,
    blockedReason = opts.blockedReason,
    versus = opts.versus,
    comboName = opts.comboName,
    equippedLink = opts.equippedLink,
    equippedName = opts.equippedName,
    deltas = DeltaParts(newStats or {}, oldStats or {}, profile),
  }
end

local function CompareWeapon(info, stats, profile)
  local setup = SetupFromSlots()
  local candKind = WEAPON_KIND[info.equipLoc]
  local newScore = Score(stats, profile)
  local candName = ShortWeaponName(info, "item")

  if setup.kind == "2h" then
    local twoHScore = Score(setup.mhStats, profile)
    local twoHName = ShortWeaponName(setup.mhInfo, "weapon")
    if candKind == "2h" then
      return Result(profile, newScore, twoHScore, stats, setup.mhStats, {
        versus = "vs your 2H " .. twoHName,
        equippedLink = setup.mhLink,
        equippedName = twoHName,
      })
    end
    if candKind == "mh" then
      local ohInfo, ohLink, ohStats, ohScore = BestBagWeapon("oh", profile, info.itemID)
      local comboScore = newScore
      local comboStats = stats
      local comboName = candName
      if ohScore then
        comboScore = newScore + ohScore
        comboName = candName .. " + " .. ShortWeaponName(ohInfo, "off-hand")
        -- deltas vs the 2H still use the candidate's own stats plus OH
        local combined = {}
        for k, v in pairs(stats) do
          combined[k] = v
        end
        for k, v in pairs(ohStats or {}) do
          combined[k] = (combined[k] or 0) + v
        end
        comboStats = combined
      end
      local versus = "vs your 2H " .. twoHName
      if ohScore then
        versus = comboName .. " vs your 2H " .. twoHName
      end
      return Result(profile, comboScore, twoHScore, comboStats, setup.mhStats, {
        versus = versus,
        comboName = ohScore and comboName or nil,
        equippedLink = setup.mhLink,
        equippedName = twoHName,
      })
    end
    if candKind == "oh" then
      local mhInfo, mhLink, mhStats, mhScore = BestBagWeapon("mh", profile, info.itemID)
      if not mhScore then
        return Result(profile, 0, twoHScore, stats, setup.mhStats, {
          blocked = true,
          blockedReason = "Off-hand: needs a 1H main-hand (you're using a 2H). Not an upgrade alone.",
          versus = "Off-hand: needs a 1H main-hand (you're using a 2H)",
          equippedLink = setup.mhLink,
          equippedName = twoHName,
        })
      end
      local comboName = ShortWeaponName(mhInfo, "main-hand") .. " + " .. candName
      local combined = {}
      for k, v in pairs(mhStats or {}) do
        combined[k] = v
      end
      for k, v in pairs(stats) do
        combined[k] = (combined[k] or 0) + v
      end
      local comboScore = mhScore + newScore
      return Result(profile, comboScore, twoHScore, combined, setup.mhStats, {
        versus = comboName .. " vs your 2H " .. twoHName,
        comboName = comboName,
        equippedLink = setup.mhLink,
        equippedName = twoHName,
      })
    end
  end

  -- Wearing MH+OH, MH only, OH only, or empty.
  local mhScore = setup.mhLink and Score(setup.mhStats, profile) or 0
  local ohScore = setup.ohLink and Score(setup.ohStats, profile) or 0
  if candKind == "2h" then
    local oldScore = mhScore + ohScore
    local oldStats = {}
    for k, v in pairs(setup.mhStats or {}) do
      oldStats[k] = v
    end
    for k, v in pairs(setup.ohStats or {}) do
      oldStats[k] = (oldStats[k] or 0) + v
    end
    local versus
    if setup.mhLink and setup.ohLink then
      versus = "vs your main-hand + off-hand"
    elseif setup.kind == "2h" then
      versus = "vs your 2H " .. ShortWeaponName(setup.mhInfo, "weapon")
    elseif setup.mhLink then
      versus = "vs your main-hand"
    else
      versus = "vs empty hands"
    end
    return Result(profile, newScore, oldScore, stats, oldStats, {
      versus = versus,
      equippedLink = setup.mhLink,
      equippedName = setup.mhInfo and setup.mhInfo.name or "equipped weapons",
    })
  end
  if candKind == "mh" then
    return Result(profile, newScore, mhScore, stats, setup.mhStats, {
      versus = setup.mhLink and ("vs your main-hand") or "vs empty main-hand",
      equippedLink = setup.mhLink,
      equippedName = setup.mhInfo and setup.mhInfo.name or "empty slot",
    })
  end
  if candKind == "oh" then
    -- An off-hand is only usable with a 1H main-hand, not a 2H (handled above).
    if setup.kind == "empty" or (not setup.mhLink) then
      -- No main-hand equipped and not a 2H; still need a MH to use an OH.
      local mhInfo = BestBagWeapon("mh", profile, info.itemID)
      if not mhInfo and not setup.mhLink then
        return Result(profile, 0, 0, stats, {}, {
          blocked = true,
          blockedReason = "Needs a main-hand to use, not an upgrade alone.",
          versus = "Off-hand: needs a 1H main-hand",
        })
      end
    end
    return Result(profile, newScore, ohScore, stats, setup.ohStats, {
      versus = setup.ohLink and "vs your off-hand" or "vs empty off-hand",
      equippedLink = setup.ohLink,
      equippedName = setup.ohInfo and setup.ohInfo.name or "empty slot",
    })
  end
  return nil
end

local function CompareProfile(info, stats, profile)
  if WEAPON_KIND[info.equipLoc] then
    return CompareWeapon(info, stats, profile)
  end
  local slots = EQUIP_SLOTS[info.equipLoc]
  if not slots then
    return nil
  end
  local newScore = Score(stats, profile)
  local worstScore, worstLink, worstName, worstStats
  for i = 1, #slots do
    local link = EquippedLink(slots[i])
    if link then
      local estats = CollectStats(link)
      local sc = Score(estats, profile)
      if worstScore == nil or sc < worstScore then
        worstScore = sc
        worstLink = link
        worstName = PC:ItemNameFromLink(link)
        worstStats = estats
      end
    end
  end
  if worstScore == nil then
    worstScore = 0
    worstStats = {}
    worstName = "empty slot"
  end
  local pct = Percent(newScore, worstScore)
  return {
    profile = profile,
    newScore = newScore,
    oldScore = worstScore,
    pct = pct,
    upgrade = newScore > worstScore + 0.01,
    equippedLink = worstLink,
    equippedName = worstName,
    versus = worstName and ("vs " .. worstName) or nil,
    deltas = DeltaParts(stats, worstStats or {}, profile),
  }
end

function PC:GetUpgradeProfiles()
  local data = self:GetClassData()
  if data and type(data.profiles) == "table" and #data.profiles > 0 then
    return data.profiles
  end
  return {
    { id = "heal", name = "Healing", labels = { "heal" }, weights = DEFAULT_WEIGHTS.heal },
    { id = "balance", name = "Balance", labels = { "balance" }, weights = DEFAULT_WEIGHTS.balance },
    { id = "both", name = "Both", labels = { "heal", "balance" }, compare = { "heal", "balance" } },
  }
end

function PC:GetProfileDef(id)
  local list = self:GetUpgradeProfiles()
  for i = 1, #list do
    if list[i].id == id then
      return list[i]
    end
  end
  return nil
end

function PC:GetDefaultUpgradeProfile()
  local data = self:GetClassData()
  if data and data.defaultProfile and self:GetProfileDef(data.defaultProfile) then
    return data.defaultProfile
  end
  local list = self:GetUpgradeProfiles()
  if list[1] then
    return list[1].id
  end
  return "both"
end

function PC:GetProfileRoleTags(profile)
  profile = profile or self:GetUpgradeProfile()
  local def = self:GetProfileDef(profile)
  if def and type(def.labels) == "table" then
    return def.labels
  end
  return {}
end

function PC:GetActiveCompareProfiles()
  local profile = self:GetUpgradeProfile()
  local def = self:GetProfileDef(profile)
  if def and type(def.compare) == "table" then
    return def.compare
  end
  if def then
    return { def.id }
  end
  return { profile }
end

function PC:ProfileDisplayName(id)
  local def = self:GetProfileDef(id)
  if def and def.name then
    return def.name
  end
  return id
end

function PC:GetUpgradeProfile()
  local db = self:GetDB()
  local p = db and db.upgradeProfile
  if p and self:GetProfileDef(p) then
    return p
  end
  return self:GetDefaultUpgradeProfile()
end

function PC:SetUpgradeProfile(profile)
  if not self:GetProfileDef(profile) then
    return nil
  end
  if not self:GetDB() then
    self:InitDB()
  end
  local db = self:GetDB()
  if db then
    db.upgradeProfile = profile
  end
  if self.Refresh then
    self:Refresh()
  end
  if self.RefreshOptionsPanel then
    self:RefreshOptionsPanel()
  end
  return profile
end

function PC:EvaluateUpgrade(idOrLink)
  local info = GetInfo(idOrLink)
  if not info then
    return { ignored = true, reason = "item info not available" }
  end
  if not info.equipLoc or info.equipLoc == "" then
    return { ignored = true, reason = "not an equippable item" }
  end
  local okUse, why = DruidCanUse(info)
  if not okUse then
    return {
      ignored = false,
      cantUse = true,
      reason = why,
      info = info,
      itemID = info.itemID,
      name = info.name,
      link = info.link or idOrLink,
    }
  end
  local stats = CollectStats(info.link or info.itemID or idOrLink)
  local result = {
    ignored = false,
    info = info,
    itemID = info.itemID,
    name = info.name,
    link = info.link or idOrLink,
    minLevel = info.minLevel,
    tooHigh = info.minLevel and self:PlayerLevel() < info.minLevel,
  }
  local list = self.GetUpgradeProfiles and self:GetUpgradeProfiles() or {}
  for i = 1, #list do
    local id = list[i].id
    if id and not list[i].compare then
      result[id] = CompareProfile(info, stats, id)
    end
  end
  local active = self.GetActiveCompareProfiles and self:GetActiveCompareProfiles() or {}
  if active[1] then
    result.primary = result[active[1]]
    result.primaryId = active[1]
  end
  return result
end

local function FormatCompare(cmp, label)
  if not cmp then
    return nil
  end
  if cmp.blocked then
    return (cmp.blockedReason or cmp.versus or "Not an upgrade alone.")
  end
  local delta = ""
  if cmp.deltas and #cmp.deltas > 0 then
    delta = " (" .. table.concat(cmp.deltas, ", ") .. ")"
  end
  local vs = cmp.versus
  if not vs or vs == "" then
    if cmp.equippedLink then
      vs = "over " .. cmp.equippedLink
    elseif cmp.equippedName then
      vs = "over " .. cmp.equippedName
    end
  end
  local sign = cmp.pct >= 0 and "+" or ""
  local core = sign .. tostring(cmp.pct) .. "% " .. string.lower(label)
  if vs then
    return vs .. ": " .. core .. delta
  end
  return "Upgrade for " .. label .. ": " .. sign .. tostring(cmp.pct) .. "%" .. delta
end

function PC:GetRecentUpgrades()
  local db = self:GetDB()
  if not db or type(db.recentUpgrades) ~= "table" then
    return {}
  end
  return db.recentUpgrades
end

local function RememberUpgrade(result, lines)
  if not PC:GetDB() then
    PC:InitDB()
  end
  local db = PC:GetDB()
  if type(db.recentUpgrades) ~= "table" then
    db.recentUpgrades = {}
  end
  local entry = {
    itemID = result.itemID,
    name = result.name,
    link = result.link,
    text = table.concat(lines, "  ·  "),
    tooHigh = result.tooHigh and result.minLevel or nil,
    time = time and time() or 0,
  }
  local list = db.recentUpgrades
  -- drop an older row for the same item
  for i = #list, 1, -1 do
    if list[i].itemID and result.itemID and list[i].itemID == result.itemID then
      table.remove(list, i)
    end
  end
  table.insert(list, 1, entry)
  while #list > 10 do
    table.remove(list)
  end
end

function PC:ShowUpgradeToast(text)
  if not text or text == "" then
    return
  end
  if not CreateFrame or not UIParent then
    return
  end
  if not self.upgradeToast then
    local f = CreateFrame("Frame", "PhilosophersCodexToast", UIParent)
    f:SetSize(360, 56)
    f:SetPoint("TOP", UIParent, "TOP", 0, -80)
    f:SetFrameStrata("TOOLTIP")
    local bg = f:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetTexture("Interface\\Buttons\\WHITE8X8")
    bg:SetVertexColor(0.07, 0.07, 0.08, 0.94)
    f.label = f:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    if f.label.SetFontObject then
      pcall(f.label.SetFontObject, f.label, GameFontHighlight)
    end
    f.label:SetPoint("TOPLEFT", 12, -10)
    f.label:SetPoint("BOTTOMRIGHT", -12, 10)
    f.label:SetJustifyH("LEFT")
    f.label:SetJustifyV("MIDDLE")
    self.upgradeToast = f
  end
  local f = self.upgradeToast
  f.label:SetText(text)
  f:Show()
  if C_Timer and C_Timer.After then
    C_Timer.After(5, function()
      if f then
        f:Hide()
      end
    end)
  end
end

function PC:AlertUpgrade(result)
  if not result or result.ignored then
    return false
  end
  local lines = {}
  local active = self.GetActiveCompareProfiles and self:GetActiveCompareProfiles() or { self:GetUpgradeProfile() }
  for i = 1, #active do
    local id = active[i]
    local cmp = result[id]
    if cmp and cmp.upgrade then
      local label = self.ProfileDisplayName and self:ProfileDisplayName(id) or id
      lines[#lines + 1] = FormatCompare(cmp, label)
    end
  end
  if #lines == 0 then
    return false
  end
  local id = result.itemID
  if id and alerted[id] and (Now() - alerted[id]) < 60 then
    return false
  end
  if id then
    alerted[id] = Now()
  end
  if result.tooHigh and result.minLevel then
    lines[#lines + 1] = "Upgrade at level " .. tostring(result.minLevel)
  end
  if self:IsUpgradeChatEnabled() then
    for i = 1, #lines do
      self:Print(lines[i])
    end
  end
  if self:IsUpgradeToastEnabled() then
    self:ShowUpgradeToast(lines[1])
  end
  RememberUpgrade(result, lines)
  if self.Refresh then
    self:Refresh()
  end
  return true
end

function PC:EvaluateAndAlert(idOrLink)
  local result = self:EvaluateUpgrade(idOrLink)
  if result and not result.ignored then
    self:AlertUpgrade(result)
  end
  return result
end

local function RoundScore(n)
  n = tonumber(n) or 0
  if n >= 0 then
    return math.floor(n + 0.5)
  end
  return math.ceil(n - 0.5)
end

-- Unmissable one-line upgrade status for the user's class and role.
-- Returns text, r, g, b, extra (optional reason or delta line).
function PC:FormatUpgradeHeadline(cmp, label, result)
  if result and result.cantUse then
    local reason = result.reason or "wrong armor or weapon type"
    return "Can't use", 0.70, 0.70, 0.72, reason
  end
  if not cmp then
    return nil
  end
  if cmp.blocked then
    return "Can't use", 0.70, 0.70, 0.72, cmp.blockedReason or cmp.versus or "Not usable on its own."
  end
  local delta = (cmp.newScore or 0) - (cmp.oldScore or 0)
  local rounded = RoundScore(delta)
  local scoreTxt
  if rounded > 0 then
    scoreTxt = "+" .. tostring(rounded) .. " score"
  elseif rounded < 0 then
    scoreTxt = tostring(rounded) .. " score"
  else
    scoreTxt = "same score"
  end
  label = label or "this spec"
  if cmp.upgrade then
    return "▲ Upgrade for " .. label .. " (" .. scoreTxt .. ")", 0.247, 0.749, 0.498
  end
  local pct = math.abs(cmp.pct or 0)
  if pct <= 2 or math.abs(delta) <= 1 then
    return "Sidegrade for " .. label, 0.62, 0.62, 0.64
  end
  return "▼ Downgrade for " .. label .. " (" .. scoreTxt .. ")", 0.85, 0.32, 0.32
end

function PC:FormatUpgradeDeltaLine(cmp)
  if not cmp or type(cmp.deltas) ~= "table" or #cmp.deltas == 0 then
    return nil
  end
  return table.concat(cmp.deltas, ", ")
end

function PC:AnnotateUpgradeTooltip(tooltip, itemID, name, link)
  if not tooltip or not tooltip.AddLine then
    return
  end
  if PC.IsScanTooltip and PC:IsScanTooltip(tooltip) then
    return
  end
  if self.IsUpgradeTooltipEnabled and not self:IsUpgradeTooltipEnabled() then
    return
  end
  local target = link or itemID
  if not target then
    return
  end
  local result = self:EvaluateUpgrade(target)
  if not result then
    return
  end
  if result.ignored and not result.cantUse then
    return
  end
  if result.cantUse then
    local text, r, g, b, extra = self:FormatUpgradeHeadline(nil, nil, result)
    tooltip:AddLine("Codex: " .. (text or "Can't use"), r or 0.70, g or 0.70, b or 0.72)
    if extra and extra ~= "" then
      tooltip:AddLine(extra, 0.62, 0.62, 0.64)
    end
    return
  end
  local active = self.GetActiveCompareProfiles and self:GetActiveCompareProfiles() or { self:GetUpgradeProfile() }
  for i = 1, #active do
    local id = active[i]
    local label = self.ProfileDisplayName and self:ProfileDisplayName(id) or id
    local cmp = result[id]
    if cmp then
      local text, r, g, b, extra = self:FormatUpgradeHeadline(cmp, label, result)
      if text then
        tooltip:AddLine("Codex: " .. text, r, g, b)
      end
      local deltas = extra or self:FormatUpgradeDeltaLine(cmp)
      if deltas and deltas ~= "" then
        tooltip:AddLine(deltas, 0.80, 0.80, 0.82)
      end
      if cmp.versus and cmp.versus ~= "" then
        tooltip:AddLine(cmp.versus, 0.56, 0.56, 0.60)
      end
    end
  end
  if result.tooHigh and result.minLevel then
    tooltip:AddLine("Upgrade at level " .. tostring(result.minLevel), 0.831, 0.686, 0.216)
  end
end

local function IsSelfLootMessage(msg)
  if type(msg) ~= "string" then
    return false
  end
  if string.find(msg, "^You receive") or string.find(msg, "^You won") or string.find(msg, "^You win") then
    return true
  end
  -- Use the client's own self-loot format string when present.
  local formats = { "LOOT_ITEM_SELF", "LOOT_ITEM_SELF_MULTIPLE", "LOOT_ITEM_PUSHED_SELF", "LOOT_ITEM_CREATED_SELF" }
  for i = 1, #formats do
    local pat = rawget(_G, formats[i])
    if type(pat) == "string" then
      -- Turn "%s" into a loose match; if the pattern's prefix appears, treat as self.
      local prefix = string.match(pat, "^([^%%]+)")
      if prefix and prefix ~= "" and string.find(msg, prefix, 1, true) then
        return true
      end
    end
  end
  return false
end

local function LinksInText(msg)
  local links = {}
  if type(msg) ~= "string" then
    return links
  end
  for link in string.gmatch(msg, "|c%x+|Hitem:.-|h.-|h|r") do
    links[#links + 1] = link
  end
  return links
end

function PC:OnLootMessage(msg)
  if not IsSelfLootMessage(msg) then
    return
  end
  local links = LinksInText(msg)
  for i = 1, #links do
    self:EvaluateAndAlert(links[i])
  end
end

local function ContainerSlots(bag)
  if C_Container and C_Container.GetContainerNumSlots then
    return C_Container.GetContainerNumSlots(bag) or 0
  end
  if GetContainerNumSlots then
    return GetContainerNumSlots(bag) or 0
  end
  return 0
end

local function ContainerLink(bag, slot)
  if C_Container and C_Container.GetContainerItemLink then
    return C_Container.GetContainerItemLink(bag, slot)
  end
  if GetContainerItemLink then
    return GetContainerItemLink(bag, slot)
  end
  return nil
end

local function SnapshotBags()
  local map = {}
  for bag = 0, 4 do
    local slots = ContainerSlots(bag)
    for slot = 1, slots do
      local link = ContainerLink(bag, slot)
      local id = ItemIDFromLink(link)
      if id then
        map[id] = (map[id] or 0) + 1
      end
    end
  end
  return map
end

function PC:SnapshotUpgradeBags()
  bagSnapshot = SnapshotBags()
end

function PC:DiffUpgradeBags()
  local now = SnapshotBags()
  local prev = bagSnapshot or {}
  for id, count in pairs(now) do
    if (prev[id] or 0) == 0 and count > 0 then
      -- New item appeared in bags; evaluate one of its links by id.
      self:EvaluateAndAlert(id)
    end
  end
  bagSnapshot = now
end

-- Hidden scan tooltip fontstrings must exist if GameTooltipTemplate was missing.
function EnsureScanLines()
  local tip = EnsureScanTip()
  if not tip then
    return
  end
  for i = 1, 30 do
    local name = "PhilosophersCodexScanTipTextLeft" .. i
    if not rawget(_G, name) then
      local ok, fs = pcall(tip.CreateFontString, tip, name, "ARTWORK", "GameFontNormal")
      if ok and fs then
        _G[name] = fs
      end
    end
  end
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("PLAYER_ENTERING_WORLD")
ev:RegisterEvent("CHAT_MSG_LOOT")
ev:RegisterEvent("BAG_UPDATE_DELAYED")
ev:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
ev:RegisterEvent("GET_ITEM_INFO_RECEIVED")

local bagPending = false
ev:SetScript("OnEvent", function(_, event, ...)
  if event == "PLAYER_LOGIN" or event == "PLAYER_ENTERING_WORLD" then
    PC:SnapshotUpgradeBags()
    return
  end
  if event == "CHAT_MSG_LOOT" then
    local msg = ...
    PC:OnLootMessage(msg)
    return
  end
  if event == "BAG_UPDATE_DELAYED" or event == "PLAYER_EQUIPMENT_CHANGED" then
    if bagPending then
      return
    end
    bagPending = true
    local function run()
      bagPending = false
      PC:DiffUpgradeBags()
    end
    if C_Timer and C_Timer.After then
      C_Timer.After(0.2, run)
    else
      run()
    end
    return
  end
  if event == "GET_ITEM_INFO_RECEIVED" then
    -- A pending evaluate may now have full item info; bag diff already stored IDs.
  end
end)

-- 1.23.0: equipped vs this item, stat by stat, for the Gear detail pane.
local COMPARE_STATS = {
  { "stamina", "Stamina" }, { "intellect", "Intellect" }, { "spirit", "Spirit" },
  { "agility", "Agility" }, { "strength", "Strength" },
  { "healing", "Healing" }, { "spellpower", "Spell power" }, { "spelldamage", "Spell damage" },
  { "attackpower", "Attack power" }, { "hit", "Hit" },
  { "crit", "Crit" }, { "mp5", "Mana per 5" }, { "armor", "Armor" }, { "dps", "Damage per sec" },
}

function PC:GetGearCompare(idOrLink)
  local info = GetInfo(idOrLink)
  if not info or not info.name then
    -- Not cached yet: ask the client for it; the pane retries shortly.
    local id = tonumber(idOrLink)
    if id and C_Item and C_Item.RequestLoadItemDataByID then
      pcall(C_Item.RequestLoadItemDataByID, id)
    end
    if not info then
      return { loading = true }
    end
  end
  local newStats = CollectStats(info.link or info.itemID or idOrLink) or {}
  local slots = info.equipLoc and EQUIP_SLOTS[info.equipLoc] or nil
  local oldLink, oldStats
  local result = self:EvaluateUpgrade(info.link or info.itemID or idOrLink)
  local primary = result and result.primary
  if primary and primary.equippedLink then
    oldLink = primary.equippedLink
  elseif slots then
    oldLink = EquippedLink(slots[1])
  end
  local oldInfo = oldLink and GetInfo(oldLink) or nil
  oldStats = oldLink and CollectStats(oldLink) or {}
  local rows = {}
  for i = 1, #COMPARE_STATS do
    local key, label = COMPARE_STATS[i][1], COMPARE_STATS[i][2]
    local a, b = oldStats[key] or 0, newStats[key] or 0
    if a ~= 0 or b ~= 0 then
      local fmt = (key == "dps") and function(v) return string.format("%.1f", v) end or function(v) return tostring(math.floor(v + 0.5)) end
      rows[#rows + 1] = { label = label, a = (a ~= 0) and fmt(a) or "-", b = (b ~= 0) and fmt(b) or "-", win = (a > b) and "a" or ((b > a) and "b" or nil) }
    end
  end
  if info.itemLevel or (oldInfo and oldInfo.itemLevel) then
    table.insert(rows, 1, { label = "Item level", a = oldInfo and oldInfo.itemLevel or "-", b = info.itemLevel or "-" })
  end
  if info.minLevel and info.minLevel > 1 then
    table.insert(rows, 1, { label = "Requires", a = (oldInfo and oldInfo.minLevel) and ("Level " .. oldInfo.minLevel) or "-", b = "Level " .. info.minLevel })
  end
  local verdict, good
  if result and result.cantUse then
    verdict = "You can't use this: " .. tostring(result.reason or "wrong type")
  elseif primary then
    local name = self.ProfileDisplayName and self:ProfileDisplayName(result.primaryId) or tostring(result.primaryId or "")
    if primary.upgrade then
      good = true
      verdict = "Upgrade for " .. name .. ": +" .. tostring(primary.pct or 0) .. "%"
      if primary.deltas and #primary.deltas > 0 then
        verdict = verdict .. " (" .. table.concat(primary.deltas, ", ") .. ")"
      end
    else
      verdict = "Not an upgrade for " .. name .. (primary.pct and primary.pct < 0 and (" (" .. primary.pct .. "%)") or "") .. "."
    end
    if result.tooHigh then
      verdict = verdict .. " Wearable at level " .. tostring(info.minLevel) .. "."
    end
  end
  return {
    new = { name = info.name, itemID = info.itemID, icon = info.icon, rarity = info.rarity },
    old = oldLink and { name = (oldInfo and oldInfo.name) or self:ItemNameFromLink(oldLink), itemID = oldInfo and oldInfo.itemID, icon = oldInfo and oldInfo.icon, rarity = oldInfo and oldInfo.rarity } or nil,
    rows = rows,
    verdict = verdict,
    good = good,
  }
end
