-- Philosopher's Codex: compact movable and resizable mini tracker.
-- Event-driven only. No per-frame OnUpdate work.

local PC = PhilosophersCodex

local GOLD = { r = 0.831, g = 0.686, b = 0.216 }
local EMERALD = { r = 0.247, g = 0.749, b = 0.498 }
local AMBER = { r = 0.90, g = 0.72, b = 0.22 }
local TEXT = { r = 0.95, g = 0.95, b = 0.97 }
local SUB = { r = 0.56, g = 0.56, b = 0.60 }
local SURFACE = { r = 0.07, g = 0.07, b = 0.08 }
local SURFACE_FILL = { r = 0.07, g = 0.05, b = 0.04 }
local SOLID = "Interface\\Buttons\\WHITE8X8"
local BAR = "Interface\\TargetingFrame\\UI-StatusBar"
local FRIZ = "Fonts\\FRIZQT__.TTF"

-- 1.23.0: the card has one fixed width (no resize grip) so nothing truncates.
local DEFAULT_W, DEFAULT_H = 320, 200
local MIN_W, MIN_H = 200, 150
local MAX_W, MAX_H = 420, 640
local TITLE_H = 22
local BOTTOM_TAB = 16
local NAMECARD_PAD = 10
local MAX_QUEST_ROWS = 10

PC.MINI_MIN_W = MIN_W
PC.MINI_MIN_H = MIN_H
PC.MINI_MAX_W = MAX_W
PC.MINI_MAX_H = MAX_H
PC.MINI_DEFAULT_W = DEFAULT_W
PC.MINI_DEFAULT_H = DEFAULT_H

local mini = { created = false, questPending = false, sizing = false }
local StyleMiniTab, SetMiniPanel, HideNextBody, ShowNextBody, EnsureFinder, RefreshFinder, CreateMini, ClampFrameToScreen


local function FS(parent, inherit, size)
  local obj = inherit or "GameFontHighlight"
  local fs = parent:CreateFontString(nil, "ARTWORK", obj)
  if fs.SetFontObject then
    pcall(fs.SetFontObject, fs, _G[obj] or GameFontHighlight)
  end
  if fs.SetFont and size then
    pcall(fs.SetFont, fs, FRIZ, size, "")
  end
  if fs.SetJustifyH then
    fs:SetJustifyH("LEFT")
  end
  return fs
end

local function Paint(tex, color, a)
  if not tex then
    return
  end
  tex:SetTexture(SOLID)
  tex:SetVertexColor(color.r, color.g, color.b, a or 1)
end

local function InInstance()
  if IsInInstance then
    local ok, inside = pcall(IsInInstance)
    if ok and inside then
      return true
    end
  end
  if GetInstanceInfo then
    local ok, _, itype = pcall(GetInstanceInfo)
    if ok and itype and itype ~= "" and itype ~= "none" then
      return true
    end
  end
  return false
end

local function InCombat()
  if UnitAffectingCombat then
    local ok, yes = pcall(UnitAffectingCombat, "player")
    if ok then
      return yes and true or false
    end
  end
  return false
end

local function Clamp(n, a, b)
  n = tonumber(n) or a
  if n < a then return a end
  if n > b then return b end
  return n
end

local function DefaultAnchor(frame)
  if not frame then
    return
  end
  frame:ClearAllPoints()
  if Minimap then
    frame:SetPoint("TOPRIGHT", Minimap, "BOTTOMRIGHT", 0, -16)
  else
    frame:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -20, -180)
  end
  if frame.SetClampedToScreen then
    pcall(frame.SetClampedToScreen, frame, true)
  end
  ClampFrameToScreen(frame)
end

local function LogMiniError(context, err)
  if err == nil then
    return
  end
  local stack = ""
  if PC.CaptureStack then
    local ok, s = pcall(PC.CaptureStack, PC)
    if ok and type(s) == "string" then
      stack = s
    end
  elseif debugstack then
    local ok, s = pcall(debugstack)
    if ok and type(s) == "string" then
      stack = s
    end
  end
  if PC.LogError then
    pcall(PC.LogError, PC, tostring(err), stack, context or "mini")
  elseif PC.ReportError then
    pcall(PC.ReportError, PC, tostring(err))
  end
end

-- Phase 2 (decorative) failures: logged to PhilosophersCodexLog and printed
-- to chat once per piece so a broken texture or animation is reportable
-- without ever hiding the card.
local decorWarned = {}
local function ChatLine(text)
  if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
    local ok = pcall(DEFAULT_CHAT_FRAME.AddMessage, DEFAULT_CHAT_FRAME, text)
    if ok then
      return
    end
  end
  if print then
    pcall(print, text)
  end
end

local function ReportDecorFailure(name, err)
  name = tostring(name or "decoration")
  local msg = tostring(err or "unknown error")
  LogMiniError("mini:" .. name, msg)
  mini.decorErrors = mini.decorErrors or {}
  if #mini.decorErrors < 20 then
    mini.decorErrors[#mini.decorErrors + 1] = name .. ": " .. msg
  end
  if not decorWarned[name] then
    decorWarned[name] = true
    ChatLine("|cffd4af37[Codex]|r tracker decoration failed: " .. name .. ": " .. msg)
  end
end

local function Decor(name, fn, ...)
  local ok, err = pcall(fn, ...)
  if not ok then
    ReportDecorFailure(name, err)
  end
  return ok
end
PC._MiniDecor = Decor

-- ---------------------------------------------------------------------------
-- Rounded card shape (1.18.3). Built from solid strips plus four corner
-- squares, each cut to a quarter circle by a circle mask. If masks are not
-- available the corners stay square; the card itself always draws.
-- ---------------------------------------------------------------------------

local CARD_RADIUS = 10
local BORDER_W = 2
local PILL_H = 24
local CORNERS = { "TOPLEFT", "TOPRIGHT", "BOTTOMLEFT", "BOTTOMRIGHT" }
local CIRCLE_MASKS = {
  "Interface\\CHARACTERFRAME\\TempPortraitAlphaMask",
  "Interface\\Masks\\CircleMaskScalable",
}
local CORNER_SIGN = {
  TOPLEFT = { 1, -1 }, TOPRIGHT = { -1, -1 },
  BOTTOMLEFT = { 1, 1 }, BOTTOMRIGHT = { -1, 1 },
}

local function NewCornerSet(f, layer, sublevel, color, alpha)
  local set = {}
  for i = 1, #CORNERS do
    local pt = CORNERS[i]
    local t = f:CreateTexture(nil, layer, nil, sublevel)
    Paint(t, color, alpha)
    if f.CreateMaskTexture and t.AddMaskTexture then
      local okM, m = pcall(f.CreateMaskTexture, f)
      if okM and m then
        for k = 1, #CIRCLE_MASKS do
          pcall(m.SetTexture, m, CIRCLE_MASKS[k], "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
          if not m.GetTexture or m:GetTexture() then
            break
          end
        end
        if pcall(t.AddMaskTexture, t, m) then
          t._roundMask = m
        end
      end
    end
    set[pt] = t
  end
  return set
end

local function PlaceCorners(set, f, inset, r)
  for i = 1, #CORNERS do
    local pt = CORNERS[i]
    local t = set[pt]
    local sx, sy = CORNER_SIGN[pt][1], CORNER_SIGN[pt][2]
    t:ClearAllPoints()
    t:SetPoint(pt, f, pt, sx * inset, sy * inset)
    t:SetSize(r, r)
    t:Show()
    local m = t._roundMask
    if m then
      -- The mask is the full circle; its quarter lands on this corner.
      m:ClearAllPoints()
      m:SetPoint(pt, f, pt, sx * inset, sy * inset)
      m:SetSize(r * 2, r * 2)
    end
  end
end

local function Strip(t, f, p1, x1, y1, p2, x2, y2, show)
  t:ClearAllPoints()
  if show then
    t:SetPoint("TOPLEFT", f, p1, x1, y1)
    t:SetPoint("BOTTOMRIGHT", f, p2, x2, y2)
    t:Show()
  else
    t:Hide()
  end
end

-- Builds the gold rim (4 edge strips + corners) and the dark fill
-- (3 non-overlapping strips + corners) so the fill alpha never tints gold.
local function BuildRoundShape(f)
  local s = { fill = {}, rim = {} }
  for i = 1, 3 do
    local t = f:CreateTexture(nil, "BACKGROUND", nil, -7)
    Paint(t, SURFACE_FILL, 0.96)
    s.fill[i] = t
  end
  s.fillCorners = NewCornerSet(f, "BACKGROUND", -7, SURFACE_FILL, 0.96)
  for i = 1, 4 do
    local t = f:CreateTexture(nil, "BACKGROUND", nil, -8)
    Paint(t, GOLD, 0.95)
    s.rim[i] = t
  end
  s.rimCorners = NewCornerSet(f, "BACKGROUND", -8, GOLD, 0.95)
  return s
end

local function LayoutRoundShape(s, f, r)
  if not s or not f then
    return
  end
  local w = (f.GetWidth and f:GetWidth()) or DEFAULT_W
  local h = (f.GetHeight and f:GetHeight()) or DEFAULT_H
  r = math.floor(math.max(BORDER_W + 1, math.min(r, w / 2, h / 2)))
  local b = BORDER_W
  local ir = r - b
  -- Rim: top, bottom, left, right edges between the corner arcs.
  Strip(s.rim[1], f, "TOPLEFT", r, 0, "TOPRIGHT", -r, -b, w > 2 * r)
  Strip(s.rim[2], f, "BOTTOMLEFT", r, b, "BOTTOMRIGHT", -r, 0, w > 2 * r)
  Strip(s.rim[3], f, "TOPLEFT", 0, -r, "BOTTOMLEFT", b, r, h > 2 * r)
  Strip(s.rim[4], f, "TOPRIGHT", -b, -r, "BOTTOMRIGHT", 0, r, h > 2 * r)
  PlaceCorners(s.rimCorners, f, 0, r)
  -- Fill: center column full height, plus left and right middle strips.
  Strip(s.fill[1], f, "TOPLEFT", r, -b, "BOTTOMRIGHT", -r, b, w > 2 * r)
  Strip(s.fill[2], f, "TOPLEFT", b, -r, "BOTTOMLEFT", r, r, h > 2 * r)
  Strip(s.fill[3], f, "TOPRIGHT", -r, -r, "BOTTOMRIGHT", -b, r, h > 2 * r)
  PlaceCorners(s.fillCorners, f, b, ir)
  s.radius = r
end

-- Fill-only rounded rect (no rim), e.g. a selected-tab pill. inset is the
-- gap from the host frame's edges.
local function BuildRoundFill(f, color, alpha, layer, sublevel)
  local s = { fill = {}, color = color }
  layer, sublevel = layer or "BACKGROUND", sublevel or 1
  for i = 1, 3 do
    local t = f:CreateTexture(nil, layer, nil, sublevel)
    Paint(t, color, alpha or 1)
    s.fill[i] = t
  end
  s.fillCorners = NewCornerSet(f, layer, sublevel, color, alpha or 1)
  return s
end

local function LayoutRoundFill(s, f, r, inset)
  if not s or not f then
    return
  end
  inset = inset or 0
  local w = ((f.GetWidth and f:GetWidth()) or 0) - 2 * inset
  local h = ((f.GetHeight and f:GetHeight()) or 0) - 2 * inset
  r = math.floor(math.max(1, math.min(r, w / 2, h / 2)))
  local e = inset + r
  Strip(s.fill[1], f, "TOPLEFT", e, -inset, "BOTTOMRIGHT", -e, inset, w > 2 * r)
  Strip(s.fill[2], f, "TOPLEFT", inset, -e, "BOTTOMLEFT", e, e, h > 2 * r)
  Strip(s.fill[3], f, "TOPRIGHT", -e, -e, "BOTTOMRIGHT", -inset, e, h > 2 * r)
  PlaceCorners(s.fillCorners, f, inset, r)
  s.radius = r
end

local function ShowRoundFill(s, on, color, alpha)
  if not s then
    return
  end
  local parts = {}
  for i = 1, #s.fill do parts[#parts + 1] = s.fill[i] end
  for i = 1, #CORNERS do parts[#parts + 1] = s.fillCorners[CORNERS[i]] end
  for i = 1, #parts do
    local t = parts[i]
    if on then
      if color then
        t:SetVertexColor(color.r, color.g, color.b, alpha or 1)
      end
      t:Show()
    else
      t:Hide()
    end
  end
end

-- Shared with the main window (1.19.0) so both use the same card look.
function PC:BuildRoundCard(f)
  return BuildRoundShape(f)
end
function PC:LayoutRoundCard(s, f, r)
  return LayoutRoundShape(s, f, r or CARD_RADIUS)
end
function PC:BuildRoundFill(f, color, alpha, layer, sublevel)
  return BuildRoundFill(f, color, alpha, layer, sublevel)
end
function PC:LayoutRoundFill(s, f, r, inset)
  return LayoutRoundFill(s, f, r, inset)
end
function PC:ShowRoundFill(s, on, color, alpha)
  return ShowRoundFill(s, on, color, alpha)
end

local function ShapeFillParts(s)
  local out = {}
  if not s then
    return out
  end
  for i = 1, #s.fill do
    out[#out + 1] = s.fill[i]
  end
  for i = 1, #CORNERS do
    out[#out + 1] = s.fillCorners[CORNERS[i]]
  end
  return out
end

local function ScreenSize()
  local sw, sh
  if GetScreenWidth and GetScreenHeight then
    sw, sh = GetScreenWidth(), GetScreenHeight()
  end
  if (not sw or sw <= 0) and UIParent and UIParent.GetWidth then
    sw = UIParent:GetWidth()
    sh = UIParent and UIParent.GetHeight and UIParent:GetHeight() or sh
  end
  sw = tonumber(sw) or 1920
  sh = tonumber(sh) or 1080
  if sw <= 0 then sw = 1920 end
  if sh <= 0 then sh = 1080 end
  return sw, sh
end

local function SavedGeometryValid(db)
  if type(db) ~= "table" then
    return false
  end
  local x, y = tonumber(db.x), tonumber(db.y)
  if not x or not y then
    return false
  end
  local w = tonumber(db.w) or DEFAULT_W
  local h = tonumber(db.h) or DEFAULT_H
  if w <= 0 then w = DEFAULT_W end
  if h <= 0 then h = DEFAULT_H end
  local sw, sh = ScreenSize()
  -- 1.18.2 saves the top edge (db.anchor = "TOP") so the card grows downward.
  local bottom = y
  if db.anchor == "TOP" then
    bottom = y - h
  end
  -- No on-screen overlap (20px slop): treat as a bad saved position.
  if x > (sw - 20) or bottom > (sh - 20) then
    return false
  end
  if (x + w) < 20 or (bottom + h) < 20 then
    return false
  end
  return true
end

function ClampFrameToScreen(frame)
  if not frame then
    return
  end
  if frame.SetClampedToScreen then
    pcall(frame.SetClampedToScreen, frame, true)
  end
  local left = frame.GetLeft and frame:GetLeft()
  local bottom = frame.GetBottom and frame:GetBottom()
  if type(left) ~= "number" or type(bottom) ~= "number" then
    return
  end
  local w = (frame.GetWidth and frame:GetWidth()) or DEFAULT_W
  local h = (frame.GetHeight and frame:GetHeight()) or DEFAULT_H
  w = tonumber(w) or DEFAULT_W
  h = tonumber(h) or DEFAULT_H
  local sw, sh = ScreenSize()
  local x, y = left, bottom
  if x < 0 then x = 0 end
  if y < 0 then y = 0 end
  if (x + w) > sw then x = math.max(0, sw - w) end
  if (y + h) > sh then y = math.max(0, sh - h) end
  if x ~= left or y ~= bottom then
    frame:ClearAllPoints()
    frame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", x, y + h)
  end
end

local function ApplyOpacity()
  local f = mini.frame
  if not f then
    return
  end
  local db = PC:GetMiniDB() or {}
  local a = Clamp(db.opacity or 0.92, 0.4, 1)
  local layers = ShapeFillParts(mini.shape)
  layers[#layers + 1] = mini.parchment
  for i = 1, #layers do
    local tex = layers[i]
    if tex and tex.SetAlpha then
      tex:SetAlpha(a)
    end
  end
  if f.SetBackdropColor then
    pcall(f.SetBackdropColor, f, 0.07, 0.05, 0.04, a)
  end
end

local function SaveMiniGeometry()
  local f = mini.frame
  if not f or not f.GetLeft then
    return
  end
  local db = PC:GetMiniDB()
  if not db then
    return
  end
  db.x = f:GetLeft()
  db.y = (f.GetTop and f:GetTop()) or ((f:GetBottom() or 0) + (f:GetHeight() or 0))
  db.anchor = "TOP"
  if db.minimized then
    -- The pill keeps its own size; remember only where it sits.
    return
  end
  if f.GetWidth then
    db.w = Clamp(f:GetWidth(), MIN_W, MAX_W)
  end
  if f.GetHeight and not db.collapsed then
    db.h = Clamp(f:GetHeight(), MIN_H, MAX_H)
  end
end

local function RestoreMiniGeometry()
  local f = mini.frame
  if not f then
    return
  end
  local db = PC:GetMiniDB() or {}
  local w = tonumber(db.w)
  local h = tonumber(db.h)
  if not w or w <= 0 then
    w = DEFAULT_W
  end
  if not h or h <= 0 then
    h = DEFAULT_H
  end
  w = DEFAULT_W
  db.w = nil
  h = Clamp(h, MIN_H, MAX_H)
  if db.minimized then
    -- LayoutPill sizes the frame; measure validity against the pill.
    w = (f.GetWidth and f:GetWidth()) or w
    h = PILL_H
  elseif f.SetWidth then
    f:SetWidth(w)
  end
  if not db.collapsed and not db.minimized and f.SetHeight then
    f:SetHeight(h)
  end
  if f.SetClampedToScreen then
    pcall(f.SetClampedToScreen, f, true)
  end
  if SavedGeometryValid(db) then
    f:ClearAllPoints()
    if db.anchor == "TOP" then
      f:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", tonumber(db.x), tonumber(db.y))
    else
      -- Pre-1.18.2 saves stored the bottom edge.
      f:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", tonumber(db.x), tonumber(db.y))
    end
  else
    if db.x ~= nil or db.y ~= nil then
      db.x, db.y = nil, nil
    end
    if (not w or w <= 0) or (db.w ~= nil and (not tonumber(db.w) or tonumber(db.w) <= 0)) then
      db.w = nil
    end
    if (not h or h <= 0) or (db.h ~= nil and (not tonumber(db.h) or tonumber(db.h) <= 0)) then
      db.h = nil
    end
    DefaultAnchor(f)
  end
  local scale = Clamp(db.scale or 1, 0.8, 1.4)
  if f.SetScale then
    f:SetScale(scale)
  end
  ClampFrameToScreen(f)
  ApplyOpacity()
end

function PC:ResetMiniPosition()
  return self:ResetMiniTracker()
end

function PC:ResetMiniTracker()
  local db = self:GetMiniDB()
  if db then
    db.x, db.y, db.w, db.h, db.anchor = nil, nil, nil, nil, nil
    db.collapsed = true
    db.minimized = false
    db.enabled = true
  end
  -- CreateMini is idempotent and fills in any piece a failed attempt left out.
  local okCreate, errCreate = pcall(CreateMini)
  if not okCreate then
    LogMiniError("mini:reset:create", errCreate)
    ChatLine("|cffd4af37[Codex]|r tracker build failed: " .. tostring(errCreate))
  end
  local f = mini.frame
  if f then
    if f.SetSize then
      f:SetSize(DEFAULT_W, DEFAULT_H)
    end
    pcall(DefaultAnchor, f)
    if f.SetClampedToScreen then
      pcall(f.SetClampedToScreen, f, true)
    end
    f:Show()
  end
  if self.RefreshMiniTracker then
    local ok, err = pcall(self.RefreshMiniTracker, self)
    if not ok then
      LogMiniError("mini:reset:refresh", err)
    end
  end
  if self.UpdateMiniVisibility then
    pcall(self.UpdateMiniVisibility, self)
  end
  if f and f.Show then
    if f.SetAlpha then f:SetAlpha(1) end
    f:Show()
  end
  return f
end

function PC:UpdateMiniVisibility()
  local f = mini.frame
  if not f then
    return
  end
  local db = self:GetMiniDB() or {}
  if db.enabled == false then
    f:Hide()
    return
  end
  if db.hideInCombat and InCombat() then
    f:Hide()
    return
  end
  if db.hideInInstances and InInstance() then
    f:Hide()
    return
  end
  f:Show()
end

local function SetLocked(locked)
  local f = mini.frame
  if not f then
    return
  end
  if f.SetMovable then
    f:SetMovable(not locked)
  end
  if f.SetResizable then
    pcall(f.SetResizable, f, false)
  end
  if mini.title then
    if locked then
      if mini.title.RegisterForDrag then
        mini.title:RegisterForDrag()
      end
    else
      if mini.title.RegisterForDrag then
        mini.title:RegisterForDrag("LeftButton")
      end
    end
  end
  if mini.grip then
    if locked then
      mini.grip:Hide()
    else
      mini.grip:Show()
    end
  end
  if mini.lock and mini.lock.label then
    mini.lock.label:SetText(locked and "L" or "o")
    if locked then
      mini.lock.label:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
    else
      mini.lock.label:SetTextColor(SUB.r, SUB.g, SUB.b)
    end
  end
end

local function OpenMain()
  if PC.ShowUI then
    PC:ShowUI()
  elseif PC.ToggleUI then
    PC:ToggleUI()
  end
end

local function Fit(fs, text, width, wrap)
  if PC.FitFontString then
    return PC:FitFontString(fs, text, width, wrap)
  end
  if fs then
    fs:SetText(text or "")
  end
  return text or ""
end


local function OpenGuildTab()
  if PC.ShowUI then
    PC:ShowUI()
  else
    OpenMain()
  end
  if PC.OpenTab then
    PC:OpenTab("guild")
  end
end

local function StyleMiniPill(btn, on)
  if not btn then
    return
  end
  if on then
    Paint(btn.bg, { r = 0.12, g = 0.22, b = 0.16 }, 1)
    if btn.label then
      btn.label:SetTextColor(EMERALD.r, EMERALD.g, EMERALD.b)
    end
  else
    Paint(btn.bg, { r = 0.16, g = 0.16, b = 0.18 }, 1)
    if btn.label then
      btn.label:SetTextColor(SUB.r, SUB.g, SUB.b)
    end
  end
end

-- Header control: 16px round button. kind is "open", "min", "max", or "close".
-- Glyphs are drawn from solid textures so no font or icon file is needed.
local HOVER_RED = { r = 0.92, g = 0.36, b = 0.36 }
local function MakeHeaderButton(parent, name, kind, tipTitle, tipText, onClick)
  local b = CreateFrame("Button", name, parent)
  b:SetSize(16, 16)
  if b.SetFrameLevel and parent.GetFrameLevel then
    pcall(b.SetFrameLevel, b, (parent:GetFrameLevel() or 1) + 2)
  end
  b.kind = kind
  b.bg = b:CreateTexture(nil, "BACKGROUND")
  b.bg:SetAllPoints()
  Paint(b.bg, { r = 0.16, g = 0.16, b = 0.18 }, 1)
  if PC.ApplyCircleMask then
    pcall(PC.ApplyCircleMask, b.bg, b)
  end
  b.glyphs = {}
  local function bar(w, h, x, y)
    local t = b:CreateTexture(nil, "ARTWORK")
    Paint(t, SUB, 1)
    t:SetSize(w, h)
    t:SetPoint("CENTER", b, "CENTER", x or 0, y or 0)
    b.glyphs[#b.glyphs + 1] = t
    return t
  end
  if kind == "open" then
    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetSize(12, 12)
    b.icon:SetPoint("CENTER", b, "CENTER", 0, 0)
    b.icon:SetTexture("Interface\\Icons\\Trade_Alchemy")
    b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    if PC.ApplyCircleMask then
      pcall(PC.ApplyCircleMask, b.icon, b)
    end
  elseif kind == "min" then
    bar(8, 2, 0, -1)
  elseif kind == "max" then
    -- Square outline.
    bar(8, 1.5, 0, 3.25)
    bar(8, 1.5, 0, -3.25)
    bar(1.5, 8, -3.25, 0)
    bar(1.5, 8, 3.25, 0)
  elseif kind == "close" then
    -- Two diagonal Line regions. Falls back to a plain "x" label.
    local okX = pcall(function()
      local function diag(x1, y1, x2, y2)
        local l = b:CreateLine(nil, "ARTWORK")
        l:SetTexture(SOLID)
        l:SetVertexColor(SUB.r, SUB.g, SUB.b, 1)
        l:SetThickness(2)
        l:SetStartPoint("CENTER", b, x1, y1)
        l:SetEndPoint("CENTER", b, x2, y2)
        b.glyphs[#b.glyphs + 1] = l
      end
      diag(-3.5, 3.5, 3.5, -3.5)
      diag(-3.5, -3.5, 3.5, 3.5)
    end)
    if not okX or not b.CreateLine then
      for i = 1, #b.glyphs do
        pcall(b.glyphs[i].Hide, b.glyphs[i])
      end
      b.glyphs = {}
      b.label = FS(b, "GameFontHighlightSmall", 11)
      b.label:SetPoint("CENTER", b, "CENTER", 0, 1)
      b.label:SetText("x")
      b.label:SetTextColor(SUB.r, SUB.g, SUB.b)
    end
  end
  local function tint(color)
    for i = 1, #b.glyphs do
      b.glyphs[i]:SetVertexColor(color.r, color.g, color.b, 1)
    end
    if b.label then
      b.label:SetTextColor(color.r, color.g, color.b)
    end
  end
  b:SetScript("OnClick", function(self)
    if GameTooltip then GameTooltip:Hide() end
    local ok, err = pcall(onClick, self)
    if not ok then
      LogMiniError("mini:" .. tostring(kind), err)
    end
  end)
  b:SetScript("OnEnter", function(self)
    tint(kind == "close" and HOVER_RED or TEXT)
    Paint(self.bg, { r = 0.24, g = 0.24, b = 0.27 }, 1)
    if GameTooltip then
      GameTooltip:SetOwner(self, "ANCHOR_LEFT")
      GameTooltip:AddLine(tipTitle, GOLD.r, GOLD.g, GOLD.b)
      if tipText then
        GameTooltip:AddLine(tipText, 0.56, 0.56, 0.60, true)
      end
      GameTooltip:Show()
    end
  end)
  b:SetScript("OnLeave", function(self)
    tint(SUB)
    Paint(self.bg, { r = 0.16, g = 0.16, b = 0.18 }, 1)
    if GameTooltip then GameTooltip:Hide() end
  end)
  return b
end

local MINI_STATUS_PILLS = {
  { id = "dungeon", label = "Dungeon", short = "Dungeon", name = "PhilosophersCodexMiniStatusDungeon", tip = "Looking for dungeon." },
  { id = "questing", label = "Questing", short = "Questing", name = "PhilosophersCodexMiniStatusQuesting", tip = "Questing buddy." },
  { id = "help", label = "Need help", short = "Help", name = "PhilosophersCodexMiniStatusHelp", tip = "Need help." },
  { id = "busy", label = "Not looking", short = "Hide", name = "PhilosophersCodexMiniStatusBusy", tip = "Not looking. You stay hidden from group lists." },
}

local function TryMiniTexture(tex, path)
  if not tex or not path then
    return false
  end
  if PC.TrySetTexture then
    return PC.TrySetTexture(tex, path) and true or false
  end
  if not tex.SetTexture then
    return false
  end
  local ok, result = pcall(tex.SetTexture, tex, path)
  if not ok or result == false then
    return false
  end
  if tex.GetTexture then
    local got = tex:GetTexture()
    return got and got ~= "" and got ~= 0
  end
  return true
end

local function MeasureName(text, fs)
  if fs and fs.SetText and fs.GetStringWidth then
    fs:SetText(text or "")
    local ok, w = pcall(fs.GetStringWidth, fs)
    if ok and type(w) == "number" and w > 0 then
      return w
    end
  end
  return (#(text or "") * 6) + 2
end

-- Pack a list of peers into at most maxLines, with a "+N more" overflow.
-- peers = { { name=, classFile=, demo=, rec= }, ... }
function PC:PlanMiniPeerNames(peers, width, maxLines, measure)
  peers = peers or {}
  width = math.max(40, tonumber(width) or 200)
  maxLines = tonumber(maxLines) or 2
  if maxLines < 1 then maxLines = 1 end
  measure = measure or function(text) return (#(text or "") * 6) + 2 end
  local gap = 6

  local function canPlace(count, overflowText)
    local line, x = 1, 0
    for i = 1, count do
      local name = (peers[i] and peers[i].name) or "?"
      local w = math.max(12, measure(name))
      if x > 0 and (x + w) > width then
        line = line + 1
        x = 0
      end
      if line > maxLines then
        return false
      end
      x = x + w + gap
    end
    if overflowText and overflowText ~= "" then
      local mw = math.max(20, measure(overflowText))
      if x > 0 and (x + mw) > width then
        line = line + 1
        x = 0
      end
      if line > maxLines then
        return false
      end
    end
    return true
  end

  local shown = #peers
  local overflow = 0
  if not canPlace(shown, nil) then
    shown = 0
    overflow = #peers
    for k = #peers - 1, 0, -1 do
      local ov = #peers - k
      local label = "+" .. tostring(ov) .. " more"
      if canPlace(k, label) then
        shown = k
        overflow = ov
        break
      end
    end
  end

  local items = {}
  local line, x = 1, 0
  local lineH = 12
  for i = 1, shown do
    local rec = peers[i]
    local name = (rec and rec.name) or "?"
    local w = math.max(12, measure(name))
    if x > 0 and (x + w) > width then
      line = line + 1
      x = 0
    end
    local r, g, b = 0.95, 0.95, 0.97
    if rec and rec.classFile and self.ClassColor then
      r, g, b = self:ClassColor(rec.classFile)
    elseif rec and rec.r then
      r, g, b = rec.r, rec.g, rec.b
    end
    items[#items + 1] = {
      name = name,
      classFile = rec and rec.classFile or nil,
      demo = rec and rec.demo and true or false,
      rec = rec and rec.rec or rec,
      r = r, g = g, b = b,
      x = x,
      line = line,
      y = (line - 1) * (lineH + 1),
      w = w,
    }
    x = x + w + gap
  end
  local overflowItem = nil
  if overflow > 0 then
    local label = "+" .. tostring(overflow) .. " more"
    local mw = math.max(20, measure(label))
    if x > 0 and (x + mw) > width then
      line = line + 1
      x = 0
    end
    overflowItem = {
      name = label,
      overflow = overflow,
      x = x,
      line = line,
      y = (line - 1) * (lineH + 1),
      w = mw,
    }
  end
  local linesUsed = 0
  if #items > 0 then
    linesUsed = items[#items].line
  end
  if overflowItem and overflowItem.line > linesUsed then
    linesUsed = overflowItem.line
  end
  return {
    items = items,
    overflow = overflow,
    overflowItem = overflowItem,
    lines = linesUsed,
    height = (linesUsed > 0) and (linesUsed * (lineH + 1)) or 0,
    width = width,
  }
end

local PORTRAIT_FRAME = 60
local PORTRAIT_INSET = 2
local STATS_H = 26
local PEER_ROW_H = 16
local MAX_PEER_ROWS = 6

-- Class- and role-relevant stats from the live API. Every call is guarded;
-- a stat whose API is missing or returns nil is left out.
local function SafeNum(fn, ...)
  if type(fn) ~= "function" then
    return nil
  end
  local ok, a, b, c, d = pcall(fn, ...)
  if not ok then
    return nil
  end
  return a, b, c, d
end

local function MaxSchool(fn)
  if type(fn) ~= "function" then
    return nil
  end
  local best = nil
  for school = 2, 7 do
    local v = SafeNum(fn, school)
    v = tonumber(v)
    if v and (not best or v > best) then
      best = v
    end
  end
  return best
end

local function EffectiveStat(index)
  if not UnitStat then
    return nil
  end
  local base, stat = SafeNum(UnitStat, "player", index)
  stat = tonumber(stat) or tonumber(base)
  return stat
end

local function FormatInt(n)
  n = tonumber(n)
  if not n then
    return nil
  end
  n = math.floor(n + 0.5)
  local s = tostring(n)
  local out = s:reverse():gsub("(%d%d%d)", "%1,"):reverse()
  if out:sub(1, 1) == "," then
    out = out:sub(2)
  end
  return out
end

local function FormatPct(n)
  n = tonumber(n)
  if not n then
    return nil
  end
  return string.format("%.1f%%", n)
end

local STAT_GETTERS = {
  spell = function()
    local v = MaxSchool(GetSpellBonusDamage)
    return v and FormatInt(v)
  end,
  heal = function()
    local v = tonumber((SafeNum(GetSpellBonusHealing)))
    return v and FormatInt(v)
  end,
  scrit = function()
    local v = MaxSchool(GetSpellCritChance)
    return v and FormatPct(v)
  end,
  shit = function()
    local v = nil
    if GetCombatRatingBonus and CR_HIT_SPELL then
      v = tonumber((SafeNum(GetCombatRatingBonus, CR_HIT_SPELL)))
    end
    if (not v or v == 0) and GetSpellHitModifier then
      local m = tonumber((SafeNum(GetSpellHitModifier)))
      if m then v = m end
    end
    return v and FormatPct(v)
  end,
  int = function() return FormatInt(EffectiveStat(4)) end,
  spi = function() return FormatInt(EffectiveStat(5)) end,
  sta = function() return FormatInt(EffectiveStat(3)) end,
  agi = function() return FormatInt(EffectiveStat(2)) end,
  str = function() return FormatInt(EffectiveStat(1)) end,
  mana = function()
    if not UnitPowerMax then return nil end
    local v = tonumber((SafeNum(UnitPowerMax, "player", 0)))
    if not v or v <= 0 then return nil end
    return FormatInt(v)
  end,
  armor = function()
    if not UnitArmor then return nil end
    local base, eff = SafeNum(UnitArmor, "player")
    return FormatInt(tonumber(eff) or tonumber(base))
  end,
  ap = function()
    if not UnitAttackPower then return nil end
    local base, pos, neg = SafeNum(UnitAttackPower, "player")
    base = tonumber(base)
    if not base then return nil end
    return FormatInt(base + (tonumber(pos) or 0) + (tonumber(neg) or 0))
  end,
  crit = function()
    local v = tonumber((SafeNum(GetCritChance)))
    return v and FormatPct(v)
  end,
}

local STAT_LABELS = {
  spell = "Spell Pwr", heal = "Healing", scrit = "Crit", shit = "Hit", int = "Int", spi = "Spirit",
  sta = "Stam", agi = "Agi", str = "Str", mana = "Mana", armor = "Armor", ap = "AP", crit = "Crit",
}

-- Ordered candidates per class/role; the first four that resolve are shown.
local function StatPlan(classFile, role)
  classFile = string.upper(tostring(classFile or ""))
  role = tostring(role or "dps")
  if role == "healer" then
    return { "heal", "int", "spi", "mana", "scrit" }
  end
  if role == "tank" then
    return { "armor", "sta", "agi", "str", "ap" }
  end
  if classFile == "MAGE" or classFile == "WARLOCK" or classFile == "PRIEST" then
    return { "spell", "scrit", "int", "shit", "mana" }
  end
  if classFile == "DRUID" or classFile == "SHAMAN" then
    return { "spell", "scrit", "int", "mana", "spi" }
  end
  if classFile == "HUNTER" or classFile == "ROGUE" then
    return { "ap", "crit", "agi", "sta" }
  end
  return { "ap", "crit", "str", "sta" }
end

function PC:GetMiniStats(classFile, role)
  if classFile == nil then
    classFile = self.GetClassFile and self:GetClassFile() or nil
  end
  if role == nil then
    role = self.GetSocialRole and self:GetSocialRole() or "dps"
  end
  local out = {}
  local plan = StatPlan(classFile, role)
  for i = 1, #plan do
    local key = plan[i]
    local getter = STAT_GETTERS[key]
    local ok, value = pcall(getter)
    if ok and value ~= nil and value ~= "" then
      out[#out + 1] = { key = key, label = STAT_LABELS[key] or key, value = tostring(value) }
      if #out >= 4 then
        break
      end
    end
  end
  return out
end

-- ---------------------------------------------------------------------------
-- Full name (1.21.0). WoW Forever characters have a first and a last name.
-- The API for the surname isn't documented yet, so try every source and
-- keep the first that adds a surname. /codex mini debug prints what each
-- source returned.
-- ---------------------------------------------------------------------------

local function CleanName(v, realm)
  if type(v) ~= "string" or v == "" then
    return nil
  end
  if realm and realm ~= "" then
    v = v:gsub("%-" .. realm:gsub("%p", "%%%0") .. "$", "")
  end
  v = v:gsub("%c", " "):gsub("%s+", " "):gsub("^%s+", ""):gsub("%s+$", "")
  return v
end

function PC:GetPlayerFullName()
  if self._fullName then
    return self._fullName
  end
  local first = (UnitName and UnitName("player")) or "You"
  -- No surname yet: retry at most every 10 seconds (the roster loads late).
  local now = GetTime and GetTime() or 0
  if self._nameTriedAt and (now - self._nameTriedAt) < 10 then
    return first
  end
  self._nameTriedAt = now
  local realm
  if GetNormalizedRealmName then
    local ok, r = pcall(GetNormalizedRealmName)
    if ok then realm = r end
  end
  local tried = {}
  local found
  local function full(src, v)
    v = CleanName(v, realm)
    tried[#tried + 1] = src .. "=" .. tostring(v)
    if not found and v and #v > #first and v:sub(1, #first) == first and v:sub(#first + 1, #first + 1):match("[%s%p]") then
      local rest = v:sub(#first + 2):gsub("^[%s%p]+", "")
      if rest ~= "" and rest ~= realm then
        found = first .. " " .. rest
      end
    end
  end
  local function surname(src, v)
    v = CleanName(v, realm)
    tried[#tried + 1] = src .. "=" .. tostring(v)
    if not found and v and v ~= "" and v ~= first and v ~= realm then
      found = first .. " " .. v
    end
  end
  local function try(fn, ...)
    if type(fn) ~= "function" then
      return nil
    end
    local ok, a = pcall(fn, ...)
    if ok then
      return a
    end
    return nil
  end
  local info = rawget(_G, "C_PlayerInfo")
  if type(info) == "table" then
    for _, k in ipairs({ "GetPlayerSurname", "GetSurname", "GetUnitSurname", "GetPlayerFullName", "GetFullName" }) do
      local v = try(info[k], "player")
      if k:find("Surname") then surname("C_PlayerInfo." .. k, v) else full("C_PlayerInfo." .. k, v) end
    end
  end
  surname("UnitSurname", try(rawget(_G, "UnitSurname"), "player"))
  full("GetUnitName", try(rawget(_G, "GetUnitName"), "player", true))
  full("UnitNameUnmodified", try(rawget(_G, "UnitNameUnmodified"), "player"))
  full("UnitPVPName", try(rawget(_G, "UnitPVPName"), "player"))
  -- The guild roster lists full names; match our own GUID.
  if not found and IsInGuild and IsInGuild() and GetNumGuildMembers and GetGuildRosterInfo then
    local me = UnitGUID and UnitGUID("player") or nil
    local okN, total = pcall(GetNumGuildMembers)
    for i = 1, (okN and tonumber(total) or 0) do
      local r = { pcall(GetGuildRosterInfo, i) }
      if r[1] and r[18] and me and r[18] == me then
        full("roster", r[2])
        break
      end
    end
  end
  self._nameSources = tried
  if found then
    self._fullName = found
    return found
  end
  return first
end

function PC:GetNameSources()
  return self._nameSources or {}
end

local function EnsurePlayerCard()
  if mini.card then
    return mini.card
  end
  local parent = mini.frame
  local c = CreateFrame("Frame", "PhilosophersCodexMiniCard", parent)
  c:SetPoint("TOPLEFT", parent, "TOPLEFT", NAMECARD_PAD, -TITLE_H)
  c:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -NAMECARD_PAD, -TITLE_H)
  c:SetHeight(120)

  -- Square ID-card portrait in a thin gold frame. No mask, no animation.
  c.ring = c:CreateTexture(nil, "ARTWORK", nil, 0)
  c.ring:SetSize(PORTRAIT_FRAME, PORTRAIT_FRAME)
  c.ring:SetPoint("TOPLEFT", c, "TOPLEFT", 2, -4)
  Paint(c.ring, GOLD, 1)
  c.portraitBack = c:CreateTexture(nil, "ARTWORK", nil, 1)
  c.portraitBack:SetPoint("TOPLEFT", c.ring, "TOPLEFT", PORTRAIT_INSET, -PORTRAIT_INSET)
  c.portraitBack:SetPoint("BOTTOMRIGHT", c.ring, "BOTTOMRIGHT", -PORTRAIT_INSET, PORTRAIT_INSET)
  Paint(c.portraitBack, { r = 0.04, g = 0.03, b = 0.03 }, 1)
  c.portrait = c:CreateTexture(nil, "ARTWORK", nil, 2)
  c.portrait:SetPoint("TOPLEFT", c.ring, "TOPLEFT", PORTRAIT_INSET, -PORTRAIT_INSET)
  c.portrait:SetPoint("BOTTOMRIGHT", c.ring, "BOTTOMRIGHT", -PORTRAIT_INSET, PORTRAIT_INSET)
  c.portrait:SetTexCoord(0.1, 0.9, 0.1, 0.9)
  c.portraitShape = "square"

  c.name = FS(c, "GameFontHighlight", 14)
  c.name:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
  c.guild = FS(c, "GameFontNormalSmall", 10)
  c.guild:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
  c.sub = FS(c, "GameFontNormalSmall", 10)
  c.sub:SetTextColor(SUB.r, SUB.g, SUB.b)
  c.rank = FS(c, "GameFontNormalSmall", 10)
  c.rank:SetTextColor(SUB.r, SUB.g, SUB.b)

  c.role = CreateFrame("Button", "PhilosophersCodexMiniRole", c)
  c.role:SetSize(16, 16)
  c.role.icon = c.role:CreateTexture(nil, "ARTWORK")
  c.role.icon:SetSize(14, 14)
  c.role.icon:SetPoint("CENTER", c.role, "CENTER", 0, 0)
  c.role.letter = FS(c.role, "GameFontNormalSmall", 9)
  c.role.letter:SetPoint("CENTER", c.role, "CENTER", 0, 0)
  c.role:SetScript("OnClick", function()
    if PC.CycleSocialRole then
      PC:CycleSocialRole()
    end
  end)
  c.role:SetScript("OnEnter", function(self)
    if GameTooltip then
      GameTooltip:SetOwner(self, "ANCHOR_LEFT")
      GameTooltip:AddLine("Your role", GOLD.r, GOLD.g, GOLD.b)
      GameTooltip:AddLine("Tap to cycle the roles your class can play.", 0.56, 0.56, 0.60, true)
      GameTooltip:Show()
    end
  end)
  c.role:SetScript("OnLeave", function()
    if GameTooltip then GameTooltip:Hide() end
  end)

  -- 1.20.0: "Can help" toggle. Guildmates on Need help see you as a helper.
  c.help = CreateFrame("Button", "PhilosophersCodexMiniCanHelp", c)
  c.help:SetSize(64, 16)
  c.help.bg = c.help:CreateTexture(nil, "BACKGROUND")
  c.help.bg:SetAllPoints()
  Paint(c.help.bg, { r = 0.16, g = 0.16, b = 0.18 }, 1)
  if PC.BuildRoundFill then
    pcall(function()
      c.help.round = PC:BuildRoundFill(c.help, { r = 0.16, g = 0.16, b = 0.18 }, 1, "BACKGROUND", 1)
      PC:LayoutRoundFill(c.help.round, c.help, 8, 0)
      c.help.bg:Hide()
    end)
  end
  c.help.label = FS(c.help, "GameFontNormalSmall", 10)
  c.help.label:SetPoint("CENTER", c.help, "CENTER", 0, 0)
  if c.help.label.SetJustifyH then c.help.label:SetJustifyH("CENTER") end
  c.help.label:SetText("Can help")
  c.help:SetScript("OnClick", function()
    if PC.SetCanHelp and PC.GetCanHelp then
      PC:SetCanHelp(not (PC.GetDB and PC:GetDB() and PC:GetDB().guildCanHelp))
    end
    if PC.RefreshMiniTracker then PC:RefreshMiniTracker() end
    if PC.Refresh then PC:Refresh() end
  end)
  c.help:SetScript("OnEnter", function(self)
    if GameTooltip then
      GameTooltip:SetOwner(self, "ANCHOR_LEFT")
      GameTooltip:AddLine("Can help", GOLD.r, GOLD.g, GOLD.b)
      GameTooltip:AddLine("Turn this on to show up for guildmates who pick Need help. Works with any status.", 0.56, 0.56, 0.60, true)
      GameTooltip:Show()
    end
  end)
  c.help:SetScript("OnLeave", function()
    if GameTooltip then GameTooltip:Hide() end
  end)

  c.statusLabel = FS(c, "GameFontNormalSmall", 10)
  c.statusLabel:SetText("Status")
  c.statusLabel:SetTextColor(GOLD.r, GOLD.g, GOLD.b)

  c.pills = {}
  c.pillRow = CreateFrame("Frame", nil, c)
  c.pillRow:SetHeight(18)
  for i = 1, #MINI_STATUS_PILLS do
    local def = MINI_STATUS_PILLS[i]
    local b = CreateFrame("Button", def.name, c.pillRow)
    b:SetHeight(18)
    b.bg = b:CreateTexture(nil, "BACKGROUND")
    b.bg:SetAllPoints()
    Paint(b.bg, { r = 0.16, g = 0.16, b = 0.18 }, 1)
    b.label = FS(b, "GameFontNormalSmall", 10)
    b.label:SetPoint("CENTER", b, "CENTER", 0, 0)
    if b.label.SetJustifyH then
      b.label:SetJustifyH("CENTER")
    end
    b.label:SetText(def.short)
    b.statusId = def.id
    b.def = def
    -- OnClick only, never hide the row on mousedown. Same contract as the Guild tab pills.
    b:SetScript("OnClick", function()
      if PC.SetSocialStatus then
        PC:SetSocialStatus(def.id)
      end
    end)
    b:SetScript("OnEnter", function(self)
      if GameTooltip then
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        local title = (PC.StatusLabel and PC:StatusLabel(def.id)) or def.label
        GameTooltip:AddLine(title, GOLD.r, GOLD.g, GOLD.b)
        GameTooltip:AddLine(def.tip, 0.56, 0.56, 0.60, true)
        GameTooltip:Show()
      end
    end)
    b:SetScript("OnLeave", function()
      if GameTooltip then GameTooltip:Hide() end
    end)
    c.pills[def.id] = b
    c.pills[i] = b
  end

  -- Compact stats strip: up to four cells of value over label.
  c.stats = CreateFrame("Frame", "PhilosophersCodexMiniStats", c)
  c.stats:SetHeight(STATS_H)
  c.stats.bg = c.stats:CreateTexture(nil, "BACKGROUND")
  c.stats.bg:SetAllPoints()
  Paint(c.stats.bg, { r = 0.0, g = 0.0, b = 0.0 }, 0.28)
  c.statCells = {}
  for i = 1, 4 do
    local cell = CreateFrame("Frame", nil, c.stats)
    cell:SetHeight(STATS_H)
    cell.value = FS(cell, "GameFontHighlightSmall", 11)
    cell.value:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
    if cell.value.SetJustifyH then cell.value:SetJustifyH("CENTER") end
    cell.label = FS(cell, "GameFontDisableSmall", 9)
    cell.label:SetTextColor(SUB.r, SUB.g, SUB.b)
    if cell.label.SetJustifyH then cell.label:SetJustifyH("CENTER") end
    cell:Hide()
    c.statCells[i] = cell
  end

  c.context = CreateFrame("Button", "PhilosophersCodexMiniContext", c)
  c.context:SetHeight(14)
  c.context.label = FS(c.context, "GameFontNormalSmall", 10)
  c.context.label:SetPoint("LEFT", c.context, "LEFT", 0, 0)
  c.context.label:SetPoint("RIGHT", c.context, "RIGHT", 0, 0)
  c.context.label:SetTextColor(SUB.r, SUB.g, SUB.b)
  c.context:SetScript("OnClick", function()
    OpenGuildTab()
  end)

  c.matches = CreateFrame("Button", "PhilosophersCodexMiniMatches", c)
  c.matches:SetHeight(14)
  c.matches.label = FS(c.matches, "GameFontNormalSmall", 10)
  c.matches.label:SetPoint("LEFT", c.matches, "LEFT", 0, 0)
  c.matches.label:SetPoint("RIGHT", c.matches, "RIGHT", 0, 0)
  c.matches.label:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
  c.matches:SetScript("OnClick", function()
    OpenGuildTab()
  end)

  -- Vertical guildmate list (expanded only).
  c.names = CreateFrame("Frame", "PhilosophersCodexMiniPeerNames", c)
  c.names:SetHeight(PEER_ROW_H)
  c.nameButtons = {}
  c.moreBtn = CreateFrame("Button", "PhilosophersCodexMiniPeerMore", c.names)
  c.moreBtn:SetHeight(14)
  c.moreBtn.label = FS(c.moreBtn, "GameFontNormalSmall", 10)
  c.moreBtn.label:SetPoint("LEFT", c.moreBtn, "LEFT", 0, 0)
  c.moreBtn.label:SetTextColor(EMERALD.r, EMERALD.g, EMERALD.b)
  c.moreBtn:SetScript("OnClick", function()
    OpenGuildTab()
  end)
  c.moreBtn:Hide()

  c.nudge = CreateFrame("Button", "PhilosophersCodexMiniNudge", c)
  c.nudge:SetHeight(14)
  c.nudge.label = FS(c.nudge, "GameFontNormalSmall", 10)
  c.nudge.label:SetPoint("LEFT", c.nudge, "LEFT", 0, 0)
  c.nudge.label:SetPoint("RIGHT", c.nudge, "RIGHT", 0, 0)
  c.nudge.label:SetText("Still looking?")
  c.nudge.label:SetTextColor(AMBER.r, AMBER.g, AMBER.b)
  c.nudge:SetScript("OnClick", function()
    if PC.AckSocialStatus then
      PC:AckSocialStatus()
    end
  end)
  c.nudge:SetScript("OnEnter", function(self)
    if GameTooltip then
      GameTooltip:SetOwner(self, "ANCHOR_LEFT")
      GameTooltip:AddLine("Still looking?", GOLD.r, GOLD.g, GOLD.b)
      GameTooltip:AddLine("Your status has been on for a while, or you entered a dungeon or group. Tap to keep it, or pick Not looking above.", 0.56, 0.56, 0.60, true)
      GameTooltip:Show()
    end
  end)
  c.nudge:SetScript("OnLeave", function()
    if GameTooltip then GameTooltip:Hide() end
  end)
  c.nudge:Hide()

  -- Dungeon pick pool (filled by LayoutDungeonPicks) and its empty line.
  c.picks = {}
  c.picksEmpty = FS(c, "GameFontNormalSmall", 10)
  c.picksEmpty:SetTextColor(SUB.r, SUB.g, SUB.b)
  c.picksEmpty:Hide()

  mini.card = c
  return c
end

local function ShortDungeonName(name)
  name = tostring(name or "?")
  name = name:gsub("^Scarlet Monastery:%s*", "SM ")
  name = name:gsub("^The ", "")
  return name
end
PC.ShortDungeonName = function(_, name) return ShortDungeonName(name) end

local function DungeonNameById(id)
  local d = PC.FindDungeon and PC:FindDungeon(id) or nil
  return ShortDungeonName((d and d.name) or id)
end

local function AcquirePeerRow(c, i)
  local b = c.nameButtons[i]
  if b then
    return b
  end
  b = CreateFrame("Button", "PhilosophersCodexMiniPeerName" .. tostring(i), c.names)
  b:SetHeight(PEER_ROW_H)
  b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  b.roleIcon = b:CreateTexture(nil, "ARTWORK")
  b.roleIcon:SetSize(12, 12)
  b.roleIcon:SetPoint("LEFT", b, "LEFT", 0, 0)
  b.roleLetter = FS(b, "GameFontNormalSmall", 9)
  b.roleLetter:SetPoint("CENTER", b.roleIcon, "CENTER", 0, 0)
  b.label = FS(b, "GameFontNormalSmall", 10)
  b.level = FS(b, "GameFontHighlightSmall", 10)
  b.level:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
  if b.level.SetJustifyH then b.level:SetJustifyH("RIGHT") end
  b.info = FS(b, "GameFontDisableSmall", 9)
  b.info:SetTextColor(SUB.r, SUB.g, SUB.b)
  b:SetScript("OnClick", function(self, button)
    if self.demo or not self.miniPeerName then
      OpenGuildTab()
      return
    end
    local right = (button == "RightButton") or (IsShiftKeyDown and IsShiftKeyDown())
    if right and PC.InvitePeer then
      PC:InvitePeer(self.miniPeerName)
    elseif PC.WhisperPeer then
      PC:WhisperPeer(self.miniPeerName)
    else
      OpenGuildTab()
    end
  end)
  b:SetScript("OnEnter", function(self)
    if not GameTooltip then
      return
    end
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    local r, g, bl = self.r or GOLD.r, self.g or GOLD.g, self.b or GOLD.b
    GameTooltip:AddLine(self.miniPeerName or "Guildmate", r, g, bl)
    if self.demo then
      GameTooltip:AddLine("Demo player. Opens the Guild tab.", 0.56, 0.56, 0.60, true)
    else
      GameTooltip:AddLine("Click to whisper. Right-click to invite.", 0.56, 0.56, 0.60, true)
    end
    GameTooltip:Show()
  end)
  b:SetScript("OnLeave", function()
    if GameTooltip then GameTooltip:Hide() end
  end)
  c.nameButtons[i] = b
  return b
end

local STATUS_SHORT = { dungeon = "Dungeon", questing = "Questing", help = "Help", busy = "Away" }

-- Plan the vertical list: at most maxRows rows, then a "+N more" row.
function PC:PlanMiniPeerList(peers, maxRows)
  peers = peers or {}
  maxRows = tonumber(maxRows) or MAX_PEER_ROWS
  if maxRows < 1 then maxRows = 1 end
  local shown = math.min(#peers, maxRows)
  local overflow = #peers - shown
  local rows = {}
  for i = 1, shown do
    rows[i] = peers[i]
  end
  local height = shown * PEER_ROW_H
  if overflow > 0 then
    height = height + 14
  end
  return { rows = rows, shown = shown, overflow = overflow, height = height }
end

local function HidePeerList(c)
  if c.names then c.names:Hide() end
  if c.moreBtn then c.moreBtn:Hide() end
  if c.nameButtons then
    for i = 1, #c.nameButtons do
      c.nameButtons[i]:Hide()
    end
  end
end

local function LayoutPeerList(c, width, compact)
  if not c.names then
    return 0
  end
  if compact then
    HidePeerList(c)
    return 0
  end
  local cards = PC.GetGuildmateCards and PC:GetGuildmateCards() or {}
  if #cards == 0 then
    HidePeerList(c)
    mini._peerPlan = { items = {}, overflow = 0, lines = 0, rows = 0, height = 0 }
    return 0
  end
  local plan = PC:PlanMiniPeerList(cards, MAX_PEER_ROWS)
  local myStatus = PC.GetSocialStatus and PC:GetSocialStatus() or "busy"
  width = math.max(80, width)
  local iconW, gap, levelW = 12, 4, 28
  local rest = width - iconW - gap - levelW - gap
  local nameW = math.max(30, math.floor(rest * 0.5))
  local infoW = math.max(20, rest - nameW - gap)
  local items = {}
  c.names:Show()
  c.names:SetHeight(math.max(PEER_ROW_H, plan.height))
  for i = 1, math.max(#c.nameButtons, plan.shown) do
    local rec = plan.rows[i]
    local b = c.nameButtons[i]
    if not rec then
      if b then b:Hide() end
    else
      b = AcquirePeerRow(c, i)
      b:ClearAllPoints()
      b:SetPoint("TOPLEFT", c.names, "TOPLEFT", 0, -((i - 1) * PEER_ROW_H))
      b:SetSize(width, PEER_ROW_H)
      local r, g, bl = 0.95, 0.95, 0.97
      if rec.classFile and PC.ClassColor then
        r, g, bl = PC:ClassColor(rec.classFile)
      end
      b.miniPeerName = rec.name
      b.demo = rec.demo and true or false
      b.r, b.g, b.b = r, g, bl
      if PC.ApplyRoleIcon then
        Decor("peer-role-icon", PC.ApplyRoleIcon, b.roleIcon, b.roleLetter, rec.role or "dps")
      end
      b.roleIcon:SetSize(12, 12)
      b.label:ClearAllPoints()
      b.label:SetPoint("LEFT", b, "LEFT", iconW + gap, 0)
      b.label:SetWidth(nameW)
      b.label:SetTextColor(r, g, bl)
      local display = tostring(rec.name or "?")
      if rec.demo then
        display = display .. " (Demo)"
      end
      Fit(b.label, display, nameW, false)
      b.level:ClearAllPoints()
      b.level:SetPoint("LEFT", b, "LEFT", iconW + gap + nameW + gap, 0)
      b.level:SetWidth(levelW)
      Fit(b.level, rec.level and tostring(rec.level) or "", levelW, false)
      b.info:ClearAllPoints()
      b.info:SetPoint("LEFT", b, "LEFT", iconW + gap + nameW + gap + levelW + gap, 0)
      b.info:SetWidth(infoW)
      local info = rec.zone or STATUS_SHORT[rec.status or ""] or ""
      if myStatus == "dungeon" then
        -- Show what they want to run: shared picks first, else all of theirs.
        local ids = (type(rec.shared) == "table" and #rec.shared > 0) and rec.shared or rec.dungeons
        if type(ids) == "table" and #ids > 0 then
          local names = {}
          for k = 1, math.min(3, #ids) do
            names[#names + 1] = DungeonNameById(ids[k])
          end
          info = table.concat(names, ", ")
        end
      end
      Fit(b.info, tostring(info), infoW, false)
      b:Show()
      items[#items + 1] = { name = rec.name, demo = rec.demo, line = i }
    end
  end
  if plan.overflow > 0 then
    c.moreBtn:ClearAllPoints()
    c.moreBtn:SetPoint("TOPLEFT", c.names, "TOPLEFT", 0, -(plan.shown * PEER_ROW_H))
    c.moreBtn:SetSize(width, 14)
    Fit(c.moreBtn.label, "+" .. tostring(plan.overflow) .. " more in the Guild tab", width, false)
    c.moreBtn:Show()
  else
    c.moreBtn:Hide()
  end
  mini._peerPlan = { items = items, overflow = plan.overflow, rows = plan.shown, lines = plan.shown, height = plan.height }
  return plan.height
end

function PC:DebugMiniPeerNames()
  local plan = mini._peerPlan or { items = {}, overflow = 0, lines = 0, rows = 0, height = 0 }
  local shown = {}
  for i = 1, #(plan.items or {}) do
    shown[#shown + 1] = plan.items[i].name
  end
  return {
    shown = shown,
    overflow = plan.overflow or 0,
    rows = plan.rows or 0,
    lines = plan.lines or 0,
    height = plan.height or 0,
    vertical = true,
    visible = mini.card and mini.card.names and mini.card.names:IsShown() and true or false,
  }
end

local function LayoutStats(c, inner, top)
  local stats = {}
  local okStats, res = pcall(PC.GetMiniStats, PC)
  if okStats and type(res) == "table" then
    stats = res
  end
  mini._stats = stats
  if #stats == 0 then
    c.stats:Hide()
    for i = 1, #c.statCells do c.statCells[i]:Hide() end
    return 0
  end
  local w = math.max(80, inner - 4)
  c.stats:ClearAllPoints()
  c.stats:SetPoint("TOPLEFT", c, "TOPLEFT", 2, -top)
  c.stats:SetSize(w, STATS_H)
  c.stats:Show()
  local n = #stats
  local cellW = math.floor(w / n)
  for i = 1, #c.statCells do
    local cell = c.statCells[i]
    local st = stats[i]
    if st then
      cell:ClearAllPoints()
      cell:SetPoint("TOPLEFT", c.stats, "TOPLEFT", (i - 1) * cellW, 0)
      cell:SetSize(cellW, STATS_H)
      cell.value:ClearAllPoints()
      cell.value:SetPoint("TOPLEFT", cell, "TOPLEFT", 2, -2)
      cell.value:SetWidth(cellW - 4)
      cell.value:SetHeight(12)
      Fit(cell.value, st.value, cellW - 4, false)
      cell.label:ClearAllPoints()
      cell.label:SetPoint("TOPLEFT", cell, "TOPLEFT", 2, -14)
      cell.label:SetWidth(cellW - 4)
      cell.label:SetHeight(10)
      Fit(cell.label, st.label, cellW - 4, false)
      cell:Show()
    else
      cell:Hide()
    end
  end
  return STATS_H
end

-- ---------------------------------------------------------------------------
-- Dungeon picks (1.18.3): with Dungeon status on, one toggle per dungeon in
-- your level range, shared with the Guild tab and broadcast to the guild.
-- ---------------------------------------------------------------------------

local PICK_H = 18
local PICK_GAP = 3

local function AcquirePick(c, i)
  local b = c.picks[i]
  if b then
    return b
  end
  b = CreateFrame("Button", "PhilosophersCodexMiniDungeon" .. tostring(i), c)
  b:SetHeight(PICK_H)
  b.bg = b:CreateTexture(nil, "BACKGROUND")
  b.bg:SetAllPoints()
  b.label = FS(b, "GameFontNormalSmall", 10)
  b.label:SetPoint("CENTER", b, "CENTER", 0, 0)
  if b.label.SetJustifyH then
    b.label:SetJustifyH("CENTER")
  end
  b:SetScript("OnClick", function(self)
    if self.dungeonId and PC.ToggleSelectedDungeon then
      PC:ToggleSelectedDungeon(self.dungeonId)
    end
  end)
  b:SetScript("OnEnter", function(self)
    if not GameTooltip then
      return
    end
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:AddLine(self.fullName or "Dungeon", GOLD.r, GOLD.g, GOLD.b)
    if self.range and self.range ~= "" then
      GameTooltip:AddLine("Levels " .. tostring(self.range), 0.95, 0.95, 0.97)
    end
    local on = self.dungeonId and PC.IsDungeonSelected and PC:IsDungeonSelected(self.dungeonId)
    GameTooltip:AddLine(on and "Picked. Guildmates see it. Tap to remove." or "Tap to pick. Guildmates see your picks.", 0.56, 0.56, 0.60, true)
    GameTooltip:Show()
  end)
  b:SetScript("OnLeave", function()
    if GameTooltip then GameTooltip:Hide() end
  end)
  c.picks[i] = b
  return b
end

local function HidePicks(c)
  if c.picks then
    for i = 1, #c.picks do
      c.picks[i]:Hide()
    end
  end
  if c.picksEmpty then
    c.picksEmpty:Hide()
  end
end

-- Returns the new y after the picks. Hides everything unless status is dungeon.
local function LayoutDungeonPicks(c, inner, y, status)
  mini._picks = { shown = 0, selected = 0, cols = 0 }
  if status ~= "dungeon" then
    HidePicks(c)
    return y
  end
  local list = PC.GetLevelDungeons and PC:GetLevelDungeons() or {}
  local avail = math.max(60, inner - 8)
  if #list == 0 then
    HidePicks(c)
    c.picksEmpty:ClearAllPoints()
    c.picksEmpty:SetPoint("TOPLEFT", c, "TOPLEFT", 4, -y)
    c.picksEmpty:SetWidth(avail)
    c.picksEmpty:SetHeight(14)
    Fit(c.picksEmpty, "No dungeons in your level range yet", avail, false)
    c.picksEmpty:Show()
    return y + 16
  end
  if c.picksEmpty then
    c.picksEmpty:Hide()
  end
  local cols = (avail >= 300) and 3 or 2
  local chipW = math.floor((avail - PICK_GAP * (cols - 1)) / cols)
  local selected = 0
  for i = 1, #list do
    local d = list[i]
    local b = AcquirePick(c, i)
    local row = math.floor((i - 1) / cols)
    local col = (i - 1) % cols
    b:ClearAllPoints()
    b:SetPoint("TOPLEFT", c, "TOPLEFT", 4 + col * (chipW + PICK_GAP), -(y + row * (PICK_H + PICK_GAP)))
    b:SetSize(chipW, PICK_H)
    b.dungeonId = d.id
    b.fullName = d.name or d.id
    b.range = d.range
    Fit(b.label, ShortDungeonName(d.name or d.id), math.max(20, chipW - 8), false)
    local on = PC.IsDungeonSelected and PC:IsDungeonSelected(d.id) or false
    if on then
      selected = selected + 1
    end
    StyleMiniPill(b, on)
    if not on and b.label then
      b.label:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
    end
    b:Show()
  end
  if c.picks then
    for i = #list + 1, #c.picks do
      c.picks[i]:Hide()
    end
  end
  local rows = math.ceil(#list / cols)
  mini._picks = { shown = #list, selected = selected, cols = cols, chipW = chipW }
  return y + rows * PICK_H + (rows - 1) * PICK_GAP + 6
end

function PC:DebugMiniDungeonPicks()
  local out = { shown = 0, selected = 0, cols = 0, ids = {}, labels = {} }
  local p = mini._picks or {}
  out.shown, out.selected, out.cols, out.chipW = p.shown or 0, p.selected or 0, p.cols or 0, p.chipW
  local c = mini.card
  if c and c.picks then
    for i = 1, #c.picks do
      local b = c.picks[i]
      if b:IsShown() then
        out.ids[#out.ids + 1] = b.dungeonId
        out.labels[#out.labels + 1] = b.label and b.label:GetText() or ""
      end
    end
  end
  return out
end

function PC:GetPlayerGuildRank()
  if not GetGuildInfo then
    return nil
  end
  local ok, gname, rank = pcall(GetGuildInfo, "player")
  if ok and type(rank) == "string" and rank ~= "" then
    return rank
  end
  return nil
end

local function LayoutPlayerCard(compact)
  local c = EnsurePlayerCard()
  local width = (mini.frame and mini.frame:GetWidth()) or DEFAULT_W
  local inner = math.max(80, width - (NAMECARD_PAD * 2))
  c:ClearAllPoints()
  c:SetPoint("TOPLEFT", mini.frame, "TOPLEFT", NAMECARD_PAD, -TITLE_H)
  c:SetPoint("TOPRIGHT", mini.frame, "TOPRIGHT", -NAMECARD_PAD, -TITLE_H)
  c:SetWidth(inner)
  c:Show()

  local name = (PC.GetPlayerFullName and PC:GetPlayerFullName()) or (UnitName and UnitName("player")) or "You"
  local classFile = PC.GetClassFile and PC:GetClassFile() or nil
  local level = PC.PlayerLevel and PC:PlayerLevel() or 1
  local className = classFile and (classFile:sub(1, 1) .. string.lower(classFile:sub(2))) or ""
  if UnitClass then
    local ok, loc = pcall(UnitClass, "player")
    if ok and type(loc) == "string" then
      className = loc
    end
  end
  local r, g, b = 0.95, 0.95, 0.97
  if PC.ClassColor then
    r, g, b = PC:ClassColor(classFile)
  end

  -- Square portrait: SetPortraitTexture, falling back to a class-free head icon.
  local usedPortrait = false
  if SetPortraitTexture then
    usedPortrait = pcall(SetPortraitTexture, c.portrait, "player")
  end
  if not usedPortrait or (c.portrait.GetTexture and not c.portrait:GetTexture()) then
    c.portrait:SetTexture("Interface\\Icons\\INV_Misc_Head_Human_01")
  end
  c.portrait:SetTexCoord(0.1, 0.9, 0.1, 0.9)

  local textX = 2 + PORTRAIT_FRAME + 8
  local nameW = math.max(40, inner - textX - 2)
  c.name:ClearAllPoints()
  c.name:SetPoint("TOPLEFT", c, "TOPLEFT", textX, -6)
  c.name:SetWidth(nameW)
  c.name:SetTextColor(r, g, b)
  Fit(c.name, name, nameW, false)

  c.guild:ClearAllPoints()
  c.guild:SetPoint("TOPLEFT", c, "TOPLEFT", textX, -23)
  c.guild:SetWidth(nameW)
  Fit(c.guild, "<Alchemists>", nameW, false)
  -- 1.23.0: guild rank (Member, Officer...) under the guild tag.
  local rankName = PC.GetPlayerGuildRank and PC:GetPlayerGuildRank() or nil
  local rankH = 0
  if c.rank then
    c.rank:ClearAllPoints()
    c.rank:SetPoint("TOPLEFT", c, "TOPLEFT", textX, -36)
    c.rank:SetWidth(nameW)
    if rankName then
      Fit(c.rank, rankName, nameW, false)
      c.rank:Show()
      rankH = 12
    else
      c.rank:SetText("")
      c.rank:Hide()
    end
  end

  local role = PC.GetSocialRole and PC:GetSocialRole() or "dps"
  local sub = "Lv " .. tostring(level)
  if className ~= "" then
    sub = sub .. "  ·  " .. className
  end
  local subMax = math.max(30, nameW - 20 - 70)
  c.sub:ClearAllPoints()
  c.sub:SetPoint("TOPLEFT", c, "TOPLEFT", textX, -38 - rankH)
  c.sub:SetWidth(subMax)
  Fit(c.sub, sub, subMax, false)
  local subW = subMax
  if c.sub.GetStringWidth then
    local okW, sw = pcall(c.sub.GetStringWidth, c.sub)
    if okW and type(sw) == "number" and sw > 0 then
      subW = math.min(subMax, math.ceil(sw) + 1)
    end
  end
  c.sub:SetWidth(subW)
  c.role:ClearAllPoints()
  c.role:SetPoint("TOPLEFT", c, "TOPLEFT", textX + subW + 4, -36 - rankH)
  if PC.ApplyRoleIcon then
    Decor("role-icon", PC.ApplyRoleIcon, c.role.icon, c.role.letter, role)
  end
  c.role.icon:SetSize(14, 14)
  c.role:Show()

  local helping = PC.GetDB and PC:GetDB() and PC:GetDB().guildCanHelp and true or false
  c.help:ClearAllPoints()
  c.help:SetPoint("TOPRIGHT", c, "TOPRIGHT", -2, -35 - rankH)
  local okHC = c.help.round and PC.ShowRoundFill and pcall(PC.ShowRoundFill, PC, c.help.round, true,
    helping and { r = 0.12, g = 0.22, b = 0.16 } or { r = 0.16, g = 0.16, b = 0.18 }, 1)
  if not okHC then
    Paint(c.help.bg, helping and { r = 0.12, g = 0.22, b = 0.16 } or { r = 0.16, g = 0.16, b = 0.18 }, 1)
  end
  if helping then
    c.help.label:SetTextColor(EMERALD.r, EMERALD.g, EMERALD.b)
  else
    c.help.label:SetTextColor(SUB.r, SUB.g, SUB.b)
  end
  c.help:Show()
  mini._helping = helping

  local status = PC.GetSocialStatus and PC:GetSocialStatus() or "busy"
  local gap = 3
  local n = #MINI_STATUS_PILLS
  local labelW = 44
  c.statusLabel:ClearAllPoints()
  c.statusLabel:SetText("Status")
  c.statusLabel:Show()

  local pillTop = 4 + PORTRAIT_FRAME + 8
  local rest = inner - 8 - labelW
  local pillW = math.floor((rest - gap * (n - 1)) / n)
  local stacked = pillW < 50
  if stacked then
    c.statusLabel:SetPoint("TOPLEFT", c, "TOPLEFT", 4, -pillTop)
    c.statusLabel:SetWidth(math.max(40, inner - 8))
    Fit(c.statusLabel, "Status", math.max(40, inner - 8), false)
    c.pillRow:ClearAllPoints()
    c.pillRow:SetPoint("TOPLEFT", c, "TOPLEFT", 4, -(pillTop + 16))
    c.pillRow:SetSize(math.max(40, inner - 8), 18)
    pillW = math.floor((inner - 8 - gap * (n - 1)) / n)
  else
    c.statusLabel:SetPoint("TOPLEFT", c, "TOPLEFT", 4, -(pillTop + 3))
    c.statusLabel:SetWidth(labelW)
    Fit(c.statusLabel, "Status", labelW, false)
    c.pillRow:ClearAllPoints()
    c.pillRow:SetPoint("TOPLEFT", c, "TOPLEFT", 4 + labelW + 6, -pillTop)
    c.pillRow:SetSize(math.max(40, inner - 8 - labelW - 6), 18)
  end
  local useShort = pillW < 58
  for i = 1, n do
    local def = MINI_STATUS_PILLS[i]
    local bt = c.pills[i]
    bt:ClearAllPoints()
    bt:SetPoint("LEFT", c.pillRow, "LEFT", (i - 1) * (pillW + gap), 0)
    bt:SetWidth(math.max(36, pillW))
    bt:SetHeight(18)
    bt:Show()
    local label = useShort and def.short or def.label
    Fit(bt.label, label, math.max(24, pillW - 6), false)
    StyleMiniPill(bt, def.id == status)
  end

  local y = pillTop + (stacked and 16 or 0) + 18 + 6
  local okPicks, picksY = pcall(LayoutDungeonPicks, c, inner, y, status)
  if okPicks and type(picksY) == "number" then
    y = picksY
  else
    LogMiniError("mini:DungeonPicks", picksY)
    pcall(HidePicks, c)
  end
  local statsH = LayoutStats(c, inner, y)
  if statsH > 0 then
    y = y + statsH + 4
  end

  if compact then
    c.context:Hide()
    c.matches:Hide()
    c.nudge:Hide()
    LayoutPeerList(c, inner - 8, true)
    c:SetHeight(y)
    return c:GetHeight() or y
  end

  -- Expanded: what you're doing, who's available, as a vertical list.
  local context = ""
  if status == "dungeon" then
    local ids = PC.GetSelectedDungeons and PC:GetSelectedDungeons() or {}
    local nD = #ids
    if nD == 0 then
      context = "Pick dungeons above so guildmates know"
    else
      context = "Your picks are shared with the guild"
    end
  elseif status == "questing" then
    local zone = (PC.GetLiveZoneName and PC:GetLiveZoneName())
      or (PC.GetActivityZone and PC:GetActivityZone())
      or (PC.GetCurrentZoneName and PC:GetCurrentZoneName())
      or "your zone"
    context = "Questing in " .. tostring(zone)
  elseif status == "help" then
    local note = PC.GetSocialNote and PC:GetSocialNote() or ""
    if note ~= "" then
      context = note
    else
      context = "Tap to add a help note"
    end
  else
    context = "Hidden from group lists"
  end

  local cards = PC.GetGuildmateCards and PC:GetGuildmateCards() or {}
  local matchCount = #cards
  local matchText
  if status == "busy" then
    matchText = "Not listed right now"
  elseif matchCount == 0 then
    matchText = "No guildmates available"
  elseif matchCount == 1 then
    matchText = "1 guildmate available"
  else
    matchText = tostring(matchCount) .. " guildmates available"
  end

  local lineW = math.max(40, inner - 8)
  c.context:ClearAllPoints()
  c.context:SetPoint("TOPLEFT", c, "TOPLEFT", 4, -y)
  c.context:SetSize(lineW, 14)
  Fit(c.context.label, context, lineW, false)
  c.context:Show()
  y = y + 16

  c.matches:ClearAllPoints()
  c.matches:SetPoint("TOPLEFT", c, "TOPLEFT", 4, -y)
  c.matches:SetSize(lineW, 14)
  Fit(c.matches.label, matchText, lineW, false)
  c.matches:Show()
  y = y + 16

  c.names:ClearAllPoints()
  c.names:SetPoint("TOPLEFT", c, "TOPLEFT", 4, -y)
  c.names:SetWidth(lineW)
  local namesH = LayoutPeerList(c, lineW, false)
  if namesH > 0 then
    y = y + namesH + 2
  end

  local stale = PC.IsSocialStatusStale and PC:IsSocialStatusStale()
  if stale and status ~= "busy" then
    c.nudge:ClearAllPoints()
    c.nudge:SetPoint("TOPLEFT", c, "TOPLEFT", 4, -y)
    c.nudge:SetSize(lineW, 14)
    Fit(c.nudge.label, "Still looking?", lineW, false)
    c.nudge:Show()
    y = y + 16
  else
    c.nudge:Hide()
  end

  c:SetHeight(y + 2)
  return c:GetHeight() or (y + 2)
end

local SECTION_DEFS = {
  { id = "next", title = "Next", iconKey = "next", tab = "next" },
  { id = "path", title = "Path", iconKey = "zones", tab = "path" },
  { id = "abilities", title = "Abilities", iconKey = "goals", tab = "abilities" },
  { id = "gear", title = "Gear", iconKey = "gear", tab = "gear" },
  { id = "craft", title = "Craft", iconKey = "professions", tab = "craft" },
  { id = "guild", title = "Guild", iconKey = "guild", tab = "guild" },
}

local function ApplyMiniIcon(tex, path)
  if not tex or not path then
    return
  end
  if tex.SetTexCoord then
    tex:SetTexCoord(0.08, 0.92, 0.08, 0.92)
  end
  if tex.SetVertexColor then
    tex:SetVertexColor(1, 1, 1, 1)
  end
  if tex.SetTexture then
    tex:SetTexture(path)
  end
end

function PC:NoteSectionCardDirty()
  self._sectionCardGen = (self._sectionCardGen or 0) + 1
  self._sectionCardCache = nil
end

function PC:GetSectionCardSpecs()
  local zone = (self.GetLiveZoneName and self:GetLiveZoneName())
    or (self.GetCurrentZoneName and self:GetCurrentZoneName())
    or "this zone"
  local level = (self.PlayerLevel and self:PlayerLevel()) or 1
  local status = self.GetSocialStatus and self:GetSocialStatus() or "busy"
  local demo = false
  if self.GetDB then
    local db = self:GetDB()
    demo = db and db.demoGuild and true or false
  end
  local key = tostring(zone) .. ":" .. tostring(level) .. ":" .. tostring(status) .. ":" .. (demo and "1" or "0") .. ":" .. tostring(self._sectionCardGen or 0)
  if self._sectionCardCache and self._sectionCardCache.key == key and self._sectionCardCache.specs then
    return self._sectionCardCache.specs
  end

  local specs = {}

  local nextLine = "No next step"
  if self.GetNextHighlights then
    local items = self:GetNextHighlights(1)
    if items and items[1] and items[1].title and items[1].title ~= "" then
      nextLine = items[1].title
    end
  end
  if nextLine == "No next step" and self.GetNextAction then
    local action = self:GetNextAction()
    if action and action.title and action.title ~= "" then
      nextLine = action.title
    end
  end

  local pick = 0
  if self.GetZoneQuestSummary then
    local summary = self:GetZoneQuestSummary(zone)
    pick = (summary and tonumber(summary.available)) or 0
  end
  local pathLine
  if pick <= 0 then
    pathLine = tostring(zone) .. " · no quests to pick up"
  elseif pick == 1 then
    pathLine = tostring(zone) .. " · 1 quest to pick up"
  else
    pathLine = tostring(zone) .. " · " .. tostring(pick) .. " quests to pick up"
  end

  local train = 0
  if self.GetTrainerVisitSummary then
    local summary = self:GetTrainerVisitSummary()
    train = (summary and tonumber(summary.available)) or 0
  end
  local goalsLine
  if train <= 0 then
    goalsLine = "No spells ready to train"
  elseif train == 1 then
    goalsLine = "1 spell ready to train"
  else
    goalsLine = tostring(train) .. " spells ready to train"
  end

  local upgrades = 0
  if self.GetRecommendedGear then
    local rec = self:GetRecommendedGear()
    upgrades = (rec and rec.soon and #rec.soon) or 0
  end
  local gearLine
  if upgrades <= 0 then
    gearLine = "No upgrades available"
  elseif upgrades == 1 then
    gearLine = "1 upgrade available"
  else
    gearLine = tostring(upgrades) .. " upgrades available"
  end

  local craftLine = "No profession yet"
  if self.GetPlayerProfessions then
    local list = self:GetPlayerProfessions() or {}
    local rec = list[1]
    if rec then
      local skill = tonumber(rec.skill) or 0
      local maxSkill = tonumber(rec.maxSkill) or 0
      local name = rec.name or "Profession"
      craftLine = name .. " " .. tostring(skill) .. "/" .. tostring(maxSkill)
      if self.GetProfessionPlan then
        local plan = self:GetProfessionPlan(rec)
        if plan and plan.needTrain and plan.rank then
          craftLine = craftLine .. " · train " .. (plan.rank.name or "next rank")
        elseif plan and plan.milestone and plan.skill and plan.milestone > plan.skill then
          craftLine = craftLine .. " · next at " .. tostring(plan.milestone)
        elseif plan and plan.step and plan.step.recipe then
          craftLine = craftLine .. " · " .. plan.step.recipe
        end
      end
    end
  end

  local status = self.GetSocialStatus and self:GetSocialStatus() or "busy"
  local guildLine
  if status == "busy" then
    guildLine = "Not looking"
  else
    local peers = self.GetGuildmateCards and self:GetGuildmateCards() or {}
    local n = #peers
    if n <= 0 then
      guildLine = "No guildmates available"
    elseif n == 1 then
      guildLine = "1 guildmate available"
    else
      guildLine = tostring(n) .. " guildmates available"
    end
  end

  local lines = {
    next = nextLine,
    path = pathLine,
    goals = goalsLine,
    abilities = goalsLine,
    gear = gearLine,
    craft = craftLine,
    guild = guildLine,
  }
  for i = 1, #SECTION_DEFS do
    local def = SECTION_DEFS[i]
    specs[#specs + 1] = {
      id = def.id,
      title = def.title,
      iconKey = def.iconKey,
      tab = def.tab,
      line = lines[def.id] or "",
      icon = (self.ClassIcon and self:ClassIcon(def.iconKey)) or nil,
    }
  end
  self._sectionCardCache = { key = key, specs = specs }
  return specs
end

function PC:OpenSection(tab)
  if self.ShowUI then
    self:ShowUI()
  end
  if self.OpenTab and tab then
    self:OpenTab(tab)
  end
  return tab
end

function PC:IsMiniSectionsCollapsed()
  local db = self.GetMiniDB and self:GetMiniDB() or nil
  return db and db.sectionsCollapsed and true or false
end

function PC:SetMiniSectionsCollapsed(on)
  local db = self.GetMiniDB and self:GetMiniDB() or nil
  if db then
    db.sectionsCollapsed = on and true or false
  end
  if self.RefreshMiniTracker then
    self:RefreshMiniTracker()
  end
end

function PC:ToggleMiniSections()
  self:SetMiniSectionsCollapsed(not self:IsMiniSectionsCollapsed())
end

function PC:DebugMiniNamecard()
  local f = mini.frame
  local c = mini.card
  local db = self:GetMiniDB() or {}
  return {
    collapsed = db.collapsed and true or false,
    width = f and f:GetWidth() or 0,
    height = f and f:GetHeight() or 0,
    parchment = mini.parchmentPath,
    border = mini.borderPath,
    sigil = nil,
    animated = false,
    hasRing = c and c.ring and true or false,
    portraitShape = c and c.portraitShape or nil,
    portraitMasked = c and c.portrait and c.portrait._circleMask and true or false,
    stats = mini._stats or {},
    statsShown = c and c.stats and c.stats:IsShown() and true or false,
    hasStatusLabel = c and c.statusLabel and c.statusLabel:IsShown() and (c.statusLabel:GetText() == "Status") or false,
    statusText = c and c.statusLabel and c.statusLabel:GetText() or nil,
    contextShown = c and c.context and c.context:IsShown() and true or false,
    namesShown = c and c.names and c.names:IsShown() and true or false,
    peerPlan = self.DebugMiniPeerNames and self:DebugMiniPeerNames() or nil,
  }
end

function PC:DebugMiniSections()
  local out = {
    shown = false,
    collapsed = self:IsMiniSectionsCollapsed() and true or false,
    cols = mini.sectionCols or 0,
    cards = {},
  }
  if mini.sections and mini.sections:IsShown() then
    out.shown = true
  end
  local specs = self:GetSectionCardSpecs()
  for i = 1, #specs do
    local card = mini.sectionCards and mini.sectionCards[i]
    out.cards[#out.cards + 1] = {
      id = specs[i].id,
      title = specs[i].title,
      line = specs[i].line,
      tab = specs[i].tab,
      shown = card and card:IsShown() and true or false,
      text = (card and card.line and card.line.GetText and card.line:GetText()) or specs[i].line,
    }
  end
  return out
end

function PC:CollectMiniOverlaps(slack)
  local hits = {}
  if not mini.frame or not mini.frame:IsShown() then
    return hits
  end
  if not self.CollectRowOverlaps then
    return hits
  end
  local roots = { mini.card, mini.body, mini.frame }
  for r = 1, #roots do
    local root = roots[r]
    if root and root.IsShown and root:IsShown() then
      local found = self:CollectRowOverlaps(root, slack)
      for i = 1, #found do
        found[i].row = "mini"
        hits[#hits + 1] = found[i]
      end
    end
  end
  if mini.quests then
    for i = 1, #mini.quests do
      local row = mini.quests[i]
      if row and row:IsShown() then
        local found = self:CollectRowOverlaps(row, slack)
        for k = 1, #found do
          found[k].row = "mini-quest"
          hits[#hits + 1] = found[k]
        end
      end
    end
  end
  if mini.sectionHeader and mini.sectionHeader:IsShown() then
    local found = self:CollectRowOverlaps(mini.sectionHeader, slack)
    for i = 1, #found do
      found[i].row = "mini-section-header"
      hits[#hits + 1] = found[i]
    end
  end
  if mini.sectionCards then
    for i = 1, #mini.sectionCards do
      local card = mini.sectionCards[i]
      if card and card:IsShown() then
        local found = self:CollectRowOverlaps(card, slack)
        for k = 1, #found do
          found[k].row = "mini-section"
          hits[#hits + 1] = found[k]
        end
      end
    end
  end
  if mini.card and mini.card.names and mini.card.names:IsShown() then
    local found = self:CollectRowOverlaps(mini.card.names, slack)
    for i = 1, #found do
      found[i].row = "mini-peer-names"
      hits[#hits + 1] = found[i]
    end
  end
  return hits
end


local function SetMiniToggleState(collapsed)
  local t = mini.toggle
  if not t then
    return
  end
  t.collapsed = collapsed and true or false
  if t.hasArrow and t.arrow then
    t.arrow:Show()
    if t.arrow.SetRotation then
      -- Down arrow when collapsed (tap to open), up when open.
      pcall(t.arrow.SetRotation, t.arrow, collapsed and 0 or math.pi)
    end
    if t.label then t.label:SetText("") end
  elseif t.label then
    t.label:SetText(collapsed and "v" or "^")
  end
  t:ClearAllPoints()
  t:SetPoint("BOTTOM", mini.frame, "BOTTOM", 0, 2)
  t:Show()
end
PC._SetMiniToggleState = SetMiniToggleState

local function LayoutCollapsed()
  local f = mini.frame
  if mini.body then
    mini.body:Hide()
  end
  if mini.finder then
    mini.finder:Hide()
  end
  if mini.grip then
    mini.grip:Hide()
  end
  if f and math.abs((f:GetWidth() or 0) - DEFAULT_W) > 0.5 then
    f:SetWidth(DEFAULT_W)
  end
  SetMiniToggleState(true)
  local cardH = 0
  if LayoutPlayerCard then
    local okCard, cardRes = pcall(LayoutPlayerCard, true)
    if okCard then
      cardH = tonumber(cardRes) or 0
    else
      LogMiniError("mini:LayoutPlayerCard", cardRes)
    end
  end
  f:SetHeight(TITLE_H + cardH + BOTTOM_TAB + 4)
end

-- ---------------------------------------------------------------------------
-- Minimized pill (1.18.3): name, guild, level, then open / maximize / close.
-- ---------------------------------------------------------------------------

local function SetResizeMin(minW)
  local f = mini.frame
  if f and f.SetResizeBounds then
    -- Height follows content, so only the width floor matters for sizing.
    pcall(f.SetResizeBounds, f, minW, PILL_H, MAX_W, MAX_H)
  end
end

local function Toggle(region, on)
  if not region then
    return
  end
  if on then region:Show() else region:Hide() end
end

local function SetPillChrome(pill)
  local t = mini.title
  if t then
    t:SetHeight(pill and PILL_H or TITLE_H)
    Toggle(t.label, not pill)
  end
  Toggle(mini.lock, not pill)
  Toggle(mini.minBtn, not pill)
  Toggle(mini.maxBtn, pill)
  Toggle(mini.pillName, pill)
  Toggle(mini.pillGuild, pill)
  Toggle(mini.pillLevel, pill)
  if pill then
    Toggle(mini.card, false)
    Toggle(mini.body, false)
    Toggle(mini.finder, false)
    Toggle(mini.grip, false)
    Toggle(mini.toggle, false)
  end
end

local function MeasureText(fs, text, cap)
  fs:SetWidth(cap)
  fs:SetText(text)
  local w = cap
  if fs.GetStringWidth then
    local ok, sw = pcall(fs.GetStringWidth, fs)
    if ok and type(sw) == "number" and sw > 0 then
      w = math.min(cap, math.ceil(sw) + 2)
    end
  end
  fs:SetWidth(w)
  Fit(fs, text, w, false)
  return w
end

local function LayoutPill()
  local f = mini.frame
  local t = mini.title
  if not f or not t then
    return
  end
  SetPillChrome(true)
  local name = (PC.GetPlayerFullName and PC:GetPlayerFullName()) or (UnitName and UnitName("player")) or "You"
  local classFile = PC.GetClassFile and PC:GetClassFile() or nil
  local r, g, b = 0.95, 0.95, 0.97
  if PC.ClassColor then
    r, g, b = PC:ClassColor(classFile)
  end
  local level = PC.PlayerLevel and PC:PlayerLevel() or 1
  mini.pillName:SetTextColor(r, g, b)
  local x = 12
  local pieces = {
    { mini.pillName, tostring(name), 140 },
    { mini.pillGuild, "<Alchemists>", 100 },
    { mini.pillLevel, "Lv " .. tostring(level), 44 },
  }
  for i = 1, #pieces do
    local fs, text, cap = pieces[i][1], pieces[i][2], pieces[i][3]
    fs:ClearAllPoints()
    fs:SetPoint("LEFT", t, "LEFT", x, 0)
    local w = MeasureText(fs, text, cap)
    x = x + w + (i < #pieces and 6 or 0)
  end
  -- Buttons: 3 x 16px, 4px gaps, 6px right pad, 10px gap after the text.
  local width = math.floor(x + 10 + (16 * 3 + 4 * 2) + 6)
  width = Clamp(width, 150, MAX_W)
  SetResizeMin(100)
  f:SetSize(width, PILL_H)
  LayoutRoundShape(mini.shape, f, PILL_H / 2)
  ClampFrameToScreen(f)
  mini._pill = { width = width, height = PILL_H, name = name, level = level }
end

function PC:IsMiniMinimized()
  local db = self.GetMiniDB and self:GetMiniDB() or nil
  return db and db.minimized and true or false
end

function PC:SetMiniMinimized(on)
  local db = self.GetMiniDB and self:GetMiniDB() or nil
  if not db then
    return
  end
  db.minimized = on and true or false
  if self.RefreshMiniTracker then
    local ok, err = pcall(self.RefreshMiniTracker, self)
    if not ok then
      LogMiniError("mini:minimize", err)
    end
  end
  SaveMiniGeometry()
end

function PC:DebugMiniPill()
  local p = mini._pill or {}
  return {
    minimized = self:IsMiniMinimized(),
    width = p.width,
    height = p.height,
    radius = mini.shape and mini.shape.radius or nil,
    nameShown = mini.pillName and mini.pillName:IsShown() and true or false,
    cardShown = mini.card and mini.card:IsShown() and true or false,
    maxShown = mini.maxBtn and mini.maxBtn:IsShown() and true or false,
    minShown = mini.minBtn and mini.minBtn:IsShown() and true or false,
  }
end

local function EnsureSectionCards()
  if mini.sections then
    return mini.sections
  end
  local body = mini.body
  if not body then
    return nil
  end
  local wrap = CreateFrame("Frame", "PhilosophersCodexMiniSections", body)
  wrap:SetPoint("TOPLEFT", body, "TOPLEFT", 0, 0)
  wrap:SetPoint("TOPRIGHT", body, "TOPRIGHT", 0, 0)
  mini.sections = wrap

  local header = CreateFrame("Button", "PhilosophersCodexMiniSectionHeader", wrap)
  header:SetHeight(18)
  header:SetPoint("TOPLEFT", wrap, "TOPLEFT", 0, 0)
  header:SetPoint("TOPRIGHT", wrap, "TOPRIGHT", 0, 0)
  header.title = FS(header, "GameFontNormalSmall", 11)
  header.title:SetPoint("LEFT", 0, 0)
  header.title:SetHeight(12)
  header.title:SetText("Sections")
  header.title:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
  header.count = FS(header, "GameFontDisableSmall", 10)
  header.count:SetHeight(12)
  header.count:SetWidth(16)
  header.count:SetText("6")
  header.count:SetTextColor(SUB.r, SUB.g, SUB.b)
  header.chevron = FS(header, "GameFontHighlightSmall", 11)
  header.chevron:SetPoint("RIGHT", 0, 0)
  header.chevron:SetHeight(12)
  header.chevron:SetWidth(12)
  header.chevron:SetText("v")
  header.chevron:SetTextColor(SUB.r, SUB.g, SUB.b)
  header.count:SetPoint("RIGHT", header.chevron, "LEFT", -4, 0)
  header:SetScript("OnClick", function()
    if PC.ToggleMiniSections then
      PC:ToggleMiniSections()
    end
  end)
  header:SetScript("OnEnter", function(self)
    if GameTooltip then
      GameTooltip:SetOwner(self, "ANCHOR_LEFT")
      GameTooltip:AddLine("Sections", GOLD.r, GOLD.g, GOLD.b)
      GameTooltip:AddLine("Open the main window to a tab, or click here to collapse this list.", 0.56, 0.56, 0.60, true)
      GameTooltip:Show()
    end
  end)
  header:SetScript("OnLeave", function()
    if GameTooltip then GameTooltip:Hide() end
  end)
  mini.sectionHeader = header

  mini.sectionCards = {}
  for i = 1, #SECTION_DEFS do
    local def = SECTION_DEFS[i]
    local card = CreateFrame("Button", "PhilosophersCodexMiniSection" .. def.title, wrap)
    card:SetHeight(40)
    card.bg = card:CreateTexture(nil, "BACKGROUND")
    card.bg:SetAllPoints()
    Paint(card.bg, { r = 0.12, g = 0.12, b = 0.14 }, 1)
    card.icon = card:CreateTexture(nil, "ARTWORK")
    card.icon:SetSize(18, 18)
    card.icon:SetPoint("LEFT", 6, 0)
    card.title = FS(card, "GameFontHighlight", 11)
    card.title:SetPoint("TOPLEFT", card, "TOPLEFT", 30, -6)
    card.title:SetHeight(12)
    card.title:SetText(def.title)
    card.title:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
    card.line = FS(card, "GameFontHighlightSmall", 10)
    card.line:SetPoint("TOPLEFT", card, "TOPLEFT", 30, -20)
    card.line:SetHeight(12)
    card.line:SetText("")
    card.line:SetTextColor(SUB.r, SUB.g, SUB.b)
    card.tab = def.tab
    card.id = def.id
    card:SetScript("OnClick", function(self)
      if PC.OpenSection then
        PC:OpenSection(self.tab)
      end
    end)
    card:SetScript("OnEnter", function(self)
      Paint(self.bg, { r = 0.16, g = 0.16, b = 0.19 }, 1)
      if GameTooltip then
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine(def.title, GOLD.r, GOLD.g, GOLD.b)
        GameTooltip:AddLine("Open the " .. def.title .. " tab.", 0.56, 0.56, 0.60, true)
        GameTooltip:Show()
      end
    end)
    card:SetScript("OnLeave", function(self)
      Paint(self.bg, { r = 0.12, g = 0.12, b = 0.14 }, 1)
      if GameTooltip then GameTooltip:Hide() end
    end)
    mini.sectionCards[i] = card
  end
  return wrap
end

local function HideSectionCards()
  if mini.sections then
    mini.sections:Hide()
  end
end

local function LayoutSectionCards()
  local body = mini.body
  if not body then
    return
  end
  local wrap = EnsureSectionCards()
  if not wrap then
    return
  end
  wrap:Show()
  wrap:ClearAllPoints()
  wrap:SetPoint("TOPLEFT", body, "TOPLEFT", 0, 0)
  wrap:SetPoint("BOTTOMRIGHT", body, "BOTTOMRIGHT", 0, 0)

  -- Use the tracker frame width, not body:GetWidth(). The body is
  -- stretch-anchored, and a mock or a just-resized frame can still
  -- report its default 100px width.
  local width = math.max(80, ((mini.frame and mini.frame:GetWidth()) or DEFAULT_W) - 20)
  -- Two columns when the tracker is wide enough for two readable cards.
  local cols = (width >= 220) and 2 or 1
  mini.sectionCols = cols
  local collapsed = PC.IsMiniSectionsCollapsed and PC:IsMiniSectionsCollapsed()
  local header = mini.sectionHeader
  if header then
    header:Show()
    header:SetWidth(width)
    if header.chevron then
      header.chevron:SetText(collapsed and ">" or "v")
    end
    if header.chevron then
      header.chevron:ClearAllPoints()
      header.chevron:SetPoint("RIGHT", header, "RIGHT", 0, 0)
      header.chevron:SetWidth(12)
      header.chevron:SetHeight(12)
    end
    if header.count then
      header.count:SetText("6")
      header.count:ClearAllPoints()
      header.count:SetPoint("RIGHT", header.chevron or header, "LEFT", header.chevron and -4 or 0, 0)
      header.count:SetWidth(16)
      header.count:SetHeight(12)
    end
    if header.title then
      header.title:ClearAllPoints()
      header.title:SetPoint("LEFT", header, "LEFT", 0, 0)
      header.title:SetHeight(12)
      local titleW = math.max(40, width - 36)
      header.title:SetWidth(titleW)
      if header.chevron then
        header.title:SetPoint("RIGHT", header.count or header.chevron, "LEFT", -6, 0)
      else
        header.title:SetPoint("RIGHT", header, "RIGHT", -8, 0)
      end
      Fit(header.title, "Sections", titleW, false)
    end
  end

  local specs = (PC.GetSectionCardSpecs and PC:GetSectionCardSpecs()) or {}
  local gap = 4
  local cardH = 40
  if collapsed then
    for i = 1, #(mini.sectionCards or {}) do
      mini.sectionCards[i]:Hide()
    end
    wrap:SetHeight(20)
    return
  end

  local availH = 0
  if body.GetHeight then
    availH = math.max(0, (body:GetHeight() or 0) - 20)
  end
  local rows = math.ceil(#specs / cols)
  if availH > 0 and rows > 0 then
    local fitH = math.floor((availH - gap * (rows - 1)) / rows)
    if fitH < 32 then
      cardH = 32
    elseif fitH < 40 then
      cardH = fitH
    else
      cardH = 40
    end
  end

  local cardW = math.floor((width - gap * (cols - 1)) / cols)
  if cardW < 80 then
    cardW = width
    cols = 1
    mini.sectionCols = 1
    rows = #specs
  end

  for i = 1, #(mini.sectionCards or {}) do
    local card = mini.sectionCards[i]
    local spec = specs[i]
    if not spec then
      card:Hide()
    else
      local row = math.floor((i - 1) / cols)
      local col = (i - 1) % cols
      local x = col * (cardW + gap)
      local y = 20 + row * (cardH + gap)
      card:ClearAllPoints()
      card:SetPoint("TOPLEFT", wrap, "TOPLEFT", x, -y)
      card:SetSize(cardW, cardH)
      card:Show()
      card.tab = spec.tab
      card.id = spec.id
      if card.icon then
        ApplyMiniIcon(card.icon, spec.icon)
      end
      local textW = math.max(30, cardW - 18 - 18)
      if card.title then
        card.title:ClearAllPoints()
        card.title:SetPoint("TOPLEFT", card, "TOPLEFT", 30, -6)
        card.title:SetHeight(12)
        card.title:SetWidth(textW)
        Fit(card.title, spec.title, textW, false)
        if card.title.SetJustifyH then
          card.title:SetJustifyH("LEFT")
        end
      end
      if card.line then
        card.line:ClearAllPoints()
        -- Anchor to the card, not the title, so the mock's default
        -- FontString height cannot pull the two labels into the same box.
        card.line:SetPoint("TOPLEFT", card, "TOPLEFT", 30, -20)
        card.line:SetHeight(12)
        card.line:SetWidth(textW)
        Fit(card.line, spec.line, textW, false)
        if card.line.SetJustifyH then
          card.line:SetJustifyH("LEFT")
        end
      end
    end
  end
end

function PC:RefreshMiniTracker()
  if not mini.created or not mini.frame then
    return
  end
  local db = self:GetMiniDB() or {}
  if not mini.sizing then
    local okGeo, errGeo = pcall(RestoreMiniGeometry)
    if not okGeo then
      LogMiniError("mini:RestoreGeometry", errGeo)
      DefaultAnchor(mini.frame)
    end
  end
  SetLocked(db.locked and true or false)
  self:UpdateMiniVisibility()
  ApplyOpacity()
  if not mini.frame:IsShown() and db.enabled == false then
    return
  end

  local level = self:PlayerLevel() or 1
  if mini.badgeText then
    mini.badgeText:SetText(tostring(level))
  end
  if db.minimized then
    local okP, errP = pcall(LayoutPill)
    if okP then
      return
    end
    -- A broken pill must never leave the player with nothing: fall back to the card.
    LogMiniError("mini:LayoutPill", errP)
    db.minimized = false
  end
  SetPillChrome(false)
  SetResizeMin(MIN_W)
  Decor("round-shape", LayoutRoundShape, mini.shape, mini.frame, CARD_RADIUS)
  SetMiniToggleState(db.collapsed and true or false)
  if mini.tabNext then
    mini.tabNext:Hide()
  end
  if mini.tabGuild then
    mini.tabGuild:Hide()
  end
  if db.collapsed then
    LayoutCollapsed()
    return
  end
  if mini.body then
    mini.body:Show()
  end
  if mini.grip and not db.locked then
    mini.grip:Show()
  end

  if math.abs((mini.frame:GetWidth() or 0) - DEFAULT_W) > 0.5 then
    mini.frame:SetWidth(DEFAULT_W)
  end
  local width = DEFAULT_W
  local height = mini.frame:GetHeight() or DEFAULT_H
  width = Clamp(width, MIN_W, MAX_W)
  height = Clamp(height, MIN_H, MAX_H)
  local innerW = math.max(80, width - 20)
  local cardH = 0
  local okCard, cardRes = pcall(LayoutPlayerCard)
  if okCard then
    cardH = tonumber(cardRes) or 0
  else
    LogMiniError("mini:LayoutPlayerCard", cardRes)
  end
  local bodyTop = TITLE_H + cardH + 4
  -- Height follows the content: ID card, guildmate list, then the section grid.
  local secCollapsed = PC.IsMiniSectionsCollapsed and PC:IsMiniSectionsCollapsed()
  local secW = math.max(80, width - 20)
  local cols = (secW >= 220) and 2 or 1
  if math.floor((secW - 4 * (cols - 1)) / cols) < 80 then cols = 1 end
  local rows = math.ceil(6 / cols)
  local sectionsH = secCollapsed and 20 or (20 + rows * 40 + (rows - 1) * 4)
  if db.panel ~= "guild" then
    local want = bodyTop + sectionsH + BOTTOM_TAB + 6
    if want < MIN_H then want = MIN_H end
    if want > MAX_H then want = MAX_H end
    if math.abs((mini.frame:GetHeight() or 0) - want) > 0.5 then
      mini.frame:SetHeight(want)
    end
  end
  if mini.body then
    mini.body:ClearAllPoints()
    mini.body:SetPoint("TOPLEFT", mini.frame, "TOPLEFT", 10, -bodyTop)
    mini.body:SetPoint("BOTTOMRIGHT", mini.frame, "BOTTOMRIGHT", -10, BOTTOM_TAB + 4)
  end
  if db.panel == "guild" then
    HideNextBody()
    HideSectionCards()
    if mini.body then
      mini.body:Hide()
    end
    if mini.finder then
      mini.finder:ClearAllPoints()
      mini.finder:SetPoint("TOPLEFT", mini.frame, "TOPLEFT", 10, -bodyTop)
      mini.finder:SetPoint("BOTTOMRIGHT", mini.frame, "BOTTOMRIGHT", -10, BOTTOM_TAB + 4)
    end
    local okF, errF = pcall(RefreshFinder)
    if not okF then
      LogMiniError("mini:RefreshFinder", errF)
    end
    return
  end
  if mini.finder then
    mini.finder:Hide()
  end
  if mini.body then
    mini.body:Show()
  end
  pcall(HideNextBody)
  local okS, errS = pcall(LayoutSectionCards)
  if not okS then
    LogMiniError("mini:LayoutSectionCards", errS)
  end
end


-- ---------------------------------------------------------------------------
-- Group finder panel (1.9.0)
-- ---------------------------------------------------------------------------

local FINDER_ROW_H = 24
local FINDER_POOL_PAD = 2

function SetMiniPanel(which)
  local db = PC:GetMiniDB()
  if db and (which == "next" or which == "guild") then
    db.panel = which
  end
  if PC.RefreshMiniTracker then
    PC:RefreshMiniTracker()
  end
end

function StyleMiniTab(btn, on)
  if not btn or not btn.label then
    return
  end
  if on then
    btn.label:SetTextColor(EMERALD.r, EMERALD.g, EMERALD.b)
  else
    btn.label:SetTextColor(SUB.r, SUB.g, SUB.b)
  end
end

function HideNextBody()
  local hide = {
    mini.nextLabel, mini.next, mini.pin, mini.zoneIcon, mini.zone,
    mini.questHeader, mini.more, mini.bar, mini.barLabel,
  }
  for i = 1, #hide do
    if hide[i] and hide[i].Hide then
      hide[i]:Hide()
    end
  end
  if mini.quests then
    for i = 1, #mini.quests do
      mini.quests[i]:Hide()
    end
  end
end

function ShowNextBody()
  local show = { mini.nextLabel, mini.next, mini.zoneIcon, mini.zone, mini.bar, mini.barLabel }
  for i = 1, #show do
    if show[i] and show[i].Show then
      show[i]:Show()
    end
  end
end

function EnsureFinder()
  if mini.finder then
    return mini.finder
  end
  local parent = mini.frame
  local f = CreateFrame("Frame", "PhilosophersCodexMiniFinder", parent)
  f:SetPoint("TOPLEFT", 10, -TITLE_H)
  f:SetPoint("BOTTOMRIGHT", -10, 12)
  f:Hide()

  local toggle = CreateFrame("Button", "PhilosophersCodexMiniAvail", f)
  toggle:SetHeight(22)
  toggle:SetPoint("TOPLEFT", 0, -2)
  toggle:SetPoint("TOPRIGHT", 0, -2)
  toggle.bg = toggle:CreateTexture(nil, "BACKGROUND")
  toggle.bg:SetAllPoints()
  Paint(toggle.bg, { r = 0.12, g = 0.22, b = 0.16 }, 1)
  toggle.label = FS(toggle, "GameFontHighlight", 12)
  toggle.label:SetPoint("CENTER", 0, 0)
  toggle.label:SetText("Available to group")
  if toggle.label.SetJustifyH then
    toggle.label:SetJustifyH("CENTER")
  end
  toggle:SetScript("OnClick", function()
    if PC.SetAvailableToGroup then
      PC:SetAvailableToGroup(not (PC.IsAvailableToGroup and PC:IsAvailableToGroup()))
    end
  end)
  f.toggle = toggle

  local kindRow = CreateFrame("Frame", nil, f)
  kindRow:SetHeight(16)
  kindRow:SetPoint("TOPLEFT", toggle, "BOTTOMLEFT", 0, -4)
  kindRow:SetPoint("RIGHT", 0, 0)
  f.kindRow = kindRow
  local function kindBtn(name, label, x, status)
    local b = CreateFrame("Button", name, kindRow)
    b:SetSize(70, 16)
    b:SetPoint("LEFT", x, 0)
    b.label = FS(b, "GameFontNormalSmall", 10)
    b.label:SetPoint("CENTER")
    b.label:SetText(label)
    b.statusId = status
    b:SetScript("OnClick", function()
      if PC.SetSocialStatus then
        PC:SetSocialStatus(status)
      end
    end)
    return b
  end
  f.kindDungeon = kindBtn("PhilosophersCodexMiniKindD", "Dungeon", 0, "dungeon")
  f.kindQuest = kindBtn("PhilosophersCodexMiniKindQ", "Questing", 56, "questing")
  f.kindHelp = kindBtn("PhilosophersCodexMiniKindH", "Help", 116, "help")
  f.kindBusy = kindBtn("PhilosophersCodexMiniKindB", "Hide", 162, "busy")
  f.kindBoth = f.kindBusy

  f.offMsg = FS(f, "GameFontHighlightSmall", 11)
  f.offMsg:SetPoint("TOPLEFT", toggle, "BOTTOMLEFT", 0, -8)
  f.offMsg:SetPoint("RIGHT", 0, 0)
  f.offMsg:SetText("You are hidden from group lists.")
  f.offMsg:SetTextColor(SUB.r, SUB.g, SUB.b)
  if f.offMsg.SetWordWrap then
    f.offMsg:SetWordWrap(true)
  end

  f.count = FS(f, "GameFontNormalSmall", 10)
  f.count:SetPoint("TOPLEFT", kindRow, "BOTTOMLEFT", 0, -4)
  f.count:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
  f.count:SetText("0 available")

  local filters = CreateFrame("Frame", nil, f)
  filters:SetHeight(16)
  filters:SetPoint("TOPLEFT", f.count, "BOTTOMLEFT", 0, -2)
  filters:SetPoint("RIGHT", 0, 0)
  f.filters = filters
  local function filterBtn(name, label, x)
    local b = CreateFrame("Button", name, filters)
    b:SetSize(20, 16)
    b:SetPoint("LEFT", x, 0)
    b.label = FS(b, "GameFontNormalSmall", 10)
    b.label:SetPoint("CENTER")
    b.label:SetText(label)
    b.label:SetTextColor(SUB.r, SUB.g, SUB.b)
    return b
  end
  f.filtTank = filterBtn("PhilosophersCodexMiniFiltT", "T", 0)
  f.filtHeal = filterBtn("PhilosophersCodexMiniFiltH", "H", 22)
  f.filtDps = filterBtn("PhilosophersCodexMiniFiltD", "D", 44)
  f.filtZone = filterBtn("PhilosophersCodexMiniFiltZ", "Zone", 72)
  f.filtZone:SetWidth(36)
  f.filtBracket = filterBtn("PhilosophersCodexMiniFiltB", "Bracket", 112)
  f.filtBracket:SetWidth(50)
  local function bindFilter(btn, key, value)
    btn:SetScript("OnClick", function()
      local db = PC:GetMiniDB() or {}
      if key == "role" then
        if db.filterRole == value then
          db.filterRole = nil
        else
          db.filterRole = value
        end
      else
        db[key] = not db[key]
      end
      if PC.RefreshMiniTracker then
        PC:RefreshMiniTracker()
      end
    end)
  end
  bindFilter(f.filtTank, "role", "tank")
  bindFilter(f.filtHeal, "role", "healer")
  bindFilter(f.filtDps, "role", "dps")
  bindFilter(f.filtZone, "filterSameZone")
  bindFilter(f.filtBracket, "filterBracket")

  local scroll = CreateFrame("ScrollFrame", "PhilosophersCodexMiniFinderScroll", f)
  scroll:SetPoint("TOPLEFT", filters, "BOTTOMLEFT", 0, -4)
  scroll:SetPoint("BOTTOMRIGHT", 0, 0)
  if scroll.EnableMouseWheel then
    scroll:EnableMouseWheel(true)
  end
  f.scroll = scroll
  f.offset = 0
  f.entries = {}
  f.pool = {}
  f.headers = {}
  f.created = 0

  scroll:SetScript("OnMouseWheel", function(self, delta)
    local vis = math.max(1, math.floor((self:GetHeight() or 80) / FINDER_ROW_H))
    local maxOff = math.max(0, #f.entries - vis)
    f.offset = f.offset - (delta or 0)
    if f.offset < 0 then f.offset = 0 end
    if f.offset > maxOff then f.offset = maxOff end
    if f.RefreshList then
      f.RefreshList()
    end
  end)

  local function AcquireFinderRow()
    for i = 1, #f.pool do
      if not f.pool[i]._inUse then
        return f.pool[i]
      end
    end
    local row = CreateFrame("Button", nil, scroll)
    row:SetHeight(FINDER_ROW_H)
    row.icon = row:CreateTexture(nil, "ARTWORK")
    row.icon:SetSize(16, 16)
    row.icon:SetPoint("LEFT", 0, 0)
    row.name = FS(row, "GameFontHighlightSmall", 11)
    row.name:SetPoint("LEFT", row.icon, "RIGHT", 4, 0)
    row.level = FS(row, "GameFontNormalSmall", 10)
    row.level:SetPoint("LEFT", row.name, "RIGHT", 4, 0)
    row.level:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
    row.role = row:CreateTexture(nil, "ARTWORK")
    row.role:SetSize(14, 14)
    row.roleLetter = FS(row, "GameFontNormalSmall", 9)
    row.roleLetter:SetPoint("CENTER", row.role, "CENTER", 0, 0)
    row.chip = FS(row, "GameFontNormalSmall", 10)
    row.chip:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
    row.invite = CreateFrame("Button", nil, row)
    row.invite:SetSize(16, 16)
    row.invite.icon = row.invite:CreateTexture(nil, "ARTWORK")
    row.invite.icon:SetAllPoints()
    row.whisper = CreateFrame("Button", nil, row)
    row.whisper:SetSize(16, 16)
    row.whisper.icon = row.whisper:CreateTexture(nil, "ARTWORK")
    row.whisper.icon:SetAllPoints()
    if PC.TrySetTexture then
      PC.TrySetTexture(row.invite.icon, "Interface\\FriendsFrame\\UI-Toast-FriendRequestIcon")
      PC.TrySetTexture(row.whisper.icon, "Interface\\ChatFrame\\UI-ChatWhisperIcon")
    end
    row.invite:Hide()
    row.whisper:Hide()
    row:SetScript("OnEnter", function(self)
      if self.rec then
        self.invite:Show()
        self.whisper:Show()
      end
    end)
    row:SetScript("OnLeave", function(self)
      self.invite:Hide()
      self.whisper:Hide()
    end)
    row:SetScript("OnClick", function(self)
      if self.rec and self.rec.name and PC.OpenTab then
        PC._focusPeer = self.rec.name
        if PC.ToggleFrame then
          -- open main window if hidden
        end
        local frame = _G.PhilosophersCodexFrame
        if frame and not frame:IsShown() and SlashCmdList and SlashCmdList.PHILOSOPHERSCODEX then
          SlashCmdList.PHILOSOPHERSCODEX("")
        elseif frame and not frame:IsShown() and PC.Toggle then
          PC:Toggle()
        elseif frame and not frame:IsShown() then
          frame:Show()
        end
        PC:OpenTab("guild")
      end
    end)
    row.invite:SetScript("OnClick", function(self)
      local rec = self:GetParent() and self:GetParent().rec
      if rec and rec.name and PC.InvitePeer then
        PC:InvitePeer(rec.name)
      end
    end)
    row.whisper:SetScript("OnClick", function(self)
      local rec = self:GetParent() and self:GetParent().rec
      if rec and rec.name and PC.WhisperPeer then
        PC:WhisperPeer(rec.name, PC.PrefillWhisper and PC:PrefillWhisper(rec) or nil)
      end
    end)
    f.created = f.created + 1
    f.pool[#f.pool + 1] = row
    return row
  end

  local function AcquireHeader()
    for i = 1, #f.headers do
      if not f.headers[i]._inUse then
        return f.headers[i]
      end
    end
    local h = CreateFrame("Button", nil, scroll)
    h:SetHeight(FINDER_ROW_H)
    h.label = FS(h, "GameFontNormalSmall", 10)
    h.label:SetPoint("LEFT", 0, 0)
    h.label:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
    f.headers[#f.headers + 1] = h
    f.created = f.created + 1
    return h
  end

  function f.RefreshList()
    for i = 1, #f.pool do
      f.pool[i]._inUse = false
      f.pool[i]:Hide()
    end
    for i = 1, #f.headers do
      f.headers[i]._inUse = false
      f.headers[i]:Hide()
    end
    local vis = math.max(1, math.floor((scroll:GetHeight() or 80) / FINDER_ROW_H))
    local maxRows = vis + FINDER_POOL_PAD
    local used = 0
    for i = 1, vis do
      local idx = f.offset + i
      local entry = f.entries[idx]
      if entry then
        used = used + 1
        local y = -(i - 1) * FINDER_ROW_H
        if entry.kind == "header" then
          local h = AcquireHeader()
          h._inUse = true
          h:ClearAllPoints()
          h:SetPoint("TOPLEFT", scroll, "TOPLEFT", 0, y)
          h:SetPoint("RIGHT", scroll, "RIGHT", 0, 0)
          local mark = entry.collapsed and ">" or "v"
          h.label:SetText(mark .. " " .. entry.title .. "  (" .. tostring(entry.count or 0) .. ")")
          h:SetScript("OnClick", function()
            local db = PC:GetMiniDB() or {}
            if entry.key == "nearby" then
              db.finderNearbyOpen = not (db.finderNearbyOpen ~= false)
            elseif entry.key == "others" then
              db.finderOthersOpen = not db.finderOthersOpen
            end
            if PC.RefreshMiniTracker then
              PC:RefreshMiniTracker()
            end
          end)
          h:Show()
        else
          local row = AcquireFinderRow()
          row._inUse = true
          row:ClearAllPoints()
          row:SetPoint("TOPLEFT", scroll, "TOPLEFT", 0, y)
          row:SetPoint("RIGHT", scroll, "RIGHT", 0, 0)
          local rec = entry.rec
          row.rec = rec
          if rec then
            if PC.TrySetTexture then
              -- class icon via character-create sheet is applied in the UI module; use alchemy as fallback
            end
            local path = "Interface\\GLUES\\CHARACTERCREATE\\UI-CHARACTERCREATE-CLASSES"
            if row.icon.SetTexture then
              row.icon:SetTexture(path)
            end
            local r, g, b = 0.95, 0.95, 0.97
            if PC.ClassColor then
              r, g, b = PC:ClassColor(rec.classFile)
            end
            row.icon:SetVertexColor(r, g, b, 1)
            row.icon:Show()
            local nm = rec.name or "?"
            if PC.FitFontString then
              PC:FitFontString(row.name, nm, 90, false)
            else
              row.name:SetText(nm)
            end
            row.name:SetTextColor(r, g, b)
            row.level:SetText(rec.level and tostring(rec.level) or "")
            row.role:ClearAllPoints()
            row.role:SetPoint("LEFT", row.level, "RIGHT", 4, 0)
            if PC.ApplyRoleIcon then
              PC.ApplyRoleIcon(row.role, row.roleLetter, rec.role or "dps")
            end
            local chips = PC.MatchChips and PC:MatchChips(rec) or {}
            row.chip:ClearAllPoints()
            row.chip:SetPoint("LEFT", row.role, "RIGHT", 4, 0)
            row.chip:SetPoint("RIGHT", row, "RIGHT", -36, 0)
            local chip = chips[1] or ""
            if PC.FitFontString then
              PC:FitFontString(row.chip, chip, 70, false)
            else
              row.chip:SetText(chip)
            end
            row.invite:ClearAllPoints()
            row.invite:SetPoint("RIGHT", row, "RIGHT", -2, 0)
            row.whisper:ClearAllPoints()
            row.whisper:SetPoint("RIGHT", row.invite, "LEFT", -2, 0)
            if rec.finderHighlight and GetTime and (GetTime() - rec.finderHighlight) < 8 then
              row:SetAlpha(1)
            else
              row:SetAlpha(1)
            end
          end
          row:Show()
        end
      end
    end
    -- Pool cap: created rows should stay near visible+2
    f.visible = vis
  end

  mini.finder = f
  return f
end

function RefreshFinder()
  local f = EnsureFinder()
  local db = PC:GetMiniDB() or {}
  local status = PC.GetSocialStatus and PC:GetSocialStatus() or "busy"
  f:Show()
  local statusLabel = (PC.StatusShortLabel and PC:StatusShortLabel(status)) or status
  if status == "busy" then
    Paint(f.toggle.bg, { r = 0.16, g = 0.16, b = 0.18 }, 1)
    f.toggle.label:SetText("Not looking")
    f.toggle.label:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
  else
    Paint(f.toggle.bg, { r = 0.12, g = 0.22, b = 0.16 }, 1)
    f.toggle.label:SetText(statusLabel)
    f.toggle.label:SetTextColor(EMERALD.r, EMERALD.g, EMERALD.b)
  end
  f.toggle:SetScript("OnClick", function()
    local order = { dungeon = "questing", questing = "help", help = "busy", busy = "dungeon", open = "dungeon" }
    if PC.SetSocialStatus then
      PC:SetSocialStatus(order[status] or "dungeon")
    end
  end)
  f.kindRow:Show()
  local function paintKind(btn, match)
    if btn and btn.label then
      if match then
        btn.label:SetTextColor(EMERALD.r, EMERALD.g, EMERALD.b)
      else
        btn.label:SetTextColor(SUB.r, SUB.g, SUB.b)
      end
    end
  end
  paintKind(f.kindDungeon, status == "dungeon")
  paintKind(f.kindQuest, status == "questing")
  paintKind(f.kindHelp, status == "help")
  paintKind(f.kindBusy, status == "busy")

  if status == "busy" then
    f.offMsg:SetText("You are hidden from group lists.")
    f.offMsg:Show()
    f.count:Hide()
    f.filters:Hide()
    f.scroll:Hide()
    f.entries = {}
    return
  end

  f.offMsg:Hide()
  f.count:Show()
  f.filters:Show()
  f.scroll:Show()
  local cards = PC.GetGuildmateCards and PC:GetGuildmateCards() or {}
  f.count:SetText(tostring(#cards) .. " available")
  local function paintFilt(btn, on)
    if btn.label then
      btn.label:SetTextColor(on and EMERALD.r or SUB.r, on and EMERALD.g or SUB.g, on and EMERALD.b or SUB.b)
    end
  end
  paintFilt(f.filtTank, db.filterRole == "tank")
  paintFilt(f.filtHeal, db.filterRole == "healer")
  paintFilt(f.filtDps, db.filterRole == "dps")
  paintFilt(f.filtZone, db.filterSameZone)
  paintFilt(f.filtBracket, db.filterBracket)
  local entries = {}
  entries[#entries + 1] = { kind = "header", title = "Available guildmates", key = "available", count = #cards, collapsed = false }
  for i = 1, #cards do
    local card = cards[i]
    local rec = card.rec or card
    rec.level = rec.level or card.level
    rec.role = rec.role or card.role
    rec.demo = rec.demo or card.demo
    entries[#entries + 1] = { kind = "row", rec = rec }
  end
  f.entries = entries
  local vis = math.max(1, math.floor((f.scroll:GetHeight() or 80) / FINDER_ROW_H))
  local maxOff = math.max(0, #entries - vis)
  if f.offset > maxOff then f.offset = maxOff end
  f.RefreshList()
end

function PC:DebugMiniFinder()
  local f = mini.finder
  if not f then
    return { created = 0, visible = 0, entries = 0, pool = 0 }
  end
  return {
    created = f.created or 0,
    visible = f.visible or 0,
    entries = f.entries and #f.entries or 0,
    pool = f.pool and #f.pool or 0,
    offset = f.offset or 0,
    shown = f:IsShown() and true or false,
  }
end

function PC:SetMiniPanel(which)
  SetMiniPanel(which)
end

function CreateMini()
  if mini.created and mini.frame and mini._chromeOk then
    return mini.frame
  end

  -- Reuse a leftover frame if a previous attempt threw mid-build.
  local f = mini.frame or rawget(_G, "PhilosophersCodexMini")
  if not f then
    local template = BackdropTemplateMixin and "BackdropTemplate" or nil
    local ok, frame = pcall(CreateFrame, "Frame", "PhilosophersCodexMini", UIParent, template)
    if (not ok or not frame) and template then
      ok, frame = pcall(CreateFrame, "Frame", "PhilosophersCodexMini", UIParent)
    end
    if not ok or not frame then
      LogMiniError("mini:CreateFrame", frame or "CreateFrame failed")
      ChatLine("|cffd4af37[Codex]|r tracker could not be created: " .. tostring(frame))
      return nil
    end
    f = frame
  end
  -- Pin the reference immediately so a later decoration error cannot
  -- leave RefreshMiniTracker thinking the tracker was never created.
  mini.frame = f

  -- -------------------------------------------------------------------
  -- Phase 1: the guaranteed card. Plain frame, solid fill, gold border
  -- lines from solid textures, anchored and sized. No optional textures,
  -- masks, animations, or backdrops here.
  -- -------------------------------------------------------------------
  if not mini._core then
    if f.SetSize then
      f:SetSize(DEFAULT_W, DEFAULT_H)
    end
    if f.SetFrameStrata then
      pcall(f.SetFrameStrata, f, "MEDIUM")
    end
    if f.SetFrameLevel then
      pcall(f.SetFrameLevel, f, 10)
    end
    if f.SetClampedToScreen then
      pcall(f.SetClampedToScreen, f, true)
    end
    if f.SetToplevel then
      pcall(f.SetToplevel, f, true)
    end
    if f.SetAlpha then
      f:SetAlpha(1)
    end
    f:EnableMouse(true)
    f:SetMovable(true)
    if f.SetResizable then
      pcall(f.SetResizable, f, false)
    end
    -- Mainline: SetResizeBounds. SetMinResize/SetMaxResize were removed.
    if f.SetResizeBounds then
      pcall(f.SetResizeBounds, f, MIN_W, MIN_H, MAX_W, MAX_H)
    end
    -- HookScript keeps BackdropTemplate's own OnSizeChanged handler.
    local function onSize()
      if mini.sizing and PC.RefreshMiniTracker then
        PC:RefreshMiniTracker()
      end
    end
    if f.HookScript then
      f:HookScript("OnSizeChanged", onSize)
    else
      f:SetScript("OnSizeChanged", onSize)
    end

    -- Anchor before anything else so a throw cannot leave a sizeless, unpointed frame.
    pcall(DefaultAnchor, f)

    local okCore, errCore = pcall(function()
      -- Rounded dark card with a thin gold rim. Solid textures only; the
      -- corner masks are optional and fail soft to square corners.
      mini.shape = BuildRoundShape(f)
      LayoutRoundShape(mini.shape, f, CARD_RADIUS)
      mini.bg = mini.shape.fill[1]
    end)
    if not okCore then
      ReportDecorFailure("core-fill", errCore)
    end
    mini.parchmentPath = "rounded"
    mini.borderPath = "rounded"
    mini._core = true
  end

  -- -------------------------------------------------------------------
  -- Phase 2: decorations. Each piece is isolated; a failure is logged to
  -- the Issues log and printed once as "[Codex] tracker decoration failed".
  -- -------------------------------------------------------------------
  -- 1.18.3: the parchment, gradient bands, dialog border, and corner studs
  -- were square and are gone; the rounded shape above is the whole look.
  mini._decorated = true

  -- Title bar is the only drag handle.
  if not mini._chromeOk then
  if mini.title and mini.title.Hide then
    -- A previous attempt threw part-way; hide its leftovers and rebuild.
    pcall(mini.title.Hide, mini.title)
    mini.title = nil
  end
  local okChrome, errChrome = pcall(function()
  local title = CreateFrame("Button", nil, f)
  title:SetPoint("TOPLEFT", 0, 0)
  title:SetPoint("TOPRIGHT", 0, 0)
  title:SetHeight(TITLE_H)
  title:EnableMouse(true)
  title:RegisterForDrag("LeftButton")
  title:SetScript("OnDragStart", function()
    local db = PC:GetMiniDB()
    if db and db.locked then
      return
    end
    f:StartMoving()
  end)
  title:SetScript("OnDragStop", function()
    f:StopMovingOrSizing()
    SaveMiniGeometry()
  end)
  mini.title = title

  title.label = FS(title, "GameFontNormal", 12)
  title.label:SetPoint("LEFT", 12, 0)
  title.label:SetText("Codex")
  title.label:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
  title:SetScript("OnClick", function()
    -- Clicking the bar (not a child button) opens the main window.
    OpenMain()
  end)

  local badge = title:CreateTexture(nil, "ARTWORK")
  badge:SetSize(18, 18)
  badge:SetPoint("LEFT", title.label, "RIGHT", 6, 0)
  Paint(badge, { r = 0.16, g = 0.16, b = 0.18 }, 1)
  mini.badge = badge
  local badgeText = FS(title, "GameFontNormalSmall", 11)
  badgeText:SetPoint("CENTER", badge, "CENTER", 0, 0)
  badgeText:SetText("1")
  badgeText:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
  if badgeText.SetJustifyH then
    badgeText:SetJustifyH("CENTER")
  end
  mini.badgeText = badgeText

  local tabNext = CreateFrame("Button", "PhilosophersCodexMiniTabNext", title)
  tabNext:SetSize(36, 16)
  tabNext:SetPoint("LEFT", badge, "RIGHT", 8, 0)
  tabNext.label = FS(tabNext, "GameFontNormalSmall", 11)
  tabNext.label:SetPoint("CENTER")
  tabNext.label:SetText("Next")
  tabNext:SetScript("OnClick", function()
    SetMiniPanel("next")
  end)
  mini.tabNext = tabNext
  local tabGuild = CreateFrame("Button", "PhilosophersCodexMiniTabGuild", title)
  tabGuild:SetSize(36, 16)
  tabGuild:SetPoint("LEFT", tabNext, "RIGHT", 4, 0)
  tabGuild.label = FS(tabGuild, "GameFontNormalSmall", 11)
  tabGuild.label:SetPoint("CENTER")
  tabGuild.label:SetText("Guild")
  tabGuild:SetScript("OnClick", function()
    SetMiniPanel("guild")
  end)
  mini.tabGuild = tabGuild

  badge:Hide()
  badgeText:Hide()

  -- Expand tab: a small gold-edged tab centered on the bottom edge with a
  -- chevron that turns when the card opens.
  local toggle = CreateFrame("Button", "PhilosophersCodexMiniToggle", f)
  toggle:SetSize(44, 14)
  toggle:SetPoint("BOTTOM", f, "BOTTOM", 0, 2)
  toggle.bg = toggle:CreateTexture(nil, "BACKGROUND")
  toggle.bg:SetAllPoints()
  Paint(toggle.bg, { r = 0.14, g = 0.11, b = 0.06 }, 0.95)
  toggle.edge = toggle:CreateTexture(nil, "BORDER")
  toggle.edge:SetPoint("TOPLEFT", toggle, "TOPLEFT", 0, 0)
  toggle.edge:SetPoint("TOPRIGHT", toggle, "TOPRIGHT", 0, 0)
  toggle.edge:SetHeight(1)
  Paint(toggle.edge, GOLD, 0.9)
  toggle.arrow = toggle:CreateTexture(nil, "ARTWORK")
  toggle.arrow:SetSize(12, 12)
  toggle.arrow:SetPoint("CENTER", toggle, "CENTER", 0, 0)
  toggle.hasArrow = TryMiniTexture(toggle.arrow, "Interface\\Buttons\\UI-MicroStream-Yellow")
    or TryMiniTexture(toggle.arrow, "Interface\\ChatFrame\\UI-ChatIcon-ScrollDown-Up")
  if not toggle.hasArrow then
    toggle.arrow:Hide()
  end
  toggle.label = FS(toggle, "GameFontHighlightSmall", 10)
  toggle.label:SetPoint("CENTER", toggle, "CENTER", 0, 0)
  if toggle.label.SetJustifyH then
    toggle.label:SetJustifyH("CENTER")
  end
  toggle.label:SetText(toggle.hasArrow and "" or "v")
  toggle.label:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
  toggle:SetScript("OnClick", function()
    local db = PC:GetMiniDB()
    if not db then
      return
    end
    db.collapsed = not db.collapsed
    if PC.RefreshMiniTracker then
      PC:RefreshMiniTracker()
    end
  end)
  toggle:SetScript("OnEnter", function(self)
    if GameTooltip then
      GameTooltip:SetOwner(self, "ANCHOR_LEFT")
      local db = PC:GetMiniDB() or {}
      GameTooltip:AddLine(db.collapsed and "Show guildmates and sections" or "Collapse to the ID card", GOLD.r, GOLD.g, GOLD.b)
      GameTooltip:Show()
    end
  end)
  toggle:SetScript("OnLeave", function()
    if GameTooltip then GameTooltip:Hide() end
  end)
  mini.toggle = toggle

  -- Child of the title bar so it sits above the bar and gets its own clicks.
  local lock = CreateFrame("Button", "PhilosophersCodexMiniLock", title)
  lock:SetSize(16, 16)
  lock:SetPoint("LEFT", title.label, "RIGHT", 4, 0)
  if lock.SetFrameLevel and title.GetFrameLevel then
    pcall(lock.SetFrameLevel, lock, (title:GetFrameLevel() or 1) + 2)
  end
  lock.label = FS(lock, "GameFontHighlight", 12)
  lock.label:SetPoint("CENTER", 0, 0)
  lock.label:SetText("o")
  lock:SetScript("OnClick", function()
    local db = PC:GetMiniDB()
    if not db then
      return
    end
    PC:SetMiniOption("locked", not db.locked)
  end)
  lock:SetScript("OnEnter", function(self)
    if GameTooltip then
      GameTooltip:SetOwner(self, "ANCHOR_LEFT")
      local db = PC:GetMiniDB() or {}
      if db.locked then
        GameTooltip:AddLine("Unlock the mini tracker", GOLD.r, GOLD.g, GOLD.b)
        GameTooltip:AddLine("Allows moving and resizing.", 0.56, 0.56, 0.60, true)
      else
        GameTooltip:AddLine("Lock the mini tracker", GOLD.r, GOLD.g, GOLD.b)
        GameTooltip:AddLine("Prevents moving and resizing.", 0.56, 0.56, 0.60, true)
      end
      GameTooltip:Show()
    end
  end)
  lock:SetScript("OnLeave", function()
    if GameTooltip then GameTooltip:Hide() end
  end)
  mini.lock = lock

  -- Top-right controls: open the main window, minimize to the pill, close.
  mini.closeBtn = MakeHeaderButton(title, "PhilosophersCodexMiniClose", "close",
    "Close the tracker", "Type /codex mini to bring it back.", function()
      if PC.HideMiniTracker then
        PC:HideMiniTracker()
      end
      ChatLine("|cffd4af37[Codex]|r Tracker closed. Type /codex mini to bring it back.")
    end)
  mini.closeBtn:SetPoint("RIGHT", title, "RIGHT", -6, 0)
  mini.minBtn = MakeHeaderButton(title, "PhilosophersCodexMiniMinimize", "min",
    "Minimize", "Shrink the tracker to a small name pill.", function()
      PC:SetMiniMinimized(true)
    end)
  mini.maxBtn = MakeHeaderButton(title, "PhilosophersCodexMiniMaximize", "max",
    "Maximize", "Bring back the full ID card.", function()
      PC:SetMiniMinimized(false)
    end)
  mini.minBtn:SetPoint("RIGHT", mini.closeBtn, "LEFT", -4, 0)
  mini.maxBtn:SetPoint("RIGHT", mini.closeBtn, "LEFT", -4, 0)
  mini.maxBtn:Hide()
  mini.openBtn = MakeHeaderButton(title, "PhilosophersCodexMiniOpenMain", "open",
    "Open the Codex", "Open the main window.", function()
      OpenMain()
    end)
  mini.openBtn:SetPoint("RIGHT", mini.minBtn, "LEFT", -4, 0)

  -- Pill text (minimized only): name, guild, level.
  mini.pillName = FS(title, "GameFontHighlight", 12)
  mini.pillGuild = FS(title, "GameFontNormalSmall", 10)
  mini.pillGuild:SetTextColor(GOLD.r, GOLD.g, GOLD.b)
  mini.pillLevel = FS(title, "GameFontNormalSmall", 10)
  mini.pillLevel:SetTextColor(SUB.r, SUB.g, SUB.b)
  mini.pillName:Hide()
  mini.pillGuild:Hide()
  mini.pillLevel:Hide()

  local body = CreateFrame("Frame", nil, f)
  body:SetPoint("TOPLEFT", 10, -TITLE_H)
  body:SetPoint("BOTTOMRIGHT", -10, 12)
  mini.body = body

  mini.nextLabel = FS(body, "GameFontNormalSmall", 10)
  mini.nextLabel:SetPoint("TOPLEFT", 0, -2)
  mini.nextLabel:SetText("Next")
  mini.nextLabel:SetTextColor(GOLD.r, GOLD.g, GOLD.b)

  mini.pin = CreateFrame("Button", nil, body)
  mini.pin:SetSize(16, 16)
  mini.pin:SetPoint("TOPRIGHT", 0, -16)
  if PC._DrawPin then
    mini.pin.icon = PC._DrawPin(mini.pin, 16)
  else
    mini.pin.icon = mini.pin:CreateTexture(nil, "ARTWORK")
    mini.pin.icon:SetAllPoints()
    mini.pin.icon:SetTexture("Interface\\Icons\\INV_Misc_Map_01")
  end
  mini.pin:SetScript("OnClick", function()
    local action = mini.nextAction
    if action and action.waypoint and PC.SetWaypoint then
      PC:SetWaypoint(action.waypoint)
    end
  end)
  mini.pin:SetScript("OnEnter", function(self)
    if GameTooltip then
      GameTooltip:SetOwner(self, "ANCHOR_LEFT")
      GameTooltip:AddLine("Set a map pin", GOLD.r, GOLD.g, GOLD.b)
      GameTooltip:Show()
    end
  end)
  mini.pin:SetScript("OnLeave", function()
    if GameTooltip then GameTooltip:Hide() end
  end)
  mini.pin:Hide()

  mini.next = FS(body, "GameFontHighlight", 13)
  mini.next:SetPoint("TOPLEFT", mini.nextLabel, "BOTTOMLEFT", 0, -2)
  mini.next:SetPoint("RIGHT", mini.pin, "LEFT", -4, 0)
  mini.next:SetText("")
  mini.next:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
  mini.nextClick = CreateFrame("Button", nil, body)
  mini.nextClick:SetPoint("TOPLEFT", mini.next, "TOPLEFT", -2, 2)
  mini.nextClick:SetPoint("BOTTOMRIGHT", mini.next, "BOTTOMRIGHT", 2, -2)
  mini.nextClick:SetScript("OnClick", function()
    local item = mini.nextItem
    if item and PC.FollowNextItem then
      if PC.ShowUI then
        PC:ShowUI()
      end
      PC:FollowNextItem(item)
    elseif PC.OpenTab then
      if PC.ShowUI then
        PC:ShowUI()
      end
      PC:OpenTab("next")
    end
  end)

  mini.zoneIcon = body:CreateTexture(nil, "ARTWORK")
  mini.zoneIcon:SetSize(10, 10)
  mini.zoneIcon:SetPoint("TOPLEFT", mini.next, "BOTTOMLEFT", 0, -6)
  Paint(mini.zoneIcon, EMERALD, 1)

  mini.zone = FS(body, "GameFontHighlightSmall", 11)
  mini.zone:SetPoint("LEFT", mini.zoneIcon, "RIGHT", 4, 0)
  mini.zone:SetPoint("TOP", mini.zoneIcon, "TOP", 0, 2)
  mini.zone:SetPoint("RIGHT", body, "RIGHT", 0, 0)
  mini.zone:SetText("")

  mini.questHeader = FS(body, "GameFontDisableSmall", 10)
  mini.questHeader:SetPoint("TOPLEFT", mini.zoneIcon, "BOTTOMLEFT", 0, -8)
  mini.questHeader:SetPoint("RIGHT", body, "RIGHT", 0, 0)
  mini.questHeader:SetText("")
  mini.questHeader:SetTextColor(SUB.r, SUB.g, SUB.b)

  mini.quests = {}
  local prev = mini.questHeader
  for i = 1, MAX_QUEST_ROWS do
    local row = CreateFrame("Frame", nil, body)
    row:SetHeight(15)
    row:SetPoint("TOPLEFT", prev, "BOTTOMLEFT", 0, i == 1 and -3 or -1)
    row:SetPoint("RIGHT", body, "RIGHT", 0, 0)
    row.bullet = row:CreateTexture(nil, "ARTWORK")
    row.bullet:SetSize(5, 5)
    row.bullet:SetPoint("LEFT", 0, 0)
    Paint(row.bullet, GOLD, 0.9)
    row.text = FS(row, "GameFontHighlightSmall", 11)
    row.text:SetPoint("LEFT", 10, 0)
    row.text:SetPoint("RIGHT", 0, 0)
    row.text:SetText("")
    row.text:SetTextColor(TEXT.r, TEXT.g, TEXT.b)
    row:Hide()
    -- FitFontString is called on row.text; Hide/Show the container.
    -- Refresh looks at mini.quests[i] as the container; expose SetText on a proxy.
    mini.quests[i] = row
    prev = row
  end

  mini.more = CreateFrame("Button", "PhilosophersCodexMiniMore", body)
  mini.more:SetHeight(14)
  mini.more:SetPoint("TOPLEFT", prev, "BOTTOMLEFT", 0, -2)
  mini.more:SetPoint("RIGHT", body, "RIGHT", 0, 0)
  mini.more.label = FS(mini.more, "GameFontNormalSmall", 10)
  mini.more.label:SetPoint("LEFT", 0, 0)
  mini.more.label:SetText("+0 more")
  mini.more.label:SetTextColor(EMERALD.r, EMERALD.g, EMERALD.b)
  mini.more:SetScript("OnClick", function()
    OpenMain()
    if PC.OpenTab then
      PC:OpenTab("path")
    end
  end)
  mini.more:Hide()

  mini.bar = CreateFrame("StatusBar", nil, body)
  mini.bar:SetHeight(4)
  mini.bar:SetPoint("BOTTOMLEFT", body, "BOTTOMLEFT", 0, 2)
  mini.bar:SetPoint("BOTTOMRIGHT", body, "BOTTOMRIGHT", -32, 2)
  if mini.bar.SetStatusBarTexture then
    mini.bar:SetStatusBarTexture(BAR)
  end
  if mini.bar.SetStatusBarColor then
    mini.bar:SetStatusBarColor(EMERALD.r, EMERALD.g, EMERALD.b, 1)
  end
  if mini.bar.SetMinMaxValues then
    mini.bar:SetMinMaxValues(0, 1)
  end
  if mini.bar.SetValue then
    mini.bar:SetValue(0)
  end
  local barBg = mini.bar:CreateTexture(nil, "BACKGROUND")
  barBg:SetAllPoints()
  Paint(barBg, { r = 0.15, g = 0.15, b = 0.16 }, 1)

  mini.barLabel = FS(body, "GameFontHighlightSmall", 10)
  mini.barLabel:SetPoint("LEFT", mini.bar, "RIGHT", 6, 0)
  mini.barLabel:SetText("0%")
  mini.barLabel:SetTextColor(SUB.r, SUB.g, SUB.b)

  -- 1.23.0: no resize grip; the card is a fixed width and its height
  -- follows the content.
  mini.grip = nil
  end)
  if not okChrome then
    ReportDecorFailure("chrome", errChrome)
  end
  mini._chromeOk = okChrome and true or false
  end

  local okFinder, errFinder = pcall(EnsureFinder)
  if not okFinder then
    LogMiniError("mini:EnsureFinder", errFinder)
  end
  mini.frame = f
  mini.created = true
  if PC.ProtectFrameTree then
    pcall(function() PC:ProtectFrameTree(f) end)
  end
  local db = PC.GetMiniDB and PC:GetMiniDB() or nil
  if not SavedGeometryValid(db or {}) then
    pcall(DefaultAnchor, f)
  end
  -- Phase 1 content: portrait, name, and status pills, built now so the
  -- card has them even if a later Refresh step throws.
  local okCard, errCard = pcall(LayoutPlayerCard, db and db.collapsed and true or false)
  if not okCard then
    ReportDecorFailure("player-card", errCard)
  end
  -- Show unless the player turned the tracker off. Do not Hide() here and
  -- rely on Refresh: a later layout error would leave the card invisible.
  if db and db.enabled == false then
    f:Hide()
  else
    f:Show()
  end
  return f
end

function PC:ShowMiniTracker()
  local db = self:GetMiniDB()
  if db then
    db.enabled = true
  end
  local okC, errC = pcall(CreateMini)
  if not okC then
    LogMiniError("mini:show:create", errC)
    ChatLine("|cffd4af37[Codex]|r tracker build failed: " .. tostring(errC))
  end
  local okR, errR = pcall(self.RefreshMiniTracker, self)
  if not okR then
    LogMiniError("mini:show:refresh", errR)
  end
  pcall(self.UpdateMiniVisibility, self)
  if mini.frame and not (db and (db.hideInCombat or db.hideInInstances)) then
    if mini.frame.SetAlpha then mini.frame:SetAlpha(1) end
    mini.frame:Show()
  end
  if self.RefreshOptionsPanel then
    self:RefreshOptionsPanel()
  end
end

function PC:HideMiniTracker()
  local db = self:GetMiniDB()
  if db then
    db.enabled = false
  end
  if mini.frame then
    mini.frame:Hide()
  end
  if self.RefreshOptionsPanel then
    self:RefreshOptionsPanel()
  end
end

function PC:ToggleMiniTracker()
  local db = self:GetMiniDB()
  local f = mini.frame
  local visible = f and f.IsVisible and f:IsVisible() and (not f.GetAlpha or (f:GetAlpha() or 0) > 0.05)
  if (db and db.enabled == false) or not visible then
    self:ShowMiniTracker()
    self:Print("The mini tracker is shown. /codex mini again to hide it.")
  else
    self:HideMiniTracker()
    self:Print("The mini tracker is hidden. /codex mini again to show it.")
  end
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("PLAYER_ENTERING_WORLD")
ev:RegisterEvent("PLAYER_LEVEL_UP")
ev:RegisterEvent("ZONE_CHANGED")
ev:RegisterEvent("ZONE_CHANGED_INDOORS")
ev:RegisterEvent("ZONE_CHANGED_NEW_AREA")
ev:RegisterEvent("QUEST_LOG_UPDATE")
ev:RegisterEvent("QUEST_TURNED_IN")
ev:RegisterEvent("PLAYER_REGEN_DISABLED")
ev:RegisterEvent("PLAYER_REGEN_ENABLED")
-- Stats strip. pcall each: an unknown event name throws in the real client.
for _, name in ipairs({ "UNIT_STATS", "PLAYER_EQUIPMENT_CHANGED", "COMBAT_RATING_UPDATE", "UNIT_MAXPOWER", "PLAYER_DAMAGE_DONE_MODS", "SPELL_POWER_CHANGED" }) do
  pcall(ev.RegisterEvent, ev, name)
end

local function QueueStatsRefresh()
  if mini.statsPending then
    return
  end
  mini.statsPending = true
  local function run()
    mini.statsPending = false
    if PC.RefreshMiniTracker then
      local ok, err = pcall(PC.RefreshMiniTracker, PC)
      if not ok then
        LogMiniError("mini:stats", err)
      end
    end
  end
  if C_Timer and C_Timer.After then
    C_Timer.After(0.25, run)
  else
    run()
  end
end

ev:SetScript("OnEvent", function(_, event, arg1)
  if event == "UNIT_STATS" or event == "UNIT_MAXPOWER" then
    if arg1 == "player" then
      QueueStatsRefresh()
    end
    return
  end
  if event == "PLAYER_EQUIPMENT_CHANGED" or event == "COMBAT_RATING_UPDATE" or event == "PLAYER_DAMAGE_DONE_MODS" or event == "SPELL_POWER_CHANGED" then
    QueueStatsRefresh()
    return
  end
  if event == "PLAYER_LOGIN" then
    if PC.GetDB and not PC:GetDB() and PC.InitDB then
      PC:InitDB()
    end
    local function bootMini()
      CreateMini()
      if PC.RefreshMiniTracker then
        PC:RefreshMiniTracker()
      end
      if PC.UpdateMiniVisibility then
        PC:UpdateMiniVisibility()
      end
    end
    if PC.SafeCall then
      PC:SafeCall("mini:login", bootMini)
    else
      local ok, err = pcall(bootMini)
      if not ok then
        LogMiniError("mini:login", err)
      end
    end
    -- Ensure the card is visible after a mid-boot error if it was created.
    if mini.frame and PC.UpdateMiniVisibility then
      pcall(PC.UpdateMiniVisibility, PC)
    elseif mini.frame then
      local db = PC.GetMiniDB and PC:GetMiniDB() or nil
      if not (db and db.enabled == false) then
        mini.frame:Show()
      end
    end
    return
  end
  if event == "PLAYER_ENTERING_WORLD" then
    if PC.SyncLiveActivityZone then
      PC:SyncLiveActivityZone(event)
    end
    if PC.RefreshMiniTracker then
      PC:RefreshMiniTracker()
    end
    if PC.UpdateMiniVisibility then
      PC:UpdateMiniVisibility()
    end
    return
  end
  if event == "PLAYER_LEVEL_UP" then
    local function after()
      if PC.RefreshMiniTracker then
        PC:RefreshMiniTracker()
      end
    end
    if C_Timer and C_Timer.After then
      C_Timer.After(0.5, after)
    else
      after()
    end
    return
  end
  if event == "ZONE_CHANGED" or event == "ZONE_CHANGED_INDOORS" or event == "ZONE_CHANGED_NEW_AREA" then
    if PC.SyncLiveActivityZone then
      PC:SyncLiveActivityZone(event)
    end
    if PC.RefreshMiniTracker then
      PC:RefreshMiniTracker()
    end
    if PC.UpdateMiniVisibility then
      PC:UpdateMiniVisibility()
    end
    return
  end
  if event == "QUEST_LOG_UPDATE" or event == "QUEST_TURNED_IN" then
    if PC.NoteSectionCardDirty then
      PC:NoteSectionCardDirty()
    end
    if mini.questPending then
      return
    end
    mini.questPending = true
    local function run()
      mini.questPending = false
      if PC.RefreshMiniTracker then
        PC:RefreshMiniTracker()
      end
    end
    if C_Timer and C_Timer.After then
      C_Timer.After(0.5, run)
    else
      run()
    end
    return
  end
  if event == "PLAYER_REGEN_DISABLED" or event == "PLAYER_REGEN_ENABLED" then
    if PC.UpdateMiniVisibility then
      PC:UpdateMiniVisibility()
    end
  end
end)

-- /codex mini debug: plain frame state so a missing card can be diagnosed in game.
function PC:GetMiniDebugLines()
  local lines = {}
  local function add(k, v)
    lines[#lines + 1] = tostring(k) .. ": " .. tostring(v)
  end
  local function call(obj, method, ...)
    if obj and type(obj[method]) == "function" then
      local ok, a, b, c, d, e = pcall(obj[method], obj, ...)
      if ok then
        return a, b, c, d, e
      end
      return "error: " .. tostring(a)
    end
    return nil
  end
  local f = mini.frame
  add("version", self.VERSION or "?")
  add("exists", f and true or false)
  add("created", mini.created and true or false)
  add("core", mini._core and true or false)
  add("chrome", mini._chromeOk and true or false)
  add("decorated", mini._decorated and true or false)
  if f then
    add("shown", call(f, "IsShown"))
    add("visible", call(f, "IsVisible"))
    add("alpha", call(f, "GetAlpha"))
    add("effectiveAlpha", call(f, "GetEffectiveAlpha"))
    add("scale", call(f, "GetScale"))
    add("size", tostring(call(f, "GetWidth")) .. " x " .. tostring(call(f, "GetHeight")))
    add("left/bottom", tostring(call(f, "GetLeft")) .. " / " .. tostring(call(f, "GetBottom")))
    local np = call(f, "GetNumPoints")
    add("points", np)
    local p, rel, rp, x, y = call(f, "GetPoint", 1)
    local relName = rel
    if type(rel) == "table" then
      relName = call(rel, "GetName") or "unnamed"
    end
    add("point1", tostring(p) .. " " .. tostring(relName) .. " " .. tostring(rp) .. " " .. tostring(x) .. "," .. tostring(y))
    add("strata", call(f, "GetFrameStrata"))
    add("level", call(f, "GetFrameLevel"))
    local parent = call(f, "GetParent")
    local parentName = parent and (call(parent, "GetName") or "unnamed") or "none"
    add("parent", tostring(parentName) .. " shown=" .. tostring(parent and call(parent, "IsShown")))
    add("card", mini.card and ("shown=" .. tostring(call(mini.card, "IsShown")) .. " h=" .. tostring(call(mini.card, "GetHeight"))) or "missing")
  end
  local sw, sh = ScreenSize()
  add("screen", tostring(sw) .. " x " .. tostring(sh))
  local db = self.GetMiniDB and self:GetMiniDB() or nil
  if type(db) == "table" then
    local keys = { "enabled", "collapsed", "minimized", "locked", "scale", "opacity", "x", "y", "w", "h", "panel", "hideInCombat", "hideInInstances", "sectionsCollapsed" }
    local parts = {}
    for i = 1, #keys do
      parts[#parts + 1] = keys[i] .. "=" .. tostring(db[keys[i]])
    end
    add("db.mini", table.concat(parts, " "))
  else
    add("db.mini", "missing")
  end
  add("fullName", self.GetPlayerFullName and self:GetPlayerFullName() or "?")
  local srcs = self.GetNameSources and self:GetNameSources() or {}
  add("nameSources", (#srcs > 0) and table.concat(srcs, "; ") or "none")
  add("inCombat", InCombat())
  add("inInstance", InInstance())
  if mini.decorErrors and #mini.decorErrors > 0 then
    for i = 1, #mini.decorErrors do
      add("decorError" .. i, mini.decorErrors[i])
    end
  else
    add("decorErrors", "none")
  end
  return lines
end

function PC:PrintMiniDebug()
  local lines = self:GetMiniDebugLines()
  ChatLine("|cffd4af37[Codex]|r mini tracker debug:")
  for i = 1, #lines do
    ChatLine("  " .. lines[i])
  end
  return lines
end

function PC:GetMiniDecorErrors()
  return mini.decorErrors or {}
end
