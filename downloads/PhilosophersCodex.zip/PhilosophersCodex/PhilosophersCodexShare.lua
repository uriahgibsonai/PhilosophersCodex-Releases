-- Philosopher's Codex: guild sharing among Alchemists who also run the addon.
-- Messages go only on the GUILD addon channel. All APIs are guarded.

local PC = PhilosophersCodex
local PREFIX = "PhiloCodex"
local THROTTLE = 10
local EXPIRE = 600

local peers = {}
local lastSend = nil
local lastRoster = nil
local started = false

local function Now()
  if GetTime then
    return GetTime()
  end
  return (time and time()) or 0
end

local function NormName(name)
  if not name or name == "" then
    return nil
  end
  if Ambiguate then
    local ok, short = pcall(Ambiguate, name, "none")
    if ok and type(short) == "string" and short ~= "" then
      return short
    end
  end
  local short = string.match(name, "^([^%-]+)")
  return short or name
end

local function PlayerName()
  if UnitName then
    return NormName(UnitName("player"))
  end
  return nil
end

local function IsSelf(name)
  local me = PlayerName()
  local them = NormName(name)
  return me and them and string.lower(me) == string.lower(them)
end

local function InGuild()
  if IsInGuild then
    local ok, result = pcall(IsInGuild)
    if ok then
      return result and true or false
    end
  end
  return false
end

local function Clean(value)
  local s = tostring(value or "-")
  s = string.gsub(s, "[%|%c]", " ")
  s = string.gsub(s, "^%s+", "")
  s = string.gsub(s, "%s+$", "")
  if s == "" then
    s = "-"
  end
  return s
end

local function SplitPipe(msg)
  local parts = {}
  if not msg then
    return parts
  end
  local start = 1
  local len = string.len(msg)
  while start <= len + 1 do
    local i = string.find(msg, "|", start, true)
    if not i then
      parts[#parts + 1] = string.sub(msg, start)
      break
    end
    parts[#parts + 1] = string.sub(msg, start, i - 1)
    start = i + 1
  end
  return parts
end

local function ParseRange(id)
  if type(id) ~= "string" then
    return nil, nil
  end
  local a, b = string.match(id, "(%d+)%s*%-%s*(%d+)")
  if a then
    return tonumber(a), tonumber(b)
  end
  return nil, nil
end

function PC:IsShareEnabled()
  local db = self:GetDB()
  if not db then
    return true
  end
  if db.shareEnabled == nil then
    return true
  end
  return db.shareEnabled and true or false
end

function PC:SetShareEnabled(on)
  if not self:GetDB() then
    self:InitDB()
  end
  local db = self:GetDB()
  if db then
    db.shareEnabled = on and true or false
  end
  if on then
    self:BroadcastStatus()
  end
  if self.Refresh then
    self:Refresh()
  end
  if self.RefreshOptionsPanel then
    self:RefreshOptionsPanel()
  end
end

function PC:RegisterSharePrefix()
  if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
    pcall(C_ChatInfo.RegisterAddonMessagePrefix, PREFIX)
  elseif RegisterAddonMessagePrefix then
    pcall(RegisterAddonMessagePrefix, PREFIX)
  end
end

function PC:SendGuildAddon(msg)
  if type(msg) ~= "string" or msg == "" then
    return false
  end
  if string.len(msg) > 254 then
    msg = string.sub(msg, 1, 254)
  end
  if not self:IsShareEnabled() or not InGuild() then
    return false
  end
  if C_ChatInfo and C_ChatInfo.SendAddonMessage then
    local ok = pcall(C_ChatInfo.SendAddonMessage, PREFIX, msg, "GUILD")
    return ok
  end
  if SendAddonMessage then
    local ok = pcall(SendAddonMessage, PREFIX, msg, "GUILD")
    return ok
  end
  return false
end

function PC:BuildSharePayload()
  local ver = self.VERSION or "1.4.0"
  local class = self:GetClassFile() or "?"
  local level = self:PlayerLevel() or 0
  local bid = "-"
  if self.BracketKey and self.GetCurrentBrackets then
    bid = self:BracketKey(self:GetCurrentBrackets())
    if bid == "" then
      bid = "-"
    end
  end
  local zone = "-"
  if self.CurrentZoneNames then
    local names = self:CurrentZoneNames()
    zone = names and names[1] or "-"
  end
  local nextD = "-"
  if self.GetNextAction then
    local action = self:GetNextAction()
    if action and action.title and action.title ~= "" then
      nextD = action.title
    end
  end
  local pct = 0
  if self.OverallProgress then
    local done, total = self:OverallProgress()
    if total and total > 0 then
      pct = math.floor((done / total) * 100 + 0.5)
    end
  end
  local status = self.GetSocialStatus and self:GetSocialStatus() or "questing"
  local role = self.GetSocialRole and self:GetSocialRole() or "healer"
  local note = self.GetSocialNote and self:GetSocialNote() or ""
  local lfg = self.GetSocialLfg and self:GetSocialLfg() or "-"
  local st = ({ questing = "Q", dungeon = "L", help = "H", open = "O", busy = "B" })[status] or "Q"
  local rl = ({ healer = "H", tank = "T", dps = "D" })[role] or "H"
  if type(note) == "string" and string.len(note) > 40 then
    note = string.sub(note, 1, 40)
  end
  if not lfg or lfg == "" then
    lfg = "-"
  end
  local avail = "-"
  -- Busy (Not looking) hides this player from group lists. Can-help is a
  -- separate trailing flag so they can still appear for Need help.
  local listed = true
  if self.IsListedForGroups then
    listed = self:IsListedForGroups()
  elseif status == "busy" or not (self.IsAvailableToGroup and self:IsAvailableToGroup()) then
    listed = false
  end
  if listed then
    local kind = self.GetAvailKind and self:GetAvailKind() or "both"
    avail = ({ quest = "Q", dungeon = "D", both = "B" })[kind] or "B"
  end
  -- Trailing fields are ignored by older peers and stay well under 255.
  -- Field 13 is 1.9 availability. Field 14 is compact dungeon chips.
  -- Field 15 is 1.16 can-help (C or -). Field 16 is an optional activity zone.
  local payload = table.concat({
    "S",
    Clean(ver),
    Clean(class),
    tostring(level),
    Clean(bid),
    Clean(zone),
    Clean(nextD),
    tostring(pct),
    st,
    rl,
    Clean(note),
    Clean(lfg),
    avail,
  }, "|")
  local chips = "-"
  if self.EncodeDungeonChips and self.GetSelectedDungeons then
    chips = self:EncodeDungeonChips(self:GetSelectedDungeons()) or "-"
  end
  if chips and chips ~= "" and chips ~= "-" then
    local with = payload .. "|" .. Clean(chips)
    if string.len(with) < 255 then
      payload = with
    end
  else
    payload = payload .. "|-"
  end
  local helpFlag = "-"
  if self.GetCanHelp and self:GetCanHelp() then
    helpFlag = "C"
  elseif status == "open" then
    helpFlag = "C"
  end
  local withHelp = payload .. "|" .. helpFlag
  if string.len(withHelp) < 255 then
    payload = withHelp
    local actZone = "-"
    if self.GetActivityZone then
      actZone = self:GetActivityZone() or "-"
    end
    if actZone == "" then
      actZone = "-"
    end
    local withZone = payload .. "|" .. Clean(actZone)
    if string.len(withZone) < 255 then
      payload = withZone
    end
  end
  return payload
end

function PC:BroadcastStatus(force)
  if not self:IsShareEnabled() or not InGuild() then
    return false
  end
  local now = Now()
  if not force and lastSend ~= nil and (now - lastSend) < THROTTLE then
    return false
  end
  if self:SendGuildAddon(self:BuildSharePayload()) then
    lastSend = now
    return true
  end
  return false
end

function PC:SendHello()
  if not self:IsShareEnabled() or not InGuild() then
    return false
  end
  return self:SendGuildAddon("H")
end

function PC:StartSharing()
  if started then
    return
  end
  started = true
  self:RegisterSharePrefix()
  self:RequestGuildRoster()
  local function kick()
    self:SendHello()
    self:BroadcastStatus()
    if self.AnnounceCollector then pcall(self.AnnounceCollector, self) end
  end
  -- A collector re-announces every 10 minutes so new problems keep flowing.
  if C_Timer and C_Timer.NewTicker then
    C_Timer.NewTicker(600, function()
      if PC.AnnounceCollector then pcall(PC.AnnounceCollector, PC) end
    end)
  end
  if C_Timer and C_Timer.After then
    C_Timer.After(4, kick)
  else
    kick()
  end
end

local function StorePeer(sender, parts)
  local name = NormName(sender)
  if not name then
    return
  end
  local rec = peers[name] or { name = name }
  rec.version = parts[2] or rec.version
  rec.classFile = parts[3] or rec.classFile
  rec.level = tonumber(parts[4]) or rec.level
  rec.bracket = parts[5] or rec.bracket
  rec.zone = parts[6] or rec.zone
  rec.nextDungeon = parts[7] or rec.nextDungeon
  rec.pct = tonumber(parts[8]) or rec.pct
  local STATUS = { Q = "questing", L = "dungeon", H = "help", O = "open", B = "busy" }
  local ROLE = { H = "healer", T = "tank", D = "dps" }
  if parts[9] and parts[9] ~= "" and parts[9] ~= "-" then
    rec.status = STATUS[parts[9]] or rec.status
  end
  if parts[10] and parts[10] ~= "" and parts[10] ~= "-" then
    rec.role = ROLE[parts[10]] or rec.role
  end
  if parts[11] and parts[11] ~= "-" then
    rec.note = parts[11]
  end
  if parts[12] and parts[12] ~= "" then
    rec.lfg = (parts[12] ~= "-") and parts[12] or nil
  end
  -- 1.9 availability. Missing field (1.4-1.8 payloads) is legacy: we no
  -- longer list those peers unless they later send an explicit available
  -- flag plus a matching status.
  rec.statusExplicit = (parts[9] and parts[9] ~= "" and parts[9] ~= "-") and true or false
  if parts[13] == nil or parts[13] == "" then
    rec.available = true
    rec.availKind = rec.availKind or "both"
    rec.availLegacy = true
    rec.availExplicit = false
  elseif parts[13] == "-" then
    rec.available = false
    rec.availKind = nil
    rec.availLegacy = false
    rec.availExplicit = true
  else
    rec.available = true
    rec.availLegacy = false
    rec.availExplicit = true
    rec.availKind = ({ Q = "quest", D = "dungeon", B = "both" })[parts[13]] or "both"
  end
  -- 1.14 dungeon chips. Missing field is fine; fall back to lfg / nextDungeon.
  if parts[14] and parts[14] ~= "" and parts[14] ~= "-" then
    if PC.DecodeDungeonChips then
      rec.dungeons = PC:DecodeDungeonChips(parts[14])
    else
      rec.dungeons = rec.dungeons or {}
    end
  end
  -- 1.16 can-help flag and optional activity zone.
  if parts[15] and parts[15] ~= "" and parts[15] ~= "-" then
    rec.canHelp = (string.sub(parts[15], 1, 1) == "C")
  else
    rec.canHelp = rec.status == "open" or rec.canHelp
  end
  if parts[16] and parts[16] ~= "" and parts[16] ~= "-" then
    rec.activityZone = parts[16]
  end
  rec.lastSeen = Now()
  rec.online = true
  rec.name = name
  peers[name] = rec
  if rec.version and PC.NoteNewerVersion then
    PC:NoteNewerVersion(rec.version, name)
  end
  if PC.NotifyPeerUpdate then
    PC:NotifyPeerUpdate(rec)
  end
end

function PC:OnAddonMessage(prefix, msg, channel, sender)
  if prefix ~= PREFIX then
    return
  end
  if channel ~= "GUILD" then
    return
  end
  if type(msg) ~= "string" or msg == "" then
    return
  end
  if IsSelf(sender) then
    return
  end
  if msg == "H" or string.sub(msg, 1, 2) == "H|" then
    self:BroadcastStatus()
    if self.HandleReportMessage then pcall(self.HandleReportMessage, self, sender, { "H" }) end
    return
  end
  local parts = SplitPipe(msg)
  local kind = parts[1]
  -- 1.24.0: automatic guild reports (R = report, RC = collector online).
  if (kind == "R" or kind == "RC") and self.HandleReportMessage then
    pcall(self.HandleReportMessage, self, sender, parts)
    return
  end
  if kind == "S" then
    StorePeer(sender, parts)
    if self.Refresh then
      self:Refresh()
    end
    return
  end
  -- Version-tolerant: unknown prefixes from older or newer clients are ignored.
  if kind == "QREQ" then
    self:SendQuestList()
    return
  end
  if kind == "QA" then
    self:StorePeerQuests(sender, parts[2])
    if self.Refresh then
      self:Refresh()
    end
    return
  end
  if kind == "J" then
    self:HandleJoinMessage(sender, parts)
    return
  end
end

function PC:RequestGuildRoster()
  local now = Now()
  if lastRoster ~= nil and (now - lastRoster) < 30 then
    return false
  end
  lastRoster = now
  if C_GuildInfo and C_GuildInfo.GuildRoster then
    pcall(C_GuildInfo.GuildRoster)
    return true
  end
  if GuildRoster then
    pcall(GuildRoster)
    return true
  end
  return false
end

function PC:ApplyGuildRoster()
  if not GetNumGuildMembers or not GetGuildRosterInfo then
    return
  end
  local ok, n = pcall(GetNumGuildMembers)
  if not ok or type(n) ~= "number" then
    return
  end
  local seen = {}
  for i = 1, n do
    local okRow, name, _, _, _, _, _, _, isOnline, _, classFile = pcall(GetGuildRosterInfo, i)
    if okRow then
      local key = NormName(name)
      if key then
        seen[string.lower(key)] = isOnline and true or false
        if peers[key] then
          peers[key].online = isOnline and true or false
          if classFile and classFile ~= "" then
            peers[key].classFile = peers[key].classFile or classFile
          end
        end
      end
    end
  end
  for key, rec in pairs(peers) do
    local flag = seen[string.lower(key)]
    if flag ~= nil then
      rec.online = flag
    end
  end
end

function PC:ExpireGuildPeers()
  local now = Now()
  for key, rec in pairs(peers) do
    if rec.lastSeen and (now - rec.lastSeen) > EXPIRE then
      peers[key] = nil
    end
  end
end

function PC:IsGoodGroupMatch(peer)
  if not peer then
    return false
  end
  local mine = self.GetCurrentBrackets and self:GetCurrentBrackets() or {}
  local their = {}
  if type(peer.bracket) == "string" and peer.bracket ~= "-" then
    for id in string.gmatch(peer.bracket, "[^,]+") do
      their[#their + 1] = id
    end
  end
  for i = 1, #mine do
    local a1, a2 = mine[i].min, mine[i].max
    if not a1 then
      a1, a2 = ParseRange(mine[i].id)
    end
    for j = 1, #their do
      local b1, b2 = ParseRange(their[j])
      if a1 and b1 and a1 <= b2 and b1 <= a2 then
        return true
      end
    end
    if peer.level and a1 and a2 and peer.level >= a1 and peer.level <= a2 then
      return true
    end
  end
  return false
end

function PC:GetGuildPeers()
  self:ExpireGuildPeers()
  local list = {}
  for _, rec in pairs(peers) do
    rec.match = self:IsGoodGroupMatch(rec)
    list[#list + 1] = rec
  end
  table.sort(list, function(a, b)
    if a.match and not b.match then
      return true
    end
    if b.match and not a.match then
      return false
    end
    if a.online and not b.online then
      return true
    end
    if b.online and not a.online then
      return false
    end
    return string.lower(a.name or "") < string.lower(b.name or "")
  end)
  return list
end

function PC:CountNearbyAlchemists()
  local n = 0
  local list = self:GetGuildPeers()
  for i = 1, #list do
    if list[i].match and list[i].online ~= false then
      n = n + 1
    end
  end
  return n
end

function PC:ClassColor(classFile)
  classFile = classFile or (self.GetClassFile and self:GetClassFile())
  if type(classFile) == "string" then
    classFile = string.upper(classFile)
  end
  if classFile and C_ClassColor and C_ClassColor.GetClassColor then
    local ok, c = pcall(C_ClassColor.GetClassColor, classFile)
    if ok and type(c) == "table" then
      local r, g, b = c.r, c.g, c.b
      if (r == nil or g == nil or b == nil) and c.GetRGB then
        local ok2, rr, gg, bb = pcall(c.GetRGB, c)
        if ok2 then
          r, g, b = rr, gg, bb
        end
      end
      if r and g and b then
        return r, g, b, c
      end
    end
  end
  if classFile and RAID_CLASS_COLORS and RAID_CLASS_COLORS[classFile] then
    local c = RAID_CLASS_COLORS[classFile]
    return c.r or 1, c.g or 1, c.b or 1, c
  end
  return 0.95, 0.95, 0.97
end

function PC:FormatPeerSeen(rec)
  if not rec then
    return ""
  end
  if rec.online == false then
    return "offline"
  end
  if not rec.lastSeen then
    return "online"
  end
  local age = Now() - rec.lastSeen
  if age < 45 then
    return "just now"
  end
  if age < 3600 then
    return tostring(math.floor(age / 60 + 0.5)) .. " min ago"
  end
  return tostring(math.floor(age / 3600 + 0.5)) .. "h ago"
end

function PC:WhisperPeer(name, text)
  name = NormName(name)
  if not name then
    return
  end
  if self.IsDemoPeer and self:IsDemoPeer(name) then
    return
  end
  local prefix = "/w " .. name .. " "
  if type(text) == "string" and text ~= "" then
    prefix = prefix .. text
  end
  if text and text ~= "" and ChatFrame_OpenChat then
    pcall(ChatFrame_OpenChat, prefix)
    return
  end
  if ChatFrame_SendTell then
    pcall(ChatFrame_SendTell, name)
    if text and text ~= "" and ChatEdit_InsertLink then
      -- No-op fallback; OpenChat already tried.
    end
    return
  end
  if ChatFrame_OpenChat then
    pcall(ChatFrame_OpenChat, prefix)
  end
end

function PC:InvitePeer(name)
  name = NormName(name)
  if not name then
    return
  end
  if self.IsDemoPeer and self:IsDemoPeer(name) then
    return
  end
  if C_PartyInfo and C_PartyInfo.InviteUnit then
    pcall(C_PartyInfo.InviteUnit, name)
    return
  end
  if InviteUnit then
    pcall(InviteUnit, name)
  end
end

-- ---------------------------------------------------------------------------
-- Social group finder (1.6.0). Status, match scoring, join requests.
-- Invite/Accept stay click-only. All extra message types stay under 255.
-- ---------------------------------------------------------------------------

local lastQuestSend = nil
local lastQuestReq = nil
local lastJoinSend = {}
local lastMatchToast = {}
local joinRequests = {} -- incoming
local outgoingRequests = {}
local notifiedOnline = {}

local function EnsureDB()
  if not PC:GetDB() then
    PC:InitDB()
  end
  return PC:GetDB()
end

local function GuessRole()
  local data = PC.GetClassData and PC:GetClassData() or nil
  local p = PC.GetUpgradeProfile and PC:GetUpgradeProfile() or (data and data.defaultProfile)
  if p == "heal" then
    return "healer"
  end
  if p == "balance" or p == "frost" or p == "fire" or p == "affliction" or p == "dest" or p == "generic" then
    return "dps"
  end
  if data and data.defaultRole then
    return data.defaultRole
  end
  return "dps"
end

function PC:GuessSocialRole()
  return GuessRole()
end

function PC:GetSocialStatus()
  local db = self:GetDB()
  local s = db and db.guildStatus
  if s == "questing" or s == "dungeon" or s == "help" or s == "open" or s == "busy" then
    return s
  end
  return "questing"
end

function PC:GetSocialRole()
  local db = self:GetDB()
  local r = db and db.guildRole
  if r ~= "healer" and r ~= "tank" and r ~= "dps" then
    r = GuessRole()
  end
  if self.ClampSocialRole then
    return self:ClampSocialRole(r)
  end
  return r
end

function PC:GetSocialNote()
  local db = self:GetDB()
  if db and type(db.guildNote) == "string" then
    return db.guildNote
  end
  return ""
end

function PC:GetSocialLfg()
  local db = self:GetDB()
  if db and type(db.guildLfg) == "string" and db.guildLfg ~= "" then
    return db.guildLfg
  end
  return nil
end

function PC:GetGuildSegment()
  local db = self:GetDB()
  local s = db and db.guildSegment
  if s == "group" or s == "everyone" or s == "requests" then
    return s
  end
  return "group"
end

function PC:SetGuildSegment(seg)
  local db = EnsureDB()
  if db and (seg == "group" or seg == "everyone" or seg == "requests") then
    db.guildSegment = seg
  end
  if self.Refresh then
    self:Refresh()
  end
end

local function WallClock()
  if time then
    local ok, t = pcall(time)
    if ok and type(t) == "number" then
      return t
    end
  end
  return Now()
end

function PC:CheckAvailExpire()
  local db = self:GetDB()
  if not db or not db.availableToGroup then
    return false
  end
  local hours = tonumber(db.availExpireHours) or 0
  local started = tonumber(db.availStartedAt)
  if hours > 0 and started and (WallClock() - started) >= (hours * 3600) then
    db.availableToGroup = false
    return true
  end
  return false
end

function PC:IsAvailableToGroup()
  self:CheckAvailExpire()
  local db = self:GetDB()
  return db and db.availableToGroup and true or false
end

function PC:GetAvailKind()
  local db = self:GetDB()
  local k = db and db.availKind
  if k == "quest" or k == "dungeon" or k == "both" then
    return k
  end
  return "both"
end

function PC:SetAvailKind(kind)
  if kind ~= "quest" and kind ~= "dungeon" and kind ~= "both" then
    return
  end
  local db = EnsureDB()
  if db then
    db.availKind = kind
  end
  if self:IsAvailableToGroup() then
    self:BroadcastStatus(true)
  end
  if self.Refresh then
    self:Refresh()
  end
  if self.RefreshOptionsPanel then
    self:RefreshOptionsPanel()
  end
  if self.RefreshMiniTracker then
    self:RefreshMiniTracker()
  end
end

function PC:SetAvailableToGroup(on, kind)
  local db = EnsureDB()
  if not db then
    return
  end
  on = on and true or false
  db.availableToGroup = on
  db.availUserSet = true
  if kind == "quest" or kind == "dungeon" or kind == "both" then
    db.availKind = kind
  end
  if on then
    db.availStartedAt = WallClock()
  else
    db.availStartedAt = nil
  end
  self:BroadcastStatus(true)
  if self.Refresh then
    self:Refresh()
  end
  if self.RefreshOptionsPanel then
    self:RefreshOptionsPanel()
  end
  if self.RefreshMiniTracker then
    self:RefreshMiniTracker()
  end
end

function PC:SetAvailExpireHours(hours)
  local db = EnsureDB()
  if not db then
    return
  end
  hours = tonumber(hours) or 4
  if hours < 0 then hours = 0 end
  if hours > 24 then hours = 24 end
  db.availExpireHours = hours
end

function PC:SetAvailExpireOnLogout(on)
  local db = EnsureDB()
  if db then
    db.availExpireOnLogout = on and true or false
  end
end

function PC:PeerIsAvailable(rec)
  if not rec then
    return false
  end
  if rec.available == false then
    return false
  end
  -- Legacy 1.4-1.8 peers (available ~= false) count as available.
  return true
end

local function PersistAndBroadcast()
  if PC.BroadcastStatus then
    -- User-initiated status, role, note, and LFG changes must go out
    -- immediately; the 10s heartbeat throttle must not swallow them.
    PC:BroadcastStatus(true)
  end
  if PC.Refresh then
    PC:Refresh()
  end
  if PC.RefreshOptionsPanel then
    PC:RefreshOptionsPanel()
  end
  if PC.RefreshMiniTracker then
    PC:RefreshMiniTracker()
  end
end

function PC:IsListedForGroups()
  if self:GetSocialStatus() == "busy" then
    return false
  end
  return self:IsAvailableToGroup()
end

function PC:GetCanHelp()
  local db = self:GetDB()
  if db and db.guildCanHelp then
    return true
  end
  return self:GetSocialStatus() == "open"
end

function PC:SetCanHelp(on)
  local db = EnsureDB()
  if db then
    db.guildCanHelp = on and true or false
  end
  PersistAndBroadcast()
end

function PC:GetActivityZone()
  -- Always prefer the live zone. A saved guildActivityZone used to stick
  -- after a zone change (for example "Questing in Loch Modan" while the
  -- player was already in Westfall). The cache is only a fallback when
  -- map APIs are empty, such as during a loading screen.
  local live = self.GetLiveZoneName and self:GetLiveZoneName()
  if (not live or live == "") and self.GetCurrentZoneName then
    live = self:GetCurrentZoneName()
  end
  if type(live) == "string" and live ~= "" then
    return live
  end
  local db = self:GetDB()
  if db and type(db.guildActivityZone) == "string" and db.guildActivityZone ~= "" then
    return db.guildActivityZone
  end
  return nil
end

-- Keep the saved activity zone in sync with where the player actually is,
-- refresh the tracker and Guild tab, and rebroadcast when questing or
-- asking for help so peers see the new zone.
function PC:SyncLiveActivityZone(reason)
  local live = self.GetLiveZoneName and self:GetLiveZoneName()
  if (not live or live == "") and self.GetCurrentZoneName then
    live = self:GetCurrentZoneName()
  end
  if type(live) ~= "string" or live == "" then
    return nil, false
  end
  local prev = self._lastLiveZone
  local db = self.GetDB and self:GetDB() or nil
  local cached = db and db.guildActivityZone
  local changed = (not prev or string.lower(prev) ~= string.lower(live))
    or (type(cached) == "string" and cached ~= "" and string.lower(cached) ~= string.lower(live))
  if db then
    db.guildActivityZone = live
  end
  self._lastLiveZone = live
  if not changed then
    return live, false
  end
  local status = self.GetSocialStatus and self:GetSocialStatus() or nil
  if (status == "questing" or status == "help") and self.BroadcastStatus then
    self:BroadcastStatus(true)
  end
  if self.RefreshMiniTracker then
    self:RefreshMiniTracker()
  end
  if self.Refresh then
    self:Refresh()
  end
  return live, true
end

function PC:SetActivityZone(zone)
  local db = EnsureDB()
  if not db then
    return
  end
  if type(zone) ~= "string" or zone == "" then
    db.guildActivityZone = nil
  else
    db.guildActivityZone = zone
  end
  PersistAndBroadcast()
end

function PC:GetHelpRequiredLevel()
  local playerLevel = (self.PlayerLevel and self:PlayerLevel()) or 1
  local db = self:GetDB()
  local explicit = db and tonumber(db.guildHelpLevel)
  if explicit and explicit > 0 then
    return math.max(playerLevel, explicit)
  end
  -- Only treat a zone or quest level as "given" when the player picked one.
  -- The current zone fallback is not enough to drop below the requester's level.
  local zone
  if db and type(db.guildActivityZone) == "string" and db.guildActivityZone ~= "" then
    zone = db.guildActivityZone
  end
  if zone and self.GetClassData then
    local data = self:GetClassData()
    local brackets = data and data.brackets
    if type(brackets) == "table" then
      local needle = string.lower(zone)
      for i = 1, #brackets do
        local zones = brackets[i].zones or {}
        for j = 1, #zones do
          if type(zones[j]) == "string" and string.lower(zones[j]) == needle then
            local zoneMin = tonumber(brackets[i].min) or 0
            return math.max(playerLevel, zoneMin)
          end
        end
      end
    end
  end
  return playerLevel
end

-- Fresh login only (PLAYER_ENTERING_WORLD isInitialLogin). /reload and
-- zoning pass isInitialLogin false or omit it, and must not reset status.
function PC:ResetSocialStatusForLogin(isInitialLogin, isReloadingUi)
  if isReloadingUi == true then
    return false
  end
  if isInitialLogin ~= true then
    return false
  end
  self:SetSocialStatus("busy")
  return true
end

function PC:SetSocialStatus(status)
  if status == "notlooking" or status == "hidden" or status == "away" or status == "dnd" then
    status = "busy"
  end
  if status == "need" or status == "needhelp" then
    status = "help"
  end
  if status == "quest" or status == "lfg" then
    status = (status == "lfg") and "dungeon" or "questing"
  end
  if status ~= "questing" and status ~= "dungeon" and status ~= "help" and status ~= "open" and status ~= "busy" then
    return
  end
  local db = EnsureDB()
  if db then
    db.guildStatus = status
    db.guildStatusSetAt = WallClock()
    db.guildStatusStale = nil
    if status ~= "dungeon" then
      db.guildLfg = nil
    end
    -- Picking an activity lists you immediately, with no Settings visit.
    if status ~= "busy" and not db.availableToGroup then
      db.availableToGroup = true
      db.availStartedAt = WallClock()
    end
  end
  PersistAndBroadcast()
end

function PC:SetSocialRole(role)
  if role ~= "healer" and role ~= "tank" and role ~= "dps" then
    return
  end
  if self.ClassCanUseRole and not self:ClassCanUseRole(role) then
    return
  end
  local db = EnsureDB()
  if db then
    db.guildRole = role
  end
  PersistAndBroadcast()
end


function PC:CycleSocialRole()
  local allowed = self.GetAllowedRoles and self:GetAllowedRoles() or { "dps" }
  if type(allowed) ~= "table" or #allowed == 0 then
    allowed = { "dps" }
  end
  if #allowed == 1 then
    if self.SetSocialRole then
      self:SetSocialRole(allowed[1])
    end
    return allowed[1]
  end
  local cur = self:GetSocialRole()
  local idx = 1
  for i = 1, #allowed do
    if allowed[i] == cur then
      idx = i
      break
    end
  end
  local nxt = allowed[(idx % #allowed) + 1] or allowed[1]
  if self.SetSocialRole then
    self:SetSocialRole(nxt)
  end
  return nxt
end

function PC:AckSocialStatus()
  local db = EnsureDB()
  if db then
    db.guildStatusSetAt = WallClock()
    db.guildStatusStale = nil
  end
  if self.RefreshMiniTracker then
    self:RefreshMiniTracker()
  end
end

function PC:NoteStatusContext(reason)
  local status = self:GetSocialStatus()
  if status == "busy" then
    return
  end
  local db = EnsureDB()
  if not db then
    return
  end
  if reason == "instance" or reason == "grouped" or reason == "party" then
    db.guildStatusStale = reason
    if self.RefreshMiniTracker then
      self:RefreshMiniTracker()
    end
  end
end

function PC:IsSocialStatusStale()
  local status = self:GetSocialStatus()
  if status == "busy" then
    return false
  end
  local db = self:GetDB()
  if not db then
    return false
  end
  if db.guildStatusStale then
    return true, db.guildStatusStale
  end
  local setAt = tonumber(db.guildStatusSetAt)
  if setAt then
    local now = WallClock()
    if (now - setAt) >= (2 * 3600) then
      return true, "time"
    end
  end
  return false
end

function PC:SetSocialNote(note)
  local db = EnsureDB()
  if type(note) ~= "string" then
    note = ""
  end
  note = string.gsub(note, "[%|%c]", " ")
  if string.len(note) > 40 then
    note = string.sub(note, 1, 40)
  end
  if db then
    db.guildNote = note
  end
  PersistAndBroadcast()
end

function PC:SetSocialLfg(dungeonId)
  local db = EnsureDB()
  if dungeonId and dungeonId ~= "" then
    if db then
      db.guildLfg = dungeonId
      db.guildStatus = "dungeon"
    end
  else
    if db then
      db.guildLfg = nil
      if db.guildStatus == "dungeon" then
        db.guildStatus = "questing"
      end
    end
  end
  PersistAndBroadcast()
end

function PC:StatusLabel(status)
  if status == "dungeon" then
    return "Looking for dungeon"
  end
  if status == "help" then
    return "Need help with a quest"
  end
  if status == "open" then
    return "Open to help"
  end
  if status == "busy" then
    return "Not looking"
  end
  return "Questing buddy"
end

function PC:StatusShortLabel(status)
  if status == "dungeon" then
    return "Looking for dungeon"
  end
  if status == "help" then
    return "Need help"
  end
  if status == "open" then
    return "Open to help"
  end
  if status == "busy" then
    return "Not looking"
  end
  return "Questing"
end

function PC:RoleLabel(role)
  if role == "tank" then
    return "Tank"
  end
  if role == "dps" then
    return "DPS"
  end
  return "Healer"
end

function PC:SendQuestList()
  local now = Now()
  if lastQuestSend ~= nil and (now - lastQuestSend) < 15 then
    return false
  end
  local ids = self.GetQuestLogIDs and self:GetQuestLogIDs(20) or {}
  local payload = "QA|" .. table.concat(ids, ",")
  if self:SendGuildAddon(payload) then
    lastQuestSend = now
    return true
  end
  return false
end

function PC:RequestPeerQuests()
  local now = Now()
  if lastQuestReq ~= nil and (now - lastQuestReq) < 20 then
    return false
  end
  if self:SendGuildAddon("QREQ") then
    lastQuestReq = now
    return true
  end
  return false
end

function PC:StorePeerQuests(sender, packed)
  local name = NormName(sender)
  if not name or not peers[name] then
    -- Keep quests even if status has not arrived yet.
    if name then
      peers[name] = peers[name] or { name = name }
    else
      return
    end
  end
  local list = {}
  if type(packed) == "string" then
    for id in string.gmatch(packed, "%d+") do
      list[#list + 1] = tonumber(id)
      if #list >= 20 then
        break
      end
    end
  end
  peers[name].quests = list
end

function PC:GetJoinRequests()
  return joinRequests, outgoingRequests
end

function PC:ClearJoinRequest(name)
  name = NormName(name)
  if name then
    joinRequests[name] = nil
    outgoingRequests[name] = nil
  end
end

function PC:PrefillWhisper(peer)
  if not peer then
    return "Hey! Want to group up?"
  end
  local target
  local lfg = peer.lfg or (self:GetSocialLfg())
  if lfg then
    local d = self.FindDungeon and self:FindDungeon(lfg)
    target = d and d.name or lfg
  elseif peer.nextDungeon and peer.nextDungeon ~= "-" then
    target = peer.nextDungeon
  elseif peer.note and peer.note ~= "" and peer.note ~= "-" then
    target = peer.note
  end
  if target then
    return "Hey! Want to group for " .. target .. "?"
  end
  return "Hey! Want to group up?"
end

function PC:SendJoinRequest(name, why)
  name = NormName(name)
  if not name then
    return false
  end
  if self.IsDemoPeer and self:IsDemoPeer(name) then
    return false
  end
  local now = Now()
  if lastJoinSend[name] and (now - lastJoinSend[name]) < 15 then
    return false
  end
  why = Clean(why or "-")
  if string.len(why) > 60 then
    why = string.sub(why, 1, 60)
  end
  -- Guild addon messages are broadcast; the fourth field names the recipient
  -- so other 1.6 peers ignore it.
  local aimed = "J|JOIN|" .. why .. "|" .. name
  if self:SendGuildAddon(aimed) then
    lastJoinSend[name] = now
    outgoingRequests[name] = { name = name, why = why, time = now, outgoing = true }
    if self.Refresh then
      self:Refresh()
    end
    return true
  end
  return false
end

-- Aimed join: J|JOIN|why|targetName. Untargeted older shape is treated as for us.
function PC:HandleJoinMessage(sender, parts)
  local name = NormName(sender)
  if not name or IsSelf(name) then
    return
  end
  local action = parts[2]
  local why = parts[3]
  local target = parts[4] and NormName(parts[4])
  local me = PlayerName()
  if action == "JOIN" then
    if target and me and string.lower(target) ~= string.lower(me) then
      return
    end
    joinRequests[name] = {
      name = name,
      why = (why and why ~= "-") and why or "wants to group up",
      time = Now(),
    }
    -- Opt-out: unavailable players auto-decline and never see a request popup.
    if not self:IsAvailableToGroup() then
      self:SendGuildAddon("J|NO|-|" .. name)
      joinRequests[name] = nil
      return
    end
    if self:GetSocialStatus() ~= "busy" and self:IsRequestToastEnabled() then
      self:ShowJoinRequestToast(joinRequests[name])
    end
    if self.Refresh then
      self:Refresh()
    end
    return
  end
  if action == "OK" or action == "NO" then
    if target and me and string.lower(target) ~= string.lower(me) then
      return
    end
    outgoingRequests[name] = outgoingRequests[name] or { name = name, outgoing = true }
    outgoingRequests[name].answer = (action == "OK") and "accepted" or "declined"
    outgoingRequests[name].time = Now()
    if action == "OK" then
      self:Print((name or "A guildmate") .. " accepted your group request. Invite them when you are ready, or wait for their invite.")
    else
      self:Print((name or "A guildmate") .. " declined your group request.")
    end
    if self.Refresh then
      self:Refresh()
    end
  end
end

-- Click-only: must be called from a button OnClick.
function PC:AcceptJoinRequest(name)
  name = NormName(name)
  local rec = name and joinRequests[name]
  if not rec then
    return
  end
  self:InvitePeer(name)
  self:SendGuildAddon("J|OK|-|" .. name)
  joinRequests[name] = nil
  if self.requestToast then
    self.requestToast:Hide()
  end
  if self.Refresh then
    self:Refresh()
  end
end

function PC:DeclineJoinRequest(name)
  name = NormName(name)
  if not name then
    return
  end
  self:SendGuildAddon("J|NO|-|" .. name)
  joinRequests[name] = nil
  if self.requestToast then
    self.requestToast:Hide()
  end
  if self.Refresh then
    self:Refresh()
  end
end

function PC:ShowJoinRequestToast(rec)
  if not rec or not CreateFrame or not UIParent then
    return
  end
  if not self.requestToast then
    local f = CreateFrame("Frame", "PhilosophersCodexRequestToast", UIParent)
    f:SetSize(360, 72)
    f:SetPoint("TOP", UIParent, "TOP", 0, -150)
    f:SetFrameStrata("TOOLTIP")
    local bg = f:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetTexture("Interface\\Buttons\\WHITE8X8")
    bg:SetVertexColor(0.07, 0.07, 0.08, 0.94)
    f.label = f:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    if f.label.SetFontObject then
      pcall(f.label.SetFontObject, f.label, GameFontHighlight)
    end
    f.label:SetPoint("TOPLEFT", 12, -8)
    f.label:SetPoint("TOPRIGHT", -12, -8)
    f.label:SetJustifyH("LEFT")
    local function makeBtn(label, x)
      local b = CreateFrame("Button", nil, f)
      b:SetSize(80, 22)
      b:SetPoint("BOTTOMLEFT", x, 8)
      b.text = b:CreateFontString(nil, "ARTWORK", "GameFontNormal")
      if b.text.SetFontObject then
        pcall(b.text.SetFontObject, b.text, GameFontNormal)
      end
      b.text:SetPoint("CENTER")
      b.text:SetText(label)
      local t = b:CreateTexture(nil, "BACKGROUND")
      t:SetAllPoints()
      t:SetTexture("Interface\\Buttons\\WHITE8X8")
      t:SetVertexColor(0.15, 0.15, 0.16, 1)
      return b
    end
    f.accept = makeBtn("Accept", 12)
    f.decline = makeBtn("Decline", 100)
    f.accept:SetScript("OnClick", function(self)
      if f.peerName and PC.AcceptJoinRequest then
        PC:AcceptJoinRequest(f.peerName)
      end
    end)
    f.decline:SetScript("OnClick", function(self)
      if f.peerName and PC.DeclineJoinRequest then
        PC:DeclineJoinRequest(f.peerName)
      end
    end)
    self.requestToast = f
  end
  local f = self.requestToast
  f.peerName = rec.name
  local why = rec.why or "wants to group up"
  f.label:SetText((rec.name or "A guildmate") .. " asks to join. " .. why)
  f:Show()
  if C_Timer and C_Timer.After then
    C_Timer.After(20, function()
      if f and f.peerName == rec.name then
        f:Hide()
      end
    end)
  end
end

local function SharedQuestNames(peer)
  local mine = PC.GetQuestLogIDs and PC:GetQuestLogIDs(20) or {}
  local theirs = peer.quests or {}
  local names = {}
  local map = {}
  for i = 1, #theirs do
    map[theirs[i]] = true
  end
  for i = 1, #mine do
    if map[mine[i]] then
      names[#names + 1] = PC:QuestName(mine[i]) or ("Quest " .. tostring(mine[i]))
    end
  end
  return names
end

function PC:ScoreGroupMatch(peer)
  if not peer then
    return 0, { "No status from this guildmate." }, {}
  end
  local reasons = {}
  local score = 0
  if peer.online == false then
    return 0, { "Offline." }, reasons
  end
  if peer.status == "busy" then
    return 0, { "Busy / do not disturb." }, reasons
  end
  local myLevel = self:PlayerLevel() or 0
  local theirLevel = tonumber(peer.level) or 0
  if theirLevel > 0 and math.abs(myLevel - theirLevel) <= 3 then
    score = score + 30
    reasons[#reasons + 1] = "Level " .. tostring(theirLevel)
  elseif self:IsGoodGroupMatch(peer) then
    score = score + 20
    reasons[#reasons + 1] = "overlapping bracket"
  end

  local myZone = "-"
  if self.CurrentZoneNames then
    local names = self:CurrentZoneNames()
    myZone = names and names[1] or "-"
  end
  local rel = self.ZonesAreRelated and self:ZonesAreRelated(myZone, peer.zone)
  if rel == "same" then
    score = score + 25
    reasons[#reasons + 1] = "in " .. peer.zone
  elseif rel == "adjacent" then
    score = score + 15
    reasons[#reasons + 1] = "in " .. (peer.zone or "a nearby zone")
  end

  local myLfg = self:GetSocialLfg()
  local myNext = nil
  if self.GetNextAction then
    local action = self:GetNextAction()
    myNext = action and action.title
  end
  local theirDungeon = peer.lfg or ((peer.nextDungeon and peer.nextDungeon ~= "-") and peer.nextDungeon)
  local sharedDungeon
  if myLfg and peer.lfg and myLfg == peer.lfg then
    sharedDungeon = self.FindDungeon and self:FindDungeon(myLfg)
    sharedDungeon = sharedDungeon and sharedDungeon.name or myLfg
  elseif theirDungeon and myNext and string.lower(tostring(theirDungeon)) == string.lower(tostring(myNext)) then
    sharedDungeon = myNext
  elseif theirDungeon and myLfg then
    local d = self.FindDungeon and self:FindDungeon(myLfg)
    if d and (string.lower(d.name) == string.lower(tostring(theirDungeon)) or d.id == theirDungeon) then
      sharedDungeon = d.name
    end
  end
  if sharedDungeon then
    score = score + 25
    reasons[#reasons + 1] = "also needs " .. sharedDungeon
  elseif peer.lfg then
    local d = self.FindDungeon and self:FindDungeon(peer.lfg)
    reasons[#reasons + 1] = "looking for " .. ((d and d.name) or peer.lfg)
    score = score + 8
  end

  local myRole = self:GetSocialRole()
  local theirRole = peer.role
  if theirRole and myRole and theirRole ~= myRole then
    if (myRole == "healer" and theirRole == "tank") or (myRole == "tank" and theirRole == "healer") or (theirRole == "dps" and myRole ~= "dps") or (myRole == "dps" and theirRole ~= "dps") then
      score = score + 15
      reasons[#reasons + 1] = self:RoleLabel(theirRole)
    end
  end

  local shared = SharedQuestNames(peer)
  if #shared > 0 then
    local add = math.min(30, #shared * 10)
    score = score + add
    local shown = {}
    for i = 1, math.min(2, #shared) do
      shown[#shown + 1] = shared[i]
    end
    reasons[#reasons + 1] = "You both have: " .. table.concat(shown, ", ")
  end

  if peer.status == "dungeon" or peer.status == "help" or peer.status == "open" or peer.status == "questing" then
    score = score + 10
  end

  local explanation
  if #reasons > 0 then
    explanation = table.concat(reasons, ", ")
    -- Plain sentence: "Level 23, in Duskwood, also needs Stockade"
    explanation = string.upper(string.sub(explanation, 1, 1)) .. string.sub(explanation, 2)
  else
    explanation = "Uses the Codex, but nothing obvious lines up right now."
  end
  return score, { explanation }, shared
end

function PC:DescribeGroupNeed(dungeonId)
  local need = { tank = 1, healer = 1, dps = 3 }
  local members = {}
  local myRole = self:GetSocialRole()
  members[#members + 1] = { name = "you", role = myRole, self = true }
  need[myRole] = math.max(0, (need[myRole] or 0) - 1)
  local peersList = self:GetGuildPeers() or {}
  for i = 1, #peersList do
    local rec = peersList[i]
    local same = dungeonId and rec.lfg == dungeonId
    if same and rec.online ~= false then
      members[#members + 1] = { name = rec.name, role = rec.role or "dps" }
      local r = rec.role or "dps"
      need[r] = math.max(0, (need[r] or 0) - 1)
    end
  end
  local parts = {}
  for i = 1, #members do
    local m = members[i]
    local label = self:RoleLabel(m.role)
    if m.self then
      parts[#parts + 1] = label .. " (you)"
    else
      parts[#parts + 1] = label .. " " .. (m.name or "")
    end
  end
  local missing = {}
  if need.tank > 0 then missing[#missing + 1] = (need.tank == 1 and "1 tank") or (tostring(need.tank) .. " tanks") end
  if need.healer > 0 then missing[#missing + 1] = (need.healer == 1 and "1 healer") or (tostring(need.healer) .. " healers") end
  if need.dps > 0 then missing[#missing + 1] = tostring(need.dps) .. " DPS" end
  local text = "Your group: " .. table.concat(parts, " + ")
  if #missing > 0 then
    text = text .. "  ·  need " .. table.concat(missing, ", ")
  else
    text = text .. "  ·  full group"
  end
  return text, members, need
end

function PC:CountJoinRequests()
  local incoming = self:GetJoinRequests()
  local n = 0
  if type(incoming) == "table" then
    for _ in pairs(incoming) do
      n = n + 1
    end
  end
  return n
end

function PC:GetActiveLfgGroups()
  local byId = {}
  local order = {}
  local function add(id, member)
    if not id or id == "" or id == "-" then
      return
    end
    local g = byId[id]
    if not g then
      local d = self.FindDungeon and self:FindDungeon(id)
      g = {
        id = id,
        name = (d and d.name) or tostring(id),
        members = {},
        leader = nil,
      }
      byId[id] = g
      order[#order + 1] = g
    end
    g.members[#g.members + 1] = member
    if not g.leader then
      g.leader = member
    end
  end
  local my = self.GetSocialLfg and self:GetSocialLfg()
  if my then
    local me = "You"
    if UnitName then
      local ok, name = pcall(UnitName, "player")
      if ok and name then
        me = name
      end
    end
    add(my, { name = me, role = self:GetSocialRole(), self = true })
  end
  local peersList = self:GetGuildPeers() or {}
  for i = 1, #peersList do
    local rec = peersList[i]
    if rec.lfg and rec.lfg ~= "-" and rec.online ~= false then
      add(rec.lfg, { name = rec.name, role = rec.role or "dps", rec = rec, self = false })
    end
  end
  for i = 1, #order do
    local g = order[i]
    local need = { tank = 1, healer = 1, dps = 3 }
    local filled = {}
    for j = 1, #g.members do
      local r = g.members[j].role or "dps"
      if (need[r] or 0) > 0 then
        need[r] = need[r] - 1
        filled[#filled + 1] = r
      else
        filled[#filled + 1] = r
      end
    end
    -- Canonical 5-slot display: tank, healer, dps, dps, dps
    local slots = {}
    local counts = { tank = 0, healer = 0, dps = 0 }
    for j = 1, #g.members do
      local r = g.members[j].role or "dps"
      counts[r] = (counts[r] or 0) + 1
    end
    slots[1] = { role = "tank", filled = counts.tank > 0 }
    slots[2] = { role = "healer", filled = counts.healer > 0 }
    local dps = counts.dps or 0
    for k = 1, 3 do
      slots[2 + k] = { role = "dps", filled = dps >= k }
    end
    g.slots = slots
    g.mine = false
    for j = 1, #g.members do
      if g.members[j].self then
        g.mine = true
      end
    end
  end
  return order
end

function PC:MatchChips(peer)
  local chips = {}
  if not peer then
    return chips
  end
  if self.GetSelectedDungeons and self.PeerDungeonList then
    local mine, theirs, set = self:GetSelectedDungeons(), self:PeerDungeonList(peer), {}
    for i = 1, #mine do
      set[mine[i]] = true
    end
    for i = 1, #theirs do
      if set[theirs[i]] and #chips < 2 then
        local d = self.FindDungeon and self:FindDungeon(theirs[i])
        chips[#chips + 1] = (d and d.name) or theirs[i]
      end
    end
  end
  local myLevel = self:PlayerLevel() or 1
  local their = tonumber(peer.level)
  if their then
    local d = math.abs(their - myLevel)
    if d <= 2 then
      chips[#chips + 1] = "Lv ±" .. tostring(d)
    end
  end
  local myZone = "-"
  if self.CurrentZoneNames then
    local names = self:CurrentZoneNames()
    myZone = names and names[1] or "-"
  end
  local rel = self.ZonesAreRelated and self:ZonesAreRelated(myZone, peer.zone)
  if rel == "same" then
    chips[#chips + 1] = "Same zone"
  elseif rel == "adjacent" and #chips < 2 then
    chips[#chips + 1] = "Nearby"
  end
  local myLfg = self.GetSocialLfg and self:GetSocialLfg()
  local theirDungeon = peer.lfg or ((peer.nextDungeon and peer.nextDungeon ~= "-") and peer.nextDungeon)
  local dungeonName
  if myLfg and peer.lfg and myLfg == peer.lfg then
    local d = self.FindDungeon and self:FindDungeon(myLfg)
    dungeonName = (d and d.name) or myLfg
  elseif theirDungeon and myLfg then
    local d = self.FindDungeon and self:FindDungeon(myLfg)
    if d and (string.lower(d.name) == string.lower(tostring(theirDungeon)) or d.id == theirDungeon) then
      dungeonName = d.name
    end
  elseif peer.lfg then
    local d = self.FindDungeon and self:FindDungeon(peer.lfg)
    dungeonName = (d and d.name) or peer.lfg
  end
  if dungeonName and #chips < 2 then
    dungeonName = string.gsub(dungeonName, "^The ", "")
    chips[#chips + 1] = "Needs " .. dungeonName
  end
  local shared = peer.sharedQuests
  if (not shared or #shared == 0) and self.ScoreGroupMatch then
    -- ScoreGroupMatch already stores sharedQuests on rec when GetGroupMatches runs.
  end
  if type(shared) == "table" and #shared > 0 and #chips < 2 then
    if #shared == 1 then
      chips[#chips + 1] = "1 shared quest"
    else
      chips[#chips + 1] = tostring(#shared) .. " shared quests"
    end
  end
  if #chips > 2 then
    local keep = { chips[1], chips[2] }
    chips = keep
  end
  return chips
end

function PC:GetGroupMatches()
  self:ExpireGuildPeers()
  local list = {}
  local missingQuests = false
  for _, rec in pairs(peers) do
    local score, lines, shared = self:ScoreGroupMatch(rec)
    rec.matchScore = score
    rec.matchWhy = lines and lines[1]
    rec.sharedQuests = shared
    rec.match = score >= 20
    if rec.online ~= false and rec.status ~= "busy" and not rec.quests then
      missingQuests = true
    end
    if rec.online ~= false and rec.status ~= "busy" and score > 0 and self:PeerIsAvailable(rec) then
      list[#list + 1] = rec
    end
  end
  table.sort(list, function(a, b)
    if (a.lfg and not b.lfg) then return true end
    if (b.lfg and not a.lfg) then return false end
    if (a.matchScore or 0) ~= (b.matchScore or 0) then
      return (a.matchScore or 0) > (b.matchScore or 0)
    end
    return string.lower(a.name or "") < string.lower(b.name or "")
  end)
  if missingQuests then
    self:RequestPeerQuests()
  end
  return list
end

-- Group finder lists for the mini tracker (and tests). Sort by score, then
-- how close their level is to yours. 'best' is the top 5 by score.
function PC:GetFinderLists(filters)
  self:ExpireGuildPeers()
  filters = filters or {}
  local myLevel = self:PlayerLevel() or 1
  local myZone = "-"
  if self.CurrentZoneNames then
    local names = self:CurrentZoneNames()
    myZone = names and names[1] or "-"
  end
  local function nearLevel(rec)
    if not rec.level then
      return 60
    end
    return math.abs((rec.level or 0) - myLevel)
  end
  local function allowed(rec)
    if rec.online == false or rec.status == "busy" then
      return false
    end
    if not self:PeerIsAvailable(rec) then
      return false
    end
    if filters.role and rec.role and rec.role ~= filters.role then
      return false
    end
    if filters.sameZone then
      if not (self.ZonesAreRelated and self:ZonesAreRelated(myZone, rec.zone) == "same") then
        return false
      end
    end
    if filters.myBracket and not self:IsGoodGroupMatch(rec) then
      return false
    end
    return true
  end
  local scored = {}
  for _, rec in pairs(peers) do
    local score, lines = self:ScoreGroupMatch(rec)
    rec.matchScore = score
    rec.matchWhy = lines and lines[1]
    rec.match = score >= 20
    rec.levelDelta = nearLevel(rec)
    if allowed(rec) then
      scored[#scored + 1] = rec
    end
  end
  table.sort(scored, function(a, b)
    if (a.matchScore or 0) ~= (b.matchScore or 0) then
      return (a.matchScore or 0) > (b.matchScore or 0)
    end
    if (a.levelDelta or 99) ~= (b.levelDelta or 99) then
      return (a.levelDelta or 99) < (b.levelDelta or 99)
    end
    return string.lower(a.name or "") < string.lower(b.name or "")
  end)
  local best, nearby, others = {}, {}, {}
  local inBest = {}
  for i = 1, math.min(5, #scored) do
    if (scored[i].matchScore or 0) > 0 then
      best[#best + 1] = scored[i]
      inBest[scored[i].name] = true
    end
  end
  for i = 1, #scored do
    local rec = scored[i]
    if not inBest[rec.name] then
      if rec.levelDelta <= 5 then
        nearby[#nearby + 1] = rec
      else
        others[#others + 1] = rec
      end
    end
  end
  local groups = {}
  if self.GetActiveLfgGroups then
    groups = self:GetActiveLfgGroups() or {}
  end
  return {
    best = best,
    nearby = nearby,
    others = others,
    groups = groups,
    all = scored,
    count = #scored,
  }
end

-- Toast / chat rate limit for match-online announcements.
local toastWindow = {} -- timestamps of toasts in the last minute
local toastBatch = {}
PC._matchToastLog = PC._matchToastLog or {}

local function PruneToastWindow(now)
  local keep = {}
  for i = 1, #toastWindow do
    if now - toastWindow[i] < 60 then
      keep[#keep + 1] = toastWindow[i]
    end
  end
  toastWindow = keep
end

local TOASTS_PER_MIN = 3

local function FlushToastBatch()
  local n = #toastBatch
  if n == 0 then
    return
  end
  toastBatch = {}
  if n == 1 then
    return
  end
  local msg = "[Codex] and " .. tostring(n) .. " more matches online"
  PC:Print(msg)
  if PC.ShowUpgradeToast then
    PC:ShowUpgradeToast(msg)
  end
  local log = PC._matchToastLog
  log[#log + 1] = msg
end

local function RoleWord(role)
  if role == "healer" then return "Healer" end
  if role == "tank" then return "Tank" end
  return "DPS"
end

function PC:NotifyPeerUpdate(rec)
  if not rec or rec.online == false then
    return
  end
  if not self:IsAvailableToGroup() then
    return
  end
  if not self:PeerIsAvailable(rec) then
    return
  end
  if self:GetSocialStatus() == "busy" then
    return
  end
  if UnitIsDND and UnitIsDND("player") then
    return
  end
  if not self.IsMatchToastEnabled or not self:IsMatchToastEnabled() then
    return
  end
  if rec.status == "busy" then
    return
  end
  local score, lines = self:ScoreGroupMatch(rec)
  rec.matchScore = score
  if lines and lines[1] then
    rec.matchWhy = lines[1]
  end
  if score < 40 then
    return
  end
  local key = rec.name or "?"
  local now = Now()
  if lastMatchToast[key] and (now - lastMatchToast[key]) < 300 then
    return
  end
  -- Only announce when they first appear, come back, or newly become available.
  if notifiedOnline[key] and (now - (notifiedOnline[key] or 0)) < 300 then
    return
  end
  lastMatchToast[key] = now
  notifiedOnline[key] = now
  rec.finderHighlight = now
  local why = rec.matchWhy
  if (not why or why == "") and lines then
    why = table.concat(lines, ", ")
  end
  why = why or "looks like a good group match"
  local msg = string.format("[Codex] %s (Lv %s %s) is online and a good match: %s",
    rec.name or "A guildmate",
    tostring(rec.level or "?"),
    RoleWord(rec.role),
    why)
  PruneToastWindow(now)
  local log = self._matchToastLog
  if #toastWindow >= TOASTS_PER_MIN then
    toastBatch[#toastBatch + 1] = rec.name
    -- Batch extras into one line instead of another per-player toast.
    if #toastBatch == 1 then
      -- first overflow starts the batch; flush on a short timer if possible
      if C_Timer and C_Timer.After then
        C_Timer.After(1.5, FlushToastBatch)
      else
        FlushToastBatch()
      end
    end
    return
  end
  toastWindow[#toastWindow + 1] = now
  log[#log + 1] = msg
  self:Print(msg)
  if self.ShowUpgradeToast then
    self:ShowUpgradeToast(msg)
  end
end

-- Party-only map pin. C_Map.GetPlayerMapPosition only works for party members.
function PC:GetPeerMapWaypoint(name)
  name = NormName(name)
  if not name then
    return nil
  end
  local function unitMatches(unit)
    if not UnitName then
      return false
    end
    local ok, unitName = pcall(UnitName, unit)
    if not ok or not unitName then
      return false
    end
    return string.lower(NormName(unitName) or "") == string.lower(name)
  end
  local unit
  if UnitInParty and pcall(UnitInParty, "player") then
    -- always check party/raid units; UnitInParty(name) is also tried.
  end
  if UnitInParty then
    local ok, inP = pcall(UnitInParty, name)
    if not ok or not inP then
      if UnitInRaid then
        local okR, inR = pcall(UnitInRaid, name)
        if not okR or not inR then
          -- still try unit tokens below
        else
          -- in raid
        end
      end
    end
  end
  local candidates = { "party1", "party2", "party3", "party4" }
  if GetNumGroupMembers then
    local ok, n = pcall(GetNumGroupMembers)
    if ok and type(n) == "number" and n > 4 then
      for i = 1, math.min(n, 40) do
        candidates[#candidates + 1] = "raid" .. i
      end
    end
  end
  for i = 1, #candidates do
    if unitMatches(candidates[i]) then
      unit = candidates[i]
      break
    end
  end
  if not unit then
    return nil
  end
  if not C_Map or not C_Map.GetPlayerMapPosition then
    return nil
  end
  local mapID
  if C_Map.GetBestMapForUnit then
    local ok, id = pcall(C_Map.GetBestMapForUnit, unit)
    if ok then
      mapID = id
    end
  end
  if not mapID then
    return nil
  end
  local ok, pos = pcall(C_Map.GetPlayerMapPosition, mapID, unit)
  if not ok or not pos then
    return nil
  end
  local x, y
  if type(pos) == "table" then
    if pos.GetXY then
      x, y = pos:GetXY()
    else
      x, y = pos.x, pos.y
    end
  end
  if not x or not y then
    return nil
  end
  return {
    uiMapID = mapID,
    x = x * 100,
    y = y * 100,
    title = name,
  }
end


local ev = CreateFrame("Frame")
ev:RegisterEvent("ADDON_LOADED")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("PLAYER_ENTERING_WORLD")
ev:RegisterEvent("PLAYER_LEVEL_UP")
ev:RegisterEvent("ZONE_CHANGED")
ev:RegisterEvent("ZONE_CHANGED_INDOORS")
ev:RegisterEvent("ZONE_CHANGED_NEW_AREA")
ev:RegisterEvent("CHAT_MSG_ADDON")
ev:RegisterEvent("GUILD_ROSTER_UPDATE")
ev:RegisterEvent("PLAYER_GUILD_UPDATE")
ev:RegisterEvent("PLAYER_LOGOUT")

local function OnShareEvent(_, event, ...)
  if event == "ADDON_LOADED" then
    local name = ...
    if name == "PhilosophersCodex" then
      PC:RegisterSharePrefix()
    end
    return
  end
  if event == "PLAYER_LOGIN" or event == "PLAYER_ENTERING_WORLD" then
    if event == "PLAYER_ENTERING_WORLD" then
      local isInitialLogin, isReloadingUi = ...
      if PC.ResetSocialStatusForLogin then
        PC:ResetSocialStatusForLogin(isInitialLogin, isReloadingUi)
      end
    end
    if PC.SyncLiveActivityZone then
      PC:SyncLiveActivityZone(event)
    end
    PC:StartSharing()
    return
  end
  if event == "PLAYER_LEVEL_UP" then
    if C_Timer and C_Timer.After then
      C_Timer.After(1, function()
        PC:BroadcastStatus()
      end)
    else
      PC:BroadcastStatus()
    end
    return
  end
  if event == "ZONE_CHANGED" or event == "ZONE_CHANGED_INDOORS" or event == "ZONE_CHANGED_NEW_AREA" then
    local _, changed = nil, false
    if PC.SyncLiveActivityZone then
      _, changed = PC:SyncLiveActivityZone(event)
    end
    -- Sync already force-broadcasts a zone change while questing or asking
    -- for help. Still send a regular heartbeat for other statuses.
    if not changed then
      PC:BroadcastStatus()
    end
    return
  end
  if event == "CHAT_MSG_ADDON" then
    local prefix, msg, channel, sender = ...
    PC:OnAddonMessage(prefix, msg, channel, sender)
    return
  end
  if event == "GUILD_ROSTER_UPDATE" then
    -- Never call GuildRoster from this event; that is an event storm.
    PC:ApplyGuildRoster()
    if PC.Refresh then
      PC:Refresh()
    end
    return
  end
  if event == "PLAYER_GUILD_UPDATE" then
    PC:RequestGuildRoster()
    PC:ApplyGuildRoster()
    if PC.Refresh then
      PC:Refresh()
    end
    return
  end
  if event == "PLAYER_LOGOUT" then
    local db = PC:GetDB()
    if db and db.availableToGroup and db.availExpireOnLogout ~= false then
      db.availableToGroup = false
      db.availStartedAt = nil
    end
  end
end

ev:SetScript("OnEvent", function(...)
  if PC.SafeCall then
    return PC:SafeCall("OnEvent:share", OnShareEvent, ...)
  end
  return OnShareEvent(...)
end)


-- Test hook: inject or clear in-memory peers without addon messages.
function PC:DebugInjectPeer(rec)
  if not rec or not rec.name then
    return
  end
  local name = NormName(rec.name)
  rec.name = name
  if rec.available == nil then
    rec.available = true
  end
  if rec.online == nil then
    rec.online = true
  end
  if rec.availLegacy then
    rec.availExplicit = false
  elseif rec.availExplicit == nil then
    rec.availExplicit = true
  end
  if rec.status and rec.status ~= "" then
    rec.statusExplicit = true
  end
  rec.lastSeen = rec.lastSeen or Now()
  peers[name] = rec
  return rec
end

function PC:DebugClearPeers()
  for k in pairs(peers) do
    peers[k] = nil
  end
  lastMatchToast = {}
  notifiedOnline = {}
  toastWindow = {}
  toastBatch = {}
  PC._matchToastLog = {}
end

function PC:DebugPeerCount()
  local n = 0
  for _ in pairs(peers) do
    n = n + 1
  end
  return n
end
