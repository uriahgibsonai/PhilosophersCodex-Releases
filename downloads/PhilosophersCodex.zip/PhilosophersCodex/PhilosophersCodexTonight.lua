-- Philosopher's Codex: Tonight list, session XP, and dungeon tip helpers.

local PC = PhilosophersCodex

local session = {
  startedAt = nil,
  startLevel = nil,
  startXP = nil,
  lastLevel = nil,
  lastXP = nil,
  lastMax = nil,
  gained = 0,
  levels = 0,
}

local function Now()
  if time then
    return time()
  end
  if GetTime then
    return GetTime()
  end
  return 0
end

local function PlayerXP()
  if UnitXP then
    local ok, v = pcall(UnitXP, "player")
    if ok and type(v) == "number" then
      return v
    end
  end
  return 0
end

local function PlayerXPMax()
  if UnitXPMax then
    local ok, v = pcall(UnitXPMax, "player")
    if ok and type(v) == "number" then
      return v
    end
  end
  return 0
end

function PC:StartSession()
  local level = self:PlayerLevel() or 1
  local xp = PlayerXP()
  local max = PlayerXPMax()
  session.startedAt = Now()
  session.startLevel = level
  session.startXP = xp
  session.lastLevel = level
  session.lastXP = xp
  session.lastMax = max
  session.gained = 0
  session.levels = 0
  local db = self:GetDB()
  if db then
    db.tonightChecks = {}
  end
end

function PC:EnsureSession()
  if not session.startedAt then
    self:StartSession()
  end
  return session
end

function PC:NoteSessionXP()
  self:EnsureSession()
  local level = self:PlayerLevel() or session.lastLevel or 1
  local xp = PlayerXP()
  local max = PlayerXPMax()
  if session.lastLevel and level > session.lastLevel then
    local prevMax = session.lastMax or 0
    local prevXP = session.lastXP or 0
    if prevMax > prevXP then
      session.gained = session.gained + (prevMax - prevXP)
    end
    session.gained = session.gained + xp
    session.levels = session.levels + (level - session.lastLevel)
  elseif session.lastXP then
    local delta = xp - session.lastXP
    if delta > 0 then
      session.gained = session.gained + delta
    end
  end
  session.lastLevel = level
  session.lastXP = xp
  session.lastMax = max
end

function PC:GetSessionInfo()
  self:EnsureSession()
  local elapsed = Now() - (session.startedAt or Now())
  if elapsed < 0 then
    elapsed = 0
  end
  return {
    startedAt = session.startedAt,
    elapsed = elapsed,
    xp = session.gained or 0,
    levels = session.levels or 0,
    startLevel = session.startLevel,
    level = self:PlayerLevel() or session.lastLevel,
  }
end

function PC:FormatDuration(seconds)
  seconds = tonumber(seconds) or 0
  seconds = math.floor(seconds)
  local h = math.floor(seconds / 3600)
  local m = math.floor((seconds % 3600) / 60)
  if h > 0 then
    return h .. "h " .. m .. "m"
  end
  if m > 0 then
    return m .. "m"
  end
  return seconds .. "s"
end

function PC:FormatXP(n)
  n = math.floor(tonumber(n) or 0)
  local s = tostring(n)
  if #s <= 3 then
    return s
  end
  local out = ""
  while #s > 3 do
    out = "," .. string.sub(s, -3) .. out
    s = string.sub(s, 1, #s - 3)
  end
  return s .. out
end

function PC:SessionSummaryLine()
  local info = self:GetSessionInfo()
  local parts = { "Session " .. self:FormatDuration(info.elapsed) }
  parts[#parts + 1] = self:FormatXP(info.xp) .. " XP"
  if (info.levels or 0) > 0 then
    local n = info.levels
    parts[#parts + 1] = "+" .. tostring(n) .. (n == 1 and " level" or " levels")
  end
  return table.concat(parts, "  ·  ")
end

function PC:IsTonightChecked(id)
  local db = self:GetDB()
  if not db or type(db.tonightChecks) ~= "table" then
    return false
  end
  return db.tonightChecks[id] and true or false
end

function PC:SetTonightChecked(id, on)
  local db = self:GetDB()
  if not db then
    return
  end
  if type(db.tonightChecks) ~= "table" then
    db.tonightChecks = {}
  end
  if on then
    db.tonightChecks[id] = true
  else
    db.tonightChecks[id] = nil
  end
  if self.Refresh then
    self:Refresh()
  end
end

function PC:IsNextChecked(id)
  return self:IsTonightChecked(id)
end

function PC:SetNextChecked(id, on)
  return self:SetTonightChecked(id, on)
end

local function Push(list, rec)
  if rec and rec.title then
    list[#list + 1] = rec
  end
end

-- Next tab: grouped "what to work on next" tiles. Tonight checkoffs (same
-- item ids) carry over so a ticked Tonight row stays ticked here.
function PC:GetNextGroups()
  local groups = {
    { id = "dungeons", title = "Dungeons", items = {} },
    { id = "zones", title = "Quests & zones", items = {} },
    { id = "professions", title = "Professions", items = {} },
    { id = "training", title = "Training", items = {} },
    { id = "gear", title = "Gear", items = {} },
    { id = "group", title = "Group", items = {} },
  }
  local byId = {}
  for i = 1, #groups do
    byId[groups[i].id] = groups[i]
  end
  local seen = {}

  local function add(groupId, rec, cap)
    if not rec or not rec.id or seen[rec.id] then
      return
    end
    local group = byId[groupId]
    if not group then
      return
    end
    cap = cap or 3
    if #group.items >= cap then
      return
    end
    if self:IsTonightChecked(rec.id) then
      rec.checked = true
    else
      rec.checked = false
    end
    rec.group = groupId
    seen[rec.id] = true
    group.items[#group.items + 1] = rec
  end

  local level = self:PlayerLevel() or 1

  -- Training: untrained current-role spells available now.
  if self.GetTrainerVisitSummary then
    local summary = self:GetTrainerVisitSummary(level)
    local groupsIn = summary and summary.groups or {}
    local added = 0
    for i = 1, #groupsIn do
      local spells = groupsIn[i].spells or {}
      for j = 1, #spells do
        local sp = spells[j]
        if not self:PlayerKnowsTrainerSpell(sp) and (sp.l or 99) <= level then
          local tag = self:RecommendTrainerSpell(sp)
          if tag and tag ~= "skip" then
            local label = self:TrainerSpellLabel(sp)
            add("training", {
              id = "spell:" .. tostring(sp.n) .. ":" .. tostring(sp.r or 0),
              kind = "spell",
              title = "Train " .. label,
              detail = "Available at your level now.",
              icon = self.SpellIcon and self:SpellIcon(sp) or nil,
              waypoint = self.GetClassTrainerWaypoint and self:GetClassTrainerWaypoint() or nil,
              tab = "abilities",
              goalGroup = "goals-trainer",
              spellName = sp.n,
            })
            added = added + 1
            if added >= 3 then
              break
            end
          end
        end
      end
      if added >= 3 then
        break
      end
    end
  end

  -- Professions: next craft or trainer, with a short mat line.
  if self.GetPlayerProfessions and self.GetProfessionPlan then
    local profs = self:GetPlayerProfessions() or {}
    for i = 1, #profs do
      local rec = profs[i]
      local plan = self:GetProfessionPlan(rec)
      if plan and plan.pack then
        local profId = rec.id or plan.pack.id or rec.name
        local name = rec.name or plan.pack.name or "Profession"
        if plan.needTrain and plan.rank then
          local r = plan.rank
          local where = r.trainer and (r.trainer .. (r.zone and (", " .. r.zone) or "")) or (r.zone or "your trainer")
          add("professions", {
            id = "prof-train:" .. tostring(profId),
            kind = "profession",
            title = name .. ": train " .. (r.name or "the next rank"),
            detail = where .. "  ·  skill " .. tostring(plan.skill),
            icon = plan.pack.icon or rec.icon,
            tab = "craft",
            profId = profId,
            recipe = nil,
            progress = { cur = plan.skill or 0, max = (plan.maxSkill and plan.maxSkill > 0) and plan.maxSkill or 75 },
          })
        elseif plan.step and (plan.remaining or 0) > 0 then
          local recipe = plan.step.recipe or "the next recipe"
          local detail
          if self.GetCraftNextSummary then
            detail = self:GetCraftNextSummary(plan)
          end
          if not detail or detail == "" then
            detail = self:ProfessionStepSummary(plan)
          end
          local miss = plan.missing and plan.missing[1]
          local haveLine
          if miss then
            haveLine = "need " .. tostring(miss.need or 0) .. " " .. (miss.name or "mats") .. ", have " .. tostring(miss.have or 0)
          elseif plan.mats and plan.mats[1] then
            local m = plan.mats[1]
            haveLine = "need " .. tostring(m.need or 0) .. " " .. (m.name or "mats") .. ", have " .. tostring(m.have or 0)
          end
          if haveLine then
            detail = "skill " .. tostring(plan.skill) .. " -> " .. tostring(plan.milestone or plan.step.to or plan.skill) .. ", " .. haveLine
          end
          add("professions", {
            id = "prof-craft:" .. tostring(profId) .. ":" .. tostring(recipe),
            kind = "profession",
            title = name .. ": craft " .. recipe,
            detail = detail,
            icon = plan.pack.icon or rec.icon,
            tab = "craft",
            profId = profId,
            recipe = recipe,
            progress = { cur = plan.skill or 0, max = (plan.milestone and plan.milestone > 0) and plan.milestone or ((plan.maxSkill and plan.maxSkill > 0) and plan.maxSkill or 75) },
          })
        end
      end
    end
  end

  -- Dungeons: the ones whose level range fits you now, best fit first.
  if self.GetDungeonsForLevel then
    local list = self:GetDungeonsForLevel(6) or {}
    for i = 1, #list do
      local d = list[i]
      if d and d.id and not self:IsDungeonChecked(d.id) then
        add("dungeons", {
          id = "dungeon:" .. d.id,
          kind = "dungeon",
          title = "Run " .. (d.name or d.id),
          detail = d.range and ("Levels " .. d.range) or "An on-level dungeon.",
          icon = (self.GetDungeonIcon and self:GetDungeonIcon(d.id)) or (self.ClassIcon and self:ClassIcon("dungeons")) or nil,
          waypoint = self.GetEntranceWaypoint and self:GetEntranceWaypoint(d.id) or nil,
          dungeonId = d.id,
          tab = "path",
        })
      end
    end
  end

  -- Zones: the best questing zones for your level (cities never count).
  if self.GetLevelingZones then
    local picks = self:GetLevelingZones(3) or {}
    for i = 1, #picks do
      local z = picks[i]
      local here = self:IsCurrentZoneName(z.name)
      local lv = z.lo and ("Levels " .. z.lo .. "-" .. z.hi) or "On your route"
      add("zones", {
        id = "zone:" .. z.name,
        kind = "zone",
        title = z.name,
        detail = here and (lv .. "  ·  You're here") or lv,
        icon = self.ClassIcon and self:ClassIcon("zones") or nil,
        waypoint = self.GetZoneWaypoint and self:GetZoneWaypoint(z.name) or nil,
        zone = z.name,
        tab = "path",
      })
    end
  end

  -- Gear: one tile for the upgrades the scorer flagged; the pane lists them.
  if self.GetRecentUpgrades then
    local recent = self:GetRecentUpgrades() or {}
    local n = 0
    for i = 1, #recent do
      if recent[i] and (recent[i].name or recent[i].itemID) then n = n + 1 end
    end
    if n > 0 then
      local top = recent[1]
      add("gear", {
        id = "gear:recent",
        kind = "gear",
        title = "Review recent upgrades",
        detail = n .. (n == 1 and " piece" or " pieces") .. "  ·  newest: " .. tostring(top.name or "item"),
        icon = self.ClassIcon and self:ClassIcon("gear") or nil,
        itemID = top.itemID,
        tab = "gear",
        gearFilter = "upgrades",
      })
    end
  end

  -- Online guild matches who opted in.
  if self.GetFinderLists then
    local lists = self:GetFinderLists()
    local nearby = lists and (lists.nearby or lists.matches or lists.available)
    if type(nearby) ~= "table" and lists and lists.groups then
      nearby = lists.groups
    end
    local peers = nearby
    if type(peers) ~= "table" or (peers[1] == nil and peers.count == nil) then
      if self.GetNearbyMatches then
        peers = self:GetNearbyMatches()
      elseif lists and lists.all then
        peers = lists.all
      end
    end
    if type(peers) == "table" then
      for i = 1, #peers do
        local p = peers[i]
        if p and p.name and p.available and p.online ~= false then
          add("group", {
            id = "guild:" .. tostring(p.name),
            kind = "guild",
            title = p.name .. " is available to group",
            detail = (p.level and ("Level " .. tostring(p.level)) or "Guildmate") .. (p.zone and ("  ·  " .. p.zone) or ""),
            icon = self.ClassIcon and self:ClassIcon("guild") or nil,
            tab = "guild",
            peerName = p.name,
          })
        end
      end
    end
  end

  local out = {}
  for i = 1, #groups do
    if #groups[i].items > 0 then
      out[#out + 1] = groups[i]
    end
  end
  return out
end

-- Flat list used by the mini tracker and as a compatibility alias for Tonight.
function PC:GetTonightItems(limit)
  limit = limit or 5
  local items = {}
  local groups = self:GetNextGroups() or {}
  for i = 1, #groups do
    local list = groups[i].items or {}
    for j = 1, #list do
      items[#items + 1] = list[j]
      if #items >= limit then
        return items
      end
    end
  end
  return items
end

function PC:GetNextHighlights(limit)
  return self:GetTonightItems(limit)
end

-- Open the matching tab and deep-link to the tile's detail.
function PC:FollowNextItem(item)
  if type(item) ~= "table" then
    return false
  end
  if item.kind == "profession" or item.tab == "craft" then
    self._pendingCraftRecipe = item.recipe
    if self.OpenCraftProfession then
      self:OpenCraftProfession(item.profId or item.id)
    elseif self.OpenTab then
      self:OpenTab("craft")
    end
    return true
  end
  if item.kind == "zone" or (item.tab == "path" and item.zone) then
    self._pendingPathZone = item.zone
    if self.OpenTab then
      self:OpenTab("path")
    end
    return true
  end
  if item.kind == "dungeon" or item.dungeonId then
    self._pendingPathDungeon = item.dungeonId
    -- Deep-links open the Path tab only. Never auto-pop the boss-tips card.
    if self.OpenTab then
      self:OpenTab("path")
    end
    return true
  end
  if item.kind == "spell" or item.tab == "goals" then
    self._pendingGoalSpell = item.spellName
    if self.OpenTab then
      -- 1.20.0: trainer spells have their own Abilities tab.
      self:OpenTab("abilities")
    end
    return true
  end
  if item.kind == "gear" or item.tab == "gear" then
    if self.SetGearFilter then
      self:SetGearFilter(item.gearFilter or "upgrades")
    end
    if self.OpenTab then
      self:OpenTab("gear")
    end
    return true
  end
  if item.kind == "guild" or item.tab == "guild" then
    if self.OpenTab then
      self:OpenTab("guild")
    end
    return true
  end
  if item.tab and self.OpenTab then
    self:OpenTab(item.tab)
    return true
  end
  return false
end

-- ---------------------------------------------------------------------------
-- Dungeon tip sheets
-- ---------------------------------------------------------------------------

function PC:GetDungeonTipSheet(dungeonId)
  if not dungeonId then
    return nil
  end
  local all = PhilosophersCodexData and PhilosophersCodexData.DUNGEON_TIPS
  if not all then
    return nil
  end
  local sheet = all[dungeonId]
  if not sheet and self.FindDungeon then
    local d = self:FindDungeon(dungeonId)
    if d and d.id then
      sheet = all[d.id]
    end
  end
  if not sheet then
    if self.LogMissing then
      self:LogMissing("dungeontips", dungeonId, "No boss cheat sheet for " .. tostring(dungeonId))
    end
    return {
      id = dungeonId,
      tipsComing = true,
      note = "Tips coming. No confirmed boss notes are written for this dungeon yet.",
      bosses = {},
    }
  end
  return sheet
end

function PC:GetDungeonTipLoot(dungeonId, classFile)
  local loot = self.GetLootForDungeon and self:GetLootForDungeon(dungeonId) or {}
  return loot
end

function PC:NotableTipLoot(dungeonId)
  local loot = self:GetDungeonTipLoot(dungeonId) or {}
  local names = {}
  for i = 1, #loot do
    local it = loot[i]
    if it and it.name then
      names[#names + 1] = it.name
    end
    if #names >= 3 then
      break
    end
  end
  return names
end

function PC:IsDungeonTipsAutoPop()
  local db = self:GetDB()
  if not db then
    return true
  end
  if db.dungeonTipsAutoPop == nil then
    return true
  end
  return db.dungeonTipsAutoPop and true or false
end

function PC:SetDungeonTipsAutoPop(on)
  local db = self:GetDB()
  if not db then
    return
  end
  db.dungeonTipsAutoPop = on and true or false
end

function PC:DungeonHasTips(dungeonId)
  if not dungeonId then
    return false
  end
  local all = PhilosophersCodexData and PhilosophersCodexData.DUNGEON_TIPS
  if not all then
    return false
  end
  local sheet = all[dungeonId]
  if not sheet and self.FindDungeon then
    local d = self:FindDungeon(dungeonId)
    if d and d.id then
      sheet = all[d.id]
    end
  end
  if not sheet or sheet.tipsComing then
    return false
  end
  local bosses = sheet.bosses
  return type(bosses) == "table" and #bosses > 0
end

function PC:OnEnteredDungeon(dungeon)
  if not dungeon or not dungeon.id then
    return
  end
  if self.NoteStatusContext then
    self:NoteStatusContext("instance")
  end
  if not self:IsDungeonTipsAutoPop() then
    return
  end
  if not self:DungeonHasTips(dungeon.id) then
    return
  end
  if self.OpenDungeonTips then
    self:OpenDungeonTips(dungeon.id, "instance")
  end
end
