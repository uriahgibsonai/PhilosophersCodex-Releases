-- Philosopher's Codex
-- Crafted for the Alchemists guild.
-- Core: saved variables, ForeverGuide migration, events, slash commands, helpers.
-- UI lives in PhilosophersCodexUI.lua. Class data lives in Data/*.lua.

local ADDON_NAME = "PhilosophersCodex"
local DB_VERSION = 11

PhilosophersCodex = PhilosophersCodex or {}
local PC = PhilosophersCodex
PC.VERSION = "1.25.0"

-- Default and resize bounds for the main window. 1.13.0 raised these so
-- tab text fits comfortably; saved sizes still at the 1.12 default are bumped.
-- 1.18.2 raised them again (default 560x800, clamped to 85% of the screen).
-- 1.19.0 widened the default to 820 for the list + detail layout; saved
-- sizes at or below the 1.18.2 default (560x800) move to it once.
PC.FRAME_WIDTH = 820
PC.FRAME_HEIGHT = 800
PC.MIN_W = 460
PC.MIN_H = 600
PC.MAX_W = 1100
PC.MAX_H = 1100
PC.OLD_FRAME_WIDTH = 560
PC.OLD_FRAME_HEIGHT = 800
PC.WINDOW_DEFAULT_REV = 1190

-- ---------------------------------------------------------------------------
-- Saved variables and one-time migration from ForeverGuide
-- ---------------------------------------------------------------------------

local function DefaultDB()
  return {
    version = DB_VERSION,
    initialized = false,
    showAllBrackets = false,
    lastBracketKey = nil,
    minimap = { angle = 200, minimapPos = 200, hide = false },
    window = { x = nil, y = nil, w = nil, h = nil, scale = 1 },
    hideCompleted = false,
    tab = "next",
    dungeons = {},
    gear = {},
    milestones = {},
    quests = {},
    expanded = {},
    shareEnabled = true,
    upgradeProfile = "both",
    recentUpgrades = {},
    upgradeChat = true,
    upgradeToast = true,
    upgradeTooltip = true,
    bracketAlerts = true,
    mini = {
      enabled = true,
      locked = false,
      scale = 1,
      showQuests = true,
      maxLines = 5,
      collapsed = true,
      hideInCombat = false,
      hideInInstances = false,
      opacity = 0.85,
      panel = "next",
      finderNearbyOpen = true,
      finderOthersOpen = false,
      sectionsCollapsed = false,
    },
    matchToast = true,
    requestToast = true,
    guildStatus = "busy",
    guildStatusSetAt = nil,
    guildStatusStale = nil,
    guildRole = "healer",
    guildNote = "",
    guildLfg = nil,
    guildSegment = "group",
    guildDungeons = {},
    guildListMode = "matches",
    guildCanHelp = false,
    guildActivityZone = nil,
    guildHelpLevel = nil,
    demoGuild = false,
    availableToGroup = true,
    availKind = "both",
    availExpireHours = 4,
    availExpireOnLogout = false,
    availStartedAt = nil,
    availDefaultsRev = 16,
    availUserSet = false,
    dungeonTipsAutoPop = true,
    profChecks = {},
    tonightChecks = {},
    gearFilter = "all",
    hideGrayQuests = true,
    pathZone = nil,
    goalsStartCollapsed = true,
  }
end

local function DeepCopy(src)
  if type(src) ~= "table" then
    return src
  end
  local dst = {}
  for k, v in pairs(src) do
    dst[k] = DeepCopy(v)
  end
  return dst
end

local function TableHasKeys(tbl)
  if type(tbl) ~= "table" then
    return false
  end
  return next(tbl) ~= nil
end

-- True when a saved table looks like real tracker progress, not an empty shell.
local function HasProgress(db)
  if type(db) ~= "table" then
    return false
  end
  if db.initialized or db.migratedFromForeverGuide then
    return true
  end
  if TableHasKeys(db.dungeons) or TableHasKeys(db.gear) or TableHasKeys(db.milestones) then
    return true
  end
  return false
end

local function NormalizeDB(db)
  if type(db) ~= "table" then
    return DefaultDB()
  end
  if type(db.dungeons) ~= "table" then db.dungeons = {} end
  if type(db.gear) ~= "table" then db.gear = {} end
  if type(db.milestones) ~= "table" then db.milestones = {} end
  if type(db.quests) ~= "table" then db.quests = {} end
  if type(db.expanded) ~= "table" then db.expanded = {} end
  if type(db.minimap) ~= "table" then db.minimap = { angle = 200, hide = false } end
  if db.minimap.angle == nil and db.minimap.minimapPos ~= nil then
    db.minimap.angle = db.minimap.minimapPos
  end
  if db.minimap.minimapPos == nil and db.minimap.angle ~= nil then
    db.minimap.minimapPos = db.minimap.angle
  end
  if type(db.window) ~= "table" then db.window = {} end
  if db.window.scale == nil then db.window.scale = 1 end
  -- Bump a saved window still at the 1.12 default to the new default. Keep a
  -- custom size unless it is below the new minimum or above the max.
  do
    local oldW, oldH = PC.OLD_FRAME_WIDTH or 400, PC.OLD_FRAME_HEIGHT or 660
    local newW, newH = PC.FRAME_WIDTH or 460, PC.FRAME_HEIGHT or 720
    local minW, minH = PC.MIN_W or 400, PC.MIN_H or 560
    local maxW, maxH = PC.MAX_W or 720, PC.MAX_H or 980
    local w, h = tonumber(db.window.w), tonumber(db.window.h)
    if w and h then
      -- Saved sizes at or below the previous default get the new default;
      -- larger custom sizes are kept.
      if (db.window.defaultRev or 0) < (PC.WINDOW_DEFAULT_REV or 1182) then
        if w <= oldW and h <= oldH then
          w, h = newW, newH
        end
        db.window.defaultRev = PC.WINDOW_DEFAULT_REV or 1182
      end
      if w < minW then w = minW end
      if h < minH then h = minH end
      if w > maxW then w = maxW end
      if h > maxH then h = maxH end
      db.window.w, db.window.h = w, h
    else
      db.window.defaultRev = PC.WINDOW_DEFAULT_REV or 1182
    end
  end
  if db.hideCompleted == nil then db.hideCompleted = false end
  if db.shareEnabled == nil then db.shareEnabled = true end
  local function profileOk(p)
    if not p then
      return false
    end
    if PC.GetProfileDef and PC:GetProfileDef(p) then
      return true
    end
    -- Class data may not be ready yet; accept known profile ids so we do not clobber them.
    if p == "heal" or p == "balance" or p == "both" or p == "frost" or p == "fire" or p == "affliction" or p == "dest" or p == "generic" then
      return true
    end
    return false
  end
  if not profileOk(db.upgradeProfile) then
    db.upgradeProfile = (PC.GetDefaultUpgradeProfile and PC:GetDefaultUpgradeProfile()) or "both"
  end
  if type(db.recentUpgrades) ~= "table" then db.recentUpgrades = {} end
  if db.upgradeChat == nil then db.upgradeChat = true end
  if db.upgradeToast == nil then db.upgradeToast = true end
  if db.upgradeTooltip == nil then db.upgradeTooltip = true end
  if db.bracketAlerts == nil then db.bracketAlerts = true end
  if type(db.mini) ~= "table" then db.mini = {} end
  if db.mini.enabled == nil then db.mini.enabled = true end
  if db.mini.locked == nil then db.mini.locked = false end
  if db.mini.scale == nil then db.mini.scale = 1 end
  if db.mini.scale < 0.8 then db.mini.scale = 0.8 end
  if db.mini.scale > 1.4 then db.mini.scale = 1.4 end
  if db.mini.showQuests == nil then db.mini.showQuests = true end
  if db.mini.hideInCombat == nil then db.mini.hideInCombat = false end
  if db.mini.hideInInstances == nil then db.mini.hideInInstances = false end
  if db.mini.collapsed == nil then db.mini.collapsed = true end
  -- 1.18.2 ID-card redesign: show the tracker once for every save (an earlier
  -- /codex mini toggle could have left it hidden), start collapsed, and use the
  -- section view. Hiding it after this point sticks.
  if (tonumber(db.mini.cardRev) or 0) < 1182 then
    db.mini.enabled = true
    db.mini.collapsed = true
    db.mini.panel = "next"
    db.mini.h = nil
    if db.mini.anchor == nil then
      db.mini.x, db.mini.y = nil, nil
    end
    db.mini.cardRev = 1182
  end
  local op = tonumber(db.mini.opacity)
  if not op then op = 0.85 end
  if op < 0.4 then op = 0.4 end
  if op > 1 then op = 1 end
  db.mini.opacity = op
  if db.mini.w ~= nil then
    local w = tonumber(db.mini.w)
    if not w then
      db.mini.w = nil
    else
      db.mini.w = w
    end
  end
  if db.mini.h ~= nil then
    local h = tonumber(db.mini.h)
    if not h then
      db.mini.h = nil
    else
      db.mini.h = h
    end
  end
  if db.matchToast == nil then db.matchToast = true end
  if db.requestToast == nil then db.requestToast = true end
  if db.guildStatus == nil then db.guildStatus = "busy" end
  if db.guildRole ~= "healer" and db.guildRole ~= "tank" and db.guildRole ~= "dps" then
    local classData = PC.GetClassData and PC:GetClassData() or nil
    db.guildRole = (classData and classData.defaultRole) or "dps"
  end
  if db.guildNote == nil then db.guildNote = "" end
  if db.guildSegment ~= "group" and db.guildSegment ~= "everyone" and db.guildSegment ~= "requests" then
    db.guildSegment = "group"
  end
  if type(db.guildDungeons) ~= "table" then db.guildDungeons = {} end
  if db.guildListMode ~= "all" and db.guildListMode ~= "matches" then
    db.guildListMode = "matches"
  end
  if db.demoGuild == nil then db.demoGuild = false end
  if db.guildCanHelp == nil then db.guildCanHelp = false end
  -- 1.16.0: turn availability and both match kinds on once, unless the
  -- player already opted out after this version (availUserSet).
  if (db.availDefaultsRev or 0) < 16 then
    if not db.availUserSet then
      db.availableToGroup = true
      db.availKind = "both"
      db.availExpireOnLogout = false
    end
    db.availDefaultsRev = 16
  end
  if db.availableToGroup == nil then db.availableToGroup = true end
  if db.availKind ~= "quest" and db.availKind ~= "dungeon" and db.availKind ~= "both" then
    db.availKind = "both"
  end
  if db.availExpireOnLogout == nil then db.availExpireOnLogout = false end
  local hours = tonumber(db.availExpireHours)
  if hours == nil then hours = 4 end
  if hours < 0 then hours = 0 end
  if hours > 24 then hours = 24 end
  db.availExpireHours = hours
  if db.availExpireOnLogout == nil then db.availExpireOnLogout = true end
  if db.mini.panel ~= "next" and db.mini.panel ~= "guild" then
    db.mini.panel = "next"
  end
  if db.mini.sectionsCollapsed == nil then
    db.mini.sectionsCollapsed = false
  end
  if db.mini.finderNearbyOpen == nil then db.mini.finderNearbyOpen = true end
  if db.mini.finderOthersOpen == nil then db.mini.finderOthersOpen = false end
  local lines = tonumber(db.mini.maxLines) or 5
  if lines < 1 then lines = 1 end
  if lines > 10 then lines = 10 end
  db.mini.maxLines = math.floor(lines + 0.5)
  if db.dungeonTipsAutoPop == nil then db.dungeonTipsAutoPop = true end
  if type(db.profChecks) ~= "table" then db.profChecks = {} end
  if type(db.tonightChecks) ~= "table" then db.tonightChecks = {} end
  if db.gearFilter ~= "all" and db.gearFilter ~= "weapons" and db.gearFilter ~= "armor" and db.gearFilter ~= "jewelry" and db.gearFilter ~= "upgrades" then
    db.gearFilter = "all"
  end
  if db.hideGrayQuests == nil then db.hideGrayQuests = true end
  -- 1.14.0: Goals groups start collapsed. Clear previously saved "trainer
  -- always open" so the first open of 1.14 does not leave that section stuck out.
  local oldVersion = tonumber(db.version) or 0
  if oldVersion < 10 or not db.goalsStartCollapsed then
    if type(db.expanded) == "table" then
      local toClear = {}
      for k in pairs(db.expanded) do
        if type(k) == "string" and string.sub(k, 1, 6) == "goals-" then
          toClear[#toClear + 1] = k
        end
      end
      for i = 1, #toClear do
        db.expanded[toClear[i]] = nil
      end
    end
    db.goalsStartCollapsed = true
  end
  db.version = DB_VERSION
  return db
end
PC._NormalizeDB = NormalizeDB

function PC:GetDB()
  return PhilosophersCodexDB
end

function PC:InitDB()
  -- ForeverGuidePC / ForeverGuideDB are also listed in the TOC so this
  -- addon can see them. ForeverGuide is an OptionalDep and should load first
  -- if it is still installed. Copy its per-character progress once.
  if HasProgress(PhilosophersCodexDB) then
    PhilosophersCodexDB = NormalizeDB(PhilosophersCodexDB)
    return
  end

  local source
  if HasProgress(ForeverGuidePC) then
    source = ForeverGuidePC
  elseif HasProgress(ForeverGuideDB) then
    source = ForeverGuideDB
  end

  if source then
    PhilosophersCodexDB = DeepCopy(source)
    PhilosophersCodexDB = NormalizeDB(PhilosophersCodexDB)
    PhilosophersCodexDB.migratedFromForeverGuide = true
    PhilosophersCodexDB.initialized = true
    self.didMigrate = true
    return
  end

  if type(PhilosophersCodexDB) ~= "table" then
    PhilosophersCodexDB = DefaultDB()
  end
  PhilosophersCodexDB = NormalizeDB(PhilosophersCodexDB)
end

local function EnsureEntry(tbl, id)
  if not tbl[id] then
    tbl[id] = {}
  end
  return tbl[id]
end

-- ---------------------------------------------------------------------------
-- Class data
-- ---------------------------------------------------------------------------

-- Forever may return a localized or mixed-case token instead of the
-- usual "MAGE" / "Gnome" file names used as table keys.
local function CanonicalClassFile(token)
  if type(token) ~= "string" then
    return nil
  end
  token = string.gsub(token, "%s+", "")
  if token == "" then
    return nil
  end
  return string.upper(token)
end

local RACE_ALIASES = {
  GNOME = "Gnome",
  NIGHTELF = "NightElf",
  HUMAN = "Human",
  DWARF = "Dwarf",
  DRAENEI = "Draenei",
  WORGEN = "Worgen",
  ORC = "Orc",
  SCOURGE = "Scourge",
  UNDEAD = "Scourge",
  TAUREN = "Tauren",
  TROLL = "Troll",
  BLOODELF = "BloodElf",
  GOBLIN = "Goblin",
}

local function CanonicalRaceFile(token)
  if type(token) ~= "string" then
    return nil
  end
  token = string.gsub(token, " ", "")
  if token == "" then
    return nil
  end
  local upper = string.upper(token)
  if RACE_ALIASES[upper] then
    return RACE_ALIASES[upper]
  end
  local starts = PhilosophersCodexData and PhilosophersCodexData.STARTS
  if type(starts) == "table" then
    if starts[token] then
      return token
    end
    for key in pairs(starts) do
      if type(key) == "string" and string.upper(key) == upper then
        return key
      end
    end
  end
  return token
end

function PC:GetClassFile()
  if UnitClass then
    local localized, classFile = UnitClass("player")
    local token = CanonicalClassFile(classFile) or CanonicalClassFile(localized)
    if token then
      return token
    end
  end
  return nil
end

function PC:GetRaceFile()
  if UnitRace then
    local localized, raceFile = UnitRace("player")
    return CanonicalRaceFile(raceFile) or CanonicalRaceFile(localized)
  end
  return nil
end

function PC:InvalidateClassData()
  self._classDataCache = nil
  self._classDataKey = nil
end

local function ShallowCopy(src)
  local dst = {}
  if type(src) ~= "table" then
    return dst
  end
  for k, v in pairs(src) do
    dst[k] = v
  end
  return dst
end

local function UnsupportedShell(classFile)
  return {
    supported = false,
    classFile = classFile,
    title = "Class guide coming soon",
    factionNote = "A full class guide for this character is not in this version yet. The dungeon route, guild tab, and upgrade scorer still work.",
    gear = {},
    milestones = {},
    gearPriorities = {},
    goalGroups = {},
    defaultRole = "dps",
    defaultProfile = "generic",
    profiles = {
      { id = "generic", name = "Stats", labels = {}, weights = {
        intellect = 4, stamina = 3, spirit = 2, spellpower = 6, spelldamage = 6, crit = 3, healing = 2, wanddps = 3,
      }},
    },
    allowWands = true,
    allowShields = false,
    allowRelics = false,
  }
end

function PC:GetClassData()
  local classFile = self:GetClassFile()
  local raceFile = self:GetRaceFile()
  local key = tostring(classFile) .. ":" .. tostring(raceFile)
  if self._classDataCache and self._classDataKey == key then
    return self._classDataCache
  end
  local classes = PhilosophersCodexData and PhilosophersCodexData.CLASSES
  local classRaw = classes and classFile and classes[classFile]
  if not classRaw and PhilosophersCodexData and classFile then
    classRaw = PhilosophersCodexData[classFile]
  end
  local data
  if type(classRaw) == "table" then
    data = ShallowCopy(classRaw)
    data.supported = true
  else
    data = UnsupportedShell(classFile)
  end
  local brackets = {}
  local startRaw = PhilosophersCodexData and PhilosophersCodexData.STARTS and raceFile and PhilosophersCodexData.STARTS[raceFile]
  local route = PhilosophersCodexData and PhilosophersCodexData.ROUTE
  if startRaw and type(startRaw.brackets) == "table" then
    for i = 1, #startRaw.brackets do
      brackets[#brackets + 1] = startRaw.brackets[i]
    end
    data.startTitle = startRaw.title
    data.startNote = startRaw.note
  end
  if route and type(route.brackets) == "table" then
    for i = 1, #route.brackets do
      brackets[#brackets + 1] = route.brackets[i]
    end
  elseif type(data.brackets) == "table" and #brackets == 0 then
    -- already copied from classRaw
  end
  if #brackets > 0 then
    data.brackets = brackets
  elseif type(data.brackets) ~= "table" then
    data.brackets = {}
  end
  if type(data.gear) ~= "table" then
    data.gear = {}
  end
  if type(data.milestones) ~= "table" then
    data.milestones = {}
  end
  self._classDataCache = data
  self._classDataKey = key
  return data
end

function PC:IsSupportedClass()
  local data = self:GetClassData()
  return data and data.supported and true or false
end

-- ---------------------------------------------------------------------------
-- Class-aware icons and colors
-- ---------------------------------------------------------------------------

local GROUP_ICON_KEY = {
  ["goals-trainer"] = "trainer",
  ["goals-forms"] = "forms",
  ["goals-talents"] = "talents",
  ["goals-zones"] = "zones",
  ["goals-dungeons"] = "dungeons",
  ["goals-professions"] = "professions",
  ["goals-mounts"] = "mounts",
  ["goals-gear"] = "gear",
  trainer = "trainer",
  forms = "forms",
  talents = "talents",
  zones = "zones",
  dungeons = "dungeons",
  professions = "professions",
  mounts = "mounts",
  gear = "gear",
  class = "class",
  goals = "goals",
  spells = "spells",
  next = "next",
  guild = "guild",
  quests = "quests",
  tonight = "tonight",
}

local function NeutralIcon(key)
  local icons = PhilosophersCodexData and PhilosophersCodexData.NEUTRAL_ICONS
  if icons and key and icons[key] then
    return icons[key]
  end
  if icons and icons.class then
    return icons.class
  end
  return "Interface\\Icons\\Trade_Alchemy"
end

function PC:ClassColor(classFile)
  classFile = classFile or self:GetClassFile()
  if type(classFile) == "string" then
    classFile = string.upper(classFile)
  end
  if classFile and C_ClassColor and C_ClassColor.GetClassColor then
    local ok, c = pcall(C_ClassColor.GetClassColor, classFile)
    if ok and type(c) == "table" then
      local r, g, b = c.r, c.g, c.b
      if (r == nil or g == nil or b == nil) and c.GetRGB then
        local ok2, rr, gg, bb = pcall(c.GetRGB, c)
        if ok2 then
          r, g, b = rr, gg, bb
        end
      end
      if r and g and b then
        return r, g, b, c
      end
    end
  end
  local c = RAID_CLASS_COLORS and classFile and RAID_CLASS_COLORS[classFile]
  if c then
    return c.r or 1, c.g or 1, c.b or 1, c
  end
  return 1, 1, 1, nil
end

function PC:HasClassColor(classFile)
  classFile = classFile or (self.GetClassFile and self:GetClassFile())
  if type(classFile) == "string" then
    classFile = string.upper(classFile)
  end
  if classFile and C_ClassColor and C_ClassColor.GetClassColor then
    local ok, c = pcall(C_ClassColor.GetClassColor, classFile)
    if ok and type(c) == "table" then
      return true
    end
  end
  return (RAID_CLASS_COLORS and classFile and RAID_CLASS_COLORS[classFile]) and true or false
end

function PC:ClassIcon(key)
  key = key or "class"
  if GROUP_ICON_KEY[key] then
    key = GROUP_ICON_KEY[key]
  elseif type(key) == "string" and string.sub(key, 1, 6) == "goals-" then
    key = string.sub(key, 7)
  end
  local data = self.GetClassData and self:GetClassData() or nil
  local icons = data and data.icons
  if icons and icons[key] then
    return icons[key]
  end
  return NeutralIcon(key)
end

local DUNGEON_ICON_CROP = { 0.07, 0.93, 0.07, 0.93 }

function PC:NormalizeDungeonIconKey(idOrName)
  if idOrName == nil or idOrName == "" then
    return nil
  end
  local key = tostring(idOrName)
  local lower = string.lower(key)
  if self.FindDungeon then
    local d = self:FindDungeon(idOrName)
    if d and d.id then
      return string.lower(tostring(d.id)), d
    end
  end
  return lower, nil
end

function PC:GetDungeonIconEntry(idOrName)
  local key = self:NormalizeDungeonIconKey(idOrName)
  local data = PhilosophersCodexData and PhilosophersCodexData.DUNGEON_ICONS
  if key and data and data[key] then
    return data[key], key
  end
  return nil, key
end

function PC:GetDungeonIconCandidates(idOrName)
  local entry = self:GetDungeonIconEntry(idOrName)
  local paths = {}
  local seen = {}
  local function add(path)
    if type(path) == "string" and path ~= "" and not seen[path] then
      seen[path] = true
      paths[#paths + 1] = path
    end
  end
  if entry then
    local lfg = entry.lfg or {}
    for i = 1, #lfg do
      add(lfg[i])
    end
    add(entry.fallback)
  end
  add(PhilosophersCodexData and PhilosophersCodexData.DUNGEON_ICON_DEFAULT)
  add("Interface\\Icons\\INV_Misc_Head_Dragon_01")
  return paths, entry
end

-- trySet(path) should return true when the texture resolved. When omitted,
-- this returns the preferred path (LFG first, then fallback) without I/O.
function PC:ResolveDungeonIcon(idOrName, trySet)
  local paths, entry = self:GetDungeonIconCandidates(idOrName)
  if type(trySet) == "function" then
    for i = 1, #paths do
      local ok, used = pcall(trySet, paths[i])
      if ok and used then
        local isFallback = true
        if entry and entry.lfg then
          for j = 1, #entry.lfg do
            if entry.lfg[j] == paths[i] then
              isFallback = false
              break
            end
          end
        end
        return paths[i], isFallback, entry
      end
    end
    return nil, true, entry
  end
  if #paths == 0 then
    return nil, true, entry
  end
  local preferred = paths[1]
  local isFallback = true
  if entry and entry.lfg then
    isFallback = true
    for j = 1, #entry.lfg do
      if entry.lfg[j] == preferred then
        isFallback = false
        break
      end
    end
  end
  -- Forever-only (no LFG list) and unknown ids report as fallback.
  if entry and entry.forever then
    isFallback = true
  end
  return preferred, isFallback, entry
end

function PC:GetDungeonIcon(idOrName)
  local path = self:ResolveDungeonIcon(idOrName)
  return path
end

function PC:ApplyDungeonIcon(tex, idOrName, host)
  if type(tex) ~= "table" then
    return nil, true
  end
  local chosen, isFallback, entry = self:ResolveDungeonIcon(idOrName, function(path)
    if self.TrySetTexture then
      return self.TrySetTexture(tex, path)
    end
    if not tex.SetTexture then
      return false
    end
    local ok, result = pcall(tex.SetTexture, tex, path)
    if not ok or result == false then
      return false
    end
    if tex.GetTexture then
      local got = tex:GetTexture()
      return got and got ~= "" and got ~= 0
    end
    return true
  end)
  if not chosen then
    local fallback = (PhilosophersCodexData and PhilosophersCodexData.DUNGEON_ICON_DEFAULT) or "Interface\\Icons\\INV_Misc_Head_Dragon_01"
    if tex.SetTexture then
      pcall(tex.SetTexture, tex, fallback)
    end
    chosen, isFallback = fallback, true
  end
  if tex.SetTexCoord then
    pcall(tex.SetTexCoord, tex, DUNGEON_ICON_CROP[1], DUNGEON_ICON_CROP[2], DUNGEON_ICON_CROP[3], DUNGEON_ICON_CROP[4])
  end
  if tex.SetVertexColor then
    pcall(tex.SetVertexColor, tex, 1, 1, 1, 1)
  end
  if self.ApplyCircleMask then
    -- ApplyCircleMask(texture, owner) is a function, not a method.
    pcall(self.ApplyCircleMask, tex, host or (tex.GetParent and tex:GetParent()) or nil)
  end
  return chosen, isFallback, entry
end

local function TextureFromAPI(idOrName)
  if idOrName == nil or idOrName == "" then
    return nil
  end
  if C_Spell and C_Spell.GetSpellTexture then
    local ok, tex = pcall(C_Spell.GetSpellTexture, idOrName)
    if ok and tex and tex ~= "" then
      return tex
    end
  end
  if GetSpellTexture then
    local ok, tex = pcall(GetSpellTexture, idOrName)
    if ok and tex and tex ~= "" then
      return tex
    end
  end
  if C_Spell and C_Spell.GetSpellInfo then
    local ok, info = pcall(C_Spell.GetSpellInfo, idOrName)
    if ok and type(info) == "table" then
      local tex = info.iconID or info.iconFileID or info.icon
      if tex and tex ~= "" then
        return tex
      end
    end
  end
  if GetSpellInfo then
    local ok, _, _, icon = pcall(GetSpellInfo, idOrName)
    if ok and icon and icon ~= "" then
      return icon
    end
  end
  return nil
end

local function CuratedSpellIcon(name, school)
  if type(name) == "string" and name ~= "" then
    local map = PhilosophersCodexData and PhilosophersCodexData.SPELL_ICONS
    if map and map[name] then
      return map[name]
    end
  end
  if type(school) == "string" and school ~= "" then
    local schools = PhilosophersCodexData and PhilosophersCodexData.SCHOOL_ICONS
    if schools and schools[school] then
      return schools[school]
    end
  end
  return nil
end

function PC:GetSpellTextureByID(spell)
  if type(spell) == "table" then
    return TextureFromAPI(spell.id or spell.spellID or spell.spellId)
  end
  return TextureFromAPI(spell)
end

function PC:SpellIcon(spell)
  if type(spell) == "string" then
    spell = { n = spell }
  end
  if type(spell) ~= "table" then
    return self:ClassIcon("spells")
  end
  if type(spell.icon) == "string" and spell.icon ~= "" then
    return spell.icon
  end
  local id = spell.id or spell.spellID or spell.spellId
  local fromId = TextureFromAPI(id)
  if fromId then
    return fromId
  end
  local name = spell.n or spell.spellName or spell.name
  local curated = CuratedSpellIcon(name, spell.s or spell.school)
  if curated then
    return curated
  end
  local fromName = TextureFromAPI(name)
  if fromName then
    return fromName
  end
  return self:ClassIcon("spells")
end

-- 1.23.0: what a trainer spell does. Live tooltip text when the client has it
-- (usually once you know the spell), otherwise the short written summary.
function PC:GetSpellText(name)
  if type(name) ~= "string" or name == "" then
    return nil
  end
  local id
  if C_Spell and C_Spell.GetSpellInfo then
    local ok, info = pcall(C_Spell.GetSpellInfo, name)
    if ok and type(info) == "table" then id = info.spellID end
  end
  if not id and GetSpellInfo then
    local ok, _, _, _, _, _, _, sid = pcall(GetSpellInfo, name)
    if ok and tonumber(sid) then id = tonumber(sid) end
  end
  if id then
    local fn = (C_Spell and C_Spell.GetSpellDescription) or GetSpellDescription
    if fn then
      local ok, text = pcall(fn, id)
      if ok and type(text) == "string" and text ~= "" then
        return text, true
      end
    end
  end
  local t = PhilosophersCodexData and PhilosophersCodexData.SPELL_TEXT
  if t and t[name] then
    return t[name], false
  end
  local dest = name:match("^Teleport: (.+)$")
  if dest then return "Teleports you to " .. dest .. ". Needs a reagent.", false end
  dest = name:match("^Portal: (.+)$")
  if dest then return "Opens a portal to " .. dest .. " for your group. Needs a reagent.", false end
  return nil
end

-- ---------------------------------------------------------------------------
-- Chat (gold prefix, alchemy flavor)
-- ---------------------------------------------------------------------------

function PC:Print(msg)
  local text = "|cffd4af37[Philosopher's Codex]|r " .. tostring(msg)
  if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
    DEFAULT_CHAT_FRAME:AddMessage(text)
  else
    print(text)
  end
end

function PC:ReportError(err)
  local text = tostring(err)
  if self.Print then
    self:Print("Error: " .. text)
  elseif DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
    DEFAULT_CHAT_FRAME:AddMessage("|cffd4af37[Philosopher's Codex]|r Error: " .. text)
  else
    print("|cffd4af37[Philosopher's Codex]|r Error: " .. text)
  end
end

-- Normalize a slash argument: any whitespace (tabs, non-breaking spaces from
-- copy/paste) collapses to one space, ends are trimmed, case is folded, and a
-- leading "/codex" typed twice is dropped.
function PC:NormalizeSlashArg(msg)
  msg = tostring(msg or "")
  msg = string.gsub(msg, "\194\160", " ")
  msg = string.gsub(msg, "%s+", " ")
  msg = string.match(msg, "^%s*(.-)%s*$") or ""
  local lower = string.lower(msg)
  local stripped = string.match(lower, "^/?codex%s+(.*)$") or string.match(lower, "^/?pc%s+(.*)$")
  if stripped then
    local n = string.len(msg) - string.len(stripped)
    msg = string.sub(msg, n + 1)
    lower = stripped
  end
  return lower, msg
end

PC.SLASH_HELP = {
  "/codex - open or close the main window",
  "/codex mini - show or hide the tracker card",
  "/codex mini reset - rebuild the tracker card and put it by the minimap",
  "/codex mini debug - print the tracker card's state",
  "/codex version - print the loaded version",
  "/codex bug - open the issue report to copy and send to Uriah",
  "/codex welcome - show the welcome card again",
  "/codex report on|off | report name on|off - automatic problem reports to the guild",
  "/codex collect on|off | reports - collect guildmates' reports (Uriah)",
  "/codex settings | issues | update | demo on|off | status <name> | role <name>",
}

function PC:PrintSlashHelp()
  for i = 1, #self.SLASH_HELP do
    self:Print(self.SLASH_HELP[i])
  end
end

function PC:HandleSlash(msg)
  local raw
  msg, raw = self:NormalizeSlashArg(msg)
  if msg == "" then
    if self.ToggleUI then
      self:ToggleUI()
    else
      self:Print("The window is not available yet. If this continues after a reload, the UI file failed to load.")
    end
    return
  end
  if msg == "version" or msg == "ver" or msg == "v" or msg == "about" then
    self:Print("Philosopher's Codex " .. tostring(self.VERSION or "?") .. " is loaded (latest known " .. tostring(self.KNOWN_LATEST or "?") .. ").")
    return
  end
  if msg == "help" or msg == "?" or msg == "commands" then
    self:PrintSlashHelp()
    return
  end
  if msg == "mini debug" or msg == "debug mini" or msg == "mini info" or msg == "mini status" then
    if self.PrintMiniDebug then
      self:PrintMiniDebug()
    else
      self:Print("The mini tracker file did not load. Version " .. tostring(self.VERSION or "?") .. ".")
    end
    return
  end
  if msg == "mini show" or msg == "show mini" or msg == "tracker" or msg == "show tracker" or msg == "mini on" then
    if self.ShowMiniTracker then
      self:ShowMiniTracker()
      self:Print("The tracker card is shown. /codex mini debug if you still cannot see it.")
    else
      self:Print("The mini tracker file did not load. Version " .. tostring(self.VERSION or "?") .. ".")
    end
    return
  end
  if msg == "mini hide" or msg == "hide mini" or msg == "mini off" then
    if self.HideMiniTracker then
      self:HideMiniTracker()
      self:Print("The tracker card is hidden. /codex mini show to bring it back.")
    end
    return
  end
  if msg == "settings" or msg == "options" then
    if self.OpenSettings then
      self:OpenSettings()
    else
      self:Print("The settings panel is not available yet.")
    end
    return
  end
  if msg == "mini reset" or msg == "reset mini" or msg == "minireset" or msg == "reset tracker" or msg == "tracker reset" then
    if self.ResetMiniTracker then
      self:ResetMiniTracker()
      local f = _G.PhilosophersCodexMini
      if f and f.IsVisible and f:IsVisible() then
        self:Print("The tracker card was rebuilt and placed under the minimap.")
      else
        self:Print("The tracker card was reset but is still not visible. Type /codex mini debug and send the lines.")
      end
    elseif self.ResetMiniPosition then
      self:ResetMiniPosition()
      self:Print("The mini tracker position was reset.")
    else
      self:Print("The mini tracker is not available yet.")
    end
    return
  end
  if msg == "mini" then
    if self.ToggleMiniTracker then
      self:ToggleMiniTracker()
    else
      self:Print("The mini tracker is not available yet.")
    end
    return
  end
  if msg == "minimap" then
    if not self:GetDB() then
      self:InitDB()
    end
    local db = self:GetDB()
    if type(db.minimap) ~= "table" then
      db.minimap = { angle = 200, hide = false }
    end
    db.minimap.hide = not db.minimap.hide
    if self.UpdateMinimapButton then
      self:UpdateMinimapButton()
    end
    self:Print(db.minimap.hide and "The minimap button is hidden." or "The minimap button is shown.")
    return
  end
  local scaleArg = string.match(msg, "^scale%s*([%d%.]*)$")
  if string.match(msg, "^scale") then
    if not self:GetDB() then
      self:InitDB()
    end
    if scaleArg and scaleArg ~= "" then
      local applied = self.ApplyWindowScale and self:ApplyWindowScale(tonumber(scaleArg))
      if applied then
        self:Print(string.format("Window scale set to %.2f.", applied))
      else
        self:Print("Usage: /codex scale 0.8-1.4")
      end
    else
      local db = self:GetDB()
      local current = db and db.window and db.window.scale or 1
      self:Print(string.format("Current scale is %.2f. Usage: /codex scale 0.8-1.4", current))
    end
    return
  end
  local shareArg = string.match(msg, "^share%s*(%S*)$")
  if string.match(msg, "^share") then
    if not self:GetDB() then
      self:InitDB()
    end
    if shareArg == "on" or shareArg == "off" then
      if self.SetShareEnabled then
        self:SetShareEnabled(shareArg == "on")
      end
      self:Print(shareArg == "on" and "Guild sharing is on. Status is sent only to your guild." or "Guild sharing is off.")
    else
      local on = self.IsShareEnabled and self:IsShareEnabled()
      self:Print("Guild sharing is " .. (on and "on" or "off") .. ". Usage: /codex share on|off")
    end
    return
  end
  local profileArg = string.match(msg, "^profile%s*(%S*)$")
  if string.match(msg, "^profile") then
    if not self:GetDB() then
      self:InitDB()
    end
    local set = false
    if profileArg and profileArg ~= "" and self.SetUpgradeProfile then
      set = self:SetUpgradeProfile(profileArg)
    end
    if set then
      self:Print("Upgrade profile set to " .. profileArg .. ".")
    else
      local cur = self.GetUpgradeProfile and self:GetUpgradeProfile() or "?"
      local names = {}
      if self.GetUpgradeProfiles then
        local list = self:GetUpgradeProfiles()
        for i = 1, #list do
          names[#names + 1] = list[i].id
        end
      end
      local usage = "heal|balance|both"
      if #names > 0 then
        usage = table.concat(names, "|")
      end
      self:Print("Upgrade profile is " .. tostring(cur) .. ". Usage: /codex profile " .. usage)
    end
    return
  end
  local statusArg = string.match(msg, "^status%s*(%S*)$")
  if string.match(msg, "^status") then
    local map = { questing = "questing", quest = "questing", lfg = "dungeon", dungeon = "dungeon", help = "help", need = "help", open = "open", busy = "busy", dnd = "busy", notlooking = "busy", hidden = "busy" }
    if statusArg and map[statusArg] and self.SetSocialStatus then
      self:SetSocialStatus(map[statusArg])
      self:Print("Guild status set to " .. map[statusArg] .. ".")
    else
      local cur = self.GetSocialStatus and self:GetSocialStatus() or "questing"
      self:Print("Guild status is " .. tostring(cur) .. ". Usage: /codex status dungeon|questing|help|busy|notlooking")
    end
    return
  end
  local roleArg = string.match(msg, "^role%s*(%S*)$")
  if string.match(msg, "^role") then
    local map = { healer = "healer", heal = "healer", tank = "tank", dps = "dps" }
    if roleArg and map[roleArg] and self.SetSocialRole then
      self:SetSocialRole(map[roleArg])
      self:Print("Guild role set to " .. map[roleArg] .. ".")
    else
      local cur = self.GetSocialRole and self:GetSocialRole() or "healer"
      self:Print("Guild role is " .. tostring(cur) .. ". Usage: /codex role healer|tank|dps")
    end
    return
  end
  if string.match(msg, "^note") then
    local rest = string.match(raw, "^[Nn][Oo][Tt][Ee]%s*(.*)$") or ""
    rest = string.gsub(rest, "^%s+", "")
    rest = string.gsub(rest, "%s+$", "")
    if self.SetSocialNote then
      self:SetSocialNote(rest)
    end
    if rest == "" then
      self:Print("Guild note cleared. Usage: /codex note <short text>")
    else
      self:Print("Guild note set to: " .. rest)
    end
    return
  end
  if msg == "update" then
    if self.OpenUpdateDialog then
      self:OpenUpdateDialog()
    else
      self:Print("Update page: " .. tostring(self.RELEASES_PAGE or "https://github.com/uriahgibsonai/PhilosophersCodex-Releases/releases/latest"))
    end
    return
  end
  if msg == "bug" or msg == "report" then
    if self.CopyIssueReport then
      self:CopyIssueReport()
    end
    return
  end
  if msg == "welcome" or msg == "intro" then
    if self.ShowWelcome then
      self:ShowWelcome(true)
    end
    return
  end
  if msg == "reports" or msg == "reports clear" then
    if msg == "reports clear" then
      self:ClearGuildReports()
      self:Print("Guild reports cleared.")
    else
      self:ShowGuildReports()
    end
    return
  end
  local collectArg = string.match(msg, "^collect%s*(%S*)$")
  if collectArg then
    if collectArg == "on" or collectArg == "off" then
      self:SetReportCollector(collectArg == "on")
    end
    self:Print("Report collecting is " .. (self:IsReportCollector() and "on: guildmates' problems are saved here. /codex reports shows them." or "off. /codex collect on turns it on."))
    return
  end
  local repArg = string.match(msg, "^report%s+(%S+)%s*(%S*)$")
  if repArg then
    local a, b = string.match(msg, "^report%s+(%S+)%s*(%S*)$")
    if a == "name" and (b == "on" or b == "off") then
      self:SetReportIncludeName(b == "on")
      self:Print("Your name is " .. (b == "on" and "included in" or "left out of") .. " automatic reports.")
    elseif a == "on" or a == "off" then
      self:SetReportsEnabled(a == "on")
      self:Print("Automatic problem reports are " .. a .. ".")
    else
      self:Print("/codex report on|off, /codex report name on|off")
    end
    return
  end
  if msg == "issues" or msg == "errors" or msg == "log" then
    if self.OpenIssues then
      self:OpenIssues()
    else
      self:Print("The Issues page is not available yet.")
    end
    return
  end
  local debugArg = string.match(msg, "^debug%s*(%S*)$")
  if string.match(msg, "^debug") then
    if debugArg == "on" or debugArg == "off" then
      if self.SetDebugMode then
        self:SetDebugMode(debugArg == "on")
      end
      self:Print("Debug mode is " .. debugArg .. ".")
    else
      local on = self.IsDebugMode and self:IsDebugMode()
      self:Print("Debug mode is " .. (on and "on" or "off") .. ". Usage: /codex debug on|off")
    end
    return
  end
  local demoArg = string.match(msg, "^demo%s*(%S*)$")
  if string.match(msg, "^demo") then
    if demoArg == "on" or demoArg == "off" then
      if self.SetDemoGuild then
        self:SetDemoGuild(demoArg == "on")
      end
      self:Print("Demo guildmates are " .. demoArg .. ". Fake names are tagged Demo and are never broadcast or invited.")
    else
      local on = self.IsDemoGuildOn and self:IsDemoGuildOn()
      self:Print("Demo guildmates are " .. (on and "on" or "off") .. ". Usage: /codex demo on|off")
    end
    return
  end
  self:Print("Unknown command \"" .. tostring(raw) .. "\". Version " .. tostring(self.VERSION or "?") .. ". Commands:")
  self:PrintSlashHelp()
end

-- Registered early so /codex still exists if a later file or event handler errors.
SLASH_PHILOSOPHERSCODEX1 = "/codex"
SLASH_PHILOSOPHERSCODEX2 = "/pc"
SLASH_PHILOSOPHERSCODEX3 = "/fg"
SLASH_PHILOSOPHERSCODEX4 = "/foreverguide"
SlashCmdList.PHILOSOPHERSCODEX = function(msg)
  local ok, err
  if PC.SafeCall then
    ok, err = PC:SafeCall("slash", PC.HandleSlash, PC, msg)
  else
    ok, err = pcall(function()
      PC:HandleSlash(msg)
    end)
    if not ok and PC.ReportError then
      PC:ReportError(err)
    end
  end
  if not ok then
    -- Never fall back silently: say which command failed and why.
    local cmd = tostring(msg or "")
    if cmd == "" then cmd = "(open window)" end
    if PC.Print then
      PC:Print("/codex " .. cmd .. " failed: " .. tostring(err) .. " (version " .. tostring(PC.VERSION or "?") .. ")")
    end
  end
end

function PC:Reveal(msg)
  if not msg or msg == "" then
    return
  end
  local text = msg
  if string.sub(text, 1, 12) == "Time to move" then
    text = "time" .. string.sub(text, 5)
  end
  if not string.find(text, "The Codex reveals", 1, true) then
    text = "The Codex reveals: " .. text
  end
  self:Print(text)
end

-- ---------------------------------------------------------------------------
-- API guards (Classic-era names, with modern C_* fallbacks used by Forever)
-- ---------------------------------------------------------------------------

function PC:GetItemCount(itemID, includeBank)
  if not itemID then
    return 0
  end
  if includeBank == nil then
    includeBank = true
  end
  if C_Item and C_Item.GetItemCount then
    return C_Item.GetItemCount(itemID, includeBank) or 0
  end
  if GetItemCount then
    return GetItemCount(itemID, includeBank) or 0
  end
  return 0
end

function PC:GetItemIcon(itemID)
  if not itemID then
    return nil
  end
  if C_Item and C_Item.GetItemIconByID then
    return C_Item.GetItemIconByID(itemID)
  end
  if GetItemIcon then
    return GetItemIcon(itemID)
  end
  return nil
end

local function ContainerNumSlots(bag)
  if C_Container and C_Container.GetContainerNumSlots then
    return C_Container.GetContainerNumSlots(bag) or 0
  end
  if GetContainerNumSlots then
    return GetContainerNumSlots(bag) or 0
  end
  return 0
end

local function ContainerItemLink(bag, slot)
  if C_Container and C_Container.GetContainerItemLink then
    return C_Container.GetContainerItemLink(bag, slot)
  end
  if GetContainerItemLink then
    return GetContainerItemLink(bag, slot)
  end
  return nil
end

function PC:ForEachOwnedItemLink(callback)
  -- Bags 0-4 (backpack and four bag slots). Bank is not scanned for name matches.
  for bag = 0, 4 do
    local slots = ContainerNumSlots(bag)
    for slot = 1, slots do
      local link = ContainerItemLink(bag, slot)
      if link then
        callback(link)
      end
    end
  end
  for inv = 1, 19 do
    local link = GetInventoryItemLink("player", inv)
    if link then
      callback(link)
    end
  end
end

function PC:ItemNameFromLink(link)
  if not link then
    return nil
  end
  return link:match("%[(.-)%]")
end

function PC:PlayerHasItemByName(name)
  if not name then
    return false
  end
  local target = string.lower(name)
  local found = false
  self:ForEachOwnedItemLink(function(link)
    local itemName = PC:ItemNameFromLink(link)
    if itemName and string.lower(itemName) == target then
      found = true
    end
  end)
  return found
end

function PC:PlayerHasGearItem(item)
  if item.itemID and self:GetItemCount(item.itemID, true) > 0 then
    return true
  end
  if item.name and self:PlayerHasItemByName(item.name) then
    return true
  end
  return false
end

local function CallKnown(fn, spellID)
  if not fn or not spellID then
    return false
  end
  local ok, result = pcall(fn, spellID)
  return ok and result and true or false
end

-- Mainline spell APIs take an int32 spell ID and throw on anything else.
local function ValidSpellID(id)
  id = tonumber(id)
  if not id or id ~= id or id < 1 or id > 2147483647 or math.floor(id) ~= id then
    return nil
  end
  return id
end
PC.ValidSpellID = ValidSpellID

local function KnownByID(spellID)
  spellID = ValidSpellID(spellID)
  if not spellID then
    return false
  end
  if CallKnown(IsPlayerSpell, spellID) then
    return true
  end
  if CallKnown(IsSpellKnown, spellID) then
    return true
  end
  if C_SpellBook and CallKnown(C_SpellBook.IsSpellKnown, spellID) then
    return true
  end
  if C_Spell and CallKnown(C_Spell.IsSpellKnown, spellID) then
    return true
  end
  return false
end

local function SpellQueries(spellName, rank)
  local q = {}
  if type(spellName) == "string" and spellName ~= "" then
    q[#q + 1] = spellName
    if rank then
      q[#q + 1] = spellName .. "(Rank " .. tostring(rank) .. ")"
      q[#q + 1] = spellName .. " (Rank " .. tostring(rank) .. ")"
    end
  end
  return q
end

function PC:PlayerKnowsSpell(spellName, spellID, rank)
  if KnownByID(spellID) then
    return true
  end
  local queries = SpellQueries(spellName, rank)
  for i = 1, #queries do
    local name = queries[i]
    -- IsPlayerSpell is an ID API on mainline, but some clients and our
    -- harness also accept a name. pcall so a type error cannot abort Goals.
    -- IsPlayerSpell only takes an int32 ID on mainline (the 1.10.0 error
    -- came from passing names). Resolve the name to an ID and check that.
    local id
    if C_Spell and C_Spell.GetSpellInfo then
      local ok, info = pcall(C_Spell.GetSpellInfo, name)
      if ok and type(info) == "table" then
        id = info.spellID
      elseif ok and type(info) == "number" then
        id = info
      end
    end
    if not id and GetSpellInfo then
      local ok, _, _, _, _, _, _, got = pcall(GetSpellInfo, name)
      if ok then
        id = got
      end
    end
    if KnownByID(id) then
      return true
    end
  end
  return false
end

function PC:PlayerKnowsTrainerSpell(spell)
  if not spell then
    return false
  end
  return self:PlayerKnowsSpell(spell.n, spell.id, spell.r)
end

function PC:ShowItemTooltip(owner, itemID)
  if not owner or not itemID or not GameTooltip then
    return
  end
  GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
  local ok
  if GameTooltip.SetItemByID then
    ok = pcall(GameTooltip.SetItemByID, GameTooltip, itemID)
  end
  if not ok and GameTooltip.SetHyperlink then
    pcall(GameTooltip.SetHyperlink, GameTooltip, "item:" .. tostring(itemID))
  end
  GameTooltip:Show()
end


-- ---------------------------------------------------------------------------
-- Quest log, waypoints, loot lookup, tooltip hook
-- ---------------------------------------------------------------------------

function PC:GetQuestList(dungeonId)
  if PhilosophersCodexData and PhilosophersCodexData.QUESTS then
    return PhilosophersCodexData.QUESTS[dungeonId]
  end
  return nil
end

function PC:GetLocations()
  if PhilosophersCodexData then
    return PhilosophersCodexData.LOCATIONS
  end
  return nil
end

function PC:GetLootTable()
  if PhilosophersCodexData then
    return PhilosophersCodexData.LOOT
  end
  return nil
end

function PC:GetLootForDungeon(dungeonId)
  local list = {}
  local loot = self:GetLootTable()
  if not loot or not dungeonId then
    return list
  end
  for i = 1, #loot do
    local it = loot[i]
    if it.dungeon == dungeonId then
      list[#list + 1] = it
    end
  end
  return list
end

function PC:FindLootByItemID(itemID)
  if not itemID then
    return nil
  end
  local loot = self:GetLootTable()
  if not loot then
    return nil
  end
  itemID = tonumber(itemID)
  for i = 1, #loot do
    if tonumber(loot[i].itemID) == itemID then
      return loot[i]
    end
  end
  return nil
end

function PC:FindLootByName(name)
  if not name or name == "" then
    return nil
  end
  local loot = self:GetLootTable()
  if not loot then
    return nil
  end
  local needle = string.lower(name)
  for i = 1, #loot do
    local n = loot[i].name
    if n and string.lower(n) == needle then
      return loot[i]
    end
  end
  -- Also match tracker gear names that might not be in LOOT.
  local data = self:GetClassData()
  if data and data.gear then
    for i = 1, #data.gear do
      local g = data.gear[i]
      if g.name and string.lower(g.name) == needle then
        return {
          itemID = g.itemID,
          name = g.name,
          dungeonName = g.source,
          boss = g.boss,
          quest = g.source,
        }
      end
    end
  end
  return nil
end

function PC:IsQuestFlaggedComplete(questID)
  if not questID then
    return false
  end
  if C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted then
    local ok, result = pcall(C_QuestLog.IsQuestFlaggedCompleted, questID)
    if ok then
      return result and true or false
    end
  end
  if IsQuestFlaggedCompleted then
    local ok, result = pcall(IsQuestFlaggedCompleted, questID)
    if ok then
      return result and true or false
    end
  end
  if GetQuestsCompleted then
    local ok, completed = pcall(GetQuestsCompleted)
    if ok and type(completed) == "table" and completed[questID] then
      return true
    end
  end
  return false
end

function PC:IsQuestInLog(questID, questName)
  if questID and C_QuestLog and C_QuestLog.IsOnQuest then
    local ok, result = pcall(C_QuestLog.IsOnQuest, questID)
    if ok and result then
      return true
    end
  end

  local num
  if C_QuestLog and C_QuestLog.GetNumQuestLogEntries then
    num = C_QuestLog.GetNumQuestLogEntries()
  elseif GetNumQuestLogEntries then
    num = GetNumQuestLogEntries()
  end
  if not num or num <= 0 then
    return false
  end

  local needle
  if questName and questName ~= "" then
    needle = string.lower(questName)
  end

  for i = 1, num do
    local title, isHeader, id
    if C_QuestLog and C_QuestLog.GetInfo then
      local info = C_QuestLog.GetInfo(i)
      if type(info) == "table" then
        title = info.title
        isHeader = info.isHeader
        id = info.questID
      end
    elseif GetQuestLogTitle then
      local t, _, _, header, _, _, _, questLogId = GetQuestLogTitle(i)
      title = t
      isHeader = header
      id = questLogId
    end
    if not isHeader then
      if questID and id and tonumber(id) == tonumber(questID) then
        return true
      end
      if needle and title and string.lower(title) == needle then
        return true
      end
    end
  end
  return false
end

function PC:QuestKey(dungeonId, questID, name)
  if questID then
    return "q:" .. tostring(questID)
  end
  return "q:" .. tostring(dungeonId) .. ":" .. tostring(name or "")
end

function PC:IsQuestChecked(dungeonId, quest)
  if not quest then
    return false
  end
  if quest.questID and self:IsQuestFlaggedComplete(quest.questID) then
    return true
  end
  local db = self:GetDB()
  if not db or type(db.quests) ~= "table" then
    return false
  end
  return db.quests[self:QuestKey(dungeonId, quest.questID, quest.name)] and true or false
end

function PC:SetQuestChecked(dungeonId, quest, checked)
  if not quest then
    return
  end
  -- Auto-completed quests stay complete; do not uncheck them by hand.
  if quest.questID and self:IsQuestFlaggedComplete(quest.questID) then
    if self.Refresh then
      self:Refresh()
    end
    return
  end
  local db = self:GetDB()
  if type(db.quests) ~= "table" then
    db.quests = {}
  end
  db.quests[self:QuestKey(dungeonId, quest.questID, quest.name)] = checked and true or nil
  if self.Refresh then
    self:Refresh()
  end
end

function PC:CountDungeonQuests(dungeonId)
  local quests = self:GetQuestList(dungeonId)
  if not quests or #quests == 0 then
    return 0, 0
  end
  local done, total = 0, #quests
  for i = 1, total do
    if self:IsQuestChecked(dungeonId, quests[i]) then
      done = done + 1
    end
  end
  return done, total
end

function PC:IsExpanded(key, defaultOn)
  local db = self:GetDB()
  if db and type(db.expanded) == "table" and db.expanded[key] ~= nil then
    return db.expanded[key] and true or false
  end
  return defaultOn and true or false
end

function PC:ToggleExpanded(key, defaultOn)
  local db = self:GetDB()
  if type(db.expanded) ~= "table" then
    db.expanded = {}
  end
  db.expanded[key] = not self:IsExpanded(key, defaultOn)
  if self.Refresh then
    self:Refresh()
  end
end

-- Reset expand/drill-in state when leaving a tab or hiding the window.
-- Gear's "Soon" groups stay available (they are not stored as expanded);
-- "Later" and other optional sections return to their default-closed state.
function PC:ResetTabState(tab)
  if not tab or tab == "" then
    return
  end
  local db = self:GetDB()
  if not db then
    return
  end
  if type(db.expanded) ~= "table" then
    db.expanded = {}
  end
  local function clearMatching(pred)
    local drop = {}
    for k, _ in pairs(db.expanded) do
      if pred(k) then
        drop[#drop + 1] = k
      end
    end
    for i = 1, #drop do
      db.expanded[drop[i]] = nil
    end
  end
  local function starts(k, prefix)
    return type(k) == "string" and string.sub(k, 1, #prefix) == prefix
  end
  if tab == "path" or tab == "all" then
    clearMatching(function(k)
      return starts(k, "path-quests:") or starts(k, "quests:") or starts(k, "loot:")
    end)
    db.pathZone = nil
  end
  if tab == "goals" or tab == "all" then
    clearMatching(function(k)
      return starts(k, "goals-")
    end)
  end
  if tab == "gear" or tab == "all" then
    db.expanded["gear-later"] = false
  end
  if tab == "craft" or tab == "all" then
    db.expanded["craft-unlearned"] = false
    if self.ResetCraftLanding then
      self:ResetCraftLanding()
    end
  end
  if tab == "guild" or tab == "all" then
    clearMatching(function(k)
      return starts(k, "guild-")
    end)
  end
  if tab == "next" or tab == "all" then
    clearMatching(function(k)
      return starts(k, "next-")
    end)
  end
end

-- Goals tab: selecting a closed group opens it and collapses the others.
-- Tapping the already-open group closes it, so every group can be shut
-- (Trainer spells included) and the list is easy to scan.
function PC:SelectGoalGroup(key)
  local db = self:GetDB()
  if not db then
    return
  end
  if type(db.expanded) ~= "table" then
    db.expanded = {}
  end
  local data = self.GetClassData and self:GetClassData() or nil
  local groups = data and data.goalGroups or {}
  -- A nil key closes every group. A named key always opens that group
  -- (and closes the others) so callers can expand without toggling shut.
  for i = 1, #groups do
    local k = groups[i].key
    if k then
      db.expanded[k] = (key and k == key) and true or false
    end
  end
  if self.Refresh then
    self:Refresh()
  end
end

function PC:GetZoneWaypoint(zoneName)
  local loc = self:GetLocations()
  if loc and loc.zones and zoneName then
    return loc.zones[zoneName]
  end
  return nil
end

function PC:GetEntranceWaypoint(dungeonId)
  local loc = self:GetLocations()
  if loc and loc.entrances and dungeonId then
    local wp = loc.entrances[dungeonId]
    if wp then
      return wp
    end
  end
  if dungeonId and self.LogMissing then
    self:LogMissing("entrance", dungeonId, "Dungeon has no entrance coordinates: " .. tostring(dungeonId))
  end
  return nil
end

function PC:GetTrainerWaypoint(id)
  local loc = self:GetLocations()
  if loc and loc.trainers and id then
    local wp = loc.trainers[id]
    if wp then
      return wp
    end
  end
  if id and self.LogMissing then
    self:LogMissing("trainer", id, "Missing trainer pin: " .. tostring(id))
  end
  return nil
end

-- Mathrengyl in Darnassus is the only Alliance druid trainer with verified
-- coordinates in this addon. Moonglade and Stormwind trainers exist but
-- their pins are left out until Forever coords are confirmed.
function PC:GetNearestDruidTrainerWaypoint()
  return self:GetClassTrainerWaypoint()
end

function PC:GetClassTrainerWaypoint()
  local data = self:GetClassData()
  local id = data and data.trainerWaypoint
  if id then
    return self:GetTrainerWaypoint(id)
  end
  return nil
end

function PC:GetSpellPack()
  local classFile = self:GetClassFile()
  local packs = PhilosophersCodexData and PhilosophersCodexData.SPELLS
  if not packs or not classFile then
    return nil
  end
  if packs[classFile] then
    return packs[classFile]
  end
  -- Tolerate mixed-case keys if a data file was written that way.
  for key, pack in pairs(packs) do
    if type(key) == "string" and string.upper(key) == classFile then
      return pack
    end
  end
  return nil
end

local function TrainerSpellArray(all)
  if type(all) ~= "table" then
    return nil
  end
  if #all > 0 then
    return all
  end
  local list = {}
  for _, sp in pairs(all) do
    if type(sp) == "table" and sp.n and sp.l then
      list[#list + 1] = sp
    end
  end
  if #list == 0 then
    return all
  end
  table.sort(list, function(a, b)
    if a.l == b.l then
      return tostring(a.n) < tostring(b.n)
    end
    return a.l < b.l
  end)
  return list
end

function PC:GetTrainerSpells()
  local pack = self:GetSpellPack()
  if pack and type(pack.list) == "table" then
    return TrainerSpellArray(pack.list)
  end
  -- Do not fall back to a leftover global trainer list (it may be another class).
  local classFile = self:GetClassFile()
  if self.LogMissing and classFile then
    self:LogMissing("spells", classFile, "No trainer spell pack for " .. tostring(classFile))
  end
  return nil
end

function PC:RecommendTrainerSpell(spell)
  local pack = self:GetSpellPack()
  if pack and pack.Recommend then
    return pack.Recommend(spell)
  end
  return "skip", "No recommendation data."
end

function PC:TrainerSpellLabel(spell)
  if not spell then
    return ""
  end
  if spell.r then
    return spell.n .. " (Rank " .. tostring(spell.r) .. ")"
  end
  return spell.n
end

function PC:RecommendLabel(tag)
  local data = self:GetClassData()
  if data and type(data.recLabels) == "table" and data.recLabels[tag] then
    return data.recLabels[tag]
  end
  if tag == "must" then
    return "Must train"
  end
  if tag and tag ~= "skip" then
    return "Train for " .. tag
  end
  return "Skip for now"
end

-- Current role spells: Must train, plus Train for healing and/or Train for
-- Balance according to the upgrade profile (heal / balance / both).
function PC:IsCurrentRoleTrainerSpell(spell)
  local tag = self:RecommendTrainerSpell(spell)
  if tag == "must" then
    return true
  end
  local labels = self.GetProfileRoleTags and self:GetProfileRoleTags() or {}
  for i = 1, #labels do
    if labels[i] == tag then
      return true
    end
  end
  return false
end

function PC:GetTrainerSpellsByLevel(fromLevel)
  local all = self:GetTrainerSpells()
  if type(all) ~= "table" then
    return {}
  end
  fromLevel = tonumber(fromLevel) or (self:PlayerLevel() or 1)
  -- Include the even trainer visit at or just below the current level so odd
  -- levels still see spells they can train now (e.g. 26 at level 27).
  if fromLevel > 1 and fromLevel % 2 == 1 then
    fromLevel = fromLevel - 1
  end
  local groups = {}
  local order = {}
  for i = 1, #all do
    local sp = all[i]
    if sp.l and sp.l >= fromLevel then
      local bucket = groups[sp.l]
      if not bucket then
        bucket = { level = sp.l, spells = {} }
        groups[sp.l] = bucket
        order[#order + 1] = sp.l
      end
      bucket.spells[#bucket.spells + 1] = sp
    end
  end
  table.sort(order)
  local out = {}
  for i = 1, #order do
    out[#out + 1] = groups[order[i]]
  end
  return out
end

function PC:GetTrainerVisitSummary(fromLevel)
  local groups = self:GetTrainerSpellsByLevel(fromLevel)
  local mustN, roleN, availableN, knownN, total = 0, 0, 0, 0, 0
  local level = self:PlayerLevel() or 1
  for i = 1, #groups do
    local list = groups[i].spells
    for j = 1, #list do
      local sp = list[j]
      total = total + 1
      local known = self:PlayerKnowsTrainerSpell(sp)
      if known then
        knownN = knownN + 1
      end
      local tag = self:RecommendTrainerSpell(sp)
      local role = self:IsCurrentRoleTrainerSpell(sp)
      if role and not known then
        roleN = roleN + 1
        if tag == "must" then
          mustN = mustN + 1
        end
        if (sp.l or 99) <= level then
          availableN = availableN + 1
        end
      end
    end
  end
  return {
    groups = groups,
    must = mustN,
    role = roleN,
    available = availableN,
    known = knownN,
    total = total,
  }
end

function PC:GetQuestLogIDs(maxN)
  maxN = maxN or 20
  local ids = {}
  local function add(id)
    id = tonumber(id)
    if id and id > 0 and #ids < maxN then
      for i = 1, #ids do
        if ids[i] == id then
          return
        end
      end
      ids[#ids + 1] = id
    end
  end
  if C_QuestLog then
    local num
    if C_QuestLog.GetNumQuestLogEntries then
      local ok, n = pcall(C_QuestLog.GetNumQuestLogEntries)
      if ok then
        num = n
      end
    end
    if type(num) == "number" and C_QuestLog.GetInfo then
      for i = 1, math.min(num, 50) do
        local ok, info = pcall(C_QuestLog.GetInfo, i)
        if ok and type(info) == "table" and not info.isHeader then
          add(info.questID)
        end
      end
    end
    if #ids == 0 and C_QuestLog.GetQuestID then
      for i = 1, 50 do
        local ok, id = pcall(C_QuestLog.GetQuestID, i)
        if ok then
          add(id)
        end
      end
    end
  end
  if #ids == 0 and GetNumQuestLogEntries then
    local ok, n = pcall(GetNumQuestLogEntries)
    if ok and type(n) == "number" then
      for i = 1, math.min(n, 50) do
        if GetQuestLogQuestID then
          local ok2, id = pcall(GetQuestLogQuestID, i)
          if ok2 then
            add(id)
          end
        elseif GetQuestLogTitle then
          local ok2, title, _, _, isHeader, _, _, _, questID = pcall(GetQuestLogTitle, i)
          if ok2 and not isHeader then
            add(questID)
          end
        end
      end
    end
  end
  return ids
end

function PC:QuestName(questID)
  questID = tonumber(questID)
  if not questID then
    return nil
  end
  if C_QuestLog and C_QuestLog.GetTitleForQuestID then
    local ok, title = pcall(C_QuestLog.GetTitleForQuestID, questID)
    if ok and type(title) == "string" and title ~= "" then
      return title
    end
  end
  if self.GetQuestInfo then
    local q = self:GetQuestInfo(questID)
    if type(q) == "table" and q.name then
      return q.name
    end
  end
  -- Fall back to the catalogued dungeon-quest list.
  local data = PhilosophersCodexData
  if data and data.QUESTS then
    local list = data.QUESTS
    for i = 1, #list do
      if list[i].id == questID or list[i].questID == questID then
        return list[i].name or list[i].title
      end
    end
  end
  -- Scan class dungeon quests
  local classData = self.GetClassData and self:GetClassData()
  -- Quests.lua may be a map by dungeon id
  if PhilosophersCodexData and PhilosophersCodexData.GetQuestName then
    local n = PhilosophersCodexData.GetQuestName(questID)
    if n then
      return n
    end
  end
  return "Quest " .. tostring(questID)
end

function PC:ZonesAreRelated(zoneA, zoneB)
  if not zoneA or not zoneB or zoneA == "-" or zoneB == "-" then
    return nil
  end
  if string.lower(zoneA) == string.lower(zoneB) then
    return "same"
  end
  local data = self:GetClassData()
  if not data or type(data.brackets) ~= "table" then
    return nil
  end
  for i = 1, #data.brackets do
    local zones = data.brackets[i].zones or {}
    local hasA, hasB = false, false
    for j = 1, #zones do
      if string.lower(zones[j]) == string.lower(zoneA) then hasA = true end
      if string.lower(zones[j]) == string.lower(zoneB) then hasB = true end
    end
    if hasA and hasB then
      return "adjacent"
    end
  end
  return nil
end

function PC:GetOnLevelDungeons()
  local out = {}
  local brackets = self.GetCurrentBrackets and self:GetCurrentBrackets() or {}
  local seen = {}
  for i = 1, #brackets do
    local dungeons = brackets[i].dungeons or {}
    for j = 1, #dungeons do
      local d = dungeons[j]
      if d and d.id and not seen[d.id] and not d.skipped then
        seen[d.id] = true
        out[#out + 1] = d
      end
    end
  end
  return out
end

function PC:FindDungeon(idOrName)
  if not idOrName or idOrName == "" or idOrName == "-" then
    return nil
  end
  local key = string.lower(tostring(idOrName))
  local data = self:GetClassData()
  if not data or type(data.brackets) ~= "table" then
    return nil
  end
  for i = 1, #data.brackets do
    local dungeons = data.brackets[i].dungeons or {}
    for j = 1, #dungeons do
      local d = dungeons[j]
      if d.id and string.lower(d.id) == key then
        return d
      end
      if d.name and string.lower(d.name) == key then
        return d
      end
      if type(d.aliases) == "table" then
        for k = 1, #d.aliases do
          if string.lower(d.aliases[k]) == key then
            return d
          end
        end
      end
    end
  end
  return nil
end

function PC:QuestWaypoint(quest)
  if quest and quest.uiMapID and quest.x and quest.y then
    return {
      uiMapID = quest.uiMapID,
      x = quest.x,
      y = quest.y,
      title = quest.giver or quest.name,
    }
  end
  return nil
end

function PC:SetWaypoint(wp)
  if not wp or not wp.uiMapID or not wp.x or not wp.y then
    self:Print("The Codex has no map mark for that place yet.")
    return
  end
  local x = wp.x / 100
  local y = wp.y / 100
  local title = wp.title or "Philosopher's Codex"
  local placed = false

  if TomTom and TomTom.AddWaypoint then
    local ok = pcall(function()
      TomTom:AddWaypoint(wp.uiMapID, x, y, { title = title, from = "PhilosophersCodex" })
    end)
    if ok then
      placed = true
    end
  end

  if C_Map and C_Map.SetUserWaypoint then
    local point
    if UiMapPoint and UiMapPoint.CreateFromCoordinates then
      local ok, created = pcall(UiMapPoint.CreateFromCoordinates, wp.uiMapID, x, y)
      if ok then
        point = created
      end
    end
    if not point then
      if CreateVector2D then
        local ok, vec = pcall(CreateVector2D, x, y)
        if ok then
          point = { uiMapID = wp.uiMapID, position = vec }
        end
      end
    end
    if not point then
      point = { uiMapID = wp.uiMapID, position = { x = x, y = y } }
    end
    local ok = pcall(C_Map.SetUserWaypoint, point)
    if ok then
      placed = true
      if C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then
        pcall(C_SuperTrack.SetSuperTrackedUserWaypoint, true)
      end
    end
  end

  local coords = string.format("%s (%.1f, %.1f)", title, wp.x, wp.y)
  if placed then
    self:Print("The Codex marks the path: " .. coords)
  else
    self:Print("The Codex cannot place a map pin here. Coordinates: " .. coords)
  end
end

local function TooltipItemID(tooltip, data)
  if data then
    if data.id then
      return tonumber(data.id)
    end
    if data.guid and C_Item and C_Item.GetItemIDForItemInfo then
      -- skip; guid parsing is client-specific
    end
  end
  if tooltip and tooltip.GetItem then
    local ok, name, link = pcall(tooltip.GetItem, tooltip)
    if ok and link then
      local id = string.match(link, "item:(%d+)")
      if id then
        return tonumber(id), name
      end
      return nil, name
    end
  end
  return nil
end

local tooltipBusy = false

local function IsScanTooltip(tooltip)
  if not tooltip then
    return true
  end
  if PC.IsScanTooltip and PC:IsScanTooltip(tooltip) then
    return true
  end
  local name
  if tooltip.GetName then
    local ok, got = pcall(tooltip.GetName, tooltip)
    if ok then
      name = got
    end
  end
  return name == "PhilosophersCodexScanTip"
end

local function AnnotateItemTooltip(tooltip, data)
  -- Re-entrancy guard: never Set*/Show the tooltip being hooked, and never
  -- run the hook on the hidden scan tip. A 1.4.0 Show() at the end of this
  -- function froze the client when the minimap button called GameTooltip:Show().
  if tooltipBusy then
    return
  end
  if not tooltip or IsScanTooltip(tooltip) then
    return
  end
  local itemID, name = TooltipItemID(tooltip, data)
  local link
  if tooltip.GetItem then
    local ok, _, gotLink = pcall(tooltip.GetItem, tooltip)
    if ok then
      link = gotLink
    end
  end
  if (not link or link == "") and data and data.hyperlink then
    link = data.hyperlink
  end
  if not itemID and type(link) == "string" then
    itemID = tonumber(string.match(link, "item:(%d+)"))
  end
  -- Only item tooltips with a real id or link. Text-only tooltips (minimap,
  -- buttons) must not be processed and must not be shown again from here.
  if not itemID and (type(link) ~= "string" or not string.find(link, "item:", 1, true)) then
    return
  end
  tooltipBusy = true
  local ok, err = pcall(function()
    if PC.FindLootByItemID then
      local rec = PC:FindLootByItemID(itemID)
      if not rec and name then
        rec = PC:FindLootByName(name)
      end
      if rec then
        local dungeon = rec.dungeonName or rec.quest or rec.dungeon or "the Path"
        local boss = rec.boss
        local line
        if boss and boss ~= "" then
          line = "Codex target: " .. dungeon .. " - " .. boss
        else
          line = "Codex target: " .. dungeon
        end
        tooltip:AddLine(line, 0.831, 0.686, 0.216)
        local owned = false
        if rec.itemID and PC.PlayerHasGearItem then
          owned = PC:PlayerHasGearItem({ itemID = rec.itemID, name = rec.name })
        elseif rec.name and PC.PlayerHasItemByName then
          owned = PC:PlayerHasItemByName(rec.name)
        end
        if owned then
          tooltip:AddLine("Acquired", 0.247, 0.749, 0.498)
        end
      end
    end
    if PC.AnnotateUpgradeTooltip then
      PC:AnnotateUpgradeTooltip(tooltip, itemID, name, link)
    end
  end)
  tooltipBusy = false
  if not ok and PC.ReportError then
    -- Cheap, bounded: do not retry, do not Show() to recover.
    pcall(PC.ReportError, PC, err)
  end
end

function PC:InstallTooltipHook()
  if self.tooltipHooked then
    return
  end
  self.tooltipHooked = true
  if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Item then
    pcall(TooltipDataProcessor.AddTooltipPostCall, Enum.TooltipDataType.Item, AnnotateItemTooltip)
    return
  end
  local function hookTip(tip)
    if not tip or not tip.HookScript then
      return
    end
    pcall(tip.HookScript, tip, "OnTooltipSetItem", function(self)
      AnnotateItemTooltip(self)
    end)
  end
  hookTip(GameTooltip)
  hookTip(ItemRefTooltip)
  hookTip(ShoppingTooltip1)
  hookTip(ShoppingTooltip2)
end


-- ---------------------------------------------------------------------------
-- Brackets, zones, dungeons
-- ---------------------------------------------------------------------------

function PC:PlayerLevel()
  return UnitLevel("player") or 1
end

function PC:GetCurrentBrackets()
  local data = self:GetClassData()
  if not data then
    return {}
  end
  local level = self:PlayerLevel()
  local list = {}
  for i = 1, #data.brackets do
    local b = data.brackets[i]
    if level >= b.min and level <= b.max then
      list[#list + 1] = b
    end
  end
  return list
end

-- 1.23.0: zone and dungeon picks by level, never the city you stand in.
function PC:IsCityZone(name)
  local loc = self:GetLocations()
  return type(name) == "string" and loc and loc.cities and loc.cities[name] and true or false
end

function PC:GetZoneLevelRange(name)
  local loc = self:GetLocations()
  local r = loc and loc.zoneLevels and loc.zoneLevels[name]
  if r then
    return r[1], r[2]
  end
  return nil
end

-- Best questing zones for this level, best first. Cities never count.
function PC:GetLevelingZones(limit)
  limit = limit or 3
  local data = self:GetClassData()
  local level = self:PlayerLevel() or 1
  local seen, cands = {}, {}
  local function consider(name, order, inCurrent)
    if type(name) ~= "string" or seen[name] or self:IsCityZone(name) then
      return
    end
    seen[name] = true
    local lo, hi = self:GetZoneLevelRange(name)
    local fit
    if lo then
      if level >= lo - 1 and level <= hi then
        -- Best when you're a little past the bottom of the range.
        fit = math.abs(level - (lo + (hi - lo) * 0.4))
      end
    elseif inCurrent then
      fit = 6
    end
    if fit then
      cands[#cands + 1] = { name = name, fit = fit + (inCurrent and 0 or 1.5), order = order, lo = lo, hi = hi }
    end
  end
  local current = self:GetCurrentBrackets() or {}
  local order = 0
  for i = 1, #current do
    for j = 1, #(current[i].zones or {}) do
      order = order + 1
      consider(current[i].zones[j], order, true)
    end
  end
  for i = 1, #((data and data.brackets) or {}) do
    for j = 1, #(data.brackets[i].zones or {}) do
      order = order + 1
      consider(data.brackets[i].zones[j], order, false)
    end
  end
  table.sort(cands, function(a, b)
    if a.fit ~= b.fit then return a.fit < b.fit end
    return a.order < b.order
  end)
  local out = {}
  for i = 1, math.min(limit, #cands) do
    out[i] = cands[i]
  end
  return out
end

local function DungeonRangeNums(d)
  local lo, hi = tostring(d and d.range or ""):match("(%d+)%s*%-%s*(%d+)")
  return tonumber(lo), tonumber(hi)
end

-- Dungeons to run at this level from the whole route, best fit first.
function PC:GetDungeonsForLevel(limit)
  local level = self:PlayerLevel() or 1
  local list = {}
  local all = self:GetAllDungeons() or {}
  for i = 1, #all do
    local d = all[i]
    local lo, hi = DungeonRangeNums(d)
    if d and d.id and lo and not d.skipped and level >= lo - 2 and level <= hi then
      list[#list + 1] = { d = d, fit = math.abs(level - (lo + 2)), lo = lo, hi = hi, order = i }
    end
  end
  table.sort(list, function(a, b)
    if a.fit ~= b.fit then return a.fit < b.fit end
    return a.order < b.order
  end)
  local out = {}
  for i = 1, math.min(limit or 4, #list) do
    out[i] = list[i].d
  end
  return out
end

-- Steps from where you are to a zone (and on to a dungeon door).
function PC:GetTravelSteps(zone, dungeonId)
  local loc = self:GetLocations() or {}
  local travel = loc.travel or {}
  local here = self:GetCurrentZoneName()
  local onKal = here and loc.kalimdor and loc.kalimdor[here] or false
  local targetKal = loc.kalimdor and loc.kalimdor[zone] or false
  local steps = {}
  local function add(t) steps[#steps + 1] = t end
  if here and zone and here == zone then
    add("You're already in " .. zone .. ".")
  else
    local t = travel[zone] or {}
    if onKal and not targetKal then
      add("Take the boat from Auberdine (Darkshore) to Menethil Harbor in the Wetlands.")
      for i = 1, #(t.east or {}) do add(t.east[i]) end
    elseif onKal and targetKal then
      for i = 1, #(t.kal or t.east or {}) do add((t.kal or t.east)[i]) end
    elseif targetKal then
      if t.east then
        for i = 1, #t.east do add(t.east[i]) end
      else
        add("Fly or ride to Menethil Harbor in the Wetlands.")
        add("Take the boat to Auberdine in Darkshore.")
        for i = 1, #(t.kal or {}) do add(t.kal[i]) end
      end
    else
      for i = 1, #(t.east or {}) do add(t.east[i]) end
    end
    if #steps == 0 and zone then
      add("Head to " .. zone .. ".")
    end
  end
  if dungeonId then
    local e = loc.entrances and loc.entrances[dungeonId]
    local hint = loc.entranceHints and loc.entranceHints[dungeonId]
    if hint then add(hint) end
    if e and e.x then
      add(string.format("Entrance at %.1f, %.1f. Tap the pin to mark it.", e.x, e.y))
    end
  end
  return steps
end

function PC:BracketKey(brackets)
  local parts = {}
  for i = 1, #brackets do
    parts[#parts + 1] = brackets[i].id
  end
  return table.concat(parts, ",")
end

function PC:GetAllDungeons()
  local data = self:GetClassData()
  local list = {}
  if not data then
    return list
  end
  local seen = {}
  for i = 1, #(data.brackets or {}) do
    local dungeons = data.brackets[i].dungeons or {}
    for j = 1, #dungeons do
      local d = dungeons[j]
      local id = d and (d.id or d.name)
      if id and not seen[id] then
        seen[id] = true
        list[#list + 1] = d
      elseif not id then
        list[#list + 1] = d
      end
    end
  end
  return list
end

function PC:FindDungeonsByInstanceName(instanceName)
  local found = {}
  if not instanceName or instanceName == "" then
    return found
  end
  local needle = string.lower(instanceName)
  local dungeons = self:GetAllDungeons()
  for i = 1, #dungeons do
    local d = dungeons[i]
    local aliases = d.aliases or { d.name }
    for j = 1, #aliases do
      if string.lower(aliases[j]) == needle then
        found[#found + 1] = d
        break
      end
    end
  end
  return found
end

function PC:GetDungeonState(id)
  local db = self:GetDB()
  return db.dungeons[id]
end

function PC:IsDungeonChecked(id)
  local st = self:GetDungeonState(id)
  return st and st.checked and true or false
end

function PC:IsDungeonVisited(id)
  local st = self:GetDungeonState(id)
  return st and st.visited and true or false
end

function PC:SetDungeonChecked(id, checked)
  local db = self:GetDB()
  local st = EnsureEntry(db.dungeons, id)
  st.checked = checked and true or false
  st.unchecked = not st.checked
  if PC.Refresh then
    PC:Refresh()
  end
end

function PC:MarkDungeonVisited(id)
  local db = self:GetDB()
  local st = EnsureEntry(db.dungeons, id)
  st.visited = true
  if not st.unchecked then
    st.checked = true
  end
  if PC.Refresh then
    PC:Refresh()
  end
end

-- Live zone name from the client. Prefer the player's best map so a
-- stale saved activity zone or a recommended route zone cannot leak in.
-- Falls back to GetRealZoneText / GetZoneText when C_Map is empty
-- (loading screens, or a client without map APIs).
function PC:GetLiveZoneName()
  if C_Map and C_Map.GetBestMapForUnit then
    local ok, mapID = pcall(C_Map.GetBestMapForUnit, "player")
    if ok and mapID and C_Map.GetMapInfo then
      local ok2, info = pcall(C_Map.GetMapInfo, mapID)
      if ok2 and type(info) == "table" then
        local name = info.name or info.nameEn
        if type(name) == "string" and name ~= "" then
          return name, mapID
        end
      end
    end
  end
  if GetRealZoneText then
    local ok, name = pcall(GetRealZoneText)
    if ok and type(name) == "string" and name ~= "" then
      return name
    end
  end
  if GetZoneText then
    local ok, name = pcall(GetZoneText)
    if ok and type(name) == "string" and name ~= "" then
      return name
    end
  end
  return nil
end

function PC:CurrentZoneNames()
  local names = {}
  local seen = {}
  local function add(name)
    if type(name) ~= "string" or name == "" then
      return
    end
    local key = string.lower(name)
    if seen[key] then
      return
    end
    seen[key] = true
    names[#names + 1] = name
  end
  -- Live map name first so GetCurrentZoneName matches the zone the
  -- player is actually standing in.
  add(self:GetLiveZoneName())
  if GetRealZoneText then
    local ok, name = pcall(GetRealZoneText)
    if ok then
      add(name)
    end
  end
  if GetZoneText then
    local ok, name = pcall(GetZoneText)
    if ok then
      add(name)
    end
  end
  if GetMinimapZoneText then
    local ok, name = pcall(GetMinimapZoneText)
    if ok then
      add(name)
    end
  end
  return names
end

function PC:GetCurrentZoneName()
  return self:GetLiveZoneName() or (self:CurrentZoneNames()[1])
end

function PC:IsCurrentZoneName(zoneName)
  if type(zoneName) ~= "string" or zoneName == "" then
    return false
  end
  local needle = string.lower(zoneName)
  local current = self:CurrentZoneNames()
  for i = 1, #current do
    if string.lower(current[i]) == needle then
      return true, current[i]
    end
  end
  return false
end

function PC:ZoneMatchesList(zoneList)
  if not zoneList then
    return false
  end
  local current = self:CurrentZoneNames()
  for i = 1, #current do
    local here = string.lower(current[i])
    for j = 1, #zoneList do
      if string.lower(zoneList[j]) == here then
        return true, current[i]
      end
    end
  end
  return false, current[1]
end

function PC:IsInRecommendedZone(currentOnly)
  local picks = self:GetLevelingZones(4)
  for i = 1, #picks do
    local ok, name = self:IsCurrentZoneName(picks[i].name)
    if ok then
      return true, name, nil
    end
  end
  local names = self:CurrentZoneNames()
  return false, names[1], nil
end

local function PrettyRace(raceFile)
  if type(raceFile) ~= "string" or raceFile == "" then
    return nil
  end
  if raceFile == "NightElf" then
    return "Night Elf"
  end
  if raceFile == "Scourge" then
    return "Undead"
  end
  if raceFile == "BloodElf" then
    return "Blood Elf"
  end
  if raceFile == "VoidElf" then
    return "Void Elf"
  end
  -- Gnome, Dwarf, Human, etc. already read well.
  return raceFile
end

-- Best zone for the player's level, faction, and starting race.
-- Prefers a current-bracket zone the player is already in; otherwise the
-- first zone of the most advanced current bracket.
function PC:GetRecommendedZone()
  local data = self:GetClassData()
  local level = self:PlayerLevel() or 1
  local race = PrettyRace(self.GetRaceFile and self:GetRaceFile() or nil)
  local faction = "Alliance"
  if UnitFactionGroup then
    local ok, name = pcall(UnitFactionGroup, "player")
    if ok and type(name) == "string" and name ~= "" then
      faction = name
    end
  end
  local current = self:GetCurrentBrackets() or {}
  if #current == 0 and data and data.brackets then
    -- Fall back to the next upcoming bracket, or the last one if past the end.
    local upcoming, last
    for i = 1, #data.brackets do
      local b = data.brackets[i]
      last = b
      if level < (b.min or 0) then
        upcoming = b
        break
      end
    end
    if upcoming then
      current = { upcoming }
    elseif last then
      current = { last }
    end
  end
  if #current == 0 then
    return {
      name = nil,
      why = "No leveling zone is written for level " .. tostring(level) .. ".",
      here = false,
      level = level,
      faction = faction,
      race = race,
    }
  end

  local function moreAdvanced(a, b)
    return (a.min or 0) > (b.min or 0)
  end
  local ranked = {}
  for i = 1, #current do
    ranked[i] = current[i]
  end
  table.sort(ranked, moreAdvanced)

  local function whoFor()
    local parts = { "level " .. tostring(level) }
    if race then
      parts[#parts + 1] = race
    end
    if faction then
      parts[#parts + 1] = faction
    end
    return table.concat(parts, " ")
  end

  -- 1.23.0: pick by level from the leveling zones; a city never wins
  -- just because you're standing in it.
  local picks = self:GetLevelingZones(4)
  local function bracketFor(zone)
    for i = 1, #ranked do
      for z = 1, #(ranked[i].zones or {}) do
        if ranked[i].zones[z] == zone then return ranked[i] end
      end
    end
    return ranked[1]
  end
  local zone, here
  for i = 1, #picks do
    if self:IsCurrentZoneName(picks[i].name) then
      zone, here = picks[i].name, true
      break
    end
  end
  if not zone then
    zone = picks[1] and picks[1].name
  end
  if not zone then
    local b0 = ranked[1]
    for z = 1, #(b0.zones or {}) do
      if not self:IsCityZone(b0.zones[z]) then zone = b0.zones[z] break end
    end
    zone = zone or (b0.zones and b0.zones[1])
  end
  local b = bracketFor(zone)
  local why = (here and "You're here. " or "") .. "Best zone for " .. whoFor()
  local lo, hi = self:GetZoneLevelRange(zone)
  if lo then
    why = why .. " (zone levels " .. lo .. "-" .. hi .. ")"
  end
  why = why .. "."
  local hereNow = self:GetCurrentZoneName()
  if not here and hereNow and zone then
    why = "Travel here from " .. hereNow .. ". " .. why
  end
  local others = {}
  for i = 1, #picks do
    if picks[i].name ~= zone then others[#others + 1] = picks[i].name end
  end
  return {
    name = zone,
    why = why,
    waypoint = zone and self:GetZoneWaypoint(zone) or nil,
    bracket = b,
    here = here and true or false,
    others = others,
    level = level,
    faction = faction,
    race = race,
  }
end

-- Group a gear slot into weapons / armor / jewelry for the Gear tab.
function PC:ClassifyGearSlot(slot)
  local raw = slot
  if type(slot) ~= "string" or slot == "" then
    return "other", "Other"
  end
  local s = string.lower(slot)
  if s == "neck" then
    return "jewelry", "Neck"
  end
  if s == "finger" or s == "ring" or s:find("finger", 1, true) or s:find("ring", 1, true) then
    return "jewelry", "Finger"
  end
  if s == "trinket" or s:find("trinket", 1, true) then
    return "jewelry", "Trinket"
  end
  local armor = {
    head = "Head",
    shoulder = "Shoulder",
    shoulders = "Shoulder",
    chest = "Chest",
    wrist = "Wrist",
    hands = "Hands",
    waist = "Waist",
    legs = "Legs",
    feet = "Feet",
    back = "Back",
    cloak = "Back",
  }
  if armor[s] then
    return "armor", armor[s]
  end
  if s:find("two%-hand") or s:find("two hand", 1, true) then
    return "weapons", "Two-Hand"
  end
  if s == "wand" or s:find("wand", 1, true) then
    return "weapons", "Wand"
  end
  if s == "ranged" or s == "bow" or s == "gun" or s == "crossbow" or s == "thrown"
      or s:find("ranged", 1, true) then
    return "weapons", "Ranged"
  end
  if s == "main hand" or s == "mainhand" or s:find("main hand", 1, true) then
    return "weapons", "Main Hand"
  end
  if s == "off hand" or s == "offhand" or s:find("off%-hand") or s:find("off hand", 1, true)
      or s:find("held in off", 1, true) or s == "shield" then
    return "weapons", "Off Hand"
  end
  return "other", raw
end

function PC:ParseLevelRange(range)
  if type(range) ~= "string" then
    return nil, nil
  end
  local a, b = string.match(range, "^(%d+)%s*%-%s*(%d+)$")
  if a then
    return tonumber(a), tonumber(b)
  end
  return nil, nil
end

function PC:TextMatches(query, ...)
  if not query or query == "" then
    return true
  end
  query = string.lower(query)
  local n = select("#", ...)
  for i = 1, n do
    local s = select(i, ...)
    if type(s) == "string" and s ~= "" then
      if string.find(string.lower(s), query, 1, true) then
        return true
      end
    end
  end
  return false
end

function PC:GetSearchQuery()
  return self.searchQuery or ""
end

function PC:SetSearchQuery(text)
  self.searchQuery = text or ""
  if self.Refresh then
    self:Refresh()
  end
end

function PC:IsHideCompleted()
  local db = self:GetDB()
  return db and db.hideCompleted and true or false
end

function PC:SetHideCompleted(hide)
  local db = self:GetDB()
  if db then
    db.hideCompleted = hide and true or false
  end
  if self.Refresh then
    self:Refresh()
  end
end

local function FlagOn(db, key)
  return not db or db[key] ~= false
end

function PC:IsUpgradeChatEnabled()
  return FlagOn(self:GetDB(), "upgradeChat")
end

function PC:IsUpgradeToastEnabled()
  return FlagOn(self:GetDB(), "upgradeToast")
end

function PC:IsUpgradeTooltipEnabled()
  return FlagOn(self:GetDB(), "upgradeTooltip")
end

function PC:IsBracketAlertsEnabled()
  return FlagOn(self:GetDB(), "bracketAlerts")
end

function PC:IsMatchToastEnabled()
  return FlagOn(self:GetDB(), "matchToast")
end

function PC:IsRequestToastEnabled()
  return FlagOn(self:GetDB(), "requestToast")
end

function PC:SetSettingFlag(key, on)
  if not self:GetDB() then
    self:InitDB()
  end
  local db = self:GetDB()
  if not db then
    return
  end
  db[key] = on and true or false
  if self.RefreshOptionsPanel then
    self:RefreshOptionsPanel()
  end
  if self.RefreshMiniTracker then
    self:RefreshMiniTracker()
  end
  if self.Refresh then
    self:Refresh()
  end
end

function PC:GetMiniDB()
  if not self:GetDB() then
    self:InitDB()
  end
  local db = self:GetDB()
  if not db then
    return nil
  end
  if type(db.mini) ~= "table" then
    NormalizeDB(db)
  end
  return db.mini
end

function PC:SetMiniOption(key, value)
  local mini = self:GetMiniDB()
  if not mini then
    return
  end
  mini[key] = value
  if self.RefreshMiniTracker then
    self:RefreshMiniTracker()
  end
  if self.UpdateMiniVisibility then
    self:UpdateMiniVisibility()
  end
  if self.RefreshOptionsPanel then
    self:RefreshOptionsPanel()
  end
end

function PC:ResetWindowPositions()
  local db = self:GetDB()
  if db then
    if type(db.window) ~= "table" then
      db.window = {}
    end
    db.window.x, db.window.y, db.window.w, db.window.h = nil, nil, nil, nil
    local mini = self:GetMiniDB()
    if mini then
      mini.x, mini.y, mini.w, mini.h = nil, nil, nil, nil
    end
  end
  if self.ResetMainWindowPosition then
    self:ResetMainWindowPosition()
  end
  if self.ResetMiniPosition then
    self:ResetMiniPosition()
  end
  self:Print("Window positions and sizes have been reset.")
end

-- Truncate a FontString to maxWidth using GetStringWidth when available,
-- otherwise a 7px-per-character estimate (matches the headless harness).
function PC:FitFontString(fs, text, maxWidth, wrap, maxLines)
  text = text or ""
  text = tostring(text)
  if fs then
    if fs.SetJustifyH then
      pcall(fs.SetJustifyH, fs, "LEFT")
    end
    fs:SetText(text)
    if wrap then
      if fs.SetWordWrap then
        pcall(fs.SetWordWrap, fs, true)
      end
      if fs.SetMaxLines then
        pcall(fs.SetMaxLines, fs, maxLines or 3)
      end
      if maxWidth and maxWidth > 0 and fs.SetWidth then
        fs:SetWidth(maxWidth)
      end
    else
      if fs.SetWordWrap then
        pcall(fs.SetWordWrap, fs, false)
      end
      if fs.SetMaxLines then
        pcall(fs.SetMaxLines, fs, maxLines or 1)
      end
    end
  end
  local function measure(s)
    if fs and fs.GetStringWidth then
      local ok, w = pcall(fs.GetStringWidth, fs)
      if ok and type(w) == "number" then
        return w
      end
    end
    return #(s or "") * 7
  end
  local fitted = text
  if (not wrap) and maxWidth and maxWidth > 12 and measure(text) > maxWidth then
    local lo, hi, best = 0, #text, "..."
    while lo <= hi do
      local mid = math.floor((lo + hi) / 2)
      local cand = string.sub(text, 1, mid) .. "..."
      if fs then
        fs:SetText(cand)
      end
      if measure(cand) <= maxWidth then
        best = cand
        lo = mid + 1
      else
        hi = mid - 1
      end
    end
    fitted = best
    if fs then
      fs:SetText(fitted)
    end
  end
  if (not wrap) and maxWidth and maxWidth > 0 and fs and fs.SetWidth then
    fs:SetWidth(maxWidth)
  end
  local sw = measure(fitted)
  if self._layoutAudit then
    self._layoutAudit[#self._layoutAudit + 1] = {
      text = fitted,
      maxWidth = maxWidth,
      stringWidth = sw,
      wrap = wrap and true or false,
      overflow = (not wrap) and maxWidth and maxWidth > 0 and sw > (maxWidth + 2),
    }
  end
  return fitted
end

function PC:BeginLayoutAudit()
  self._layoutAudit = {}
end

function PC:GetLayoutAudit()
  return self._layoutAudit or {}
end

-- Walk a frame tree and report FontStrings that extend past their parent.
-- Used by the harness overflow audit at min, default, and large sizes.
function PC:CollectFontStringOverflows(root, slack)
  slack = tonumber(slack) or 3
  root = root or (rawget(_G, "PhilosophersCodexFrame"))
  local hits = {}
  if not root then
    return hits
  end
  local function walk(obj, depth)
    if not obj or (depth or 0) > 16 then
      return
    end
    if obj.IsShown and not obj:IsShown() then
      return
    end
    local kind
    if obj.GetObjectType then
      local ok, got = pcall(obj.GetObjectType, obj)
      if ok then
        kind = got
      end
    end
    if kind == "FontString" and obj.GetRight and obj.GetParent then
      local parent = obj:GetParent()
      if parent and parent.GetRight and parent.GetLeft then
        local okL, oleft = pcall(obj.GetLeft, obj)
        local okR, oright = pcall(obj.GetRight, obj)
        local okPL, pleft = pcall(parent.GetLeft, parent)
        local okPR, pright = pcall(parent.GetRight, parent)
        local sw = 0
        if obj.GetStringWidth then
          local ok, w = pcall(obj.GetStringWidth, obj)
          if ok and type(w) == "number" then
            sw = w
          end
        end
        local wrap = false
        if obj.GetWordWrap then
          local ok, v = pcall(obj.GetWordWrap, obj)
          wrap = ok and v and true or false
        end
        local width = 0
        if obj.GetWidth then
          local ok, w = pcall(obj.GetWidth, obj)
          if ok and type(w) == "number" then
            width = w
          end
        end
        if okL and okR and okPL and okPR and type(oleft) == "number" and type(oright) == "number"
            and type(pleft) == "number" and type(pright) == "number" then
          local parentW = pright - pleft
          local painted = sw
          if wrap and width and width > 0 then
            painted = width
          elseif (not wrap) and sw <= 0 and width and width > 0 then
            painted = width
          end
          -- The painted text overflows when it is wider than its parent panel.
          -- Default FontString widths in the mock (often 40) can extend past a
          -- 28px button even when the glyphs themselves fit, so glyph width wins.
          local overflow = painted > (parentW + slack)
          local visualRight = oright
          if not wrap and sw > 0 then
            visualRight = oleft + sw
          end
          if overflow then
            -- already
          elseif painted > parentW * 0.5 and (visualRight > pright + slack) and (oleft >= pleft - slack) then
            overflow = true
          end
          if overflow then
            local label = ""
            if obj.GetText then
              local ok, t = pcall(obj.GetText, obj)
              if ok then
                label = tostring(t or "")
              end
            end
            hits[#hits + 1] = {
              text = label,
              left = oleft,
              right = visualRight,
              parentLeft = pleft,
              parentRight = pright,
              stringWidth = sw,
              width = width,
              wrap = wrap,
              overflow = true,
            }
          end
        end
      end
    end
    local function eachChild(getter)
      if not getter then
        return
      end
      local ok, packed = pcall(function()
        return { getter(obj) }
      end)
      if not ok or type(packed) ~= "table" then
        return
      end
      for i = 1, #packed do
        if type(packed[i]) == "table" then
          walk(packed[i], (depth or 0) + 1)
        end
      end
    end
    -- Prefer the mock's child lists so we don't lose rows to unpack limits.
    local rawKids = rawget(obj, "_children")
    local rawRegs = rawget(obj, "_textures")
    if type(rawRegs) == "table" then
      for i = 1, #rawRegs do
        if type(rawRegs[i]) == "table" then
          walk(rawRegs[i], (depth or 0) + 1)
        end
      end
    else
      eachChild(obj.GetRegions)
    end
    if type(rawKids) == "table" then
      for i = 1, #rawKids do
        if type(rawKids[i]) == "table" then
          walk(rawKids[i], (depth or 0) + 1)
        end
      end
    else
      eachChild(obj.GetChildren)
    end
  end
  walk(root, 0)
  return hits
end

function PC:ResetAllProgress()
  if not self:GetDB() then
    self:InitDB()
  end
  local db = self:GetDB()
  if not db then
    return
  end
  db.dungeons = {}
  db.gear = {}
  db.milestones = {}
  db.quests = {}
  db.expanded = {}
  db.recentUpgrades = {}
  db.lastBracketKey = nil
  if self.Refresh then
    self:Refresh()
  end
  if self.RefreshMiniTracker then
    self:RefreshMiniTracker()
  end
  self:Print("All progress for this character has been reset. Settings were left as they are.")
end

function PC:GetCurrentBracketLabel()
  local brackets = self:GetCurrentBrackets()
  if #brackets == 0 then
    return nil
  end
  local parts = {}
  for i = 1, #brackets do
    parts[#parts + 1] = brackets[i].heading
  end
  return table.concat(parts, ", ")
end

-- Next recommended action for the Today card: an on-level unfinished
-- dungeon in the current bracket, or a zone to travel to.
function PC:GetNextAction()
  local data = self:GetClassData()
  if not data or (not data.supported and (not data.brackets or #data.brackets == 0)) then
    return {
      kind = "none",
      title = "Class guide coming soon",
      subtitle = (data and data.factionNote) or "A full class guide is not in this version yet. The dungeon route and guild tab still work when a path is available.",
    }
  end
  local level = self:PlayerLevel()
  local brackets = self:GetCurrentBrackets()
  if #brackets == 0 then
    local first = data.brackets and data.brackets[1]
    if first and level < (first.min or 0) then
      local zone = first.zones and first.zones[1]
      return {
        kind = "zone",
        title = zone and ("Travel to " .. zone) or ("Start " .. (first.heading or "the first bracket")),
        subtitle = "Your first written bracket starts at level " .. tostring(first.min),
        waypoint = zone and self:GetZoneWaypoint(zone) or nil,
        zone = zone,
        bracket = first,
      }
    end
    return {
      kind = "none",
      title = "No bracket is written for this level",
      subtitle = "Open Path to review the full route.",
    }
  end

  local function actionForDungeon(d, b, prefix)
    local subParts = {}
    if prefix then
      subParts[#subParts + 1] = prefix
    end
    if d.range then
      subParts[#subParts + 1] = d.range
    end
    if b and b.heading then
      subParts[#subParts + 1] = b.heading
    end
    return {
      kind = "dungeon",
      title = d.name,
      subtitle = table.concat(subParts, "  ·  "),
      waypoint = self:GetEntranceWaypoint(d.id),
      dungeon = d,
      bracket = b,
    }
  end

  local onLevel, later = {}, {}
  for i = 1, #brackets do
    local b = brackets[i]
    local dungeons = b.dungeons or {}
    for j = 1, #dungeons do
      local d = dungeons[j]
      if not d.skipped and not self:IsDungeonChecked(d.id) then
        local rmin, rmax = self:ParseLevelRange(d.range)
        if rmin and level >= rmin and level <= rmax then
          onLevel[#onLevel + 1] = actionForDungeon(d, b, "On-level dungeon")
        else
          later[#later + 1] = actionForDungeon(d, b, nil)
        end
      end
    end
  end
  if onLevel[1] then
    return onLevel[1]
  end

  local inZone, zoneName = self:IsInRecommendedZone(true)
  if not inZone then
    local b = brackets[1]
    local zone = b.zones and b.zones[1]
    return {
      kind = "zone",
      title = zone and ("Travel to " .. zone) or "Move to a recommended zone",
      subtitle = (b.heading or "Current bracket") .. (zoneName and ("  ·  you are in " .. zoneName) or ""),
      waypoint = zone and self:GetZoneWaypoint(zone) or nil,
      zone = zone,
      bracket = b,
    }
  end

  if later[1] then
    return later[1]
  end

  local last = brackets[#brackets]
  local nextB
  for i = 1, #(data.brackets or {}) do
    if data.brackets[i] == last or (last and data.brackets[i].id == last.id) then
      nextB = data.brackets[i + 1]
      break
    end
  end
  if nextB then
    local dungeons = nextB.dungeons or {}
    for j = 1, #dungeons do
      local d = dungeons[j]
      if not d.skipped and not self:IsDungeonChecked(d.id) then
        return actionForDungeon(d, nextB, "Coming up")
      end
    end
    local zone = nextB.zones and nextB.zones[1]
    return {
      kind = "zone",
      title = zone and ("Travel to " .. zone) or ("Start " .. (nextB.heading or "the next bracket")),
      subtitle = nextB.heading,
      waypoint = zone and self:GetZoneWaypoint(zone) or nil,
      zone = zone,
      bracket = nextB,
    }
  end

  return {
    kind = "done",
    title = "You're all caught up",
    subtitle = "Every listed dungeon on your current path is checked.",
  }
end

function PC:ApplyWindowScale(scale)
  scale = tonumber(scale)
  if not scale then
    return nil
  end
  if scale < 0.8 then
    scale = 0.8
  end
  if scale > 1.4 then
    scale = 1.4
  end
  local db = self:GetDB()
  if db then
    if type(db.window) ~= "table" then
      db.window = {}
    end
    db.window.scale = scale
  end
  if self.SetUIScale then
    self:SetUIScale(scale)
  end
  return scale
end

-- ---------------------------------------------------------------------------
-- Gear, milestones, and progress counts
-- ---------------------------------------------------------------------------

function PC:IsGearChecked(id)
  local st = self:GetDB().gear[id]
  return st and st.checked and true or false
end

function PC:SetGearChecked(id, checked)
  local st = EnsureEntry(self:GetDB().gear, id)
  st.checked = checked and true or false
  st.unchecked = not st.checked
  st.auto = nil
  if PC.Refresh then
    PC:Refresh()
  end
end

function PC:ScanGear()
  local data = self:GetClassData()
  if not data then
    return
  end
  local db = self:GetDB()
  local changed = false
  for i = 1, #data.gear do
    local item = data.gear[i]
    local has = self:PlayerHasGearItem(item)
    local st = EnsureEntry(db.gear, item.id)
    if has and not st.unchecked and not st.checked then
      st.checked = true
      st.auto = true
      changed = true
    end
  end
  if changed and PC.Refresh then
    PC:Refresh()
  end
end

function PC:IsMilestoneChecked(id)
  local st = self:GetDB().milestones[id]
  return st and st.checked and true or false
end

function PC:SetMilestoneChecked(id, checked)
  local st = EnsureEntry(self:GetDB().milestones, id)
  st.checked = checked and true or false
  st.unchecked = not st.checked
  st.auto = nil
  if PC.Refresh then
    PC:Refresh()
  end
end

function PC:ScanMilestones()
  local data = self:GetClassData()
  if not data then
    return
  end
  local db = self:GetDB()
  local changed = false
  for i = 1, #data.milestones do
    local m = data.milestones[i]
    local st = EnsureEntry(db.milestones, m.id)
    if not st.unchecked then
      local should = false
      if m.spellName and self:PlayerKnowsSpell(m.spellName) then
        should = true
      end
      if should and not st.checked then
        st.checked = true
        st.auto = true
        changed = true
      end
    end
  end
  if changed and PC.Refresh then
    PC:Refresh()
  end
end

function PC:MilestoneLevelReached(milestone)
  return milestone.level and self:PlayerLevel() >= milestone.level
end

function PC:CountChecked(items, isChecked)
  local done, total = 0, items and #items or 0
  for i = 1, total do
    if isChecked(items[i]) then
      done = done + 1
    end
  end
  return done, total
end

function PC:OverallProgress()
  local data = self:GetClassData()
  if not data then
    return 0, 0
  end
  local done, total = 0, 0
  local dungeons = self:GetAllDungeons()
  local d, t = self:CountChecked(dungeons, function(dungeon)
    return self:IsDungeonChecked(dungeon.id)
  end)
  done = done + d
  total = total + t
  d, t = self:CountChecked(data.gear, function(item)
    return self:IsGearChecked(item.id)
  end)
  done = done + d
  total = total + t
  d, t = self:CountChecked(data.milestones, function(m)
    return self:IsMilestoneChecked(m.id)
  end)
  done = done + d
  total = total + t
  return done, total
end

-- ---------------------------------------------------------------------------
-- Instance visit + bracket alerts
-- ---------------------------------------------------------------------------

function PC:CheckInstanceVisit()
  if not GetInstanceInfo then
    return
  end
  local name, instanceType = GetInstanceInfo()
  if instanceType ~= "party" and instanceType ~= "raid" then
    return
  end
  local matches = self:FindDungeonsByInstanceName(name)
  for i = 1, #matches do
    local dungeon = matches[i]
    local already = self:IsDungeonVisited(dungeon.id)
    self:MarkDungeonVisited(dungeon.id)
    if not already then
      self:Print("The Codex records your visit to " .. dungeon.name .. ". It is marked on The Path.")
    end
    if self.OnEnteredDungeon then
      self:OnEnteredDungeon(dungeon)
    end
  end
end

function PC:CheckBracketChange(fromLevelUp)
  local brackets = self:GetCurrentBrackets()
  local key = self:BracketKey(brackets)
  local db = self:GetDB()
  local previous = db.lastBracketKey
  db.lastBracketKey = key
  if fromLevelUp and key ~= "" and key ~= previous and db.bracketAlerts ~= false then
    local newest = brackets[#brackets]
    if newest and newest.alert then
      self:Reveal(newest.alert)
    elseif newest then
      self:Reveal("time to move to " .. newest.heading .. ".")
    end
  end
  -- Login/zone/level broadcasts are handled by the share module. Only
  -- announce here when the bracket actually changed, so we do not send
  -- immediately at login (sharing waits a few seconds) or double-fire.
  if key ~= previous and self.BroadcastStatus then
    self:BroadcastStatus()
  end
end

-- ---------------------------------------------------------------------------
-- First-load defaults for this character
-- ---------------------------------------------------------------------------

function PC:ApplyFirstLoadDefaults()
  local db = self:GetDB()
  if not db then
    self:InitDB()
    db = self:GetDB()
  end
  if not db or db.initialized then
    return
  end
  db.initialized = true
  local data = self:GetClassData()
  if not data then
    return
  end
  -- First load only (initialized was false). Existing characters skip this function.
  if data.defaultProfile then
    db.upgradeProfile = data.defaultProfile
  end
  if data.defaultRole then
    db.guildRole = data.defaultRole
  end
  local minDone = data.startingDoneMinLevel or 1
  if data.startingDone and self:PlayerLevel() >= minDone then
    for i = 1, #data.startingDone do
      local id = data.startingDone[i]
      local st = EnsureEntry(db.dungeons, id)
      st.checked = true
    end
  end
end

-- ---------------------------------------------------------------------------
-- Events
-- ---------------------------------------------------------------------------

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("PLAYER_LEVEL_UP")
eventFrame:RegisterEvent("ZONE_CHANGED")
eventFrame:RegisterEvent("ZONE_CHANGED_INDOORS")
eventFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
eventFrame:RegisterEvent("BAG_UPDATE_DELAYED")
eventFrame:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
eventFrame:RegisterEvent("QUEST_LOG_UPDATE")
eventFrame:RegisterEvent("QUEST_TURNED_IN")
eventFrame:RegisterEvent("QUEST_ACCEPTED")
eventFrame:RegisterEvent("QUEST_REMOVED")
eventFrame:RegisterEvent("PLAYER_XP_UPDATE")

local bagPending = false
local questPending = false

local function OnCoreEvent(self, event, arg1, arg2, ...)
  if event == "ADDON_LOADED" then
    if arg1 == ADDON_NAME then
      PC:InitDB()
      if PC.InitLog then
        PC:InitLog()
      end
    end
    return
  end

  if event == "PLAYER_LOGIN" then
    local function loginWork()
      PC:ApplyFirstLoadDefaults()
      if PC.SafeCreateUI then
        PC:SafeCreateUI()
      elseif PC.CreateUI then
        PC:CreateUI()
      end
      PC:ScanGear()
      PC:ScanMilestones()
      PC:CheckBracketChange(false)
      if PC.InstallTooltipHook then
        PC:InstallTooltipHook()
      end
      if PC.AuditMissingData then
        PC:AuditMissingData()
      end
      if PC.CheckKnownLatest then
        PC:CheckKnownLatest()
      end
      if PC.StartSession then
        PC:StartSession()
      end
      -- 1.22.0: first-run welcome, a few seconds after login.
      if PC.ShowWelcome then
        if C_Timer and C_Timer.After then
          C_Timer.After(4, function()
            pcall(PC.ShowWelcome, PC, false)
          end)
        else
          pcall(PC.ShowWelcome, PC, false)
        end
      end
    end
    if PC.SafeCall then
      PC:SafeCall("PLAYER_LOGIN", loginWork)
    else
      local ok, err = pcall(loginWork)
      if not ok then
        PC:ReportError(err)
      end
    end
    if PC.didMigrate then
      PC:Print("The Codex has inherited your ForeverGuide notes for this character.")
    end
    PC:Print("Bound to this character. Type |cffffffff/codex|r to open the tome.")
    return
  end

  if event == "PLAYER_ENTERING_WORLD" then
    if PC.SyncLiveActivityZone then
      PC:SyncLiveActivityZone(event)
    end
    if PC.EnsureSession then
      PC:EnsureSession()
    end
    if PC.NoteSessionXP then
      PC:NoteSessionXP()
    end
    PC:CheckInstanceVisit()
    PC:ScanGear()
    PC:ScanMilestones()
    if PC.Refresh then
      PC:Refresh()
    end
    return
  end

  if event == "PLAYER_LEVEL_UP" then
    -- UnitLevel can still report the old level during this event.
    local function afterLevel()
      if PC.NoteSessionXP then
        PC:NoteSessionXP()
      end
      PC:CheckBracketChange(true)
      PC:ScanMilestones()
      if PC.Refresh then
        PC:Refresh()
      end
    end
    if C_Timer and C_Timer.After then
      C_Timer.After(0.5, afterLevel)
    else
      afterLevel()
    end
    return
  end

  if event == "PLAYER_XP_UPDATE" then
    if PC.NoteSessionXP then
      PC:NoteSessionXP()
    end
    if PC.RefreshMiniTracker then
      pcall(PC.RefreshMiniTracker, PC)
    end
    return
  end

  if event == "ZONE_CHANGED" or event == "ZONE_CHANGED_INDOORS" or event == "ZONE_CHANGED_NEW_AREA" then
    if PC.SyncLiveActivityZone then
      PC:SyncLiveActivityZone(event)
    end
    PC:CheckInstanceVisit()
    if PC.Refresh then
      PC:Refresh()
    end
    return
  end

  if event == "QUEST_LOG_UPDATE" or event == "QUEST_TURNED_IN" or event == "QUEST_ACCEPTED" or event == "QUEST_REMOVED" then
    if PC.NoteSectionCardDirty then
      PC:NoteSectionCardDirty()
    end
    if PC.OnZoneQuestEvent then
      PC:OnZoneQuestEvent(event, arg1, arg2)
    elseif PC.InvalidateQuestCache then
      PC:InvalidateQuestCache()
    end
    if questPending then
      return
    end
    questPending = true
    local function run()
      questPending = false
      if PC.Refresh then
        PC:Refresh()
      end
    end
    if C_Timer and C_Timer.After then
      C_Timer.After(0.2, run)
    else
      run()
    end
    return
  end

  if event == "BAG_UPDATE_DELAYED" or event == "PLAYER_EQUIPMENT_CHANGED" then
    if PC.NoteSectionCardDirty then
      PC:NoteSectionCardDirty()
    end
    if bagPending then
      return
    end
    bagPending = true
    local function run()
      bagPending = false
      PC:ScanGear()
      if PC.Refresh then
        PC:Refresh()
      end
    end
    if C_Timer and C_Timer.After then
      C_Timer.After(0.15, run)
    else
      run()
    end
  end
end

eventFrame:SetScript("OnEvent", function(...)
  if PC.SafeCall then
    return PC:SafeCall("OnEvent", OnCoreEvent, ...)
  end
  return OnCoreEvent(...)
end)

-- Slash commands are registered early, immediately after PC:Print.
